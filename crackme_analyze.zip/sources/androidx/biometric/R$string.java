package androidx.biometric;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int abc_action_bar_home_description = 2131820547;
    public static int abc_action_bar_up_description = 2131820548;
    public static int abc_action_menu_overflow_description = 2131820549;
    public static int abc_action_mode_done = 2131820550;
    public static int abc_activity_chooser_view_see_all = 2131820551;
    public static int abc_activitychooserview_choose_application = 2131820552;
    public static int abc_capital_off = 2131820553;
    public static int abc_capital_on = 2131820554;
    public static int abc_menu_alt_shortcut_label = 2131820555;
    public static int abc_menu_ctrl_shortcut_label = 2131820556;
    public static int abc_menu_delete_shortcut_label = 2131820557;
    public static int abc_menu_enter_shortcut_label = 2131820558;
    public static int abc_menu_function_shortcut_label = 2131820559;
    public static int abc_menu_meta_shortcut_label = 2131820560;
    public static int abc_menu_shift_shortcut_label = 2131820561;
    public static int abc_menu_space_shortcut_label = 2131820562;
    public static int abc_menu_sym_shortcut_label = 2131820563;
    public static int abc_prepend_shortcut_label = 2131820564;
    public static int abc_search_hint = 2131820565;
    public static int abc_searchview_description_clear = 2131820566;
    public static int abc_searchview_description_query = 2131820567;
    public static int abc_searchview_description_search = 2131820568;
    public static int abc_searchview_description_submit = 2131820569;
    public static int abc_searchview_description_voice = 2131820570;
    public static int abc_shareactionprovider_share_with = 2131820571;
    public static int abc_shareactionprovider_share_with_application = 2131820572;
    public static int abc_toolbar_collapse_description = 2131820573;
    public static int confirm_device_credential_password = 2131820625;
    public static int default_error_msg = 2131820629;
    public static int fingerprint_dialog_touch_sensor = 2131820645;
    public static int fingerprint_error_hw_not_available = 2131820646;
    public static int fingerprint_error_hw_not_present = 2131820647;
    public static int fingerprint_error_lockout = 2131820648;
    public static int fingerprint_error_no_fingerprints = 2131820649;
    public static int fingerprint_error_user_canceled = 2131820650;
    public static int fingerprint_not_recognized = 2131820651;
    public static int generic_error_no_device_credential = 2131820654;
    public static int generic_error_no_keyguard = 2131820655;
    public static int generic_error_user_canceled = 2131820656;
    public static int search_menu_title = 2131820987;
    public static int status_bar_notification_info_overflow = 2131820998;

    private R$string() {
    }
}

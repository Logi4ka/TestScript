package androidx.asynclayoutinflater;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int action_container = 2131296318;
    public static int action_divider = 2131296320;
    public static int action_image = 2131296323;
    public static int action_text = 2131296331;
    public static int actions = 2131296332;
    public static int async = 2131296354;
    public static int blocking = 2131296366;
    public static int chronometer = 2131296394;
    public static int forever = 2131296492;
    public static int icon = 2131296528;
    public static int icon_group = 2131296530;
    public static int info = 2131296539;
    public static int italic = 2131296546;
    public static int line1 = 2131296556;
    public static int line3 = 2131296557;
    public static int normal = 2131296640;
    public static int notification_background = 2131296642;
    public static int notification_main_column = 2131296643;
    public static int notification_main_column_container = 2131296644;
    public static int right_icon = 2131296697;
    public static int right_side = 2131296698;
    public static int tag_transition_group = 2131296796;
    public static int tag_unhandled_key_event_manager = 2131296797;
    public static int tag_unhandled_key_listeners = 2131296798;
    public static int text = 2131296800;
    public static int text2 = 2131296801;
    public static int time = 2131296816;
    public static int title = 2131296821;

    private R$id() {
    }
}

package androidx.dynamicanimation;

/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static int alpha = 2130968633;
    public static int font = 2130969144;
    public static int fontProviderAuthority = 2130969146;
    public static int fontProviderCerts = 2130969147;
    public static int fontProviderFetchStrategy = 2130969149;
    public static int fontProviderFetchTimeout = 2130969150;
    public static int fontProviderPackage = 2130969151;
    public static int fontProviderQuery = 2130969152;
    public static int fontStyle = 2130969154;
    public static int fontVariationSettings = 2130969155;
    public static int fontWeight = 2130969156;
    public static int ttcIndex = 2130969958;

    private R$attr() {
    }
}

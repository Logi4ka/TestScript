package androidx.customview;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int accessibility_action_clickable_span = 2131296273;
    public static int accessibility_custom_action_0 = 2131296274;
    public static int accessibility_custom_action_1 = 2131296275;
    public static int accessibility_custom_action_10 = 2131296276;
    public static int accessibility_custom_action_11 = 2131296277;
    public static int accessibility_custom_action_12 = 2131296278;
    public static int accessibility_custom_action_13 = 2131296279;
    public static int accessibility_custom_action_14 = 2131296280;
    public static int accessibility_custom_action_15 = 2131296281;
    public static int accessibility_custom_action_16 = 2131296282;
    public static int accessibility_custom_action_17 = 2131296283;
    public static int accessibility_custom_action_18 = 2131296284;
    public static int accessibility_custom_action_19 = 2131296285;
    public static int accessibility_custom_action_2 = 2131296286;
    public static int accessibility_custom_action_20 = 2131296287;
    public static int accessibility_custom_action_21 = 2131296288;
    public static int accessibility_custom_action_22 = 2131296289;
    public static int accessibility_custom_action_23 = 2131296290;
    public static int accessibility_custom_action_24 = 2131296291;
    public static int accessibility_custom_action_25 = 2131296292;
    public static int accessibility_custom_action_26 = 2131296293;
    public static int accessibility_custom_action_27 = 2131296294;
    public static int accessibility_custom_action_28 = 2131296295;
    public static int accessibility_custom_action_29 = 2131296296;
    public static int accessibility_custom_action_3 = 2131296297;
    public static int accessibility_custom_action_30 = 2131296298;
    public static int accessibility_custom_action_31 = 2131296299;
    public static int accessibility_custom_action_4 = 2131296300;
    public static int accessibility_custom_action_5 = 2131296301;
    public static int accessibility_custom_action_6 = 2131296302;
    public static int accessibility_custom_action_7 = 2131296303;
    public static int accessibility_custom_action_8 = 2131296304;
    public static int accessibility_custom_action_9 = 2131296305;
    public static int action_container = 2131296318;
    public static int action_divider = 2131296320;
    public static int action_image = 2131296323;
    public static int action_text = 2131296331;
    public static int actions = 2131296332;
    public static int async = 2131296354;
    public static int blocking = 2131296366;
    public static int chronometer = 2131296394;
    public static int dialog_button = 2131296438;
    public static int forever = 2131296492;
    public static int icon = 2131296528;
    public static int icon_group = 2131296530;
    public static int info = 2131296539;
    public static int italic = 2131296546;
    public static int line1 = 2131296556;
    public static int line3 = 2131296557;
    public static int normal = 2131296640;
    public static int notification_background = 2131296642;
    public static int notification_main_column = 2131296643;
    public static int notification_main_column_container = 2131296644;
    public static int right_icon = 2131296697;
    public static int right_side = 2131296698;
    public static int tag_accessibility_actions = 2131296787;
    public static int tag_accessibility_clickable_spans = 2131296788;
    public static int tag_accessibility_heading = 2131296789;
    public static int tag_accessibility_pane_title = 2131296790;
    public static int tag_screen_reader_focusable = 2131296794;
    public static int tag_transition_group = 2131296796;
    public static int tag_unhandled_key_event_manager = 2131296797;
    public static int tag_unhandled_key_listeners = 2131296798;
    public static int text = 2131296800;
    public static int text2 = 2131296801;
    public static int time = 2131296816;
    public static int title = 2131296821;

    private R$id() {
    }
}

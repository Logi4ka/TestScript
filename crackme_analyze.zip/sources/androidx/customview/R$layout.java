package androidx.customview;

/* JADX INFO: loaded from: classes.dex */
public final class R$layout {
    public static int custom_dialog = 2131492896;
    public static int notification_action = 2131492976;
    public static int notification_action_tombstone = 2131492977;
    public static int notification_template_custom_big = 2131492984;
    public static int notification_template_icon_group = 2131492985;
    public static int notification_template_part_chronometer = 2131492989;
    public static int notification_template_part_time = 2131492990;

    private R$layout() {
    }
}

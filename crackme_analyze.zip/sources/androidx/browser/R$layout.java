package androidx.browser;

/* JADX INFO: loaded from: classes.dex */
public final class R$layout {
    public static int browser_actions_context_menu_page = 2131492893;
    public static int browser_actions_context_menu_row = 2131492894;

    private R$layout() {
    }
}

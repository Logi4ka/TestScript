package androidx.browser;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int copy_toast_msg = 2131820627;
    public static int fallback_menu_item_copy_link = 2131820641;
    public static int fallback_menu_item_open_in_browser = 2131820642;
    public static int fallback_menu_item_share_link = 2131820643;

    private R$string() {
    }
}

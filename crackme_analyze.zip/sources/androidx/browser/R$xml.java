package androidx.browser;

/* JADX INFO: loaded from: classes.dex */
public final class R$xml {
    public static int image_share_filepaths = 2132017157;

    private R$xml() {
    }
}

package androidx.browser;

/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static int browser_actions_bg_grey = 2131099689;
    public static int browser_actions_divider_color = 2131099690;
    public static int browser_actions_text_color = 2131099691;
    public static int browser_actions_title_color = 2131099692;

    private R$color() {
    }
}

package androidx.browser;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int browser_actions_header_text = 2131296373;
    public static int browser_actions_menu_item_icon = 2131296374;
    public static int browser_actions_menu_item_text = 2131296375;
    public static int browser_actions_menu_items = 2131296376;
    public static int browser_actions_menu_view = 2131296377;

    private R$id() {
    }
}

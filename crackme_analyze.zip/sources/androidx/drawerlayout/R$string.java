package androidx.drawerlayout;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int status_bar_notification_info_overflow = 2131820998;

    private R$string() {
    }
}

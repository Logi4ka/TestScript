package androidx.drawerlayout.widget;

import android.view.View;
import androidx.drawerlayout.widget.DrawerLayout;
import defpackage.lg;
import defpackage.q26;
import defpackage.wc7;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b extends q26 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f332a;
    public wc7 b;
    public final lg c = new lg(this, 5);
    public final /* synthetic */ DrawerLayout d;

    public b(DrawerLayout drawerLayout, int i) {
        this.d = drawerLayout;
        this.f332a = i;
    }

    @Override // defpackage.q26
    public final int b(int i, View view) {
        DrawerLayout drawerLayout = this.d;
        if (drawerLayout.a(3, view)) {
            return Math.max(-view.getWidth(), Math.min(i, 0));
        }
        int width = drawerLayout.getWidth();
        return Math.max(width - view.getWidth(), Math.min(i, width));
    }

    @Override // defpackage.q26
    public final int c(int i, View view) {
        return view.getTop();
    }

    @Override // defpackage.q26
    public final int g(View view) {
        if (DrawerLayout.j(view)) {
            return view.getWidth();
        }
        return 0;
    }

    @Override // defpackage.q26
    public final void k(int i, int i2) {
        int i3 = i & 1;
        DrawerLayout drawerLayout = this.d;
        View viewD = i3 == 1 ? drawerLayout.d(3) : drawerLayout.d(5);
        if (viewD == null || drawerLayout.f(viewD) != 0) {
            return;
        }
        this.b.c(i2, viewD);
    }

    @Override // defpackage.q26
    public final void l(int i) {
        this.d.postDelayed(this.c, 160L);
    }

    @Override // defpackage.q26
    public final void m(int i, View view) {
        ((DrawerLayout.LayoutParams) view.getLayoutParams()).c = false;
        int i2 = this.f332a == 3 ? 5 : 3;
        DrawerLayout drawerLayout = this.d;
        View viewD = drawerLayout.d(i2);
        if (viewD != null) {
            drawerLayout.b(viewD, true);
        }
    }

    @Override // defpackage.q26
    public final void n(int i) {
        this.d.p(i, this.b.t);
    }

    @Override // defpackage.q26
    public final void o(View view, int i, int i2) {
        int width = view.getWidth();
        DrawerLayout drawerLayout = this.d;
        float width2 = (drawerLayout.a(3, view) ? i + width : drawerLayout.getWidth() - i) / width;
        drawerLayout.m(view, width2);
        view.setVisibility(width2 == 0.0f ? 4 : 0);
        drawerLayout.invalidate();
    }

    @Override // defpackage.q26
    public final void p(View view, float f, float f2) {
        int i;
        int[] iArr = DrawerLayout.u0;
        float f3 = ((DrawerLayout.LayoutParams) view.getLayoutParams()).b;
        int width = view.getWidth();
        DrawerLayout drawerLayout = this.d;
        if (drawerLayout.a(3, view)) {
            i = (f > 0.0f || (f == 0.0f && f3 > 0.5f)) ? 0 : -width;
        } else {
            int width2 = drawerLayout.getWidth();
            if (f < 0.0f || (f == 0.0f && f3 > 0.5f)) {
                width2 -= width;
            }
            i = width2;
        }
        this.b.s(i, view.getTop());
        drawerLayout.invalidate();
    }

    @Override // defpackage.q26
    public final boolean r(int i, View view) {
        if (!DrawerLayout.j(view)) {
            return false;
        }
        int i2 = this.f332a;
        DrawerLayout drawerLayout = this.d;
        return drawerLayout.a(i2, view) && drawerLayout.f(view) == 0;
    }
}

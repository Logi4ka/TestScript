package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;
import androidx.constraintlayout.widget.d;
import androidx.core.widget.NestedScrollView;
import defpackage.aa3;
import defpackage.aa4;
import defpackage.bc4;
import defpackage.cz0;
import defpackage.df7;
import defpackage.dz0;
import defpackage.ef7;
import defpackage.ej2;
import defpackage.ez0;
import defpackage.fa4;
import defpackage.g9;
import defpackage.ha4;
import defpackage.hb3;
import defpackage.ia4;
import defpackage.ja4;
import defpackage.ka4;
import defpackage.la4;
import defpackage.lg;
import defpackage.lz0;
import defpackage.ma4;
import defpackage.mz0;
import defpackage.n76;
import defpackage.na4;
import defpackage.nt;
import defpackage.o96;
import defpackage.oh1;
import defpackage.p01;
import defpackage.pa4;
import defpackage.pf4;
import defpackage.po1;
import defpackage.q30;
import defpackage.qa4;
import defpackage.qe0;
import defpackage.ra4;
import defpackage.rk5;
import defpackage.ue7;
import defpackage.zd7;
import defpackage.zn6;
import io.sentry.android.core.o0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class MotionLayout extends ConstraintLayout implements pf4 {
    public static boolean u1;
    public boolean A0;
    public la4 B0;
    public int C0;
    public ia4 D0;
    public boolean E0;
    public final n76 F0;
    public final ha4 G0;
    public po1 H0;
    public int I0;
    public int J0;
    public boolean K0;
    public float L0;
    public float M0;
    public long N0;
    public float O0;
    public boolean P0;
    public ArrayList Q0;
    public ArrayList R0;
    public ArrayList S0;
    public CopyOnWriteArrayList T0;
    public int U0;
    public long V0;
    public float W0;
    public int X0;
    public float Y0;
    public boolean Z0;
    public int a1;
    public int b1;
    public int c1;
    public int d1;
    public int e1;
    public int f1;
    public float g1;
    public final aa3 h1;
    public ra4 i0;
    public boolean i1;
    public fa4 j0;
    public ka4 j1;
    public Interpolator k0;
    public ej2 k1;
    public float l0;
    public final Rect l1;
    public int m0;
    public boolean m1;
    public int n0;
    public ma4 n1;
    public int o0;
    public final ja4 o1;
    public int p0;
    public boolean p1;
    public int q0;
    public final RectF q1;
    public boolean r0;
    public View r1;
    public final HashMap s0;
    public Matrix s1;
    public long t0;
    public final ArrayList t1;
    public float u0;
    public float v0;
    public float w0;
    public long x0;
    public float y0;
    public boolean z0;

    public MotionLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.k0 = null;
        this.l0 = 0.0f;
        this.m0 = -1;
        this.n0 = -1;
        this.o0 = -1;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = true;
        this.s0 = new HashMap();
        this.t0 = 0L;
        this.u0 = 1.0f;
        this.v0 = 0.0f;
        this.w0 = 0.0f;
        this.y0 = 0.0f;
        this.A0 = false;
        this.C0 = 0;
        this.E0 = false;
        this.F0 = new n76();
        this.G0 = new ha4(this);
        this.K0 = false;
        this.P0 = false;
        this.Q0 = null;
        this.R0 = null;
        this.S0 = null;
        this.T0 = null;
        this.U0 = 0;
        this.V0 = -1L;
        this.W0 = 0.0f;
        this.X0 = 0;
        this.Y0 = 0.0f;
        this.Z0 = false;
        this.h1 = new aa3(0);
        this.i1 = false;
        this.k1 = null;
        new HashMap();
        this.l1 = new Rect();
        this.m1 = false;
        this.n1 = ma4.f4115a;
        this.o1 = new ja4(this);
        this.p1 = false;
        this.q1 = new RectF();
        this.r1 = null;
        this.s1 = null;
        this.t1 = new ArrayList();
        t(attributeSet);
    }

    public static Rect k(MotionLayout motionLayout, lz0 lz0Var) {
        Rect rect = motionLayout.l1;
        rect.top = lz0Var.t();
        rect.left = lz0Var.s();
        rect.right = lz0Var.r() + rect.left;
        rect.bottom = lz0Var.l() + rect.top;
        return rect;
    }

    public final void A(int i, d dVar) {
        ra4 ra4Var = this.i0;
        if (ra4Var != null) {
            ra4Var.g.put(i, dVar);
        }
        this.o1.e(this.i0.b(this.m0), this.i0.b(this.o0));
        w();
        if (this.n0 == i) {
            dVar.b(this);
        }
    }

    public final void B(int i, View... viewArr) {
        ra4 ra4Var = this.i0;
        if (ra4Var == null) {
            o0.d("MotionLayout", " no motionScene");
            return;
        }
        rk5 rk5Var = ra4Var.q;
        String str = (String) rk5Var.d;
        ArrayList arrayList = new ArrayList();
        ef7 ef7Var = null;
        for (ef7 ef7Var2 : (ArrayList) rk5Var.b) {
            if (ef7Var2.f1936a == i) {
                for (View view : viewArr) {
                    if (ef7Var2.b(view)) {
                        arrayList.add(view);
                    }
                }
                if (arrayList.isEmpty()) {
                    ef7Var = ef7Var2;
                } else {
                    View[] viewArr2 = (View[]) arrayList.toArray(new View[0]);
                    MotionLayout motionLayout = (MotionLayout) rk5Var.f5249a;
                    int currentState = motionLayout.getCurrentState();
                    if (ef7Var2.e != 2) {
                        if (currentState == -1) {
                            o0.q(str, "No support for ViewTransition within transition yet. Currently: ".concat(motionLayout.toString()));
                        } else {
                            ra4 ra4Var2 = motionLayout.i0;
                            d dVarB = ra4Var2 == null ? null : ra4Var2.b(currentState);
                            if (dVarB != null) {
                                ef7Var = ef7Var2;
                                ef7Var.a(rk5Var, (MotionLayout) rk5Var.f5249a, currentState, dVarB, viewArr2);
                            }
                        }
                        ef7Var = ef7Var2;
                    } else {
                        ef7Var = ef7Var2;
                        ef7Var.a(rk5Var, (MotionLayout) rk5Var.f5249a, currentState, null, viewArr2);
                    }
                    arrayList.clear();
                }
            }
        }
        if (ef7Var == null) {
            o0.d(str, " Could not find ViewTransition");
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        ArrayList arrayList;
        int i;
        int i2;
        ia4 ia4Var;
        int i3;
        Paint paint;
        Paint paint2;
        int i4;
        aa4 aa4Var;
        ia4 ia4Var2;
        int i5;
        Paint paint3;
        float fMin;
        Paint paint4;
        int i6;
        double dA;
        Paint paint5;
        float f;
        String resourceEntryName;
        rk5 rk5Var;
        ArrayList arrayList2 = this.S0;
        if (arrayList2 != null) {
            Iterator it = arrayList2.iterator();
            while (it.hasNext()) {
                ((MotionHelper) it.next()).getClass();
            }
        }
        n(false);
        ra4 ra4Var = this.i0;
        if (ra4Var != null && (rk5Var = ra4Var.q) != null) {
            ArrayList arrayList3 = (ArrayList) rk5Var.f;
            ArrayList arrayList4 = (ArrayList) rk5Var.e;
            if (arrayList4 != null) {
                Iterator it2 = arrayList4.iterator();
                while (it2.hasNext()) {
                    ((df7) it2.next()).a();
                }
                ((ArrayList) rk5Var.e).removeAll(arrayList3);
                arrayList3.clear();
                if (((ArrayList) rk5Var.e).isEmpty()) {
                    rk5Var.e = null;
                }
            }
        }
        super.dispatchDraw(canvas);
        if (this.i0 == null) {
            return;
        }
        if ((this.C0 & 1) == 1 && !isInEditMode()) {
            this.U0++;
            long nanoTime = getNanoTime();
            long j = this.V0;
            if (j != -1) {
                if (nanoTime - j > 200000000) {
                    this.W0 = ((int) ((this.U0 / (r10 * 1.0E-9f)) * 100.0f)) / 100.0f;
                    this.U0 = 0;
                    this.V0 = nanoTime;
                }
            } else {
                this.V0 = nanoTime;
            }
            Paint paint6 = new Paint();
            paint6.setTextSize(42.0f);
            float progress = ((int) (getProgress() * 1000.0f)) / 10.0f;
            StringBuilder sb = new StringBuilder();
            sb.append(this.W0);
            sb.append(" fps ");
            int i7 = this.m0;
            StringBuilder sbO = bc4.o(oh1.p(sb, i7 == -1 ? "UNDEFINED" : getContext().getResources().getResourceEntryName(i7), " -> "));
            int i8 = this.o0;
            sbO.append(i8 == -1 ? "UNDEFINED" : getContext().getResources().getResourceEntryName(i8));
            sbO.append(" (progress: ");
            sbO.append(progress);
            sbO.append(" ) state=");
            int i9 = this.n0;
            if (i9 == -1) {
                resourceEntryName = "undefined";
            } else {
                resourceEntryName = i9 != -1 ? getContext().getResources().getResourceEntryName(i9) : "UNDEFINED";
            }
            sbO.append(resourceEntryName);
            String string = sbO.toString();
            paint6.setColor(-16777216);
            canvas.drawText(string, 11.0f, getHeight() - 29, paint6);
            paint6.setColor(-7864184);
            canvas.drawText(string, 10.0f, getHeight() - 30, paint6);
        }
        if (this.C0 > 1) {
            if (this.D0 == null) {
                this.D0 = new ia4(this);
            }
            ia4 ia4Var3 = this.D0;
            int iC = this.i0.c();
            int i10 = this.C0;
            Paint paint7 = ia4Var3.g;
            Paint paint8 = ia4Var3.f;
            Paint paint9 = ia4Var3.i;
            int i11 = ia4Var3.m;
            Paint paint10 = ia4Var3.e;
            MotionLayout motionLayout = ia4Var3.n;
            HashMap map = this.s0;
            if (map != null && map.size() != 0) {
                canvas.save();
                if (!motionLayout.isInEditMode() && (i10 & 1) == 2) {
                    String str = motionLayout.getContext().getResources().getResourceName(motionLayout.o0) + ":" + motionLayout.getProgress();
                    canvas.drawText(str, 10.0f, motionLayout.getHeight() - 30, ia4Var3.h);
                    canvas.drawText(str, 11.0f, motionLayout.getHeight() - 29, paint10);
                }
                Iterator it3 = map.values().iterator();
                while (it3.hasNext()) {
                    aa4 aa4Var2 = (aa4) it3.next();
                    na4 na4Var = aa4Var2.f;
                    ArrayList arrayList5 = aa4Var2.u;
                    int iMax = na4Var.b;
                    Iterator it4 = arrayList5.iterator();
                    while (it4.hasNext()) {
                        iMax = Math.max(iMax, ((na4) it4.next()).b);
                        it3 = it3;
                    }
                    Iterator it5 = it3;
                    int iMax2 = Math.max(iMax, aa4Var2.g.b);
                    if (i10 > 0 && iMax2 == 0) {
                        iMax2 = 1;
                    }
                    if (iMax2 == 0) {
                        it3 = it5;
                    } else {
                        float[] fArr = ia4Var3.c;
                        int[] iArr = ia4Var3.b;
                        if (fArr != null) {
                            arrayList = arrayList5;
                            double[] dArrV = aa4Var2.j[0].V();
                            if (iArr != null) {
                                Iterator it6 = arrayList.iterator();
                                int i12 = 0;
                                while (it6.hasNext()) {
                                    iArr[i12] = ((na4) it6.next()).d0;
                                    i12++;
                                    fArr = fArr;
                                }
                            }
                            float[] fArr2 = fArr;
                            int i13 = 0;
                            int i14 = 0;
                            while (i13 < dArrV.length) {
                                int i15 = i13;
                                double[] dArr = dArrV;
                                aa4Var2.j[0].Q(dArrV[i15], aa4Var2.p);
                                aa4Var2.f.c(dArr[i15], aa4Var2.o, aa4Var2.p, fArr2, i14);
                                i14 += 2;
                                i13 = i15 + 1;
                                iC = iC;
                                dArrV = dArr;
                            }
                            i = iC;
                            i2 = i14 / 2;
                        } else {
                            arrayList = arrayList5;
                            i = iC;
                            i2 = 0;
                        }
                        ia4Var3.k = i2;
                        if (iMax2 >= 1) {
                            int i16 = i / 16;
                            float[] fArr3 = ia4Var3.f2803a;
                            if (fArr3 == null || fArr3.length != i16 * 2) {
                                ia4Var3.f2803a = new float[i16 * 2];
                                ia4Var3.d = new Path();
                            }
                            float f2 = i11;
                            canvas.translate(f2, f2);
                            paint10.setColor(1996488704);
                            paint9.setColor(1996488704);
                            paint8.setColor(1996488704);
                            paint7.setColor(1996488704);
                            float[] fArr4 = ia4Var3.f2803a;
                            float f3 = 1.0f / (i16 - 1);
                            float f4 = 1.0f;
                            HashMap map2 = aa4Var2.y;
                            ue7 ue7Var = map2 == null ? null : (ue7) map2.get("translationX");
                            HashMap map3 = aa4Var2.y;
                            i3 = i10;
                            ue7 ue7Var2 = map3 == null ? null : (ue7) map3.get("translationY");
                            HashMap map4 = aa4Var2.z;
                            zd7 zd7Var = map4 == null ? null : (zd7) map4.get("translationX");
                            HashMap map5 = aa4Var2.z;
                            zd7 zd7Var2 = map5 == null ? null : (zd7) map5.get("translationY");
                            int i17 = 0;
                            while (true) {
                                float f5 = Float.NaN;
                                float f6 = 0.0f;
                                if (i17 >= i16) {
                                    break;
                                }
                                int i18 = i16;
                                float f7 = i17 * f3;
                                float f8 = aa4Var2.n;
                                if (f8 != f4) {
                                    float f9 = aa4Var2.m;
                                    if (f7 < f9) {
                                        f = f9;
                                        fMin = 0.0f;
                                    } else {
                                        f = f9;
                                        fMin = f7;
                                    }
                                    i5 = i17;
                                    paint3 = paint7;
                                    if (fMin > f && fMin < 1.0d) {
                                        fMin = Math.min((fMin - f) * f8, f4);
                                    }
                                } else {
                                    i5 = i17;
                                    paint3 = paint7;
                                    fMin = f7;
                                }
                                double d = fMin;
                                g9 g9Var = na4Var.f4335a;
                                Iterator it7 = arrayList.iterator();
                                while (it7.hasNext()) {
                                    Iterator it8 = it7;
                                    na4 na4Var2 = (na4) it7.next();
                                    na4 na4Var3 = na4Var;
                                    g9 g9Var2 = na4Var2.f4335a;
                                    if (g9Var2 != null) {
                                        float f10 = na4Var2.c;
                                        if (f10 < fMin) {
                                            f6 = f10;
                                            g9Var = g9Var2;
                                        } else if (Float.isNaN(f5)) {
                                            f5 = na4Var2.c;
                                        }
                                    }
                                    it7 = it8;
                                    na4Var = na4Var3;
                                }
                                na4 na4Var4 = na4Var;
                                if (g9Var != null) {
                                    if (Float.isNaN(f5)) {
                                        f5 = 1.0f;
                                    }
                                    paint4 = paint9;
                                    i6 = i11;
                                    dA = (((float) g9Var.a((fMin - f6) / r22)) * (f5 - f6)) + f6;
                                } else {
                                    paint4 = paint9;
                                    i6 = i11;
                                    dA = d;
                                }
                                aa4Var2.j[0].Q(dA, aa4Var2.p);
                                nt ntVar = aa4Var2.k;
                                if (ntVar != null) {
                                    double[] dArr2 = aa4Var2.p;
                                    paint5 = paint4;
                                    if (dArr2.length > 0) {
                                        ntVar.Q(dA, dArr2);
                                    }
                                } else {
                                    paint5 = paint4;
                                }
                                int i19 = i5 * 2;
                                aa4Var2.f.c(dA, aa4Var2.o, aa4Var2.p, fArr4, i19);
                                if (zd7Var != null) {
                                    fArr4[i19] = zd7Var.a(fMin) + fArr4[i19];
                                } else if (ue7Var != null) {
                                    fArr4[i19] = ue7Var.a(fMin) + fArr4[i19];
                                }
                                if (zd7Var2 != null) {
                                    int i20 = i19 + 1;
                                    fArr4[i20] = zd7Var2.a(fMin) + fArr4[i20];
                                } else if (ue7Var2 != null) {
                                    int i21 = i19 + 1;
                                    fArr4[i21] = ue7Var2.a(fMin) + fArr4[i21];
                                }
                                i17 = i5 + 1;
                                i16 = i18;
                                paint7 = paint3;
                                na4Var = na4Var4;
                                i11 = i6;
                                paint9 = paint5;
                                f4 = 1.0f;
                            }
                            na4 na4Var5 = na4Var;
                            Paint paint11 = paint7;
                            ia4Var3.a(canvas, iMax2, ia4Var3.k, aa4Var2);
                            paint10.setColor(-21965);
                            paint8.setColor(-2067046);
                            paint2 = paint9;
                            paint2.setColor(-2067046);
                            Paint paint12 = paint11;
                            paint12.setColor(-13391360);
                            int i22 = i11;
                            float f11 = -i22;
                            canvas.translate(f11, f11);
                            ia4Var3.a(canvas, iMax2, ia4Var3.k, aa4Var2);
                            char c = 5;
                            if (iMax2 == 5) {
                                float[] fArr5 = ia4Var3.j;
                                ia4Var3.d.reset();
                                int i23 = 0;
                                while (i23 <= 50) {
                                    char c2 = c;
                                    int i24 = i23;
                                    aa4Var2.j[0].Q(aa4Var2.b(i23 / 50.0f, null), aa4Var2.p);
                                    int[] iArr2 = aa4Var2.o;
                                    double[] dArr3 = aa4Var2.p;
                                    na4 na4Var6 = na4Var5;
                                    float fSin = na4Var6.e;
                                    float fCos = na4Var6.f;
                                    float f12 = na4Var6.i;
                                    float f13 = na4Var6.v;
                                    int i25 = i22;
                                    float[] fArr6 = fArr5;
                                    int i26 = 0;
                                    while (true) {
                                        aa4Var = aa4Var2;
                                        if (i26 >= iArr2.length) {
                                            break;
                                        }
                                        Paint paint13 = paint12;
                                        float f14 = (float) dArr3[i26];
                                        int i27 = iArr2[i26];
                                        if (i27 == 1) {
                                            fSin = f14;
                                        } else if (i27 == 2) {
                                            fCos = f14;
                                        } else if (i27 == 3) {
                                            f12 = f14;
                                        } else if (i27 == 4) {
                                            f13 = f14;
                                        }
                                        i26++;
                                        aa4Var2 = aa4Var;
                                        paint12 = paint13;
                                    }
                                    Paint paint14 = paint12;
                                    if (na4Var6.b0 != null) {
                                        double d2 = fSin;
                                        double d3 = fCos;
                                        ia4Var2 = ia4Var3;
                                        fSin = (float) (((Math.sin(d3) * d2) + 0.0d) - ((double) (f12 / 2.0f)));
                                        fCos = (float) ((0.0d - (Math.cos(d3) * d2)) - ((double) (f13 / 2.0f)));
                                    } else {
                                        ia4Var2 = ia4Var3;
                                    }
                                    float f15 = f12 + fSin;
                                    float f16 = f13 + fCos;
                                    Float.isNaN(Float.NaN);
                                    Float.isNaN(Float.NaN);
                                    float f17 = fSin + 0.0f;
                                    float f18 = fCos + 0.0f;
                                    float f19 = f15 + 0.0f;
                                    float f20 = f16 + 0.0f;
                                    fArr6[0] = f17;
                                    fArr6[1] = f18;
                                    fArr6[2] = f19;
                                    fArr6[3] = f18;
                                    fArr6[4] = f19;
                                    fArr6[c2] = f20;
                                    fArr6[6] = f17;
                                    fArr6[7] = f20;
                                    ia4 ia4Var4 = ia4Var2;
                                    ia4Var4.d.moveTo(f17, f18);
                                    ia4Var4.d.lineTo(fArr6[2], fArr6[3]);
                                    ia4Var4.d.lineTo(fArr6[4], fArr6[c2]);
                                    ia4Var4.d.lineTo(fArr6[6], fArr6[7]);
                                    ia4Var4.d.close();
                                    i23 = i24 + 1;
                                    ia4Var3 = ia4Var4;
                                    na4Var5 = na4Var6;
                                    c = c2;
                                    fArr5 = fArr6;
                                    aa4Var2 = aa4Var;
                                    paint12 = paint14;
                                    i22 = i25;
                                }
                                i4 = i22;
                                ia4Var = ia4Var3;
                                paint = paint12;
                                paint10.setColor(1140850688);
                                canvas.translate(2.0f, 2.0f);
                                canvas.drawPath(ia4Var.d, paint10);
                                canvas.translate(-2.0f, -2.0f);
                                paint10.setColor(-65536);
                                canvas.drawPath(ia4Var.d, paint10);
                                ia4Var3 = ia4Var;
                                paint9 = paint2;
                                it3 = it5;
                                iC = i;
                                i10 = i3;
                                paint7 = paint;
                                i11 = i4;
                            } else {
                                i4 = i22;
                                ia4Var = ia4Var3;
                                paint = paint12;
                            }
                        } else {
                            ia4Var = ia4Var3;
                            i3 = i10;
                            paint = paint7;
                            paint2 = paint9;
                            i4 = i11;
                        }
                        ia4Var3 = ia4Var;
                        paint9 = paint2;
                        it3 = it5;
                        iC = i;
                        i10 = i3;
                        paint7 = paint;
                        i11 = i4;
                    }
                }
                canvas.restore();
            }
        }
        ArrayList arrayList6 = this.S0;
        if (arrayList6 != null) {
            Iterator it9 = arrayList6.iterator();
            while (it9.hasNext()) {
                ((MotionHelper) it9.next()).getClass();
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public final void g(int i) {
        this.c0 = null;
    }

    public int[] getConstraintSetIds() {
        ra4 ra4Var = this.i0;
        if (ra4Var == null) {
            return null;
        }
        SparseArray sparseArray = ra4Var.g;
        int size = sparseArray.size();
        int[] iArr = new int[size];
        for (int i = 0; i < size; i++) {
            iArr[i] = sparseArray.keyAt(i);
        }
        return iArr;
    }

    public int getCurrentState() {
        return this.n0;
    }

    public ArrayList<qa4> getDefinedTransitions() {
        ra4 ra4Var = this.i0;
        if (ra4Var == null) {
            return null;
        }
        return ra4Var.d;
    }

    public po1 getDesignTool() {
        if (this.H0 == null) {
            this.H0 = new po1();
        }
        return this.H0;
    }

    public int getEndState() {
        return this.o0;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.w0;
    }

    public ra4 getScene() {
        return this.i0;
    }

    public int getStartState() {
        return this.m0;
    }

    public float getTargetPosition() {
        return this.y0;
    }

    public Bundle getTransitionState() {
        if (this.j1 == null) {
            this.j1 = new ka4(this);
        }
        ka4 ka4Var = this.j1;
        MotionLayout motionLayout = ka4Var.e;
        ka4Var.d = motionLayout.o0;
        ka4Var.c = motionLayout.m0;
        ka4Var.b = motionLayout.getVelocity();
        ka4Var.f3673a = motionLayout.getProgress();
        ka4 ka4Var2 = this.j1;
        ka4Var2.getClass();
        Bundle bundle = new Bundle();
        bundle.putFloat("motion.progress", ka4Var2.f3673a);
        bundle.putFloat("motion.velocity", ka4Var2.b);
        bundle.putInt("motion.StartState", ka4Var2.c);
        bundle.putInt("motion.EndState", ka4Var2.d);
        return bundle;
    }

    public long getTransitionTimeMs() {
        if (this.i0 != null) {
            this.u0 = r0.c() / 1000.0f;
        }
        return (long) (this.u0 * 1000.0f);
    }

    public float getVelocity() {
        return this.l0;
    }

    public final void l(float f) {
        if (this.i0 == null) {
            return;
        }
        float f2 = this.w0;
        float f3 = this.v0;
        if (f2 != f3 && this.z0) {
            this.w0 = f3;
        }
        float f4 = this.w0;
        if (f4 == f) {
            return;
        }
        this.E0 = false;
        this.y0 = f;
        this.u0 = r0.c() / 1000.0f;
        setProgress(this.y0);
        this.j0 = null;
        this.k0 = this.i0.e();
        this.z0 = false;
        this.t0 = getNanoTime();
        this.A0 = true;
        this.v0 = f4;
        this.w0 = f4;
        invalidate();
    }

    public final void m(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            aa4 aa4Var = (aa4) this.s0.get(getChildAt(i));
            if (aa4Var != null && "button".equals(p01.J(aa4Var.b)) && aa4Var.A != null) {
                int i2 = 0;
                while (true) {
                    hb3[] hb3VarArr = aa4Var.A;
                    if (i2 < hb3VarArr.length) {
                        hb3VarArr[i2].h(aa4Var.b, z ? -100.0f : 100.0f);
                        i2++;
                    }
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:116:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:125:0x01c6  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x01e4  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x01fd  */
    /* JADX WARN: Removed duplicated region for block: B:148:0x0214  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00e0 A[PHI: r3
  0x00e0: PHI (r3v13 float) = (r3v12 float), (r3v14 float), (r3v14 float) binds: [B:49:0x00ae, B:60:0x00d4, B:62:0x00d8] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:74:0x010b  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x0147  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0149  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0152  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0169  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void n(boolean r22) {
        /*
            Method dump skipped, instruction units count: 612
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.n(boolean):void");
    }

    public final void o() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        CopyOnWriteArrayList copyOnWriteArrayList2;
        if ((this.B0 == null && ((copyOnWriteArrayList2 = this.T0) == null || copyOnWriteArrayList2.isEmpty())) || this.Y0 == this.v0) {
            return;
        }
        if (this.X0 != -1 && (copyOnWriteArrayList = this.T0) != null) {
            Iterator it = copyOnWriteArrayList.iterator();
            while (it.hasNext()) {
                ((la4) it.next()).getClass();
            }
        }
        this.X0 = -1;
        this.Y0 = this.v0;
        CopyOnWriteArrayList copyOnWriteArrayList3 = this.T0;
        if (copyOnWriteArrayList3 != null) {
            Iterator it2 = copyOnWriteArrayList3.iterator();
            while (it2.hasNext()) {
                ((la4) it2.next()).getClass();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        qa4 qa4Var;
        int i;
        super.onAttachedToWindow();
        Display display = getDisplay();
        if (display != null) {
            display.getRotation();
        }
        ra4 ra4Var = this.i0;
        if (ra4Var != null && (i = this.n0) != -1) {
            d dVarB = ra4Var.b(i);
            ra4 ra4Var2 = this.i0;
            SparseArray sparseArray = ra4Var2.g;
            loop0: for (int i2 = 0; i2 < sparseArray.size(); i2++) {
                int iKeyAt = sparseArray.keyAt(i2);
                SparseIntArray sparseIntArray = ra4Var2.i;
                int i3 = sparseIntArray.get(iKeyAt);
                int size = sparseIntArray.size();
                while (i3 > 0) {
                    if (i3 != iKeyAt) {
                        int i4 = size - 1;
                        if (size >= 0) {
                            i3 = sparseIntArray.get(i3);
                            size = i4;
                        }
                    }
                    o0.d("MotionScene", "Cannot be derived from yourself");
                    break loop0;
                }
                ra4Var2.m(iKeyAt, this);
            }
            ArrayList arrayList = this.S0;
            if (arrayList != null) {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((MotionHelper) it.next()).getClass();
                }
            }
            if (dVarB != null) {
                dVarB.b(this);
            }
            this.m0 = this.n0;
        }
        u();
        ka4 ka4Var = this.j1;
        if (ka4Var != null) {
            if (this.m1) {
                post(new lg(this, 18));
                return;
            } else {
                ka4Var.a();
                return;
            }
        }
        ra4 ra4Var3 = this.i0;
        if (ra4Var3 == null || (qa4Var = ra4Var3.c) == null || qa4Var.n != 4) {
            return;
        }
        l(1.0f);
        this.k1 = null;
        setState(ma4.b);
        setState(ma4.c);
    }

    /* JADX WARN: Removed duplicated region for block: B:68:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0125  */
    @Override // android.view.ViewGroup
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onInterceptTouchEvent(android.view.MotionEvent r18) {
        /*
            Method dump skipped, instruction units count: 441
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.i1 = true;
        try {
            if (this.i0 == null) {
                super.onLayout(z, i, i2, i3, i4);
                this.i1 = false;
                return;
            }
            int i5 = i3 - i;
            int i6 = i4 - i2;
            if (this.I0 != i5 || this.J0 != i6) {
                w();
                n(true);
            }
            this.I0 = i5;
            this.J0 = i6;
            this.i1 = false;
        } catch (Throwable th) {
            this.i1 = false;
            throw th;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        boolean z;
        mz0 mz0Var = this.c;
        if (this.i0 == null) {
            super.onMeasure(i, i2);
            return;
        }
        boolean z2 = true;
        boolean z3 = (this.p0 == i && this.q0 == i2) ? false : true;
        if (this.p1) {
            this.p1 = false;
            u();
            v();
            z3 = true;
        }
        if (this.v) {
            z3 = true;
        }
        this.p0 = i;
        this.q0 = i2;
        int iH = this.i0.h();
        qa4 qa4Var = this.i0.c;
        int i3 = qa4Var == null ? -1 : qa4Var.c;
        ja4 ja4Var = this.o1;
        if ((!z3 && iH == ja4Var.e && i3 == ja4Var.f) || this.m0 == -1) {
            if (z3) {
                super.onMeasure(i, i2);
            }
            z = true;
        } else {
            super.onMeasure(i, i2);
            ja4Var.e(this.i0.b(iH), this.i0.b(i3));
            ja4Var.f();
            ja4Var.e = iH;
            ja4Var.f = i3;
            z = false;
        }
        if (this.Z0 || z) {
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int iR = mz0Var.r() + getPaddingRight() + getPaddingLeft();
            int iL = mz0Var.l() + paddingBottom;
            int i4 = this.e1;
            if (i4 == Integer.MIN_VALUE || i4 == 0) {
                iR = (int) ((this.g1 * (this.c1 - r1)) + this.a1);
                requestLayout();
            }
            int i5 = this.f1;
            if (i5 == Integer.MIN_VALUE || i5 == 0) {
                iL = (int) ((this.g1 * (this.d1 - r2)) + this.b1);
                requestLayout();
            }
            setMeasuredDimension(iR, iL);
        }
        float fSignum = Math.signum(this.y0 - this.w0);
        long nanoTime = getNanoTime();
        fa4 fa4Var = this.j0;
        float interpolation = this.w0 + (!(fa4Var instanceof n76) ? (((nanoTime - this.x0) * fSignum) * 1.0E-9f) / this.u0 : 0.0f);
        if (this.z0) {
            interpolation = this.y0;
        }
        if ((fSignum <= 0.0f || interpolation < this.y0) && (fSignum > 0.0f || interpolation > this.y0)) {
            z2 = false;
        } else {
            interpolation = this.y0;
        }
        if (fa4Var != null && !z2) {
            interpolation = this.E0 ? fa4Var.getInterpolation((nanoTime - this.t0) * 1.0E-9f) : fa4Var.getInterpolation(interpolation);
        }
        if ((fSignum > 0.0f && interpolation >= this.y0) || (fSignum <= 0.0f && interpolation <= this.y0)) {
            interpolation = this.y0;
        }
        this.g1 = interpolation;
        int childCount = getChildCount();
        long nanoTime2 = getNanoTime();
        Interpolator interpolator = this.k0;
        if (interpolator != null) {
            interpolation = interpolator.getInterpolation(interpolation);
        }
        float f = interpolation;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            aa4 aa4Var = (aa4) this.s0.get(childAt);
            if (aa4Var != null) {
                aa4Var.f(f, nanoTime2, this.h1, childAt);
            }
        }
        if (this.Z0) {
            requestLayout();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    @Override // defpackage.of4
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr, int i3) {
        qa4 qa4Var;
        boolean z;
        float f;
        zn6 zn6Var;
        float f2;
        zn6 zn6Var2;
        zn6 zn6Var3;
        zn6 zn6Var4;
        int i4;
        ra4 ra4Var = this.i0;
        if (ra4Var == null || (qa4Var = ra4Var.c) == null || (z = qa4Var.o)) {
            return;
        }
        int i5 = -1;
        if (z || (zn6Var4 = qa4Var.l) == null || (i4 = zn6Var4.e) == -1 || view.getId() == i4) {
            qa4 qa4Var2 = ra4Var.c;
            if ((qa4Var2 == null || (zn6Var3 = qa4Var2.l) == null) ? false : zn6Var3.u) {
                zn6 zn6Var5 = qa4Var.l;
                if (zn6Var5 != null && (zn6Var5.w & 4) != 0) {
                    i5 = i2;
                }
                float f3 = this.v0;
                if ((f3 == 1.0f || f3 == 0.0f) && view.canScrollVertically(i5)) {
                    return;
                }
            }
            zn6 zn6Var6 = qa4Var.l;
            if (zn6Var6 == null || (zn6Var6.w & 1) == 0) {
                f = 0.0f;
            } else {
                float f4 = i;
                float f5 = i2;
                qa4 qa4Var3 = ra4Var.c;
                if (qa4Var3 == null || (zn6Var2 = qa4Var3.l) == null) {
                    f = 0.0f;
                    f2 = 0.0f;
                } else {
                    float[] fArr = zn6Var2.n;
                    f = 0.0f;
                    zn6Var2.r.q(zn6Var2.d, zn6Var2.r.getProgress(), zn6Var2.h, zn6Var2.g, fArr);
                    float f6 = zn6Var2.k;
                    if (f6 != 0.0f) {
                        if (fArr[0] == 0.0f) {
                            fArr[0] = 1.0E-7f;
                        }
                        f2 = (f4 * f6) / fArr[0];
                    } else {
                        if (fArr[1] == 0.0f) {
                            fArr[1] = 1.0E-7f;
                        }
                        f2 = (f5 * zn6Var2.l) / fArr[1];
                    }
                }
                float f7 = this.w0;
                if ((f7 <= f && f2 < f) || (f7 >= 1.0f && f2 > f)) {
                    view.setNestedScrollingEnabled(false);
                    view.post(new lg((ViewGroup) view, 17));
                    return;
                }
            }
            float f8 = this.v0;
            long nanoTime = getNanoTime();
            float f9 = i;
            this.L0 = f9;
            float f10 = i2;
            this.M0 = f10;
            this.O0 = (float) ((nanoTime - this.N0) * 1.0E-9d);
            this.N0 = nanoTime;
            qa4 qa4Var4 = ra4Var.c;
            if (qa4Var4 != null && (zn6Var = qa4Var4.l) != null) {
                float[] fArr2 = zn6Var.n;
                MotionLayout motionLayout = zn6Var.r;
                float progress = motionLayout.getProgress();
                if (!zn6Var.m) {
                    zn6Var.m = true;
                    motionLayout.setProgress(progress);
                }
                zn6Var.r.q(zn6Var.d, progress, zn6Var.h, zn6Var.g, fArr2);
                if (Math.abs((zn6Var.l * fArr2[1]) + (zn6Var.k * fArr2[0])) < 0.01d) {
                    fArr2[0] = 0.01f;
                    fArr2[1] = 0.01f;
                }
                float f11 = zn6Var.k;
                float fMax = Math.max(Math.min(progress + (f11 != f ? (f9 * f11) / fArr2[0] : (f10 * zn6Var.l) / fArr2[1]), 1.0f), f);
                if (fMax != motionLayout.getProgress()) {
                    motionLayout.setProgress(fMax);
                }
            }
            if (f8 != this.v0) {
                iArr[0] = i;
                iArr[1] = i2;
            }
            n(false);
            if (iArr[0] == 0 && iArr[1] == 0) {
                return;
            }
            this.K0 = true;
        }
    }

    @Override // defpackage.pf4
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (this.K0 || i != 0 || i2 != 0) {
            iArr[0] = iArr[0] + i3;
            iArr[1] = iArr[1] + i4;
        }
        this.K0 = false;
    }

    @Override // defpackage.of4
    public final void onNestedScrollAccepted(View view, View view2, int i, int i2) {
        this.N0 = getNanoTime();
        this.O0 = 0.0f;
        this.L0 = 0.0f;
        this.M0 = 0.0f;
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        zn6 zn6Var;
        ra4 ra4Var = this.i0;
        if (ra4Var != null) {
            boolean zF = f();
            ra4Var.p = zF;
            qa4 qa4Var = ra4Var.c;
            if (qa4Var == null || (zn6Var = qa4Var.l) == null) {
                return;
            }
            zn6Var.c(zF);
        }
    }

    @Override // defpackage.of4
    public final boolean onStartNestedScroll(View view, View view2, int i, int i2) {
        qa4 qa4Var;
        zn6 zn6Var;
        ra4 ra4Var = this.i0;
        return (ra4Var == null || (qa4Var = ra4Var.c) == null || (zn6Var = qa4Var.l) == null || (zn6Var.w & 2) != 0) ? false : true;
    }

    @Override // defpackage.of4
    public final void onStopNestedScroll(View view, int i) {
        zn6 zn6Var;
        int i2;
        ra4 ra4Var = this.i0;
        if (ra4Var != null) {
            float f = this.O0;
            if (f == 0.0f) {
                return;
            }
            float f2 = this.L0 / f;
            float f3 = this.M0 / f;
            qa4 qa4Var = ra4Var.c;
            if (qa4Var == null || (zn6Var = qa4Var.l) == null) {
                return;
            }
            float[] fArr = zn6Var.n;
            zn6Var.m = false;
            MotionLayout motionLayout = zn6Var.r;
            float progress = motionLayout.getProgress();
            zn6Var.r.q(zn6Var.d, progress, zn6Var.h, zn6Var.g, fArr);
            float f4 = zn6Var.k;
            float f5 = f4 != 0.0f ? (f2 * f4) / fArr[0] : (f3 * zn6Var.l) / fArr[1];
            if (!Float.isNaN(f5)) {
                progress += f5 / 3.0f;
            }
            if (progress == 0.0f || progress == 1.0f || (i2 = zn6Var.c) == 3) {
                return;
            }
            motionLayout.z(((double) progress) >= 0.5d ? 1.0f : 0.0f, f5, i2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:110:0x021f  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x0225  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x04d0  */
    /* JADX WARN: Removed duplicated region for block: B:205:0x04ee  */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0510  */
    /* JADX WARN: Removed duplicated region for block: B:210:0x051f  */
    /* JADX WARN: Removed duplicated region for block: B:237:0x057e  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x058c  */
    /* JADX WARN: Type inference failed for: r18v15 */
    /* JADX WARN: Type inference failed for: r18v24 */
    /* JADX WARN: Type inference failed for: r18v25 */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouchEvent(android.view.MotionEvent r31) {
        /*
            Method dump skipped, instruction units count: 2047
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof MotionHelper) {
            MotionHelper motionHelper = (MotionHelper) view;
            if (this.T0 == null) {
                this.T0 = new CopyOnWriteArrayList();
            }
            this.T0.add(motionHelper);
            if (motionHelper.b0) {
                if (this.Q0 == null) {
                    this.Q0 = new ArrayList();
                }
                this.Q0.add(motionHelper);
            }
            if (motionHelper.c0) {
                if (this.R0 == null) {
                    this.R0 = new ArrayList();
                }
                this.R0.add(motionHelper);
            }
            if (motionHelper instanceof MotionEffect) {
                if (this.S0 == null) {
                    this.S0 = new ArrayList();
                }
                this.S0.add(motionHelper);
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public final void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList arrayList = this.Q0;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList arrayList2 = this.R0;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    public final void p() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        if ((this.B0 != null || ((copyOnWriteArrayList = this.T0) != null && !copyOnWriteArrayList.isEmpty())) && this.X0 == -1) {
            this.X0 = this.n0;
            ArrayList arrayList = this.t1;
            int iIntValue = !arrayList.isEmpty() ? ((Integer) qe0.i(1, arrayList)).intValue() : -1;
            int i = this.n0;
            if (iIntValue != i && i != -1) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        v();
        ej2 ej2Var = this.k1;
        if (ej2Var != null) {
            ej2Var.run();
            this.k1 = null;
        }
    }

    public final void q(int i, float f, float f2, float f3, float[] fArr) {
        View viewC = c(i);
        aa4 aa4Var = (aa4) this.s0.get(viewC);
        if (aa4Var != null) {
            aa4Var.d(f, f2, f3, fArr);
            viewC.getY();
        } else {
            o0.q("MotionLayout", "WARNING could not find view id " + (viewC == null ? oh1.h(i, HttpUrl.FRAGMENT_ENCODE_SET) : viewC.getContext().getResources().getResourceName(i)));
        }
    }

    public final qa4 r(int i) {
        for (qa4 qa4Var : this.i0.d) {
            if (qa4Var.f4986a == i) {
                return qa4Var;
            }
        }
        return null;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View, android.view.ViewParent
    public final void requestLayout() {
        ra4 ra4Var;
        qa4 qa4Var;
        if (!this.Z0 && this.n0 == -1 && (ra4Var = this.i0) != null && (qa4Var = ra4Var.c) != null) {
            int i = qa4Var.q;
            if (i == 0) {
                return;
            }
            if (i == 2) {
                int childCount = getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    ((aa4) this.s0.get(getChildAt(i2))).d = true;
                }
                return;
            }
        }
        super.requestLayout();
    }

    public final boolean s(float f, float f2, View view, MotionEvent motionEvent) {
        boolean z;
        boolean zOnTouchEvent;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                if (s((r3.getLeft() + f) - view.getScrollX(), (r3.getTop() + f2) - view.getScrollY(), viewGroup.getChildAt(childCount), motionEvent)) {
                    z = true;
                    break;
                }
            }
            z = false;
        } else {
            z = false;
        }
        if (!z) {
            RectF rectF = this.q1;
            rectF.set(f, f2, (view.getRight() + f) - view.getLeft(), (view.getBottom() + f2) - view.getTop());
            if (motionEvent.getAction() != 0 || rectF.contains(motionEvent.getX(), motionEvent.getY())) {
                float f3 = -f;
                float f4 = -f2;
                Matrix matrix = view.getMatrix();
                if (matrix.isIdentity()) {
                    motionEvent.offsetLocation(f3, f4);
                    zOnTouchEvent = view.onTouchEvent(motionEvent);
                    motionEvent.offsetLocation(-f3, -f4);
                } else {
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.offsetLocation(f3, f4);
                    if (this.s1 == null) {
                        this.s1 = new Matrix();
                    }
                    matrix.invert(this.s1);
                    motionEventObtain.transform(this.s1);
                    zOnTouchEvent = view.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                }
                if (zOnTouchEvent) {
                    return true;
                }
            }
        }
        return z;
    }

    public void setDebugMode(int i) {
        this.C0 = i;
        invalidate();
    }

    public void setDelayedApplicationOfInitialState(boolean z) {
        this.m1 = z;
    }

    public void setInteractionEnabled(boolean z) {
        this.r0 = z;
    }

    public void setInterpolatedProgress(float f) {
        if (this.i0 != null) {
            setState(ma4.c);
            Interpolator interpolatorE = this.i0.e();
            if (interpolatorE != null) {
                setProgress(interpolatorE.getInterpolation(f));
                return;
            }
        }
        setProgress(f);
    }

    public void setOnHide(float f) {
        ArrayList arrayList = this.R0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((MotionHelper) this.R0.get(i)).setProgress(f);
            }
        }
    }

    public void setOnShow(float f) {
        ArrayList arrayList = this.Q0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((MotionHelper) this.Q0.get(i)).setProgress(f);
            }
        }
    }

    public void setProgress(float f) {
        if (f < 0.0f || f > 1.0f) {
            o0.q("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive");
        }
        if (!isAttachedToWindow()) {
            if (this.j1 == null) {
                this.j1 = new ka4(this);
            }
            this.j1.f3673a = f;
            return;
        }
        ma4 ma4Var = ma4.d;
        ma4 ma4Var2 = ma4.c;
        if (f <= 0.0f) {
            if (this.w0 == 1.0f && this.n0 == this.o0) {
                setState(ma4Var2);
            }
            this.n0 = this.m0;
            if (this.w0 == 0.0f) {
                setState(ma4Var);
            }
        } else if (f >= 1.0f) {
            if (this.w0 == 0.0f && this.n0 == this.m0) {
                setState(ma4Var2);
            }
            this.n0 = this.o0;
            if (this.w0 == 1.0f) {
                setState(ma4Var);
            }
        } else {
            this.n0 = -1;
            setState(ma4Var2);
        }
        if (this.i0 == null) {
            return;
        }
        this.z0 = true;
        this.y0 = f;
        this.v0 = f;
        this.x0 = -1L;
        this.t0 = -1L;
        this.j0 = null;
        this.A0 = true;
        invalidate();
    }

    public void setScene(ra4 ra4Var) {
        zn6 zn6Var;
        this.i0 = ra4Var;
        boolean zF = f();
        ra4Var.p = zF;
        qa4 qa4Var = ra4Var.c;
        if (qa4Var != null && (zn6Var = qa4Var.l) != null) {
            zn6Var.c(zF);
        }
        w();
    }

    public void setStartState(int i) {
        if (isAttachedToWindow()) {
            this.n0 = i;
            return;
        }
        if (this.j1 == null) {
            this.j1 = new ka4(this);
        }
        ka4 ka4Var = this.j1;
        ka4Var.c = i;
        ka4Var.d = i;
    }

    public void setState(ma4 ma4Var) {
        ma4 ma4Var2 = ma4.d;
        if (ma4Var == ma4Var2 && this.n0 == -1) {
            return;
        }
        ma4 ma4Var3 = this.n1;
        this.n1 = ma4Var;
        ma4 ma4Var4 = ma4.c;
        if (ma4Var3 == ma4Var4 && ma4Var == ma4Var4) {
            o();
        }
        int iOrdinal = ma4Var3.ordinal();
        if (iOrdinal != 0 && iOrdinal != 1) {
            if (iOrdinal == 2 && ma4Var == ma4Var2) {
                p();
                return;
            }
            return;
        }
        if (ma4Var == ma4Var4) {
            o();
        }
        if (ma4Var == ma4Var2) {
            p();
        }
    }

    public void setTransition(int i) {
        if (this.i0 != null) {
            qa4 qa4VarR = r(i);
            this.m0 = qa4VarR.d;
            this.o0 = qa4VarR.c;
            if (!isAttachedToWindow()) {
                if (this.j1 == null) {
                    this.j1 = new ka4(this);
                }
                ka4 ka4Var = this.j1;
                ka4Var.c = this.m0;
                ka4Var.d = this.o0;
                return;
            }
            int i2 = this.n0;
            float f = i2 == this.m0 ? 0.0f : i2 == this.o0 ? 1.0f : Float.NaN;
            ra4 ra4Var = this.i0;
            ra4Var.c = qa4VarR;
            zn6 zn6Var = qa4VarR.l;
            if (zn6Var != null) {
                zn6Var.c(ra4Var.p);
            }
            this.o1.e(this.i0.b(this.m0), this.i0.b(this.o0));
            w();
            if (this.w0 != f) {
                if (f == 0.0f) {
                    m(true);
                    this.i0.b(this.m0).b(this);
                } else if (f == 1.0f) {
                    m(false);
                    this.i0.b(this.o0).b(this);
                }
            }
            this.w0 = Float.isNaN(f) ? 0.0f : f;
            if (!Float.isNaN(f)) {
                setProgress(f);
            } else {
                p01.H();
                l(0.0f);
            }
        }
    }

    public void setTransitionDuration(int i) {
        ra4 ra4Var = this.i0;
        if (ra4Var == null) {
            o0.d("MotionLayout", "MotionScene not defined");
            return;
        }
        qa4 qa4Var = ra4Var.c;
        if (qa4Var != null) {
            qa4Var.h = Math.max(i, 8);
        } else {
            ra4Var.j = i;
        }
    }

    public void setTransitionListener(la4 la4Var) {
        this.B0 = la4Var;
    }

    public void setTransitionState(Bundle bundle) {
        if (this.j1 == null) {
            this.j1 = new ka4(this);
        }
        ka4 ka4Var = this.j1;
        ka4Var.getClass();
        ka4Var.f3673a = bundle.getFloat("motion.progress");
        ka4Var.b = bundle.getFloat("motion.velocity");
        ka4Var.c = bundle.getInt("motion.StartState");
        ka4Var.d = bundle.getInt("motion.EndState");
        if (isAttachedToWindow()) {
            this.j1.a();
        }
    }

    public final void t(AttributeSet attributeSet) {
        ra4 ra4Var;
        u1 = isInEditMode();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.MotionLayout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            boolean z = true;
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.MotionLayout_layoutDescription) {
                    this.i0 = new ra4(getContext(), this, typedArrayObtainStyledAttributes.getResourceId(index, -1));
                } else if (index == R$styleable.MotionLayout_currentState) {
                    this.n0 = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                } else if (index == R$styleable.MotionLayout_motionProgress) {
                    this.y0 = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                    this.A0 = true;
                } else if (index == R$styleable.MotionLayout_applyMotionScene) {
                    z = typedArrayObtainStyledAttributes.getBoolean(index, z);
                } else if (index == R$styleable.MotionLayout_showPaths) {
                    if (this.C0 == 0) {
                        this.C0 = typedArrayObtainStyledAttributes.getBoolean(index, false) ? 2 : 0;
                    }
                } else if (index == R$styleable.MotionLayout_motionDebug) {
                    this.C0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            if (this.i0 == null) {
                o0.d("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z) {
                this.i0 = null;
            }
        }
        if (this.C0 != 0) {
            ra4 ra4Var2 = this.i0;
            if (ra4Var2 == null) {
                o0.d("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            } else {
                int iH = ra4Var2.h();
                ra4 ra4Var3 = this.i0;
                d dVarB = ra4Var3.b(ra4Var3.h());
                String strI = p01.I(getContext(), iH);
                int childCount = getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = getChildAt(i2);
                    int id = childAt.getId();
                    if (id == -1) {
                        StringBuilder sbQ = qe0.q("CHECK: ", strI, " ALL VIEWS SHOULD HAVE ID's ");
                        sbQ.append(childAt.getClass().getName());
                        sbQ.append(" does not!");
                        o0.q("MotionLayout", sbQ.toString());
                    }
                    if (dVarB.j(id) == null) {
                        StringBuilder sbQ2 = qe0.q("CHECK: ", strI, " NO CONSTRAINTS for ");
                        sbQ2.append(p01.J(childAt));
                        o0.q("MotionLayout", sbQ2.toString());
                    }
                }
                Integer[] numArr = (Integer[]) dVarB.g.keySet().toArray(new Integer[0]);
                int length = numArr.length;
                int[] iArr = new int[length];
                for (int i3 = 0; i3 < length; i3++) {
                    iArr[i3] = numArr[i3].intValue();
                }
                for (int i4 = 0; i4 < length; i4++) {
                    int i5 = iArr[i4];
                    String strI2 = p01.I(getContext(), i5);
                    if (findViewById(iArr[i4]) == null) {
                        o0.q("MotionLayout", "CHECK: " + strI + " NO View matches id " + strI2);
                    }
                    if (dVarB.i(i5).e.d == -1) {
                        o0.q("MotionLayout", bc4.k("CHECK: ", strI, "(", strI2, ") no LAYOUT_HEIGHT"));
                    }
                    if (dVarB.i(i5).e.c == -1) {
                        o0.q("MotionLayout", bc4.k("CHECK: ", strI, "(", strI2, ") no LAYOUT_HEIGHT"));
                    }
                }
                SparseIntArray sparseIntArray = new SparseIntArray();
                SparseIntArray sparseIntArray2 = new SparseIntArray();
                for (qa4 qa4Var : this.i0.d) {
                    qa4 qa4Var2 = this.i0.c;
                    if (qa4Var.d == qa4Var.c) {
                        o0.d("MotionLayout", "CHECK: start and end constraint set should not be the same!");
                    }
                    int i6 = qa4Var.d;
                    int i7 = qa4Var.c;
                    String strI3 = p01.I(getContext(), i6);
                    String strI4 = p01.I(getContext(), i7);
                    if (sparseIntArray.get(i6) == i7) {
                        o0.d("MotionLayout", "CHECK: two transitions with the same start and end " + strI3 + "->" + strI4);
                    }
                    if (sparseIntArray2.get(i7) == i6) {
                        o0.d("MotionLayout", "CHECK: you can't have reverse transitions" + strI3 + "->" + strI4);
                    }
                    sparseIntArray.put(i6, i7);
                    sparseIntArray2.put(i7, i6);
                    if (this.i0.b(i6) == null) {
                        o0.d("MotionLayout", " no such constraintSetStart " + strI3);
                    }
                    if (this.i0.b(i7) == null) {
                        o0.d("MotionLayout", " no such constraintSetEnd " + strI3);
                    }
                }
            }
        }
        if (this.n0 != -1 || (ra4Var = this.i0) == null) {
            return;
        }
        this.n0 = ra4Var.h();
        this.m0 = this.i0.h();
        qa4 qa4Var3 = this.i0.c;
        this.o0 = qa4Var3 != null ? qa4Var3.c : -1;
    }

    @Override // android.view.View
    public final String toString() {
        Context context = getContext();
        return p01.I(context, this.m0) + "->" + p01.I(context, this.o0) + " (pos:" + this.w0 + " Dpos/Dt:" + this.l0;
    }

    public final void u() {
        qa4 qa4Var;
        zn6 zn6Var;
        View viewFindViewById;
        ra4 ra4Var = this.i0;
        if (ra4Var == null) {
            return;
        }
        if (ra4Var.a(this.n0, this)) {
            requestLayout();
            return;
        }
        int i = this.n0;
        if (i != -1) {
            ra4 ra4Var2 = this.i0;
            ArrayList<qa4> arrayList = ra4Var2.f;
            ArrayList<qa4> arrayList2 = ra4Var2.d;
            for (qa4 qa4Var2 : arrayList2) {
                if (qa4Var2.m.size() > 0) {
                    Iterator it = qa4Var2.m.iterator();
                    while (it.hasNext()) {
                        ((pa4) it.next()).b(this);
                    }
                }
            }
            for (qa4 qa4Var3 : arrayList) {
                if (qa4Var3.m.size() > 0) {
                    Iterator it2 = qa4Var3.m.iterator();
                    while (it2.hasNext()) {
                        ((pa4) it2.next()).b(this);
                    }
                }
            }
            for (qa4 qa4Var4 : arrayList2) {
                if (qa4Var4.m.size() > 0) {
                    Iterator it3 = qa4Var4.m.iterator();
                    while (it3.hasNext()) {
                        ((pa4) it3.next()).a(this, i, qa4Var4);
                    }
                }
            }
            for (qa4 qa4Var5 : arrayList) {
                if (qa4Var5.m.size() > 0) {
                    Iterator it4 = qa4Var5.m.iterator();
                    while (it4.hasNext()) {
                        ((pa4) it4.next()).a(this, i, qa4Var5);
                    }
                }
            }
        }
        if (!this.i0.o() || (qa4Var = this.i0.c) == null || (zn6Var = qa4Var.l) == null) {
            return;
        }
        MotionLayout motionLayout = zn6Var.r;
        int i2 = zn6Var.d;
        if (i2 != -1) {
            viewFindViewById = motionLayout.findViewById(i2);
            if (viewFindViewById == null) {
                o0.d("TouchResponse", "cannot find TouchAnchorId @id/" + p01.I(motionLayout.getContext(), zn6Var.d));
            }
        } else {
            viewFindViewById = null;
        }
        if (viewFindViewById instanceof NestedScrollView) {
            NestedScrollView nestedScrollView = (NestedScrollView) viewFindViewById;
            nestedScrollView.setOnTouchListener(new q30(2));
            nestedScrollView.setOnScrollChangeListener(new o96(2));
        }
    }

    public final void v() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        if (this.B0 == null && ((copyOnWriteArrayList = this.T0) == null || copyOnWriteArrayList.isEmpty())) {
            return;
        }
        ArrayList<Integer> arrayList = this.t1;
        for (Integer num : arrayList) {
            la4 la4Var = this.B0;
            if (la4Var != null) {
                la4Var.a(num.intValue());
            }
            CopyOnWriteArrayList copyOnWriteArrayList2 = this.T0;
            if (copyOnWriteArrayList2 != null) {
                Iterator it = copyOnWriteArrayList2.iterator();
                while (it.hasNext()) {
                    ((la4) it.next()).a(num.intValue());
                }
            }
        }
        arrayList.clear();
    }

    public final void w() {
        this.o1.f();
        invalidate();
    }

    public final void x(int i) {
        setState(ma4.b);
        this.n0 = i;
        this.m0 = -1;
        this.o0 = -1;
        ez0 ez0Var = this.c0;
        if (ez0Var == null) {
            ra4 ra4Var = this.i0;
            if (ra4Var != null) {
                ra4Var.b(i).b(this);
                return;
            }
            return;
        }
        ConstraintLayout constraintLayout = (ConstraintLayout) ez0Var.c;
        SparseArray sparseArray = (SparseArray) ez0Var.d;
        int i2 = ez0Var.f2059a;
        int i3 = 0;
        if (i2 != i) {
            ez0Var.f2059a = i;
            cz0 cz0Var = (cz0) sparseArray.get(i);
            ArrayList arrayList = cz0Var.b;
            while (true) {
                if (i3 >= arrayList.size()) {
                    i3 = -1;
                    break;
                } else if (((dz0) arrayList.get(i3)).a(-1.0f, -1.0f)) {
                    break;
                } else {
                    i3++;
                }
            }
            ArrayList arrayList2 = cz0Var.b;
            d dVar = i3 == -1 ? cz0Var.d : ((dz0) arrayList2.get(i3)).f;
            if (i3 != -1) {
                int i4 = ((dz0) arrayList2.get(i3)).e;
            }
            if (dVar == null) {
                return;
            }
            ez0Var.b = i3;
            dVar.b(constraintLayout);
            return;
        }
        cz0 cz0Var2 = i == -1 ? (cz0) sparseArray.valueAt(0) : (cz0) sparseArray.get(i2);
        int i5 = ez0Var.b;
        if (i5 == -1 || !((dz0) cz0Var2.b.get(i5)).a(-1.0f, -1.0f)) {
            ArrayList arrayList3 = cz0Var2.b;
            while (true) {
                if (i3 >= arrayList3.size()) {
                    i3 = -1;
                    break;
                } else if (((dz0) arrayList3.get(i3)).a(-1.0f, -1.0f)) {
                    break;
                } else {
                    i3++;
                }
            }
            ArrayList arrayList4 = cz0Var2.b;
            if (ez0Var.b == i3) {
                return;
            }
            d dVar2 = i3 == -1 ? null : ((dz0) arrayList4.get(i3)).f;
            if (i3 != -1) {
                int i6 = ((dz0) arrayList4.get(i3)).e;
            }
            if (dVar2 == null) {
                return;
            }
            ez0Var.b = i3;
            dVar2.b(constraintLayout);
        }
    }

    public final void y(int i, int i2) {
        if (!isAttachedToWindow()) {
            if (this.j1 == null) {
                this.j1 = new ka4(this);
            }
            ka4 ka4Var = this.j1;
            ka4Var.c = i;
            ka4Var.d = i2;
            return;
        }
        ra4 ra4Var = this.i0;
        if (ra4Var != null) {
            this.m0 = i;
            this.o0 = i2;
            ra4Var.n(i, i2);
            this.o1.e(this.i0.b(i), this.i0.b(i2));
            w();
            this.w0 = 0.0f;
            l(0.0f);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00be  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void z(float r14, float r15, int r16) {
        /*
            Method dump skipped, instruction units count: 358
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.z(float, float, int):void");
    }

    @Override // defpackage.of4
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5) {
    }

    public MotionLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.k0 = null;
        this.l0 = 0.0f;
        this.m0 = -1;
        this.n0 = -1;
        this.o0 = -1;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = true;
        this.s0 = new HashMap();
        this.t0 = 0L;
        this.u0 = 1.0f;
        this.v0 = 0.0f;
        this.w0 = 0.0f;
        this.y0 = 0.0f;
        this.A0 = false;
        this.C0 = 0;
        this.E0 = false;
        this.F0 = new n76();
        this.G0 = new ha4(this);
        this.K0 = false;
        this.P0 = false;
        this.Q0 = null;
        this.R0 = null;
        this.S0 = null;
        this.T0 = null;
        this.U0 = 0;
        this.V0 = -1L;
        this.W0 = 0.0f;
        this.X0 = 0;
        this.Y0 = 0.0f;
        this.Z0 = false;
        this.h1 = new aa3(0);
        this.i1 = false;
        this.k1 = null;
        new HashMap();
        this.l1 = new Rect();
        this.m1 = false;
        this.n1 = ma4.f4115a;
        this.o1 = new ja4(this);
        this.p1 = false;
        this.q1 = new RectF();
        this.r1 = null;
        this.s1 = null;
        this.t1 = new ArrayList();
        t(attributeSet);
    }

    public void setTransition(qa4 qa4Var) {
        zn6 zn6Var;
        ra4 ra4Var = this.i0;
        ra4Var.c = qa4Var;
        if (qa4Var != null && (zn6Var = qa4Var.l) != null) {
            zn6Var.c(ra4Var.p);
        }
        setState(ma4.b);
        int i = this.n0;
        qa4 qa4Var2 = this.i0.c;
        if (i == (qa4Var2 == null ? -1 : qa4Var2.c)) {
            this.w0 = 1.0f;
            this.v0 = 1.0f;
            this.y0 = 1.0f;
        } else {
            this.w0 = 0.0f;
            this.v0 = 0.0f;
            this.y0 = 0.0f;
        }
        this.x0 = (qa4Var.r & 1) != 0 ? -1L : getNanoTime();
        int iH = this.i0.h();
        ra4 ra4Var2 = this.i0;
        qa4 qa4Var3 = ra4Var2.c;
        int i2 = qa4Var3 != null ? qa4Var3.c : -1;
        if (iH == this.m0 && i2 == this.o0) {
            return;
        }
        this.m0 = iH;
        this.o0 = i2;
        ra4Var2.n(iH, i2);
        d dVarB = this.i0.b(this.m0);
        d dVarB2 = this.i0.b(this.o0);
        ja4 ja4Var = this.o1;
        ja4Var.e(dVarB, dVarB2);
        int i3 = this.m0;
        int i4 = this.o0;
        ja4Var.e = i3;
        ja4Var.f = i4;
        ja4Var.f();
        w();
    }
}

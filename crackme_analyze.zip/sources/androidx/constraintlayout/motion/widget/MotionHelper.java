package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;
import defpackage.la4;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class MotionHelper extends ConstraintHelper implements la4 {
    public boolean b0;
    public boolean c0;
    public float d0;
    public View[] e0;

    public MotionHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b0 = false;
        this.c0 = false;
        k(attributeSet);
    }

    public void a(int i) {
    }

    public float getProgress() {
        return this.d0;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.MotionHelper);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.MotionHelper_onShow) {
                    this.b0 = typedArrayObtainStyledAttributes.getBoolean(index, this.b0);
                } else if (index == R$styleable.MotionHelper_onHide) {
                    this.c0 = typedArrayObtainStyledAttributes.getBoolean(index, this.c0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void r(MotionLayout motionLayout, HashMap map) {
    }

    public void setProgress(float f) {
        this.d0 = f;
        int i = 0;
        if (this.b > 0) {
            this.e0 = j((ConstraintLayout) getParent());
            while (i < this.b) {
                View view = this.e0[i];
                i++;
            }
            return;
        }
        ViewGroup viewGroup = (ViewGroup) getParent();
        int childCount = viewGroup.getChildCount();
        while (i < childCount) {
            viewGroup.getChildAt(i);
            i++;
        }
    }

    public MotionHelper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.b0 = false;
        this.c0 = false;
        k(attributeSet);
    }
}

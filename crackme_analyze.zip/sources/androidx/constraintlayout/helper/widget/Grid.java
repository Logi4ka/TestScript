package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;
import androidx.constraintlayout.widget.VirtualLayout;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashSet;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class Grid extends VirtualLayout {
    public View[] d0;
    public ConstraintLayout e0;
    public int f0;
    public int g0;
    public int h0;
    public int i0;
    public String j0;
    public String k0;
    public String l0;
    public String m0;
    public float n0;
    public float o0;
    public int p0;
    public int q0;
    public boolean[][] r0;
    public final HashSet s0;
    public int[] t0;

    public Grid(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.q0 = 0;
        this.s0 = new HashSet();
    }

    public static int[][] B(String str) {
        String[] strArrSplit = str.split(",");
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, strArrSplit.length, 3);
        for (int i = 0; i < strArrSplit.length; i++) {
            String[] strArrSplit2 = strArrSplit[i].trim().split(":");
            String[] strArrSplit3 = strArrSplit2[1].split("x");
            iArr[i][0] = Integer.parseInt(strArrSplit2[0]);
            iArr[i][1] = Integer.parseInt(strArrSplit3[0]);
            iArr[i][2] = Integer.parseInt(strArrSplit3[1]);
        }
        return iArr;
    }

    public static float[] C(int i, String str) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        String[] strArrSplit = str.split(",");
        if (strArrSplit.length != i) {
            return null;
        }
        float[] fArr = new float[i];
        for (int i2 = 0; i2 < i; i2++) {
            fArr[i2] = Float.parseFloat(strArrSplit[i2].trim());
        }
        return fArr;
    }

    private int getNextPosition() {
        boolean z = false;
        int i = 0;
        while (!z) {
            i = this.q0;
            if (i >= this.f0 * this.h0) {
                return -1;
            }
            int iX = x(i);
            int iW = w(this.q0);
            boolean[] zArr = this.r0[iX];
            if (zArr[iW]) {
                zArr[iW] = false;
                z = true;
            }
            this.q0++;
        }
        return i;
    }

    public static void s(View view) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        layoutParams.H = -1.0f;
        layoutParams.f = -1;
        layoutParams.e = -1;
        layoutParams.g = -1;
        layoutParams.h = -1;
        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = -1;
        view.setLayoutParams(layoutParams);
    }

    public static void t(View view) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        layoutParams.I = -1.0f;
        layoutParams.j = -1;
        layoutParams.i = -1;
        layoutParams.k = -1;
        layoutParams.l = -1;
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = -1;
        view.setLayoutParams(layoutParams);
    }

    public final View A() {
        View view = new View(getContext());
        view.setId(View.generateViewId());
        view.setVisibility(4);
        this.e0.addView(view, new ConstraintLayout.LayoutParams(0, 0));
        return view;
    }

    public final void D() {
        int i;
        int i2 = this.g0;
        if (i2 != 0 && (i = this.i0) != 0) {
            this.f0 = i2;
            this.h0 = i;
            return;
        }
        int i3 = this.i0;
        if (i3 > 0) {
            this.h0 = i3;
            this.f0 = ((this.b + i3) - 1) / i3;
        } else if (i2 > 0) {
            this.f0 = i2;
            this.h0 = ((this.b + i2) - 1) / i2;
        } else {
            int iSqrt = (int) (Math.sqrt(this.b) + 1.5d);
            this.f0 = iSqrt;
            this.h0 = ((this.b + iSqrt) - 1) / iSqrt;
        }
    }

    public String getColumnWeights() {
        return this.m0;
    }

    public int getColumns() {
        return this.i0;
    }

    public float getHorizontalGaps() {
        return this.n0;
    }

    public int getOrientation() {
        return this.p0;
    }

    public String getRowWeights() {
        return this.l0;
    }

    public int getRows() {
        return this.g0;
    }

    public String getSkips() {
        return this.k0;
    }

    public String getSpans() {
        return this.j0;
    }

    public float getVerticalGaps() {
        return this.o0;
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.e = true;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.Grid);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.Grid_grid_rows) {
                    this.g0 = typedArrayObtainStyledAttributes.getInteger(index, 0);
                } else if (index == R$styleable.Grid_grid_columns) {
                    this.i0 = typedArrayObtainStyledAttributes.getInteger(index, 0);
                } else if (index == R$styleable.Grid_grid_spans) {
                    this.j0 = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.Grid_grid_skips) {
                    this.k0 = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.Grid_grid_rowWeights) {
                    this.l0 = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.Grid_grid_columnWeights) {
                    this.m0 = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.Grid_grid_orientation) {
                    this.p0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.Grid_grid_horizontalGaps) {
                    this.n0 = typedArrayObtainStyledAttributes.getDimension(index, 0.0f);
                } else if (index == R$styleable.Grid_grid_verticalGaps) {
                    this.o0 = typedArrayObtainStyledAttributes.getDimension(index, 0.0f);
                } else if (index == R$styleable.Grid_grid_validateInputs) {
                    typedArrayObtainStyledAttributes.getBoolean(index, false);
                } else if (index == R$styleable.Grid_grid_useRtl) {
                    typedArrayObtainStyledAttributes.getBoolean(index, false);
                }
            }
            D();
            y();
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.e0 = (ConstraintLayout) getParent();
        v(false);
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onDraw(Canvas canvas) {
        if (isInEditMode()) {
            Paint paint = new Paint();
            paint.setColor(-65536);
            paint.setStyle(Paint.Style.STROKE);
            int top = getTop();
            int left = getLeft();
            int bottom = getBottom();
            int right = getRight();
            View[] viewArr = this.d0;
            int length = viewArr.length;
            int i = 0;
            while (i < length) {
                View view = viewArr[i];
                int left2 = view.getLeft() - left;
                int top2 = view.getTop() - top;
                int right2 = view.getRight() - left;
                int bottom2 = view.getBottom() - top;
                Canvas canvas2 = canvas;
                canvas2.drawRect(left2, 0.0f, right2, bottom - top, paint);
                canvas2.drawRect(0.0f, top2, right - left, bottom2, paint);
                i++;
                canvas = canvas2;
            }
        }
    }

    public void setColumnWeights(String str) {
        String str2 = this.m0;
        if (str2 == null || !str2.equals(str)) {
            this.m0 = str;
            v(true);
            invalidate();
        }
    }

    public void setColumns(int i) {
        if (i <= 50 && this.i0 != i) {
            this.i0 = i;
            D();
            y();
            v(false);
            invalidate();
        }
    }

    public void setHorizontalGaps(float f) {
        if (f >= 0.0f && this.n0 != f) {
            this.n0 = f;
            v(true);
            invalidate();
        }
    }

    public void setOrientation(int i) {
        if ((i == 0 || i == 1) && this.p0 != i) {
            this.p0 = i;
            v(true);
            invalidate();
        }
    }

    public void setRowWeights(String str) {
        String str2 = this.l0;
        if (str2 == null || !str2.equals(str)) {
            this.l0 = str;
            v(true);
            invalidate();
        }
    }

    public void setRows(int i) {
        if (i <= 50 && this.g0 != i) {
            this.g0 = i;
            D();
            y();
            v(false);
            invalidate();
        }
    }

    public void setSkips(String str) {
        String str2 = this.k0;
        if (str2 == null || !str2.equals(str)) {
            this.k0 = str;
            v(true);
            invalidate();
        }
    }

    public void setSpans(CharSequence charSequence) {
        String str = this.j0;
        if (str == null || !str.contentEquals(charSequence)) {
            this.j0 = charSequence.toString();
            v(true);
            invalidate();
        }
    }

    public void setVerticalGaps(float f) {
        if (f >= 0.0f && this.o0 != f) {
            this.o0 = f;
            v(true);
            invalidate();
        }
    }

    public final void u(View view, int i, int i2, int i3, int i4) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        int[] iArr = this.t0;
        layoutParams.e = iArr[i2];
        layoutParams.i = iArr[i];
        layoutParams.h = iArr[(i2 + i4) - 1];
        layoutParams.l = iArr[(i + i3) - 1];
        view.setLayoutParams(layoutParams);
    }

    public final void v(boolean z) {
        int i;
        int i2;
        int[][] iArrB;
        int[][] iArrB2;
        if (this.e0 == null || this.f0 < 1 || this.h0 < 1) {
            return;
        }
        HashSet hashSet = this.s0;
        if (z) {
            for (int i3 = 0; i3 < this.r0.length; i3++) {
                int i4 = 0;
                while (true) {
                    boolean[][] zArr = this.r0;
                    if (i4 < zArr[0].length) {
                        zArr[i3][i4] = true;
                        i4++;
                    }
                }
            }
            hashSet.clear();
        }
        this.q0 = 0;
        int iMax = Math.max(this.f0, this.h0);
        View[] viewArr = this.d0;
        if (viewArr == null) {
            this.d0 = new View[iMax];
            int i5 = 0;
            while (true) {
                View[] viewArr2 = this.d0;
                if (i5 >= viewArr2.length) {
                    break;
                }
                viewArr2[i5] = A();
                i5++;
            }
        } else if (iMax != viewArr.length) {
            View[] viewArr3 = new View[iMax];
            for (int i6 = 0; i6 < iMax; i6++) {
                View[] viewArr4 = this.d0;
                if (i6 < viewArr4.length) {
                    viewArr3[i6] = viewArr4[i6];
                } else {
                    viewArr3[i6] = A();
                }
            }
            int i7 = iMax;
            while (true) {
                View[] viewArr5 = this.d0;
                if (i7 >= viewArr5.length) {
                    break;
                }
                this.e0.removeView(viewArr5[i7]);
                i7++;
            }
            this.d0 = viewArr3;
        }
        this.t0 = new int[iMax];
        int i8 = 0;
        while (true) {
            View[] viewArr6 = this.d0;
            if (i8 >= viewArr6.length) {
                break;
            }
            this.t0[i8] = viewArr6[i8].getId();
            i8++;
        }
        int id = getId();
        int iMax2 = Math.max(this.f0, this.h0);
        float[] fArrC = C(this.f0, this.l0);
        if (this.f0 == 1) {
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) this.d0[0].getLayoutParams();
            t(this.d0[0]);
            layoutParams.i = id;
            layoutParams.l = id;
            this.d0[0].setLayoutParams(layoutParams);
        } else {
            int i9 = 0;
            while (true) {
                i = this.f0;
                if (i9 >= i) {
                    break;
                }
                ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams) this.d0[i9].getLayoutParams();
                t(this.d0[i9]);
                if (fArrC != null) {
                    layoutParams2.I = fArrC[i9];
                }
                if (i9 > 0) {
                    layoutParams2.j = this.t0[i9 - 1];
                } else {
                    layoutParams2.i = id;
                }
                if (i9 < this.f0 - 1) {
                    layoutParams2.k = this.t0[i9 + 1];
                } else {
                    layoutParams2.l = id;
                }
                if (i9 > 0) {
                    ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin = (int) this.n0;
                }
                this.d0[i9].setLayoutParams(layoutParams2);
                i9++;
            }
            while (i < iMax2) {
                ConstraintLayout.LayoutParams layoutParams3 = (ConstraintLayout.LayoutParams) this.d0[i].getLayoutParams();
                t(this.d0[i]);
                layoutParams3.i = id;
                layoutParams3.l = id;
                this.d0[i].setLayoutParams(layoutParams3);
                i++;
            }
        }
        int id2 = getId();
        int iMax3 = Math.max(this.f0, this.h0);
        float[] fArrC2 = C(this.h0, this.m0);
        ConstraintLayout.LayoutParams layoutParams4 = (ConstraintLayout.LayoutParams) this.d0[0].getLayoutParams();
        if (this.h0 == 1) {
            s(this.d0[0]);
            layoutParams4.e = id2;
            layoutParams4.h = id2;
            this.d0[0].setLayoutParams(layoutParams4);
        } else {
            int i10 = 0;
            while (true) {
                i2 = this.h0;
                if (i10 >= i2) {
                    break;
                }
                ConstraintLayout.LayoutParams layoutParams5 = (ConstraintLayout.LayoutParams) this.d0[i10].getLayoutParams();
                s(this.d0[i10]);
                if (fArrC2 != null) {
                    layoutParams5.H = fArrC2[i10];
                }
                if (i10 > 0) {
                    layoutParams5.f = this.t0[i10 - 1];
                } else {
                    layoutParams5.e = id2;
                }
                if (i10 < this.h0 - 1) {
                    layoutParams5.g = this.t0[i10 + 1];
                } else {
                    layoutParams5.h = id2;
                }
                if (i10 > 0) {
                    ((ViewGroup.MarginLayoutParams) layoutParams5).leftMargin = (int) this.n0;
                }
                this.d0[i10].setLayoutParams(layoutParams5);
                i10++;
            }
            while (i2 < iMax3) {
                ConstraintLayout.LayoutParams layoutParams6 = (ConstraintLayout.LayoutParams) this.d0[i2].getLayoutParams();
                s(this.d0[i2]);
                layoutParams6.e = id2;
                layoutParams6.h = id2;
                this.d0[i2].setLayoutParams(layoutParams6);
                i2++;
            }
        }
        String str = this.k0;
        if (str != null && !str.trim().isEmpty() && (iArrB2 = B(this.k0)) != null) {
            for (int i11 = 0; i11 < iArrB2.length; i11++) {
                int iX = x(iArrB2[i11][0]);
                int iW = w(iArrB2[i11][0]);
                int[] iArr = iArrB2[i11];
                if (!z(iX, iW, iArr[1], iArr[2])) {
                    break;
                }
            }
        }
        String str2 = this.j0;
        if (str2 != null && !str2.trim().isEmpty() && (iArrB = B(this.j0)) != null) {
            int[] iArr2 = this.f306a;
            View[] viewArrJ = j(this.e0);
            for (int i12 = 0; i12 < iArrB.length; i12++) {
                int iX2 = x(iArrB[i12][0]);
                int iW2 = w(iArrB[i12][0]);
                int[] iArr3 = iArrB[i12];
                if (!z(iX2, iW2, iArr3[1], iArr3[2])) {
                    break;
                }
                View view = viewArrJ[i12];
                int[] iArr4 = iArrB[i12];
                u(view, iX2, iW2, iArr4[1], iArr4[2]);
                hashSet.add(Integer.valueOf(iArr2[i12]));
            }
        }
        View[] viewArrJ2 = j(this.e0);
        for (int i13 = 0; i13 < this.b; i13++) {
            if (!hashSet.contains(Integer.valueOf(this.f306a[i13]))) {
                int nextPosition = getNextPosition();
                int iX3 = x(nextPosition);
                int iW3 = w(nextPosition);
                if (nextPosition == -1) {
                    return;
                } else {
                    u(viewArrJ2[i13], iX3, iW3, 1, 1);
                }
            }
        }
    }

    public final int w(int i) {
        return this.p0 == 1 ? i / this.f0 : i % this.h0;
    }

    public final int x(int i) {
        return this.p0 == 1 ? i % this.f0 : i / this.h0;
    }

    public final void y() {
        boolean[][] zArr = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.f0, this.h0);
        this.r0 = zArr;
        for (boolean[] zArr2 : zArr) {
            Arrays.fill(zArr2, true);
        }
    }

    public final boolean z(int i, int i2, int i3, int i4) {
        for (int i5 = i; i5 < i + i3; i5++) {
            for (int i6 = i2; i6 < i2 + i4; i6++) {
                boolean[][] zArr = this.r0;
                if (i5 < zArr.length && i6 < zArr[0].length) {
                    boolean[] zArr2 = zArr[i5];
                    if (zArr2[i6]) {
                        zArr2[i6] = false;
                    }
                }
                return false;
            }
        }
        return true;
    }

    public Grid(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.q0 = 0;
        this.s0 = new HashSet();
    }
}

package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.R$styleable;
import defpackage.lg;
import defpackage.qa4;
import defpackage.sj0;
import defpackage.zn6;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class Carousel extends MotionHelper {
    public final ArrayList f0;
    public int g0;
    public MotionLayout h0;
    public int i0;
    public boolean j0;
    public int k0;
    public int l0;
    public int m0;
    public int n0;
    public float o0;
    public int p0;
    public int q0;
    public float r0;

    public Carousel(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f0 = new ArrayList();
        this.g0 = 0;
        this.i0 = -1;
        this.j0 = false;
        this.k0 = -1;
        this.l0 = -1;
        this.m0 = -1;
        this.n0 = -1;
        this.o0 = 0.9f;
        this.p0 = 4;
        this.q0 = 1;
        this.r0 = 2.0f;
        new lg(this, 3);
        s(context, attributeSet);
    }

    @Override // androidx.constraintlayout.motion.widget.MotionHelper, defpackage.la4
    public final void a(int i) {
        int i2 = this.g0;
        if (i == this.n0) {
            this.g0 = i2 + 1;
        } else if (i == this.m0) {
            this.g0 = i2 - 1;
        }
        if (!this.j0) {
            throw null;
        }
        throw null;
    }

    public int getCount() {
        return 0;
    }

    public int getCurrentIndex() {
        return this.g0;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        zn6 zn6Var;
        zn6 zn6Var2;
        super.onAttachedToWindow();
        if (getParent() instanceof MotionLayout) {
            MotionLayout motionLayout = (MotionLayout) getParent();
            ArrayList arrayList = this.f0;
            arrayList.clear();
            for (int i = 0; i < this.b; i++) {
                arrayList.add(motionLayout.c(this.f306a[i]));
            }
            this.h0 = motionLayout;
            if (this.q0 == 2) {
                qa4 qa4VarR = motionLayout.r(this.l0);
                if (qa4VarR != null && (zn6Var2 = qa4VarR.l) != null) {
                    zn6Var2.c = 5;
                }
                qa4 qa4VarR2 = this.h0.r(this.k0);
                if (qa4VarR2 == null || (zn6Var = qa4VarR2.l) == null) {
                    return;
                }
                zn6Var.c = 5;
            }
        }
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f0.clear();
    }

    public final void s(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Carousel);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.Carousel_carousel_firstView) {
                    this.i0 = typedArrayObtainStyledAttributes.getResourceId(index, this.i0);
                } else if (index == R$styleable.Carousel_carousel_backwardTransition) {
                    this.k0 = typedArrayObtainStyledAttributes.getResourceId(index, this.k0);
                } else if (index == R$styleable.Carousel_carousel_forwardTransition) {
                    this.l0 = typedArrayObtainStyledAttributes.getResourceId(index, this.l0);
                } else if (index == R$styleable.Carousel_carousel_emptyViewsBehavior) {
                    this.p0 = typedArrayObtainStyledAttributes.getInt(index, this.p0);
                } else if (index == R$styleable.Carousel_carousel_previousState) {
                    this.m0 = typedArrayObtainStyledAttributes.getResourceId(index, this.m0);
                } else if (index == R$styleable.Carousel_carousel_nextState) {
                    this.n0 = typedArrayObtainStyledAttributes.getResourceId(index, this.n0);
                } else if (index == R$styleable.Carousel_carousel_touchUp_dampeningFactor) {
                    this.o0 = typedArrayObtainStyledAttributes.getFloat(index, this.o0);
                } else if (index == R$styleable.Carousel_carousel_touchUpMode) {
                    this.q0 = typedArrayObtainStyledAttributes.getInt(index, this.q0);
                } else if (index == R$styleable.Carousel_carousel_touchUp_velocityThreshold) {
                    this.r0 = typedArrayObtainStyledAttributes.getFloat(index, this.r0);
                } else if (index == R$styleable.Carousel_carousel_infinite) {
                    this.j0 = typedArrayObtainStyledAttributes.getBoolean(index, this.j0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void setAdapter(sj0 sj0Var) {
    }

    public void setInfinite(boolean z) {
        this.j0 = z;
    }

    public Carousel(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f0 = new ArrayList();
        this.g0 = 0;
        this.i0 = -1;
        this.j0 = false;
        this.k0 = -1;
        this.l0 = -1;
        this.m0 = -1;
        this.n0 = -1;
        this.o0 = 0.9f;
        this.p0 = 4;
        this.q0 = 1;
        this.r0 = 2.0f;
        new lg(this, 3);
        s(context, attributeSet);
    }
}

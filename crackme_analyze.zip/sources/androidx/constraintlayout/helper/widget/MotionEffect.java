package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class MotionEffect extends MotionHelper {
    public float f0;
    public int g0;
    public int h0;
    public int i0;
    public int j0;
    public boolean k0;
    public int l0;
    public int m0;

    public MotionEffect(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f0 = 0.1f;
        this.g0 = 49;
        this.h0 = 50;
        this.i0 = 0;
        this.j0 = 0;
        this.k0 = true;
        this.l0 = -1;
        this.m0 = -1;
        s(context, attributeSet);
    }

    /* JADX WARN: Code restructure failed: missing block: B:56:0x016b, code lost:
    
        if (r15 == 0.0f) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0186, code lost:
    
        if (r15 == 0.0f) goto L59;
     */
    /* JADX WARN: Removed duplicated region for block: B:91:0x01b8  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x01d9  */
    @Override // androidx.constraintlayout.motion.widget.MotionHelper
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void r(androidx.constraintlayout.motion.widget.MotionLayout r24, java.util.HashMap r25) {
        /*
            Method dump skipped, instruction units count: 552
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.helper.widget.MotionEffect.r(androidx.constraintlayout.motion.widget.MotionLayout, java.util.HashMap):void");
    }

    public final void s(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.MotionEffect);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.MotionEffect_motionEffect_start) {
                    int i2 = typedArrayObtainStyledAttributes.getInt(index, this.g0);
                    this.g0 = i2;
                    this.g0 = Math.max(Math.min(i2, 99), 0);
                } else if (index == R$styleable.MotionEffect_motionEffect_end) {
                    int i3 = typedArrayObtainStyledAttributes.getInt(index, this.h0);
                    this.h0 = i3;
                    this.h0 = Math.max(Math.min(i3, 99), 0);
                } else if (index == R$styleable.MotionEffect_motionEffect_translationX) {
                    this.i0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.i0);
                } else if (index == R$styleable.MotionEffect_motionEffect_translationY) {
                    this.j0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.j0);
                } else if (index == R$styleable.MotionEffect_motionEffect_alpha) {
                    this.f0 = typedArrayObtainStyledAttributes.getFloat(index, this.f0);
                } else if (index == R$styleable.MotionEffect_motionEffect_move) {
                    this.m0 = typedArrayObtainStyledAttributes.getInt(index, this.m0);
                } else if (index == R$styleable.MotionEffect_motionEffect_strict) {
                    this.k0 = typedArrayObtainStyledAttributes.getBoolean(index, this.k0);
                } else if (index == R$styleable.MotionEffect_motionEffect_viewTransition) {
                    this.l0 = typedArrayObtainStyledAttributes.getResourceId(index, this.l0);
                }
            }
            int i4 = this.g0;
            int i5 = this.h0;
            if (i4 == i5) {
                if (i4 > 0) {
                    this.g0 = i4 - 1;
                } else {
                    this.h0 = i5 + 1;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public MotionEffect(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f0 = 0.1f;
        this.g0 = 49;
        this.h0 = 50;
        this.i0 = 0;
        this.j0 = 0;
        this.k0 = true;
        this.l0 = -1;
        this.m0 = -1;
        s(context, attributeSet);
    }
}

package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;
import androidx.constraintlayout.widget.VirtualLayout;
import io.sentry.android.core.o0;
import java.util.Arrays;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class CircularFlow extends VirtualLayout {
    public static int n0;
    public static float o0;
    public ConstraintLayout d0;
    public int e0;
    public float[] f0;
    public int[] g0;
    public int h0;
    public int i0;
    public String j0;
    public String k0;
    public Float l0;
    public Integer m0;

    public CircularFlow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    private void setAngles(String str) {
        if (str == null) {
            return;
        }
        int i = 0;
        this.i0 = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i);
            if (iIndexOf == -1) {
                s(str.substring(i).trim());
                return;
            } else {
                s(str.substring(i, iIndexOf).trim());
                i = iIndexOf + 1;
            }
        }
    }

    private void setRadius(String str) {
        if (str == null) {
            return;
        }
        int i = 0;
        this.h0 = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i);
            if (iIndexOf == -1) {
                t(str.substring(i).trim());
                return;
            } else {
                t(str.substring(i, iIndexOf).trim());
                i = iIndexOf + 1;
            }
        }
    }

    public float[] getAngles() {
        return Arrays.copyOf(this.f0, this.i0);
    }

    public int[] getRadius() {
        return Arrays.copyOf(this.g0, this.h0);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.ConstraintLayout_Layout_circularflow_viewCenter) {
                    this.e0 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_circularflow_angles) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.j0 = string;
                    setAngles(string);
                } else if (index == R$styleable.ConstraintLayout_Layout_circularflow_radiusInDP) {
                    String string2 = typedArrayObtainStyledAttributes.getString(index);
                    this.k0 = string2;
                    setRadius(string2);
                } else if (index == R$styleable.ConstraintLayout_Layout_circularflow_defaultAngle) {
                    Float fValueOf = Float.valueOf(typedArrayObtainStyledAttributes.getFloat(index, o0));
                    this.l0 = fValueOf;
                    setDefaultAngle(fValueOf.floatValue());
                } else if (index == R$styleable.ConstraintLayout_Layout_circularflow_defaultRadius) {
                    Integer numValueOf = Integer.valueOf(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, n0));
                    this.m0 = numValueOf;
                    setDefaultRadius(numValueOf.intValue());
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.j0;
        if (str != null) {
            this.f0 = new float[1];
            setAngles(str);
        }
        String str2 = this.k0;
        if (str2 != null) {
            this.g0 = new int[1];
            setRadius(str2);
        }
        Float f = this.l0;
        if (f != null) {
            setDefaultAngle(f.floatValue());
        }
        Integer num = this.m0;
        if (num != null) {
            setDefaultRadius(num.intValue());
        }
        HashMap map = this.w;
        this.d0 = (ConstraintLayout) getParent();
        for (int i = 0; i < this.b; i++) {
            View viewC = this.d0.c(this.f306a[i]);
            if (viewC != null) {
                int i2 = n0;
                float f2 = o0;
                int[] iArr = this.g0;
                if (iArr == null || i >= iArr.length) {
                    Integer num2 = this.m0;
                    if (num2 == null || num2.intValue() == -1) {
                        o0.d("CircularFlow", "Added radius to view with id: " + ((String) map.get(Integer.valueOf(viewC.getId()))));
                    } else {
                        this.h0++;
                        if (this.g0 == null) {
                            this.g0 = new int[1];
                        }
                        int[] radius = getRadius();
                        this.g0 = radius;
                        radius[this.h0 - 1] = i2;
                    }
                } else {
                    i2 = iArr[i];
                }
                float[] fArr = this.f0;
                if (fArr == null || i >= fArr.length) {
                    Float f3 = this.l0;
                    if (f3 == null || f3.floatValue() == -1.0f) {
                        o0.d("CircularFlow", "Added angle to view with id: " + ((String) map.get(Integer.valueOf(viewC.getId()))));
                    } else {
                        this.i0++;
                        if (this.f0 == null) {
                            this.f0 = new float[1];
                        }
                        float[] angles = getAngles();
                        this.f0 = angles;
                        angles[this.i0 - 1] = f2;
                    }
                } else {
                    f2 = fArr[i];
                }
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) viewC.getLayoutParams();
                layoutParams.r = f2;
                layoutParams.p = this.e0;
                layoutParams.q = i2;
                viewC.setLayoutParams(layoutParams);
            }
        }
        e();
    }

    public final void s(String str) {
        float[] fArr;
        if (str == null || str.length() == 0 || this.c == null || (fArr = this.f0) == null) {
            return;
        }
        if (this.i0 + 1 > fArr.length) {
            this.f0 = Arrays.copyOf(fArr, fArr.length + 1);
        }
        this.f0[this.i0] = Integer.parseInt(str);
        this.i0++;
    }

    public void setDefaultAngle(float f) {
        o0 = f;
    }

    public void setDefaultRadius(int i) {
        n0 = i;
    }

    public final void t(String str) {
        int[] iArr;
        Context context = this.c;
        if (str == null || str.length() == 0 || context == null || (iArr = this.g0) == null) {
            return;
        }
        if (this.h0 + 1 > iArr.length) {
            this.g0 = Arrays.copyOf(iArr, iArr.length + 1);
        }
        this.g0[this.h0] = (int) (Integer.parseInt(str) * context.getResources().getDisplayMetrics().density);
        this.h0++;
    }

    public CircularFlow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}

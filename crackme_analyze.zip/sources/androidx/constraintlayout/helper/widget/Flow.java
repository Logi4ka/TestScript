package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.Constraints;
import androidx.constraintlayout.widget.R$styleable;
import androidx.constraintlayout.widget.VirtualLayout;
import androidx.constraintlayout.widget.c;
import defpackage.cg7;
import defpackage.lz0;
import defpackage.nd2;
import defpackage.wt2;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class Flow extends VirtualLayout {
    public nd2 d0;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.d0 = new nd2();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.ConstraintLayout_Layout_android_orientation) {
                    this.d0.Z0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_padding) {
                    nd2 nd2Var = this.d0;
                    int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    nd2Var.w0 = dimensionPixelSize;
                    nd2Var.x0 = dimensionPixelSize;
                    nd2Var.y0 = dimensionPixelSize;
                    nd2Var.z0 = dimensionPixelSize;
                } else if (index == R$styleable.ConstraintLayout_Layout_android_paddingStart) {
                    nd2 nd2Var2 = this.d0;
                    int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    nd2Var2.y0 = dimensionPixelSize2;
                    nd2Var2.A0 = dimensionPixelSize2;
                    nd2Var2.B0 = dimensionPixelSize2;
                } else if (index == R$styleable.ConstraintLayout_Layout_android_paddingEnd) {
                    this.d0.z0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_paddingLeft) {
                    this.d0.A0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_paddingTop) {
                    this.d0.w0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_paddingRight) {
                    this.d0.B0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_paddingBottom) {
                    this.d0.x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_wrapMode) {
                    this.d0.X0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_horizontalStyle) {
                    this.d0.H0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_verticalStyle) {
                    this.d0.I0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_firstHorizontalStyle) {
                    this.d0.J0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_lastHorizontalStyle) {
                    this.d0.L0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_firstVerticalStyle) {
                    this.d0.K0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_lastVerticalStyle) {
                    this.d0.M0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_horizontalBias) {
                    this.d0.N0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_firstHorizontalBias) {
                    this.d0.P0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_lastHorizontalBias) {
                    this.d0.R0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_firstVerticalBias) {
                    this.d0.Q0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_lastVerticalBias) {
                    this.d0.S0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_verticalBias) {
                    this.d0.O0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_horizontalAlign) {
                    this.d0.V0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_verticalAlign) {
                    this.d0.W0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_horizontalGap) {
                    this.d0.T0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_verticalGap) {
                    this.d0.U0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == R$styleable.ConstraintLayout_Layout_flow_maxElementsWrap) {
                    this.d0.Y0 = typedArrayObtainStyledAttributes.getInt(index, -1);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.d = this.d0;
        q();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void l(c cVar, wt2 wt2Var, Constraints.LayoutParams layoutParams, SparseArray sparseArray) {
        super.l(cVar, wt2Var, layoutParams, sparseArray);
        if (wt2Var instanceof nd2) {
            nd2 nd2Var = (nd2) wt2Var;
            int i = layoutParams.V;
            if (i != -1) {
                nd2Var.Z0 = i;
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void m(lz0 lz0Var, boolean z) {
        nd2 nd2Var = this.d0;
        int i = nd2Var.y0;
        if (i > 0 || nd2Var.z0 > 0) {
            if (z) {
                nd2Var.A0 = nd2Var.z0;
                nd2Var.B0 = i;
            } else {
                nd2Var.A0 = i;
                nd2Var.B0 = nd2Var.z0;
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onMeasure(int i, int i2) {
        r(this.d0, i, i2);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout
    public final void r(cg7 cg7Var, int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (cg7Var == null) {
            setMeasuredDimension(0, 0);
        } else {
            cg7Var.V(mode, size, mode2, size2);
            setMeasuredDimension(cg7Var.D0, cg7Var.E0);
        }
    }

    public void setFirstHorizontalBias(float f) {
        this.d0.P0 = f;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i) {
        this.d0.J0 = i;
        requestLayout();
    }

    public void setFirstVerticalBias(float f) {
        this.d0.Q0 = f;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i) {
        this.d0.K0 = i;
        requestLayout();
    }

    public void setHorizontalAlign(int i) {
        this.d0.V0 = i;
        requestLayout();
    }

    public void setHorizontalBias(float f) {
        this.d0.N0 = f;
        requestLayout();
    }

    public void setHorizontalGap(int i) {
        this.d0.T0 = i;
        requestLayout();
    }

    public void setHorizontalStyle(int i) {
        this.d0.H0 = i;
        requestLayout();
    }

    public void setLastHorizontalBias(float f) {
        this.d0.R0 = f;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i) {
        this.d0.L0 = i;
        requestLayout();
    }

    public void setLastVerticalBias(float f) {
        this.d0.S0 = f;
        requestLayout();
    }

    public void setLastVerticalStyle(int i) {
        this.d0.M0 = i;
        requestLayout();
    }

    public void setMaxElementsWrap(int i) {
        this.d0.Y0 = i;
        requestLayout();
    }

    public void setOrientation(int i) {
        this.d0.Z0 = i;
        requestLayout();
    }

    public void setPadding(int i) {
        nd2 nd2Var = this.d0;
        nd2Var.w0 = i;
        nd2Var.x0 = i;
        nd2Var.y0 = i;
        nd2Var.z0 = i;
        requestLayout();
    }

    public void setPaddingBottom(int i) {
        this.d0.x0 = i;
        requestLayout();
    }

    public void setPaddingLeft(int i) {
        this.d0.A0 = i;
        requestLayout();
    }

    public void setPaddingRight(int i) {
        this.d0.B0 = i;
        requestLayout();
    }

    public void setPaddingTop(int i) {
        this.d0.w0 = i;
        requestLayout();
    }

    public void setVerticalAlign(int i) {
        this.d0.W0 = i;
        requestLayout();
    }

    public void setVerticalBias(float f) {
        this.d0.O0 = f;
        requestLayout();
    }

    public void setVerticalGap(int i) {
        this.d0.U0 = i;
        requestLayout();
    }

    public void setVerticalStyle(int i) {
        this.d0.I0 = i;
        requestLayout();
    }

    public void setWrapMode(int i) {
        this.d0.X0 = i;
        requestLayout();
    }

    public Flow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}

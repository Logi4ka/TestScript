package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;
import defpackage.lz0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class Layer extends ConstraintHelper {
    public float b0;
    public float c0;
    public float d0;
    public ConstraintLayout e0;
    public float f0;
    public float g0;
    public float h0;
    public float i0;
    public float j0;
    public float k0;
    public float l0;
    public float m0;
    public final boolean n0;
    public View[] o0;
    public float p0;
    public float q0;
    public boolean r0;
    public boolean s0;

    public Layer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b0 = Float.NaN;
        this.c0 = Float.NaN;
        this.d0 = Float.NaN;
        this.f0 = 1.0f;
        this.g0 = 1.0f;
        this.h0 = Float.NaN;
        this.i0 = Float.NaN;
        this.j0 = Float.NaN;
        this.k0 = Float.NaN;
        this.l0 = Float.NaN;
        this.m0 = Float.NaN;
        this.n0 = true;
        this.o0 = null;
        this.p0 = 0.0f;
        this.q0 = 0.0f;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void g(ConstraintLayout constraintLayout) {
        f(constraintLayout);
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.e = false;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.ConstraintLayout_Layout_android_visibility) {
                    this.r0 = true;
                } else if (index == R$styleable.ConstraintLayout_Layout_android_elevation) {
                    this.s0 = true;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void n() {
        s();
        this.h0 = Float.NaN;
        this.i0 = Float.NaN;
        lz0 lz0Var = ((ConstraintLayout.LayoutParams) getLayoutParams()).q0;
        lz0Var.P(0);
        lz0Var.M(0);
        r();
        layout(((int) this.l0) - getPaddingLeft(), ((int) this.m0) - getPaddingTop(), getPaddingRight() + ((int) this.j0), getPaddingBottom() + ((int) this.k0));
        t();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void o(ConstraintLayout constraintLayout) {
        this.e0 = constraintLayout;
        float rotation = getRotation();
        if (rotation != 0.0f) {
            this.d0 = rotation;
        } else {
            if (Float.isNaN(this.d0)) {
                return;
            }
            this.d0 = rotation;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.e0 = (ConstraintLayout) getParent();
        if (this.r0 || this.s0) {
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i = 0; i < this.b; i++) {
                View viewC = this.e0.c(this.f306a[i]);
                if (viewC != null) {
                    if (this.r0) {
                        viewC.setVisibility(visibility);
                    }
                    if (this.s0 && elevation > 0.0f) {
                        viewC.setTranslationZ(viewC.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    public final void r() {
        if (this.e0 == null) {
            return;
        }
        if (this.n0 || Float.isNaN(this.h0) || Float.isNaN(this.i0)) {
            if (!Float.isNaN(this.b0) && !Float.isNaN(this.c0)) {
                this.i0 = this.c0;
                this.h0 = this.b0;
                return;
            }
            View[] viewArrJ = j(this.e0);
            int left = viewArrJ[0].getLeft();
            int top = viewArrJ[0].getTop();
            int right = viewArrJ[0].getRight();
            int bottom = viewArrJ[0].getBottom();
            for (int i = 0; i < this.b; i++) {
                View view = viewArrJ[i];
                left = Math.min(left, view.getLeft());
                top = Math.min(top, view.getTop());
                right = Math.max(right, view.getRight());
                bottom = Math.max(bottom, view.getBottom());
            }
            this.j0 = right;
            this.k0 = bottom;
            this.l0 = left;
            this.m0 = top;
            if (Float.isNaN(this.b0)) {
                this.h0 = (left + right) / 2;
            } else {
                this.h0 = this.b0;
            }
            if (Float.isNaN(this.c0)) {
                this.i0 = (top + bottom) / 2;
            } else {
                this.i0 = this.c0;
            }
        }
    }

    public final void s() {
        int i;
        if (this.e0 == null || (i = this.b) == 0) {
            return;
        }
        View[] viewArr = this.o0;
        if (viewArr == null || viewArr.length != i) {
            this.o0 = new View[i];
        }
        for (int i2 = 0; i2 < this.b; i2++) {
            this.o0[i2] = this.e0.c(this.f306a[i2]);
        }
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        e();
    }

    @Override // android.view.View
    public void setPivotX(float f) {
        this.b0 = f;
        t();
    }

    @Override // android.view.View
    public void setPivotY(float f) {
        this.c0 = f;
        t();
    }

    @Override // android.view.View
    public void setRotation(float f) {
        this.d0 = f;
        t();
    }

    @Override // android.view.View
    public void setScaleX(float f) {
        this.f0 = f;
        t();
    }

    @Override // android.view.View
    public void setScaleY(float f) {
        this.g0 = f;
        t();
    }

    @Override // android.view.View
    public void setTranslationX(float f) {
        this.p0 = f;
        t();
    }

    @Override // android.view.View
    public void setTranslationY(float f) {
        this.q0 = f;
        t();
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        e();
    }

    public final void t() {
        if (this.e0 == null) {
            return;
        }
        if (this.o0 == null) {
            s();
        }
        r();
        double radians = Float.isNaN(this.d0) ? 0.0d : Math.toRadians(this.d0);
        float fSin = (float) Math.sin(radians);
        float fCos = (float) Math.cos(radians);
        float f = this.f0;
        float f2 = f * fCos;
        float f3 = this.g0;
        float f4 = (-f3) * fSin;
        float f5 = f * fSin;
        float f6 = f3 * fCos;
        for (int i = 0; i < this.b; i++) {
            View view = this.o0[i];
            int right = (view.getRight() + view.getLeft()) / 2;
            int bottom = (view.getBottom() + view.getTop()) / 2;
            float f7 = right - this.h0;
            float f8 = bottom - this.i0;
            float f9 = (((f4 * f8) + (f2 * f7)) - f7) + this.p0;
            float f10 = (((f6 * f8) + (f7 * f5)) - f8) + this.q0;
            view.setTranslationX(f9);
            view.setTranslationY(f10);
            view.setScaleY(this.g0);
            view.setScaleX(this.f0);
            if (!Float.isNaN(this.d0)) {
                view.setRotation(this.d0);
            }
        }
    }

    public Layer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.b0 = Float.NaN;
        this.c0 = Float.NaN;
        this.d0 = Float.NaN;
        this.f0 = 1.0f;
        this.g0 = 1.0f;
        this.h0 = Float.NaN;
        this.i0 = Float.NaN;
        this.j0 = Float.NaN;
        this.k0 = Float.NaN;
        this.l0 = Float.NaN;
        this.m0 = Float.NaN;
        this.n0 = true;
        this.o0 = null;
        this.p0 = 0.0f;
        this.q0 = 0.0f;
    }
}

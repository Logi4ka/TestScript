package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.R$styleable;
import defpackage.bx7;
import defpackage.tx2;
import defpackage.ux2;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ImageFilterView extends AppCompatImageView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ux2 f303a;
    public boolean b;
    public RectF b0;
    public Drawable c;
    public final Drawable[] c0;
    public Drawable d;
    public LayerDrawable d0;
    public float e;
    public float e0;
    public float f;
    public float f0;
    public float g0;
    public float h0;
    public float i;
    public Path v;
    public ViewOutlineProvider w;

    public ImageFilterView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f303a = new ux2();
        this.b = true;
        this.c = null;
        this.d = null;
        this.e = 0.0f;
        this.f = 0.0f;
        this.i = Float.NaN;
        this.c0 = new Drawable[2];
        this.e0 = Float.NaN;
        this.f0 = Float.NaN;
        this.g0 = Float.NaN;
        this.h0 = Float.NaN;
        c(context, attributeSet);
    }

    private void setOverlay(boolean z) {
        this.b = z;
    }

    public final void c(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ImageFilterView);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            this.c = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ImageFilterView_altSrc);
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.ImageFilterView_crossfade) {
                    this.e = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == R$styleable.ImageFilterView_warmth) {
                    setWarmth(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_saturation) {
                    setSaturation(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_contrast) {
                    setContrast(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_brightness) {
                    setBrightness(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_round) {
                    setRound(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_roundPercent) {
                    setRoundPercent(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_overlay) {
                    setOverlay(typedArrayObtainStyledAttributes.getBoolean(index, this.b));
                } else if (index == R$styleable.ImageFilterView_imagePanX) {
                    setImagePanX(typedArrayObtainStyledAttributes.getFloat(index, this.e0));
                } else if (index == R$styleable.ImageFilterView_imagePanY) {
                    setImagePanY(typedArrayObtainStyledAttributes.getFloat(index, this.f0));
                } else if (index == R$styleable.ImageFilterView_imageRotate) {
                    setImageRotate(typedArrayObtainStyledAttributes.getFloat(index, this.h0));
                } else if (index == R$styleable.ImageFilterView_imageZoom) {
                    setImageZoom(typedArrayObtainStyledAttributes.getFloat(index, this.g0));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            Drawable drawable = getDrawable();
            this.d = drawable;
            Drawable drawable2 = this.c;
            Drawable[] drawableArr = this.c0;
            if (drawable2 == null || drawable == null) {
                Drawable drawable3 = getDrawable();
                this.d = drawable3;
                if (drawable3 != null) {
                    Drawable drawableMutate = drawable3.mutate();
                    this.d = drawableMutate;
                    drawableArr[0] = drawableMutate;
                    return;
                }
                return;
            }
            Drawable drawableMutate2 = getDrawable().mutate();
            this.d = drawableMutate2;
            drawableArr[0] = drawableMutate2;
            drawableArr[1] = this.c.mutate();
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.d0 = layerDrawable;
            layerDrawable.getDrawable(1).setAlpha((int) (this.e * 255.0f));
            if (!this.b) {
                this.d0.getDrawable(0).setAlpha((int) ((1.0f - this.e) * 255.0f));
            }
            super.setImageDrawable(this.d0);
        }
    }

    public final void d() {
        if (Float.isNaN(this.e0) && Float.isNaN(this.f0) && Float.isNaN(this.g0) && Float.isNaN(this.h0)) {
            return;
        }
        float f = Float.isNaN(this.e0) ? 0.0f : this.e0;
        float f2 = Float.isNaN(this.f0) ? 0.0f : this.f0;
        float f3 = Float.isNaN(this.g0) ? 1.0f : this.g0;
        float f4 = Float.isNaN(this.h0) ? 0.0f : this.h0;
        Matrix matrix = new Matrix();
        matrix.reset();
        float intrinsicWidth = getDrawable().getIntrinsicWidth();
        float intrinsicHeight = getDrawable().getIntrinsicHeight();
        float width = getWidth();
        float height = getHeight();
        float f5 = f3 * (intrinsicWidth * height < intrinsicHeight * width ? width / intrinsicWidth : height / intrinsicHeight);
        matrix.postScale(f5, f5);
        float f6 = intrinsicWidth * f5;
        float f7 = f5 * intrinsicHeight;
        matrix.postTranslate(((((width - f6) * f) + width) - f6) * 0.5f, ((((height - f7) * f2) + height) - f7) * 0.5f);
        matrix.postRotate(f4, width / 2.0f, height / 2.0f);
        setImageMatrix(matrix);
        setScaleType(ImageView.ScaleType.MATRIX);
    }

    public final void e() {
        if (Float.isNaN(this.e0) && Float.isNaN(this.f0) && Float.isNaN(this.g0) && Float.isNaN(this.h0)) {
            setScaleType(ImageView.ScaleType.FIT_CENTER);
        } else {
            d();
        }
    }

    public float getBrightness() {
        return this.f303a.d;
    }

    public float getContrast() {
        return this.f303a.f;
    }

    public float getCrossfade() {
        return this.e;
    }

    public float getImagePanX() {
        return this.e0;
    }

    public float getImagePanY() {
        return this.f0;
    }

    public float getImageRotate() {
        return this.h0;
    }

    public float getImageZoom() {
        return this.g0;
    }

    public float getRound() {
        return this.i;
    }

    public float getRoundPercent() {
        return this.f;
    }

    public float getSaturation() {
        return this.f303a.e;
    }

    public float getWarmth() {
        return this.f303a.g;
    }

    @Override // android.view.View
    public final void layout(int i, int i2, int i3, int i4) {
        super.layout(i, i2, i3, i4);
        d();
    }

    public void setAltImageDrawable(Drawable drawable) {
        Drawable drawableMutate = drawable.mutate();
        this.c = drawableMutate;
        Drawable drawable2 = this.d;
        Drawable[] drawableArr = this.c0;
        drawableArr[0] = drawable2;
        drawableArr[1] = drawableMutate;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.d0 = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.e);
    }

    public void setAltImageResource(int i) {
        Drawable drawableT = bx7.t(getContext(), i);
        this.c = drawableT;
        setAltImageDrawable(drawableT);
    }

    public void setBrightness(float f) {
        ux2 ux2Var = this.f303a;
        ux2Var.d = f;
        ux2Var.a(this);
    }

    public void setContrast(float f) {
        ux2 ux2Var = this.f303a;
        ux2Var.f = f;
        ux2Var.a(this);
    }

    public void setCrossfade(float f) {
        this.e = f;
        if (this.c0 != null) {
            if (!this.b) {
                this.d0.getDrawable(0).setAlpha((int) ((1.0f - this.e) * 255.0f));
            }
            this.d0.getDrawable(1).setAlpha((int) (this.e * 255.0f));
            super.setImageDrawable(this.d0);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatImageView, android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        if (this.c == null || drawable == null) {
            super.setImageDrawable(drawable);
            return;
        }
        Drawable drawableMutate = drawable.mutate();
        this.d = drawableMutate;
        Drawable[] drawableArr = this.c0;
        drawableArr[0] = drawableMutate;
        drawableArr[1] = this.c;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.d0 = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.e);
    }

    public void setImagePanX(float f) {
        this.e0 = f;
        e();
    }

    public void setImagePanY(float f) {
        this.f0 = f;
        e();
    }

    @Override // androidx.appcompat.widget.AppCompatImageView, android.widget.ImageView
    public void setImageResource(int i) {
        if (this.c == null) {
            super.setImageResource(i);
            return;
        }
        Drawable drawableMutate = bx7.t(getContext(), i).mutate();
        this.d = drawableMutate;
        Drawable[] drawableArr = this.c0;
        drawableArr[0] = drawableMutate;
        drawableArr[1] = this.c;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.d0 = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.e);
    }

    public void setImageRotate(float f) {
        this.h0 = f;
        e();
    }

    public void setImageZoom(float f) {
        this.g0 = f;
        e();
    }

    public void setRound(float f) {
        if (Float.isNaN(f)) {
            this.i = f;
            float f2 = this.f;
            this.f = -1.0f;
            setRoundPercent(f2);
            return;
        }
        boolean z = this.i != f;
        this.i = f;
        if (f != 0.0f) {
            if (this.v == null) {
                this.v = new Path();
            }
            if (this.b0 == null) {
                this.b0 = new RectF();
            }
            if (this.w == null) {
                tx2 tx2Var = new tx2(this, 1);
                this.w = tx2Var;
                setOutlineProvider(tx2Var);
            }
            setClipToOutline(true);
            this.b0.set(0.0f, 0.0f, getWidth(), getHeight());
            this.v.reset();
            Path path = this.v;
            RectF rectF = this.b0;
            float f3 = this.i;
            path.addRoundRect(rectF, f3, f3, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f) {
        boolean z = this.f != f;
        this.f = f;
        if (f != 0.0f) {
            if (this.v == null) {
                this.v = new Path();
            }
            if (this.b0 == null) {
                this.b0 = new RectF();
            }
            if (this.w == null) {
                tx2 tx2Var = new tx2(this, 0);
                this.w = tx2Var;
                setOutlineProvider(tx2Var);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f) / 2.0f;
            this.b0.set(0.0f, 0.0f, width, height);
            this.v.reset();
            this.v.addRoundRect(this.b0, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f) {
        ux2 ux2Var = this.f303a;
        ux2Var.e = f;
        ux2Var.a(this);
    }

    public void setWarmth(float f) {
        ux2 ux2Var = this.f303a;
        ux2Var.g = f;
        ux2Var.a(this);
    }

    public ImageFilterView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f303a = new ux2();
        this.b = true;
        this.c = null;
        this.d = null;
        this.e = 0.0f;
        this.f = 0.0f;
        this.i = Float.NaN;
        this.c0 = new Drawable[2];
        this.e0 = Float.NaN;
        this.f0 = Float.NaN;
        this.g0 = Float.NaN;
        this.h0 = Float.NaN;
        c(context, attributeSet);
    }
}

package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class MockView extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint f304a;
    public final Paint b;
    public int b0;
    public final Paint c;
    public int c0;
    public boolean d;
    public boolean e;
    public String f;
    public final Rect i;
    public int v;
    public int w;

    public MockView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f304a = new Paint();
        this.b = new Paint();
        this.c = new Paint();
        this.d = true;
        this.e = true;
        this.f = null;
        this.i = new Rect();
        this.v = Color.argb(255, 0, 0, 0);
        this.w = Color.argb(255, 200, 200, 200);
        this.b0 = Color.argb(255, 50, 50, 50);
        this.c0 = 4;
        a(context, attributeSet);
    }

    public final void a(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.MockView);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.MockView_mock_label) {
                    this.f = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.MockView_mock_showDiagonals) {
                    this.d = typedArrayObtainStyledAttributes.getBoolean(index, this.d);
                } else if (index == R$styleable.MockView_mock_diagonalsColor) {
                    this.v = typedArrayObtainStyledAttributes.getColor(index, this.v);
                } else if (index == R$styleable.MockView_mock_labelBackgroundColor) {
                    this.b0 = typedArrayObtainStyledAttributes.getColor(index, this.b0);
                } else if (index == R$styleable.MockView_mock_labelColor) {
                    this.w = typedArrayObtainStyledAttributes.getColor(index, this.w);
                } else if (index == R$styleable.MockView_mock_showLabel) {
                    this.e = typedArrayObtainStyledAttributes.getBoolean(index, this.e);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        if (this.f == null) {
            try {
                this.f = context.getResources().getResourceEntryName(getId());
            } catch (Exception unused) {
            }
        }
        int i2 = this.v;
        Paint paint = this.f304a;
        paint.setColor(i2);
        paint.setAntiAlias(true);
        int i3 = this.w;
        Paint paint2 = this.b;
        paint2.setColor(i3);
        paint2.setAntiAlias(true);
        this.c.setColor(this.b0);
        this.c0 = Math.round((getResources().getDisplayMetrics().xdpi / 160.0f) * this.c0);
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        Canvas canvas2;
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.d) {
            width--;
            height--;
            float f = width;
            float f2 = height;
            canvas2 = canvas;
            canvas2.drawLine(0.0f, 0.0f, f, f2, this.f304a);
            canvas2.drawLine(0.0f, f2, f, 0.0f, this.f304a);
            canvas2.drawLine(0.0f, 0.0f, f, 0.0f, this.f304a);
            canvas2.drawLine(f, 0.0f, f, f2, this.f304a);
            canvas2.drawLine(f, f2, 0.0f, f2, this.f304a);
            canvas2.drawLine(0.0f, f2, 0.0f, 0.0f, this.f304a);
        } else {
            canvas2 = canvas;
        }
        String str = this.f;
        if (str == null || !this.e) {
            return;
        }
        int length = str.length();
        Paint paint = this.b;
        Rect rect = this.i;
        paint.getTextBounds(str, 0, length, rect);
        float fWidth = (width - rect.width()) / 2.0f;
        float fHeight = ((height - rect.height()) / 2.0f) + rect.height();
        rect.offset((int) fWidth, (int) fHeight);
        int i = rect.left;
        int i2 = this.c0;
        rect.set(i - i2, rect.top - i2, rect.right + i2, rect.bottom + i2);
        canvas2.drawRect(rect, this.c);
        canvas2.drawText(this.f, fWidth, fHeight, paint);
    }

    public MockView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f304a = new Paint();
        this.b = new Paint();
        this.c = new Paint();
        this.d = true;
        this.e = true;
        this.f = null;
        this.i = new Rect();
        this.v = Color.argb(255, 0, 0, 0);
        this.w = Color.argb(255, 200, 200, 200);
        this.b0 = Color.argb(255, 50, 50, 50);
        this.c0 = 4;
        a(context, attributeSet);
    }
}

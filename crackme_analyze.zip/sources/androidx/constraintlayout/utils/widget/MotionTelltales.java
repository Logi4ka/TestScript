package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.ViewParent;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.R$styleable;
import defpackage.aa4;
import defpackage.fa4;
import defpackage.ke0;
import defpackage.na4;
import defpackage.nt;
import defpackage.ue7;
import defpackage.zd7;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class MotionTelltales extends MockView {
    public final Paint d0;
    public MotionLayout e0;
    public final float[] f0;
    public final Matrix g0;
    public int h0;
    public int i0;
    public float j0;

    public MotionTelltales(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = new Paint();
        this.f0 = new float[2];
        this.g0 = new Matrix();
        this.h0 = 0;
        this.i0 = -65281;
        this.j0 = 0.25f;
        b(context, attributeSet);
    }

    public final void b(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.MotionTelltales);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.MotionTelltales_telltales_tailColor) {
                    this.i0 = typedArrayObtainStyledAttributes.getColor(index, this.i0);
                } else if (index == R$styleable.MotionTelltales_telltales_velocityMode) {
                    this.h0 = typedArrayObtainStyledAttributes.getInt(index, this.h0);
                } else if (index == R$styleable.MotionTelltales_telltales_tailScale) {
                    this.j0 = typedArrayObtainStyledAttributes.getFloat(index, this.j0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        int i2 = this.i0;
        Paint paint = this.d0;
        paint.setColor(i2);
        paint.setStrokeWidth(5.0f);
    }

    @Override // android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override // androidx.constraintlayout.utils.widget.MockView, android.view.View
    public final void onDraw(Canvas canvas) {
        int i;
        Matrix matrix;
        int i2;
        float f;
        float[] fArr;
        int i3;
        int i4;
        int i5;
        char c;
        zd7 zd7Var;
        zd7 zd7Var2;
        ue7 ue7Var;
        zd7 zd7Var3;
        zd7 zd7Var4;
        zd7 zd7Var5;
        double[] dArr;
        ke0 ke0Var;
        MotionTelltales motionTelltales = this;
        super.onDraw(canvas);
        Matrix matrix2 = motionTelltales.getMatrix();
        Matrix matrix3 = motionTelltales.g0;
        matrix2.invert(matrix3);
        if (motionTelltales.e0 == null) {
            ViewParent parent = motionTelltales.getParent();
            if (parent instanceof MotionLayout) {
                motionTelltales.e0 = (MotionLayout) parent;
                return;
            }
            return;
        }
        int width = motionTelltales.getWidth();
        int height = motionTelltales.getHeight();
        int i6 = 5;
        float[] fArr2 = {0.1f, 0.25f, 0.5f, 0.75f, 0.9f};
        int i7 = 0;
        while (i7 < i6) {
            float f2 = fArr2[i7];
            int i8 = 0;
            while (i8 < i6) {
                float f3 = fArr2[i8];
                MotionLayout motionLayout = motionTelltales.e0;
                int i9 = motionTelltales.h0;
                float fA = motionLayout.l0;
                float f4 = motionLayout.w0;
                if (motionLayout.j0 != null) {
                    float fSignum = Math.signum(motionLayout.y0 - f4);
                    float interpolation = motionLayout.j0.getInterpolation(motionLayout.w0 + 1.0E-5f);
                    float interpolation2 = motionLayout.j0.getInterpolation(motionLayout.w0);
                    fA = (((interpolation - interpolation2) / 1.0E-5f) * fSignum) / motionLayout.u0;
                    f4 = interpolation2;
                }
                fa4 fa4Var = motionLayout.j0;
                if (fa4Var != null) {
                    fA = fa4Var.a();
                }
                float f5 = fA;
                aa4 aa4Var = (aa4) motionLayout.s0.get(motionTelltales);
                int i10 = i9 & 1;
                float[] fArr3 = motionTelltales.f0;
                if (i10 == 0) {
                    int width2 = motionTelltales.getWidth();
                    int height2 = motionTelltales.getHeight();
                    float[] fArr4 = aa4Var.v;
                    c = 0;
                    na4 na4Var = aa4Var.f;
                    float fB = aa4Var.b(f4, fArr4);
                    f = f5;
                    HashMap map = aa4Var.y;
                    fArr = fArr2;
                    ue7 ue7Var2 = map == null ? null : (ue7) map.get("translationX");
                    i3 = i7;
                    HashMap map2 = aa4Var.y;
                    ue7 ue7Var3 = map2 == null ? null : (ue7) map2.get("translationY");
                    float f6 = f2;
                    HashMap map3 = aa4Var.y;
                    ue7 ue7Var4 = map3 == null ? null : (ue7) map3.get("rotation");
                    i4 = i8;
                    HashMap map4 = aa4Var.y;
                    i2 = height;
                    ue7 ue7Var5 = map4 == null ? null : (ue7) map4.get("scaleX");
                    i = width;
                    HashMap map5 = aa4Var.y;
                    matrix = matrix3;
                    ue7 ue7Var6 = map5 == null ? null : (ue7) map5.get("scaleY");
                    HashMap map6 = aa4Var.z;
                    zd7 zd7Var6 = map6 == null ? null : (zd7) map6.get("translationX");
                    HashMap map7 = aa4Var.z;
                    zd7 zd7Var7 = map7 == null ? null : (zd7) map7.get("translationY");
                    HashMap map8 = aa4Var.z;
                    zd7 zd7Var8 = map8 == null ? null : (zd7) map8.get("rotation");
                    HashMap map9 = aa4Var.z;
                    zd7 zd7Var9 = map9 == null ? null : (zd7) map9.get("scaleX");
                    HashMap map10 = aa4Var.z;
                    zd7 zd7Var10 = map10 != null ? (zd7) map10.get("scaleY") : null;
                    ke0 ke0Var2 = new ke0();
                    i5 = i9;
                    ke0Var2.e = 0.0f;
                    ke0Var2.d = 0.0f;
                    ke0Var2.c = 0.0f;
                    ke0Var2.b = 0.0f;
                    ke0Var2.f3696a = 0.0f;
                    if (ue7Var4 != null) {
                        zd7Var = zd7Var10;
                        zd7Var2 = zd7Var9;
                        ke0Var2.e = (float) ue7Var4.f5863a.S(fB);
                        ke0Var2.f = ue7Var4.a(fB);
                    } else {
                        zd7Var = zd7Var10;
                        zd7Var2 = zd7Var9;
                    }
                    if (ue7Var2 != null) {
                        ue7Var = ue7Var2;
                        ke0Var2.c = (float) ue7Var2.f5863a.S(fB);
                    } else {
                        ue7Var = ue7Var2;
                    }
                    if (ue7Var3 != null) {
                        ke0Var2.d = (float) ue7Var3.f5863a.S(fB);
                    }
                    if (ue7Var5 != null) {
                        ke0Var2.f3696a = (float) ue7Var5.f5863a.S(fB);
                    }
                    if (ue7Var6 != null) {
                        ke0Var2.b = (float) ue7Var6.f5863a.S(fB);
                    }
                    if (zd7Var8 != null) {
                        ke0Var2.e = zd7Var8.b(fB);
                    }
                    if (zd7Var6 != null) {
                        ke0Var2.c = zd7Var6.b(fB);
                    }
                    if (zd7Var7 != null) {
                        ke0Var2.d = zd7Var7.b(fB);
                    }
                    zd7 zd7Var11 = zd7Var2;
                    if (zd7Var2 != null) {
                        ke0Var2.f3696a = zd7Var11.b(fB);
                    }
                    if (zd7Var != null) {
                        zd7Var3 = zd7Var;
                        ke0Var2.b = zd7Var3.b(fB);
                    } else {
                        zd7Var3 = zd7Var;
                    }
                    nt ntVar = aa4Var.k;
                    if (ntVar != null) {
                        double[] dArr2 = aa4Var.p;
                        if (dArr2.length > 0) {
                            double d = fB;
                            ntVar.Q(d, dArr2);
                            aa4Var.k.T(d, aa4Var.q);
                            int[] iArr = aa4Var.o;
                            double[] dArr3 = aa4Var.q;
                            double[] dArr4 = aa4Var.p;
                            na4Var.getClass();
                            na4.e(f3, f6, fArr3, iArr, dArr3, dArr4);
                            fArr3 = fArr3;
                            f2 = f6;
                            f3 = f3;
                            ke0Var = ke0Var2;
                        } else {
                            ke0Var = ke0Var2;
                            f3 = f3;
                            f2 = f6;
                            fArr3 = fArr3;
                        }
                        ke0Var.a(f3, f2, width2, height2, fArr3);
                    } else {
                        fArr3 = fArr3;
                        if (aa4Var.j != null) {
                            double dB = aa4Var.b(fB, fArr4);
                            aa4Var.j[0].T(dB, aa4Var.q);
                            aa4Var.j[0].Q(dB, aa4Var.p);
                            float f7 = fArr4[0];
                            int i11 = 0;
                            while (true) {
                                dArr = aa4Var.q;
                                if (i11 >= dArr.length) {
                                    break;
                                }
                                dArr[i11] = dArr[i11] * ((double) f7);
                                i11++;
                            }
                            int[] iArr2 = aa4Var.o;
                            double[] dArr5 = aa4Var.p;
                            na4Var.getClass();
                            na4.e(f3, f6, fArr3, iArr2, dArr, dArr5);
                            fArr3 = fArr3;
                            f2 = f6;
                            f3 = f3;
                            ke0Var2.a(f3, f2, width2, height2, fArr3);
                        } else {
                            na4 na4Var2 = aa4Var.g;
                            float f8 = na4Var2.e - na4Var.e;
                            float f9 = na4Var2.f - na4Var.f;
                            float f10 = na4Var2.i - na4Var.i;
                            float f11 = f9 + (na4Var2.v - na4Var.v);
                            fArr3[0] = ((f8 + f10) * f3) + ((1.0f - f3) * f8);
                            fArr3[1] = (f11 * f6) + ((1.0f - f6) * f9);
                            ke0Var2.e = 0.0f;
                            ke0Var2.d = 0.0f;
                            ke0Var2.c = 0.0f;
                            ke0Var2.b = 0.0f;
                            ke0Var2.f3696a = 0.0f;
                            if (ue7Var4 != null) {
                                zd7Var4 = zd7Var3;
                                zd7Var5 = zd7Var11;
                                ke0Var2.e = (float) ue7Var4.f5863a.S(fB);
                                ke0Var2.f = ue7Var4.a(fB);
                            } else {
                                zd7Var4 = zd7Var3;
                                zd7Var5 = zd7Var11;
                            }
                            if (ue7Var != null) {
                                ke0Var2.c = (float) ue7Var.f5863a.S(fB);
                            }
                            if (ue7Var3 != null) {
                                ke0Var2.d = (float) ue7Var3.f5863a.S(fB);
                            }
                            if (ue7Var5 != null) {
                                ke0Var2.f3696a = (float) ue7Var5.f5863a.S(fB);
                            }
                            if (ue7Var6 != null) {
                                ke0Var2.b = (float) ue7Var6.f5863a.S(fB);
                            }
                            if (zd7Var8 != null) {
                                ke0Var2.e = zd7Var8.b(fB);
                            }
                            if (zd7Var6 != null) {
                                ke0Var2.c = zd7Var6.b(fB);
                            }
                            if (zd7Var7 != null) {
                                ke0Var2.d = zd7Var7.b(fB);
                            }
                            if (zd7Var5 != null) {
                                ke0Var2.f3696a = zd7Var5.b(fB);
                            }
                            if (zd7Var4 != null) {
                                ke0Var2.b = zd7Var4.b(fB);
                            }
                            f3 = f3;
                            f2 = f6;
                            ke0Var2.a(f3, f2, width2, height2, fArr3);
                        }
                    }
                } else {
                    i = width;
                    matrix = matrix3;
                    i2 = height;
                    f = f5;
                    fArr = fArr2;
                    i3 = i7;
                    i4 = i8;
                    i5 = i9;
                    c = 0;
                    aa4Var.d(f4, f3, f2, fArr3);
                }
                if (i5 < 2) {
                    fArr3[c] = fArr3[c] * f;
                    fArr3[1] = fArr3[1] * f;
                }
                motionTelltales = this;
                float[] fArr5 = motionTelltales.f0;
                matrix3 = matrix;
                matrix3.mapVectors(fArr5);
                int i12 = i;
                float f12 = i12 * f3;
                int i13 = i2;
                float f13 = i13 * f2;
                float f14 = fArr5[c];
                float f15 = motionTelltales.j0;
                float f16 = f13 - (fArr5[1] * f15);
                matrix3.mapVectors(fArr5);
                canvas.drawLine(f12, f13, f12 - (f14 * f15), f16, motionTelltales.d0);
                i8 = i4 + 1;
                width = i12;
                height = i13;
                fArr2 = fArr;
                i7 = i3;
                i6 = 5;
            }
            i7++;
            height = height;
            i6 = 5;
        }
    }

    @Override // android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        postInvalidate();
    }

    public void setText(CharSequence charSequence) {
        this.f = charSequence.toString();
        requestLayout();
    }

    public MotionTelltales(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.d0 = new Paint();
        this.f0 = new float[2];
        this.g0 = new Matrix();
        this.h0 = 0;
        this.i0 = -65281;
        this.j0 = 0.25f;
        b(context, attributeSet);
    }
}

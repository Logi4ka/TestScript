package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.appcompat.R$attr;
import androidx.constraintlayout.widget.R$styleable;
import defpackage.ga4;
import defpackage.p01;
import java.util.Objects;
import okhttp3.internal.http2.Settings;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class MotionLabel extends View {
    public float A0;
    public float B0;
    public float C0;
    public final Paint D0;
    public int E0;
    public Rect F0;
    public Paint G0;
    public float H0;
    public float I0;
    public float J0;
    public float K0;
    public float L0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextPaint f305a;
    public Path b;
    public float b0;
    public int c;
    public float c0;
    public int d;
    public int d0;
    public boolean e;
    public int e0;
    public float f;
    public float f0;
    public String g0;
    public boolean h0;
    public float i;
    public final Rect i0;
    public int j0;
    public int k0;
    public int l0;
    public int m0;
    public String n0;
    public int o0;
    public int p0;
    public boolean q0;
    public float r0;
    public float s0;
    public float t0;
    public Drawable u0;
    public ViewOutlineProvider v;
    public Matrix v0;
    public RectF w;
    public Bitmap w0;
    public BitmapShader x0;
    public Matrix y0;
    public float z0;

    public MotionLabel(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f305a = new TextPaint();
        this.b = new Path();
        this.c = Settings.DEFAULT_INITIAL_WINDOW_SIZE;
        this.d = Settings.DEFAULT_INITIAL_WINDOW_SIZE;
        this.e = false;
        this.f = 0.0f;
        this.i = Float.NaN;
        this.b0 = 48.0f;
        this.c0 = Float.NaN;
        this.f0 = 0.0f;
        this.g0 = "Hello World";
        this.h0 = true;
        this.i0 = new Rect();
        this.j0 = 1;
        this.k0 = 1;
        this.l0 = 1;
        this.m0 = 1;
        this.o0 = 8388659;
        this.p0 = 0;
        this.q0 = false;
        this.z0 = Float.NaN;
        this.A0 = Float.NaN;
        this.B0 = 0.0f;
        this.C0 = 0.0f;
        this.D0 = new Paint();
        this.E0 = 0;
        this.I0 = Float.NaN;
        this.J0 = Float.NaN;
        this.K0 = Float.NaN;
        this.L0 = Float.NaN;
        b(context, attributeSet);
    }

    private float getHorizontalOffset() {
        float f = Float.isNaN(this.c0) ? 1.0f : this.b0 / this.c0;
        String str = this.g0;
        return ((this.B0 + 1.0f) * ((((Float.isNaN(this.s0) ? getMeasuredWidth() : this.s0) - getPaddingLeft()) - getPaddingRight()) - (this.f305a.measureText(str, 0, str.length()) * f))) / 2.0f;
    }

    private float getVerticalOffset() {
        float f = Float.isNaN(this.c0) ? 1.0f : this.b0 / this.c0;
        Paint.FontMetrics fontMetrics = this.f305a.getFontMetrics();
        float measuredHeight = ((Float.isNaN(this.t0) ? getMeasuredHeight() : this.t0) - getPaddingTop()) - getPaddingBottom();
        float f2 = fontMetrics.descent;
        float f3 = fontMetrics.ascent;
        return (((1.0f - this.C0) * (measuredHeight - ((f2 - f3) * f))) / 2.0f) - (f * f3);
    }

    private void setUpTheme(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R$attr.colorPrimary, typedValue, true);
        int i = typedValue.data;
        this.c = i;
        this.f305a.setColor(i);
    }

    public final void a(float f) {
        if (this.e || f != 1.0f) {
            this.b.reset();
            String str = this.g0;
            int length = str.length();
            TextPaint textPaint = this.f305a;
            Rect rect = this.i0;
            textPaint.getTextBounds(str, 0, length, rect);
            textPaint.getTextPath(str, 0, length, 0.0f, 0.0f, this.b);
            if (f != 1.0f) {
                p01.G();
                Matrix matrix = new Matrix();
                matrix.postScale(f, f);
                this.b.transform(matrix);
            }
            rect.right--;
            rect.left++;
            rect.bottom++;
            rect.top--;
            RectF rectF = new RectF();
            rectF.bottom = getHeight();
            rectF.right = getWidth();
            this.h0 = false;
        }
    }

    public final void b(Context context, AttributeSet attributeSet) {
        Typeface typefaceCreate;
        setUpTheme(context);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.MotionLabel);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.MotionLabel_android_text) {
                    setText(typedArrayObtainStyledAttributes.getText(index));
                } else if (index == R$styleable.MotionLabel_android_fontFamily) {
                    this.n0 = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.MotionLabel_scaleFromTextSize) {
                    this.c0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, (int) this.c0);
                } else if (index == R$styleable.MotionLabel_android_textSize) {
                    this.b0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, (int) this.b0);
                } else if (index == R$styleable.MotionLabel_android_textStyle) {
                    this.d0 = typedArrayObtainStyledAttributes.getInt(index, this.d0);
                } else if (index == R$styleable.MotionLabel_android_typeface) {
                    this.e0 = typedArrayObtainStyledAttributes.getInt(index, this.e0);
                } else if (index == R$styleable.MotionLabel_android_textColor) {
                    this.c = typedArrayObtainStyledAttributes.getColor(index, this.c);
                } else if (index == R$styleable.MotionLabel_borderRound) {
                    float dimension = typedArrayObtainStyledAttributes.getDimension(index, this.i);
                    this.i = dimension;
                    setRound(dimension);
                } else if (index == R$styleable.MotionLabel_borderRoundPercent) {
                    float f = typedArrayObtainStyledAttributes.getFloat(index, this.f);
                    this.f = f;
                    setRoundPercent(f);
                } else if (index == R$styleable.MotionLabel_android_gravity) {
                    setGravity(typedArrayObtainStyledAttributes.getInt(index, -1));
                } else if (index == R$styleable.MotionLabel_android_autoSizeTextType) {
                    this.p0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == R$styleable.MotionLabel_textOutlineColor) {
                    this.d = typedArrayObtainStyledAttributes.getInt(index, this.d);
                    this.e = true;
                } else if (index == R$styleable.MotionLabel_textOutlineThickness) {
                    this.f0 = typedArrayObtainStyledAttributes.getDimension(index, this.f0);
                    this.e = true;
                } else if (index == R$styleable.MotionLabel_textBackground) {
                    this.u0 = typedArrayObtainStyledAttributes.getDrawable(index);
                    this.e = true;
                } else if (index == R$styleable.MotionLabel_textBackgroundPanX) {
                    this.I0 = typedArrayObtainStyledAttributes.getFloat(index, this.I0);
                } else if (index == R$styleable.MotionLabel_textBackgroundPanY) {
                    this.J0 = typedArrayObtainStyledAttributes.getFloat(index, this.J0);
                } else if (index == R$styleable.MotionLabel_textPanX) {
                    this.B0 = typedArrayObtainStyledAttributes.getFloat(index, this.B0);
                } else if (index == R$styleable.MotionLabel_textPanY) {
                    this.C0 = typedArrayObtainStyledAttributes.getFloat(index, this.C0);
                } else if (index == R$styleable.MotionLabel_textBackgroundRotate) {
                    this.L0 = typedArrayObtainStyledAttributes.getFloat(index, this.L0);
                } else if (index == R$styleable.MotionLabel_textBackgroundZoom) {
                    this.K0 = typedArrayObtainStyledAttributes.getFloat(index, this.K0);
                } else if (index == R$styleable.MotionLabel_textureHeight) {
                    this.z0 = typedArrayObtainStyledAttributes.getDimension(index, this.z0);
                } else if (index == R$styleable.MotionLabel_textureWidth) {
                    this.A0 = typedArrayObtainStyledAttributes.getDimension(index, this.A0);
                } else if (index == R$styleable.MotionLabel_textureEffect) {
                    this.E0 = typedArrayObtainStyledAttributes.getInt(index, this.E0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        if (this.u0 != null) {
            this.y0 = new Matrix();
            int intrinsicWidth = this.u0.getIntrinsicWidth();
            int intrinsicHeight = this.u0.getIntrinsicHeight();
            if (intrinsicWidth <= 0 && (intrinsicWidth = getWidth()) == 0) {
                intrinsicWidth = Float.isNaN(this.A0) ? 128 : (int) this.A0;
            }
            if (intrinsicHeight <= 0 && (intrinsicHeight = getHeight()) == 0) {
                intrinsicHeight = Float.isNaN(this.z0) ? 128 : (int) this.z0;
            }
            if (this.E0 != 0) {
                intrinsicWidth /= 2;
                intrinsicHeight /= 2;
            }
            this.w0 = Bitmap.createBitmap(intrinsicWidth, intrinsicHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(this.w0);
            this.u0.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            this.u0.setFilterBitmap(true);
            this.u0.draw(canvas);
            if (this.E0 != 0) {
                Bitmap bitmap = this.w0;
                int width = bitmap.getWidth() / 2;
                int height = bitmap.getHeight() / 2;
                Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
                for (int i2 = 0; i2 < 4 && width >= 32 && height >= 32; i2++) {
                    width /= 2;
                    height /= 2;
                    bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapCreateScaledBitmap, width, height, true);
                }
                this.w0 = bitmapCreateScaledBitmap;
            }
            Bitmap bitmap2 = this.w0;
            Shader.TileMode tileMode = Shader.TileMode.REPEAT;
            this.x0 = new BitmapShader(bitmap2, tileMode, tileMode);
        }
        this.j0 = getPaddingLeft();
        this.k0 = getPaddingRight();
        this.l0 = getPaddingTop();
        this.m0 = getPaddingBottom();
        String str = this.n0;
        int i3 = this.e0;
        int i4 = this.d0;
        TextPaint textPaint = this.f305a;
        if (str != null) {
            typefaceCreate = Typeface.create(str, i4);
            if (typefaceCreate != null) {
                setTypeface(typefaceCreate);
            }
            textPaint.setColor(this.c);
            textPaint.setStrokeWidth(this.f0);
            textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            textPaint.setFlags(128);
            setTextSize(this.b0);
            textPaint.setAntiAlias(true);
        }
        typefaceCreate = null;
        if (i3 == 1) {
            typefaceCreate = Typeface.SANS_SERIF;
        } else if (i3 == 2) {
            typefaceCreate = Typeface.SERIF;
        } else if (i3 == 3) {
            typefaceCreate = Typeface.MONOSPACE;
        }
        if (i4 > 0) {
            Typeface typefaceDefaultFromStyle = typefaceCreate == null ? Typeface.defaultFromStyle(i4) : Typeface.create(typefaceCreate, i4);
            setTypeface(typefaceDefaultFromStyle);
            int i5 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i4;
            textPaint.setFakeBoldText((i5 & 1) != 0);
            textPaint.setTextSkewX((i5 & 2) != 0 ? -0.25f : 0.0f);
        } else {
            textPaint.setFakeBoldText(false);
            textPaint.setTextSkewX(0.0f);
            setTypeface(typefaceCreate);
        }
        textPaint.setColor(this.c);
        textPaint.setStrokeWidth(this.f0);
        textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        textPaint.setFlags(128);
        setTextSize(this.b0);
        textPaint.setAntiAlias(true);
    }

    public final void c(float f, float f2, float f3, float f4) {
        int i = (int) (f + 0.5f);
        this.r0 = f - i;
        int i2 = (int) (f3 + 0.5f);
        int i3 = i2 - i;
        int i4 = (int) (f4 + 0.5f);
        int i5 = (int) (0.5f + f2);
        int i6 = i4 - i5;
        float f5 = f3 - f;
        this.s0 = f5;
        float f6 = f4 - f2;
        this.t0 = f6;
        if (this.y0 != null) {
            this.s0 = f5;
            this.t0 = f6;
            d();
        }
        if (getMeasuredHeight() == i6 && getMeasuredWidth() == i3) {
            super.layout(i, i5, i2, i4);
        } else {
            measure(View.MeasureSpec.makeMeasureSpec(i3, 1073741824), View.MeasureSpec.makeMeasureSpec(i6, 1073741824));
            super.layout(i, i5, i2, i4);
        }
        if (this.q0) {
            Rect rect = this.F0;
            TextPaint textPaint = this.f305a;
            if (rect == null) {
                this.G0 = new Paint();
                this.F0 = new Rect();
                this.G0.set(textPaint);
                this.H0 = this.G0.getTextSize();
            }
            this.s0 = f5;
            this.t0 = f6;
            Paint paint = this.G0;
            String str = this.g0;
            paint.getTextBounds(str, 0, str.length(), this.F0);
            float fHeight = this.F0.height() * 1.3f;
            float f7 = (f5 - this.k0) - this.j0;
            float f8 = (f6 - this.m0) - this.l0;
            float fWidth = this.F0.width();
            float f9 = fWidth * f8;
            float f10 = fHeight * f7;
            float f11 = this.H0;
            if (f9 > f10) {
                textPaint.setTextSize((f11 * f7) / fWidth);
            } else {
                textPaint.setTextSize((f11 * f8) / fHeight);
            }
            if (this.e || !Float.isNaN(this.c0)) {
                a(Float.isNaN(this.c0) ? 1.0f : this.b0 / this.c0);
            }
        }
    }

    public final void d() {
        float f = Float.isNaN(this.I0) ? 0.0f : this.I0;
        float f2 = Float.isNaN(this.J0) ? 0.0f : this.J0;
        float f3 = Float.isNaN(this.K0) ? 1.0f : this.K0;
        float f4 = Float.isNaN(this.L0) ? 0.0f : this.L0;
        this.y0.reset();
        float width = this.w0.getWidth();
        float height = this.w0.getHeight();
        float f5 = Float.isNaN(this.A0) ? this.s0 : this.A0;
        float f6 = Float.isNaN(this.z0) ? this.t0 : this.z0;
        float f7 = f3 * (width * f6 < height * f5 ? f5 / width : f6 / height);
        this.y0.postScale(f7, f7);
        float f8 = width * f7;
        float f9 = f5 - f8;
        float f10 = f7 * height;
        float f11 = f6 - f10;
        if (!Float.isNaN(this.z0)) {
            f11 = this.z0 / 2.0f;
        }
        if (!Float.isNaN(this.A0)) {
            f9 = this.A0 / 2.0f;
        }
        this.y0.postTranslate((((f * f9) + f5) - f8) * 0.5f, (((f2 * f11) + f6) - f10) * 0.5f);
        this.y0.postRotate(f4, f5 / 2.0f, f6 / 2.0f);
        this.x0.setLocalMatrix(this.y0);
    }

    public float getRound() {
        return this.i;
    }

    public float getRoundPercent() {
        return this.f;
    }

    public float getScaleFromTextSize() {
        return this.c0;
    }

    public float getTextBackgroundPanX() {
        return this.I0;
    }

    public float getTextBackgroundPanY() {
        return this.J0;
    }

    public float getTextBackgroundRotate() {
        return this.L0;
    }

    public float getTextBackgroundZoom() {
        return this.K0;
    }

    public int getTextOutlineColor() {
        return this.d;
    }

    public float getTextPanX() {
        return this.B0;
    }

    public float getTextPanY() {
        return this.C0;
    }

    public float getTextureHeight() {
        return this.z0;
    }

    public float getTextureWidth() {
        return this.A0;
    }

    public Typeface getTypeface() {
        return this.f305a.getTypeface();
    }

    @Override // android.view.View
    public final void layout(int i, int i2, int i3, int i4) {
        super.layout(i, i2, i3, i4);
        boolean zIsNaN = Float.isNaN(this.c0);
        float f = zIsNaN ? 1.0f : this.b0 / this.c0;
        this.s0 = i3 - i;
        this.t0 = i4 - i2;
        if (this.q0) {
            Rect rect = this.F0;
            TextPaint textPaint = this.f305a;
            if (rect == null) {
                this.G0 = new Paint();
                this.F0 = new Rect();
                this.G0.set(textPaint);
                this.H0 = this.G0.getTextSize();
            }
            Paint paint = this.G0;
            String str = this.g0;
            paint.getTextBounds(str, 0, str.length(), this.F0);
            int iWidth = this.F0.width();
            int iHeight = (int) (this.F0.height() * 1.3f);
            float f2 = (this.s0 - this.k0) - this.j0;
            float f3 = (this.t0 - this.m0) - this.l0;
            if (zIsNaN) {
                float f4 = iWidth;
                float f5 = f4 * f3;
                float f6 = iHeight;
                float f7 = f6 * f2;
                float f8 = this.H0;
                if (f5 > f7) {
                    textPaint.setTextSize((f8 * f2) / f4);
                } else {
                    textPaint.setTextSize((f8 * f3) / f6);
                }
            } else {
                float f9 = iWidth;
                float f10 = iHeight;
                f = f9 * f3 > f10 * f2 ? f2 / f9 : f3 / f10;
            }
        }
        if (this.e || !zIsNaN) {
            float f11 = i;
            float f12 = i2;
            float f13 = i3;
            float f14 = i4;
            if (this.y0 != null) {
                this.s0 = f13 - f11;
                this.t0 = f14 - f12;
                d();
            }
            a(f);
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        float f = Float.isNaN(this.c0) ? 1.0f : this.b0 / this.c0;
        super.onDraw(canvas);
        boolean z = this.e;
        TextPaint textPaint = this.f305a;
        if (!z && f == 1.0f) {
            canvas.drawText(this.g0, this.r0 + this.j0 + getHorizontalOffset(), this.l0 + getVerticalOffset(), textPaint);
            return;
        }
        if (this.h0) {
            a(f);
        }
        if (this.v0 == null) {
            this.v0 = new Matrix();
        }
        if (!this.e) {
            float horizontalOffset = this.j0 + getHorizontalOffset();
            float verticalOffset = this.l0 + getVerticalOffset();
            this.v0.reset();
            this.v0.preTranslate(horizontalOffset, verticalOffset);
            this.b.transform(this.v0);
            textPaint.setColor(this.c);
            textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            textPaint.setStrokeWidth(this.f0);
            canvas.drawPath(this.b, textPaint);
            this.v0.reset();
            this.v0.preTranslate(-horizontalOffset, -verticalOffset);
            this.b.transform(this.v0);
            return;
        }
        Paint paint = this.D0;
        paint.set(textPaint);
        this.v0.reset();
        float horizontalOffset2 = this.j0 + getHorizontalOffset();
        float verticalOffset2 = this.l0 + getVerticalOffset();
        this.v0.postTranslate(horizontalOffset2, verticalOffset2);
        this.v0.preScale(f, f);
        this.b.transform(this.v0);
        if (this.x0 != null) {
            textPaint.setFilterBitmap(true);
            textPaint.setShader(this.x0);
        } else {
            textPaint.setColor(this.c);
        }
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setStrokeWidth(this.f0);
        canvas.drawPath(this.b, textPaint);
        if (this.x0 != null) {
            textPaint.setShader(null);
        }
        textPaint.setColor(this.d);
        textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStrokeWidth(this.f0);
        canvas.drawPath(this.b, textPaint);
        this.v0.reset();
        this.v0.postTranslate(-horizontalOffset2, -verticalOffset2);
        this.b.transform(this.v0);
        textPaint.set(paint);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i);
        int size2 = View.MeasureSpec.getSize(i2);
        this.q0 = false;
        this.j0 = getPaddingLeft();
        this.k0 = getPaddingRight();
        this.l0 = getPaddingTop();
        this.m0 = getPaddingBottom();
        if (mode != 1073741824 || mode2 != 1073741824) {
            String str = this.g0;
            int length = str.length();
            this.f305a.getTextBounds(str, 0, length, this.i0);
            if (mode != 1073741824) {
                size = (int) (r7.width() + 0.99999f);
            }
            size += this.j0 + this.k0;
            if (mode2 != 1073741824) {
                int fontMetricsInt = (int) (r6.getFontMetricsInt(null) + 0.99999f);
                if (mode2 == Integer.MIN_VALUE) {
                    fontMetricsInt = Math.min(size2, fontMetricsInt);
                }
                size2 = this.l0 + this.m0 + fontMetricsInt;
            }
        } else if (this.p0 != 0) {
            this.q0 = true;
        }
        setMeasuredDimension(size, size2);
    }

    public void setGravity(int i) {
        if ((i & 8388615) == 0) {
            i |= 8388611;
        }
        if ((i & 112) == 0) {
            i |= 48;
        }
        if (i != this.o0) {
            invalidate();
        }
        this.o0 = i;
        int i2 = i & 112;
        if (i2 == 48) {
            this.C0 = -1.0f;
        } else if (i2 != 80) {
            this.C0 = 0.0f;
        } else {
            this.C0 = 1.0f;
        }
        int i3 = i & 8388615;
        if (i3 != 3) {
            if (i3 != 5) {
                if (i3 != 8388611) {
                    if (i3 != 8388613) {
                        this.B0 = 0.0f;
                        return;
                    }
                }
            }
            this.B0 = 1.0f;
            return;
        }
        this.B0 = -1.0f;
    }

    public void setRound(float f) {
        if (Float.isNaN(f)) {
            this.i = f;
            float f2 = this.f;
            this.f = -1.0f;
            setRoundPercent(f2);
            return;
        }
        boolean z = this.i != f;
        this.i = f;
        if (f != 0.0f) {
            if (this.b == null) {
                this.b = new Path();
            }
            if (this.w == null) {
                this.w = new RectF();
            }
            if (this.v == null) {
                ga4 ga4Var = new ga4(this, 1);
                this.v = ga4Var;
                setOutlineProvider(ga4Var);
            }
            setClipToOutline(true);
            this.w.set(0.0f, 0.0f, getWidth(), getHeight());
            this.b.reset();
            Path path = this.b;
            RectF rectF = this.w;
            float f3 = this.i;
            path.addRoundRect(rectF, f3, f3, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f) {
        boolean z = this.f != f;
        this.f = f;
        if (f != 0.0f) {
            if (this.b == null) {
                this.b = new Path();
            }
            if (this.w == null) {
                this.w = new RectF();
            }
            if (this.v == null) {
                ga4 ga4Var = new ga4(this, 0);
                this.v = ga4Var;
                setOutlineProvider(ga4Var);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f) / 2.0f;
            this.w.set(0.0f, 0.0f, width, height);
            this.b.reset();
            this.b.addRoundRect(this.w, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z) {
            invalidateOutline();
        }
    }

    public void setScaleFromTextSize(float f) {
        this.c0 = f;
    }

    public void setText(CharSequence charSequence) {
        this.g0 = charSequence.toString();
        invalidate();
    }

    public void setTextBackgroundPanX(float f) {
        this.I0 = f;
        d();
        invalidate();
    }

    public void setTextBackgroundPanY(float f) {
        this.J0 = f;
        d();
        invalidate();
    }

    public void setTextBackgroundRotate(float f) {
        this.L0 = f;
        d();
        invalidate();
    }

    public void setTextBackgroundZoom(float f) {
        this.K0 = f;
        d();
        invalidate();
    }

    public void setTextFillColor(int i) {
        this.c = i;
        invalidate();
    }

    public void setTextOutlineColor(int i) {
        this.d = i;
        this.e = true;
        invalidate();
    }

    public void setTextOutlineThickness(float f) {
        this.f0 = f;
        this.e = true;
        if (Float.isNaN(f)) {
            this.f0 = 1.0f;
            this.e = false;
        }
        invalidate();
    }

    public void setTextPanX(float f) {
        this.B0 = f;
        invalidate();
    }

    public void setTextPanY(float f) {
        this.C0 = f;
        invalidate();
    }

    public void setTextSize(float f) {
        this.b0 = f;
        if (!Float.isNaN(this.c0)) {
            f = this.c0;
        }
        this.f305a.setTextSize(f);
        a(Float.isNaN(this.c0) ? 1.0f : this.b0 / this.c0);
        requestLayout();
        invalidate();
    }

    public void setTextureHeight(float f) {
        this.z0 = f;
        d();
        invalidate();
    }

    public void setTextureWidth(float f) {
        this.A0 = f;
        d();
        invalidate();
    }

    public void setTypeface(Typeface typeface) {
        TextPaint textPaint = this.f305a;
        if (Objects.equals(textPaint.getTypeface(), typeface)) {
            return;
        }
        textPaint.setTypeface(typeface);
    }

    public MotionLabel(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f305a = new TextPaint();
        this.b = new Path();
        this.c = Settings.DEFAULT_INITIAL_WINDOW_SIZE;
        this.d = Settings.DEFAULT_INITIAL_WINDOW_SIZE;
        this.e = false;
        this.f = 0.0f;
        this.i = Float.NaN;
        this.b0 = 48.0f;
        this.c0 = Float.NaN;
        this.f0 = 0.0f;
        this.g0 = "Hello World";
        this.h0 = true;
        this.i0 = new Rect();
        this.j0 = 1;
        this.k0 = 1;
        this.l0 = 1;
        this.m0 = 1;
        this.o0 = 8388659;
        this.p0 = 0;
        this.q0 = false;
        this.z0 = Float.NaN;
        this.A0 = Float.NaN;
        this.B0 = 0.0f;
        this.C0 = 0.0f;
        this.D0 = new Paint();
        this.E0 = 0;
        this.I0 = Float.NaN;
        this.J0 = Float.NaN;
        this.K0 = Float.NaN;
        this.L0 = Float.NaN;
        b(context, attributeSet);
    }
}

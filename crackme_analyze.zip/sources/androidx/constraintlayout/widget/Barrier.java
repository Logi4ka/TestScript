package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import androidx.constraintlayout.widget.Constraints;
import defpackage.gz0;
import defpackage.lz0;
import defpackage.mz0;
import defpackage.s20;
import defpackage.wt2;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class Barrier extends ConstraintHelper {
    public int b0;
    public int c0;
    public s20 d0;

    public Barrier(Context context) {
        super(context);
        this.f306a = new int[32];
        this.e = false;
        this.v = null;
        this.w = new HashMap();
        this.c = context;
        k(null);
        super.setVisibility(8);
    }

    public boolean getAllowsGoneWidget() {
        return this.d0.x0;
    }

    public int getMargin() {
        return this.d0.y0;
    }

    public int getType() {
        return this.b0;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.d0 = new s20();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.ConstraintLayout_Layout_barrierDirection) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == R$styleable.ConstraintLayout_Layout_barrierAllowsGoneWidgets) {
                    this.d0.x0 = typedArrayObtainStyledAttributes.getBoolean(index, true);
                } else if (index == R$styleable.ConstraintLayout_Layout_barrierMargin) {
                    this.d0.y0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.d = this.d0;
        q();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void l(c cVar, wt2 wt2Var, Constraints.LayoutParams layoutParams, SparseArray sparseArray) {
        super.l(cVar, wt2Var, layoutParams, sparseArray);
        gz0 gz0Var = cVar.e;
        if (wt2Var instanceof s20) {
            s20 s20Var = (s20) wt2Var;
            r(s20Var, gz0Var.g0, ((mz0) wt2Var.V).z0);
            s20Var.x0 = gz0Var.o0;
            s20Var.y0 = gz0Var.h0;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void m(lz0 lz0Var, boolean z) {
        r(lz0Var, this.b0, z);
    }

    public final void r(lz0 lz0Var, int i, boolean z) {
        this.c0 = i;
        int i2 = this.b0;
        if (z) {
            if (i2 == 5) {
                this.c0 = 1;
            } else if (i2 == 6) {
                this.c0 = 0;
            }
        } else if (i2 == 5) {
            this.c0 = 0;
        } else if (i2 == 6) {
            this.c0 = 1;
        }
        if (lz0Var instanceof s20) {
            ((s20) lz0Var).w0 = this.c0;
        }
    }

    public void setAllowsGoneWidget(boolean z) {
        this.d0.x0 = z;
    }

    public void setDpMargin(int i) {
        this.d0.y0 = (int) ((i * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i) {
        this.d0.y0 = i;
    }

    public void setType(int i) {
        this.b0 = i;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        super.setVisibility(8);
    }
}

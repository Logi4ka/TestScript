package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;
import defpackage.gz0;
import defpackage.lz0;
import defpackage.wt2;
import io.sentry.android.core.o0;
import java.util.Arrays;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class ConstraintHelper extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int[] f306a;
    public int b;
    public Context c;
    public wt2 d;
    public boolean e;
    public String f;
    public String i;
    public View[] v;
    public HashMap w;

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f306a = new int[32];
        this.e = false;
        this.v = null;
        this.w = new HashMap();
        this.c = context;
        k(attributeSet);
    }

    public final void b(String str) {
        if (str.length() == 0 || this.c == null) {
            return;
        }
        String strTrim = str.trim();
        int i = i(strTrim);
        if (i != 0) {
            this.w.put(Integer.valueOf(i), strTrim);
            c(i);
        } else {
            o0.q("ConstraintHelper", "Could not find id of \"" + strTrim + "\"");
        }
    }

    public final void c(int i) {
        if (i == getId()) {
            return;
        }
        int i2 = this.b + 1;
        int[] iArr = this.f306a;
        if (i2 > iArr.length) {
            this.f306a = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f306a;
        int i3 = this.b;
        iArr2[i3] = i;
        this.b = i3 + 1;
    }

    public final void d(String str) {
        if (str.length() == 0 || this.c == null) {
            return;
        }
        String strTrim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            o0.q("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = constraintLayout.getChildAt(i);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.LayoutParams) && strTrim.equals(((ConstraintLayout.LayoutParams) layoutParams).Y)) {
                if (childAt.getId() == -1) {
                    o0.q("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                } else {
                    c(childAt.getId());
                }
            }
        }
    }

    public final void e() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        f((ConstraintLayout) parent);
    }

    public final void f(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i = 0; i < this.b; i++) {
            View viewC = constraintLayout.c(this.f306a[i]);
            if (viewC != null) {
                viewC.setVisibility(visibility);
                if (elevation > 0.0f) {
                    viewC.setTranslationZ(viewC.getTranslationZ() + elevation);
                }
            }
        }
    }

    public void g(ConstraintLayout constraintLayout) {
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f306a, this.b);
    }

    public final int h(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String resourceEntryName;
        if (str != null && (resources = this.c.getResources()) != null) {
            int childCount = constraintLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = constraintLayout.getChildAt(i);
                if (childAt.getId() != -1) {
                    try {
                        resourceEntryName = resources.getResourceEntryName(childAt.getId());
                    } catch (Resources.NotFoundException unused) {
                        resourceEntryName = null;
                    }
                    if (str.equals(resourceEntryName)) {
                        return childAt.getId();
                    }
                }
            }
        }
        return 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x003a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int i(java.lang.String r6) {
        /*
            r5 = this;
            android.content.Context r0 = r5.c
            android.view.ViewParent r1 = r5.getParent()
            boolean r1 = r1 instanceof androidx.constraintlayout.widget.ConstraintLayout
            r2 = 0
            if (r1 == 0) goto L12
            android.view.ViewParent r1 = r5.getParent()
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            goto L13
        L12:
            r1 = r2
        L13:
            boolean r3 = r5.isInEditMode()
            if (r3 == 0) goto L3a
            if (r1 == 0) goto L3a
            if (r6 == 0) goto L2e
            java.util.HashMap r3 = r1.e0
            if (r3 == 0) goto L2e
            boolean r3 = r3.containsKey(r6)
            if (r3 == 0) goto L2e
            java.util.HashMap r3 = r1.e0
            java.lang.Object r3 = r3.get(r6)
            goto L2f
        L2e:
            r3 = r2
        L2f:
            boolean r4 = r3 instanceof java.lang.Integer
            if (r4 == 0) goto L3a
            java.lang.Integer r3 = (java.lang.Integer) r3
            int r3 = r3.intValue()
            goto L3b
        L3a:
            r3 = 0
        L3b:
            if (r3 != 0) goto L43
            if (r1 == 0) goto L43
            int r3 = r5.h(r1, r6)
        L43:
            if (r3 != 0) goto L4f
            java.lang.Class<androidx.constraintlayout.widget.R$id> r5 = androidx.constraintlayout.widget.R$id.class
            java.lang.reflect.Field r5 = r5.getField(r6)     // Catch: java.lang.Exception -> L4f
            int r3 = r5.getInt(r2)     // Catch: java.lang.Exception -> L4f
        L4f:
            if (r3 != 0) goto L5f
            android.content.res.Resources r5 = r0.getResources()
            java.lang.String r1 = "id"
            java.lang.String r0 = r0.getPackageName()
            int r3 = r5.getIdentifier(r6, r1, r0)
        L5f:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintHelper.i(java.lang.String):int");
    }

    public final View[] j(ConstraintLayout constraintLayout) {
        View[] viewArr = this.v;
        if (viewArr == null || viewArr.length != this.b) {
            this.v = new View[this.b];
        }
        for (int i = 0; i < this.b; i++) {
            this.v[i] = constraintLayout.c(this.f306a[i]);
        }
        return this.v;
    }

    public void k(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R$styleable.ConstraintLayout_Layout_constraint_referenced_ids) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.f = string;
                    setIds(string);
                } else if (index == R$styleable.ConstraintLayout_Layout_constraint_referenced_tags) {
                    String string2 = typedArrayObtainStyledAttributes.getString(index);
                    this.i = string2;
                    setReferenceTags(string2);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void l(c cVar, wt2 wt2Var, Constraints.LayoutParams layoutParams, SparseArray sparseArray) {
        gz0 gz0Var = cVar.e;
        int[] iArr = gz0Var.j0;
        int i = 0;
        if (iArr != null) {
            setReferencedIds(iArr);
        } else {
            String str = gz0Var.k0;
            if (str != null) {
                if (str.length() > 0) {
                    String[] strArrSplit = gz0Var.k0.split(",");
                    int[] iArrCopyOf = new int[strArrSplit.length];
                    int i2 = 0;
                    for (String str2 : strArrSplit) {
                        int i3 = i(str2.trim());
                        if (i3 != 0) {
                            iArrCopyOf[i2] = i3;
                            i2++;
                        }
                    }
                    if (i2 != strArrSplit.length) {
                        iArrCopyOf = Arrays.copyOf(iArrCopyOf, i2);
                    }
                    gz0Var.j0 = iArrCopyOf;
                } else {
                    gz0Var.j0 = null;
                }
            }
        }
        wt2Var.v0 = 0;
        Arrays.fill(wt2Var.u0, (Object) null);
        if (gz0Var.j0 == null) {
            return;
        }
        while (true) {
            int[] iArr2 = gz0Var.j0;
            if (i >= iArr2.length) {
                return;
            }
            lz0 lz0Var = (lz0) sparseArray.get(iArr2[i]);
            if (lz0Var != null) {
                wt2Var.S(lz0Var);
            }
            i++;
        }
    }

    public void m(lz0 lz0Var, boolean z) {
    }

    public void n() {
    }

    public void o(ConstraintLayout constraintLayout) {
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.i;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    public void onMeasure(int i, int i2) {
        if (this.e) {
            super.onMeasure(i, i2);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void p(wt2 wt2Var, SparseArray sparseArray) {
        wt2Var.v0 = 0;
        Arrays.fill(wt2Var.u0, (Object) null);
        for (int i = 0; i < this.b; i++) {
            wt2Var.S((lz0) sparseArray.get(this.f306a[i]));
        }
    }

    public final void q() {
        if (this.d == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.LayoutParams) {
            ((ConstraintLayout.LayoutParams) layoutParams).q0 = this.d;
        }
    }

    public void setIds(String str) {
        this.f = str;
        if (str == null) {
            return;
        }
        int i = 0;
        this.b = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i);
            if (iIndexOf == -1) {
                b(str.substring(i));
                return;
            } else {
                b(str.substring(i, iIndexOf));
                i = iIndexOf + 1;
            }
        }
    }

    public void setReferenceTags(String str) {
        this.i = str;
        if (str == null) {
            return;
        }
        int i = 0;
        this.b = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i);
            if (iIndexOf == -1) {
                d(str.substring(i));
                return;
            } else {
                d(str.substring(i, iIndexOf));
                i = iIndexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f = null;
        this.b = 0;
        for (int i : iArr) {
            c(i);
        }
    }

    @Override // android.view.View
    public final void setTag(int i, Object obj) {
        super.setTag(i, obj);
        if (obj == null && this.f == null) {
            c(i);
        }
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f306a = new int[32];
        this.e = false;
        this.v = null;
        this.w = new HashMap();
        this.c = context;
        k(attributeSet);
    }
}

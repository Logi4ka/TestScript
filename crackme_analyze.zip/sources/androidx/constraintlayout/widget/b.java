package androidx.constraintlayout.widget;

import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import defpackage.az0;
import defpackage.c40;
import defpackage.cg7;
import defpackage.d40;
import defpackage.kz0;
import defpackage.lz0;
import defpackage.mz0;
import defpackage.qp7;
import defpackage.uz5;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b implements d40 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ConstraintLayout f314a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public final /* synthetic */ ConstraintLayout h;

    public b(ConstraintLayout constraintLayout, ConstraintLayout constraintLayout2) {
        this.h = constraintLayout;
        this.f314a = constraintLayout2;
    }

    public static boolean a(int i, int i2, int i3) {
        if (i == i2) {
            return true;
        }
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode2 == 1073741824) {
            return (mode == Integer.MIN_VALUE || mode == 0) && i3 == size;
        }
        return false;
    }

    public final void b(lz0 lz0Var, c40 c40Var) {
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        int iMax;
        int iMax2;
        boolean z;
        int baseline;
        int i;
        if (lz0Var == null) {
            return;
        }
        az0 az0Var = lz0Var.L;
        az0 az0Var2 = lz0Var.J;
        if (lz0Var.i0 == 8 && !lz0Var.F) {
            c40Var.e = 0;
            c40Var.f = 0;
            c40Var.g = 0;
            return;
        }
        if (lz0Var.V == null) {
            return;
        }
        uz5 uz5Var = ConstraintLayout.h0;
        kz0 kz0Var = c40Var.f725a;
        kz0 kz0Var2 = c40Var.b;
        int i2 = c40Var.c;
        int i3 = c40Var.d;
        int i4 = this.b + this.c;
        int i5 = this.d;
        View view = lz0Var.h0;
        int iOrdinal = kz0Var.ordinal();
        if (iOrdinal == 0) {
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
        } else if (iOrdinal == 1) {
            iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i5, -2);
        } else if (iOrdinal == 2) {
            iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i5, -2);
            boolean z2 = lz0Var.r == 1;
            int i6 = c40Var.j;
            if (i6 == 1 || i6 == 2) {
                boolean z3 = view.getMeasuredHeight() == lz0Var.l();
                if (c40Var.j == 2 || !z2 || ((z2 && z3) || (view instanceof Placeholder) || lz0Var.B())) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(lz0Var.r(), 1073741824);
                }
            }
        } else if (iOrdinal != 3) {
            iMakeMeasureSpec = 0;
        } else {
            int i7 = this.f;
            int i8 = az0Var2 != null ? az0Var2.g : 0;
            if (az0Var != null) {
                i8 += az0Var.g;
            }
            iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(i7, i5 + i8, -1);
        }
        int iOrdinal2 = kz0Var2.ordinal();
        if (iOrdinal2 == 0) {
            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
        } else if (iOrdinal2 == 1) {
            iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i4, -2);
        } else if (iOrdinal2 == 2) {
            iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i4, -2);
            boolean z4 = lz0Var.s == 1;
            int i9 = c40Var.j;
            if (i9 == 1 || i9 == 2) {
                boolean z5 = view.getMeasuredWidth() == lz0Var.r();
                if (c40Var.j == 2 || !z4 || ((z4 && z5) || (view instanceof Placeholder) || lz0Var.C())) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(lz0Var.l(), 1073741824);
                }
            }
        } else if (iOrdinal2 != 3) {
            iMakeMeasureSpec2 = 0;
        } else {
            int i10 = this.g;
            int i11 = az0Var2 != null ? lz0Var.K.g : 0;
            if (az0Var != null) {
                i11 += lz0Var.M.g;
            }
            iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(i10, i4 + i11, -1);
        }
        mz0 mz0Var = (mz0) lz0Var.V;
        ConstraintLayout constraintLayout = this.h;
        if (mz0Var != null && qp7.q(constraintLayout.w, NotificationCompat.FLAG_LOCAL_ONLY) && view.getMeasuredWidth() == lz0Var.r() && view.getMeasuredWidth() < mz0Var.r() && view.getMeasuredHeight() == lz0Var.l() && view.getMeasuredHeight() < mz0Var.l() && view.getBaseline() == lz0Var.c0 && !lz0Var.A() && a(lz0Var.H, iMakeMeasureSpec, lz0Var.r()) && a(lz0Var.I, iMakeMeasureSpec2, lz0Var.l())) {
            c40Var.e = lz0Var.r();
            c40Var.f = lz0Var.l();
            c40Var.g = lz0Var.c0;
            return;
        }
        kz0 kz0Var3 = kz0.c;
        boolean z6 = kz0Var == kz0Var3;
        boolean z7 = kz0Var2 == kz0Var3;
        kz0 kz0Var4 = kz0.f3829a;
        kz0 kz0Var5 = kz0.d;
        boolean z8 = kz0Var2 == kz0Var5 || kz0Var2 == kz0Var4;
        boolean z9 = kz0Var == kz0Var5 || kz0Var == kz0Var4;
        boolean z10 = z6 && lz0Var.Y > 0.0f;
        boolean z11 = z7 && lz0Var.Y > 0.0f;
        if (view == null) {
            return;
        }
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        int i12 = c40Var.j;
        if (i12 != 1 && i12 != 2 && z6 && lz0Var.r == 0 && z7 && lz0Var.s == 0) {
            i = -1;
            z = false;
            baseline = 0;
            iMax = 0;
            iMax2 = 0;
        } else {
            if ((view instanceof VirtualLayout) && (lz0Var instanceof cg7)) {
                ((VirtualLayout) view).r((cg7) lz0Var, iMakeMeasureSpec, iMakeMeasureSpec2);
            } else {
                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
            }
            lz0Var.H = iMakeMeasureSpec;
            lz0Var.I = iMakeMeasureSpec2;
            lz0Var.g = false;
            int measuredWidth = view.getMeasuredWidth();
            int measuredHeight = view.getMeasuredHeight();
            int baseline2 = view.getBaseline();
            int i13 = lz0Var.u;
            iMax = i13 > 0 ? Math.max(i13, measuredWidth) : measuredWidth;
            int i14 = lz0Var.v;
            if (i14 > 0) {
                iMax = Math.min(i14, iMax);
            }
            int i15 = lz0Var.x;
            iMax2 = i15 > 0 ? Math.max(i15, measuredHeight) : measuredHeight;
            int i16 = iMakeMeasureSpec2;
            int i17 = lz0Var.y;
            if (i17 > 0) {
                iMax2 = Math.min(i17, iMax2);
            }
            if (!qp7.q(constraintLayout.w, 1)) {
                if (z10 && z8) {
                    iMax = (int) ((iMax2 * lz0Var.Y) + 0.5f);
                } else if (z11 && z9) {
                    iMax2 = (int) ((iMax / lz0Var.Y) + 0.5f);
                }
            }
            if (measuredWidth == iMax && measuredHeight == iMax2) {
                baseline = baseline2;
                i = -1;
                z = false;
            } else {
                if (measuredWidth != iMax) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMax, 1073741824);
                }
                int iMakeMeasureSpec3 = measuredHeight != iMax2 ? View.MeasureSpec.makeMeasureSpec(iMax2, 1073741824) : i16;
                view.measure(iMakeMeasureSpec, iMakeMeasureSpec3);
                lz0Var.H = iMakeMeasureSpec;
                lz0Var.I = iMakeMeasureSpec3;
                z = false;
                lz0Var.g = false;
                int measuredWidth2 = view.getMeasuredWidth();
                int measuredHeight2 = view.getMeasuredHeight();
                baseline = view.getBaseline();
                iMax = measuredWidth2;
                iMax2 = measuredHeight2;
                i = -1;
            }
        }
        boolean z12 = baseline != i ? true : z;
        c40Var.i = (iMax == c40Var.c && iMax2 == c40Var.d) ? z : true;
        boolean z13 = layoutParams.c0 ? true : z12;
        if (z13 && baseline != -1 && lz0Var.c0 != baseline) {
            c40Var.i = true;
        }
        c40Var.e = iMax;
        c40Var.f = iMax2;
        c40Var.h = z13;
        c40Var.g = baseline;
    }
}

package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.appsflyer.attribution.RequestError;
import defpackage.ax6;
import defpackage.bz0;
import defpackage.fz0;
import defpackage.g9;
import defpackage.gz0;
import defpackage.hz0;
import defpackage.iz0;
import defpackage.jz0;
import defpackage.p01;
import defpackage.qe0;
import defpackage.uz5;
import io.flutter.Build;
import io.flutter.plugin.editing.FlutterTextUtils;
import io.sentry.android.core.o0;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import okhttp3.HttpUrl;
import okhttp3.internal.ws.WebSocketProtocol;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class d {
    public static final int[] h = {0, 4, 8};
    public static final SparseIntArray i;
    public static final SparseIntArray j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f316a;
    public String b = HttpUrl.FRAGMENT_ENCODE_SET;
    public String[] c = new String[0];
    public int d = 0;
    public final HashMap e = new HashMap();
    public boolean f = true;
    public final HashMap g = new HashMap();

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        SparseIntArray sparseIntArray2 = new SparseIntArray();
        j = sparseIntArray2;
        sparseIntArray.append(R$styleable.Constraint_layout_constraintLeft_toLeftOf, 25);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintLeft_toRightOf, 26);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintRight_toLeftOf, 29);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintRight_toRightOf, 30);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintTop_toTopOf, 36);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintTop_toBottomOf, 35);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBottom_toTopOf, 4);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBottom_toBottomOf, 3);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBaseline_toBaselineOf, 1);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBaseline_toTopOf, 91);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBaseline_toBottomOf, 92);
        sparseIntArray.append(R$styleable.Constraint_layout_editor_absoluteX, 6);
        sparseIntArray.append(R$styleable.Constraint_layout_editor_absoluteY, 7);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintGuide_begin, 17);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintGuide_end, 18);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintGuide_percent, 19);
        sparseIntArray.append(R$styleable.Constraint_guidelineUseRtl, 99);
        sparseIntArray.append(R$styleable.Constraint_android_orientation, 27);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintStart_toEndOf, 32);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintStart_toStartOf, 33);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintEnd_toStartOf, 10);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintEnd_toEndOf, 9);
        sparseIntArray.append(R$styleable.Constraint_layout_goneMarginLeft, 13);
        sparseIntArray.append(R$styleable.Constraint_layout_goneMarginTop, 16);
        sparseIntArray.append(R$styleable.Constraint_layout_goneMarginRight, 14);
        sparseIntArray.append(R$styleable.Constraint_layout_goneMarginBottom, 11);
        sparseIntArray.append(R$styleable.Constraint_layout_goneMarginStart, 15);
        sparseIntArray.append(R$styleable.Constraint_layout_goneMarginEnd, 12);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintVertical_weight, 40);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHorizontal_weight, 39);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHorizontal_chainStyle, 41);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintVertical_chainStyle, 42);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHorizontal_bias, 20);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintVertical_bias, 37);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintDimensionRatio, 5);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintLeft_creator, 87);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintTop_creator, 87);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintRight_creator, 87);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBottom_creator, 87);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintBaseline_creator, 87);
        sparseIntArray.append(R$styleable.Constraint_android_layout_marginLeft, 24);
        sparseIntArray.append(R$styleable.Constraint_android_layout_marginRight, 28);
        sparseIntArray.append(R$styleable.Constraint_android_layout_marginStart, 31);
        sparseIntArray.append(R$styleable.Constraint_android_layout_marginEnd, 8);
        sparseIntArray.append(R$styleable.Constraint_android_layout_marginTop, 34);
        sparseIntArray.append(R$styleable.Constraint_android_layout_marginBottom, 2);
        sparseIntArray.append(R$styleable.Constraint_android_layout_width, 23);
        sparseIntArray.append(R$styleable.Constraint_android_layout_height, 21);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintWidth, 95);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHeight, 96);
        sparseIntArray.append(R$styleable.Constraint_android_visibility, 22);
        sparseIntArray.append(R$styleable.Constraint_android_alpha, 43);
        sparseIntArray.append(R$styleable.Constraint_android_elevation, 44);
        sparseIntArray.append(R$styleable.Constraint_android_rotationX, 45);
        sparseIntArray.append(R$styleable.Constraint_android_rotationY, 46);
        sparseIntArray.append(R$styleable.Constraint_android_rotation, 60);
        sparseIntArray.append(R$styleable.Constraint_android_scaleX, 47);
        sparseIntArray.append(R$styleable.Constraint_android_scaleY, 48);
        sparseIntArray.append(R$styleable.Constraint_android_transformPivotX, 49);
        sparseIntArray.append(R$styleable.Constraint_android_transformPivotY, 50);
        sparseIntArray.append(R$styleable.Constraint_android_translationX, 51);
        sparseIntArray.append(R$styleable.Constraint_android_translationY, 52);
        sparseIntArray.append(R$styleable.Constraint_android_translationZ, 53);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintWidth_default, 54);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHeight_default, 55);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintWidth_max, 56);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHeight_max, 57);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintWidth_min, 58);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHeight_min, 59);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintCircle, 61);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintCircleRadius, 62);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintCircleAngle, 63);
        sparseIntArray.append(R$styleable.Constraint_animateRelativeTo, 64);
        sparseIntArray.append(R$styleable.Constraint_transitionEasing, 65);
        sparseIntArray.append(R$styleable.Constraint_drawPath, 66);
        sparseIntArray.append(R$styleable.Constraint_transitionPathRotate, 67);
        sparseIntArray.append(R$styleable.Constraint_motionStagger, 79);
        sparseIntArray.append(R$styleable.Constraint_android_id, 38);
        sparseIntArray.append(R$styleable.Constraint_motionProgress, 68);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintWidth_percent, 69);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintHeight_percent, 70);
        sparseIntArray.append(R$styleable.Constraint_layout_wrapBehaviorInParent, 97);
        sparseIntArray.append(R$styleable.Constraint_chainUseRtl, 71);
        sparseIntArray.append(R$styleable.Constraint_barrierDirection, 72);
        sparseIntArray.append(R$styleable.Constraint_barrierMargin, 73);
        sparseIntArray.append(R$styleable.Constraint_constraint_referenced_ids, 74);
        sparseIntArray.append(R$styleable.Constraint_barrierAllowsGoneWidgets, 75);
        sparseIntArray.append(R$styleable.Constraint_pathMotionArc, 76);
        sparseIntArray.append(R$styleable.Constraint_layout_constraintTag, 77);
        sparseIntArray.append(R$styleable.Constraint_visibilityMode, 78);
        sparseIntArray.append(R$styleable.Constraint_layout_constrainedWidth, 80);
        sparseIntArray.append(R$styleable.Constraint_layout_constrainedHeight, 81);
        sparseIntArray.append(R$styleable.Constraint_polarRelativeTo, 82);
        sparseIntArray.append(R$styleable.Constraint_transformPivotTarget, 83);
        sparseIntArray.append(R$styleable.Constraint_quantizeMotionSteps, 84);
        sparseIntArray.append(R$styleable.Constraint_quantizeMotionPhase, 85);
        sparseIntArray.append(R$styleable.Constraint_quantizeMotionInterpolator, 86);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_editor_absoluteY, 6);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_editor_absoluteY, 7);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_orientation, 27);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_goneMarginLeft, 13);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_goneMarginTop, 16);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_goneMarginRight, 14);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_goneMarginBottom, 11);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_goneMarginStart, 15);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_goneMarginEnd, 12);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintVertical_weight, 40);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHorizontal_weight, 39);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHorizontal_chainStyle, 41);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintVertical_chainStyle, 42);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHorizontal_bias, 20);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintVertical_bias, 37);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintDimensionRatio, 5);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintLeft_creator, 87);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintTop_creator, 87);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintRight_creator, 87);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintBottom_creator, 87);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintBaseline_creator, 87);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_marginLeft, 24);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_marginRight, 28);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_marginStart, 31);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_marginEnd, 8);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_marginTop, 34);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_marginBottom, 2);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_width, 23);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_layout_height, 21);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintWidth, 95);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHeight, 96);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_visibility, 22);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_alpha, 43);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_elevation, 44);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_rotationX, 45);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_rotationY, 46);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_rotation, 60);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_scaleX, 47);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_scaleY, 48);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_transformPivotX, 49);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_transformPivotY, 50);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_translationX, 51);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_translationY, 52);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_translationZ, 53);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintWidth_default, 54);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHeight_default, 55);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintWidth_max, 56);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHeight_max, 57);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintWidth_min, 58);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHeight_min, 59);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintCircleRadius, 62);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintCircleAngle, 63);
        sparseIntArray2.append(R$styleable.ConstraintOverride_animateRelativeTo, 64);
        sparseIntArray2.append(R$styleable.ConstraintOverride_transitionEasing, 65);
        sparseIntArray2.append(R$styleable.ConstraintOverride_drawPath, 66);
        sparseIntArray2.append(R$styleable.ConstraintOverride_transitionPathRotate, 67);
        sparseIntArray2.append(R$styleable.ConstraintOverride_motionStagger, 79);
        sparseIntArray2.append(R$styleable.ConstraintOverride_android_id, 38);
        sparseIntArray2.append(R$styleable.ConstraintOverride_motionTarget, 98);
        sparseIntArray2.append(R$styleable.ConstraintOverride_motionProgress, 68);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintWidth_percent, 69);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintHeight_percent, 70);
        sparseIntArray2.append(R$styleable.ConstraintOverride_chainUseRtl, 71);
        sparseIntArray2.append(R$styleable.ConstraintOverride_barrierDirection, 72);
        sparseIntArray2.append(R$styleable.ConstraintOverride_barrierMargin, 73);
        sparseIntArray2.append(R$styleable.ConstraintOverride_constraint_referenced_ids, 74);
        sparseIntArray2.append(R$styleable.ConstraintOverride_barrierAllowsGoneWidgets, 75);
        sparseIntArray2.append(R$styleable.ConstraintOverride_pathMotionArc, 76);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constraintTag, 77);
        sparseIntArray2.append(R$styleable.ConstraintOverride_visibilityMode, 78);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constrainedWidth, 80);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_constrainedHeight, 81);
        sparseIntArray2.append(R$styleable.ConstraintOverride_polarRelativeTo, 82);
        sparseIntArray2.append(R$styleable.ConstraintOverride_transformPivotTarget, 83);
        sparseIntArray2.append(R$styleable.ConstraintOverride_quantizeMotionSteps, 84);
        sparseIntArray2.append(R$styleable.ConstraintOverride_quantizeMotionPhase, 85);
        sparseIntArray2.append(R$styleable.ConstraintOverride_quantizeMotionInterpolator, 86);
        sparseIntArray2.append(R$styleable.ConstraintOverride_layout_wrapBehaviorInParent, 97);
    }

    public static c d(Context context, XmlResourceParser xmlResourceParser) {
        AttributeSet attributeSetAsAttributeSet = Xml.asAttributeSet(xmlResourceParser);
        c cVar = new c();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSetAsAttributeSet, R$styleable.ConstraintOverride);
        p(cVar, typedArrayObtainStyledAttributes);
        typedArrayObtainStyledAttributes.recycle();
        return cVar;
    }

    public static int[] g(Barrier barrier, String str) {
        int iIntValue;
        String[] strArrSplit = str.split(",");
        Context context = barrier.getContext();
        int[] iArr = new int[strArrSplit.length];
        int i2 = 0;
        int i3 = 0;
        while (i2 < strArrSplit.length) {
            String strTrim = strArrSplit[i2].trim();
            Object obj = null;
            try {
                iIntValue = R$id.class.getField(strTrim).getInt(null);
            } catch (Exception unused) {
                iIntValue = 0;
            }
            if (iIntValue == 0) {
                iIntValue = context.getResources().getIdentifier(strTrim, "id", context.getPackageName());
            }
            if (iIntValue == 0 && barrier.isInEditMode() && (barrier.getParent() instanceof ConstraintLayout)) {
                ConstraintLayout constraintLayout = (ConstraintLayout) barrier.getParent();
                if (strTrim != null) {
                    HashMap map = constraintLayout.e0;
                    if (map != null && map.containsKey(strTrim)) {
                        obj = constraintLayout.e0.get(strTrim);
                    }
                } else {
                    constraintLayout.getClass();
                }
                if (obj != null && (obj instanceof Integer)) {
                    iIntValue = ((Integer) obj).intValue();
                }
            }
            iArr[i3] = iIntValue;
            i2++;
            i3++;
        }
        return i3 != strArrSplit.length ? Arrays.copyOf(iArr, i3) : iArr;
    }

    public static c h(Context context, AttributeSet attributeSet, boolean z) {
        c cVar = new c();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z ? R$styleable.ConstraintOverride : R$styleable.Constraint);
        if (z) {
            p(cVar, typedArrayObtainStyledAttributes);
        } else {
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            int i2 = 0;
            while (true) {
                gz0 gz0Var = cVar.e;
                if (i2 < indexCount) {
                    int index = typedArrayObtainStyledAttributes.getIndex(i2);
                    int i3 = R$styleable.Constraint_android_id;
                    iz0 iz0Var = cVar.c;
                    jz0 jz0Var = cVar.f;
                    hz0 hz0Var = cVar.d;
                    if (index != i3 && R$styleable.Constraint_android_layout_marginStart != index && R$styleable.Constraint_android_layout_marginEnd != index) {
                        hz0Var.f2725a = true;
                        gz0Var.b = true;
                        iz0Var.f3377a = true;
                        jz0Var.f3602a = true;
                    }
                    SparseIntArray sparseIntArray = i;
                    switch (sparseIntArray.get(index)) {
                        case 1:
                            gz0Var.q = m(typedArrayObtainStyledAttributes, index, gz0Var.q);
                            break;
                        case 2:
                            gz0Var.J = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.J);
                            break;
                        case 3:
                            gz0Var.p = m(typedArrayObtainStyledAttributes, index, gz0Var.p);
                            break;
                        case 4:
                            gz0Var.o = m(typedArrayObtainStyledAttributes, index, gz0Var.o);
                            break;
                        case 5:
                            gz0Var.z = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 6:
                            gz0Var.D = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, gz0Var.D);
                            break;
                        case 7:
                            gz0Var.E = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, gz0Var.E);
                            break;
                        case 8:
                            gz0Var.K = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.K);
                            break;
                        case 9:
                            gz0Var.w = m(typedArrayObtainStyledAttributes, index, gz0Var.w);
                            break;
                        case 10:
                            gz0Var.v = m(typedArrayObtainStyledAttributes, index, gz0Var.v);
                            break;
                        case 11:
                            gz0Var.Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.Q);
                            break;
                        case 12:
                            gz0Var.R = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.R);
                            break;
                        case FlutterTextUtils.CARRIAGE_RETURN /* 13 */:
                            gz0Var.N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.N);
                            break;
                        case 14:
                            gz0Var.P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.P);
                            break;
                        case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                            gz0Var.S = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.S);
                            break;
                        case 16:
                            gz0Var.O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.O);
                            break;
                        case 17:
                            gz0Var.e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, gz0Var.e);
                            break;
                        case 18:
                            gz0Var.f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, gz0Var.f);
                            break;
                        case 19:
                            gz0Var.g = typedArrayObtainStyledAttributes.getFloat(index, gz0Var.g);
                            break;
                        case 20:
                            gz0Var.x = typedArrayObtainStyledAttributes.getFloat(index, gz0Var.x);
                            break;
                        case Build.API_LEVELS.API_21 /* 21 */:
                            gz0Var.d = typedArrayObtainStyledAttributes.getLayoutDimension(index, gz0Var.d);
                            break;
                        case Build.API_LEVELS.API_22 /* 22 */:
                            int i4 = typedArrayObtainStyledAttributes.getInt(index, iz0Var.b);
                            iz0Var.b = i4;
                            iz0Var.b = h[i4];
                            break;
                        case Build.API_LEVELS.API_23 /* 23 */:
                            gz0Var.c = typedArrayObtainStyledAttributes.getLayoutDimension(index, gz0Var.c);
                            break;
                        case 24:
                            gz0Var.G = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.G);
                            break;
                        case Build.API_LEVELS.API_25 /* 25 */:
                            gz0Var.i = m(typedArrayObtainStyledAttributes, index, gz0Var.i);
                            break;
                        case Build.API_LEVELS.API_26 /* 26 */:
                            gz0Var.j = m(typedArrayObtainStyledAttributes, index, gz0Var.j);
                            break;
                        case Build.API_LEVELS.API_27 /* 27 */:
                            gz0Var.F = typedArrayObtainStyledAttributes.getInt(index, gz0Var.F);
                            break;
                        case Build.API_LEVELS.API_28 /* 28 */:
                            gz0Var.H = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.H);
                            break;
                        case Build.API_LEVELS.API_29 /* 29 */:
                            gz0Var.k = m(typedArrayObtainStyledAttributes, index, gz0Var.k);
                            break;
                        case Build.API_LEVELS.API_30 /* 30 */:
                            gz0Var.l = m(typedArrayObtainStyledAttributes, index, gz0Var.l);
                            break;
                        case Build.API_LEVELS.API_31 /* 31 */:
                            gz0Var.L = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.L);
                            break;
                        case 32:
                            gz0Var.t = m(typedArrayObtainStyledAttributes, index, gz0Var.t);
                            break;
                        case Build.API_LEVELS.API_33 /* 33 */:
                            gz0Var.u = m(typedArrayObtainStyledAttributes, index, gz0Var.u);
                            break;
                        case Build.API_LEVELS.API_34 /* 34 */:
                            gz0Var.I = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.I);
                            break;
                        case Build.API_LEVELS.API_35 /* 35 */:
                            gz0Var.n = m(typedArrayObtainStyledAttributes, index, gz0Var.n);
                            break;
                        case Build.API_LEVELS.API_36 /* 36 */:
                            gz0Var.m = m(typedArrayObtainStyledAttributes, index, gz0Var.m);
                            break;
                        case 37:
                            gz0Var.y = typedArrayObtainStyledAttributes.getFloat(index, gz0Var.y);
                            break;
                        case 38:
                            cVar.f315a = typedArrayObtainStyledAttributes.getResourceId(index, cVar.f315a);
                            break;
                        case 39:
                            gz0Var.V = typedArrayObtainStyledAttributes.getFloat(index, gz0Var.V);
                            break;
                        case RequestError.NETWORK_FAILURE /* 40 */:
                            gz0Var.U = typedArrayObtainStyledAttributes.getFloat(index, gz0Var.U);
                            break;
                        case RequestError.NO_DEV_KEY /* 41 */:
                            gz0Var.W = typedArrayObtainStyledAttributes.getInt(index, gz0Var.W);
                            break;
                        case 42:
                            gz0Var.X = typedArrayObtainStyledAttributes.getInt(index, gz0Var.X);
                            break;
                        case 43:
                            iz0Var.d = typedArrayObtainStyledAttributes.getFloat(index, iz0Var.d);
                            break;
                        case 44:
                            jz0Var.m = true;
                            jz0Var.n = typedArrayObtainStyledAttributes.getDimension(index, jz0Var.n);
                            break;
                        case 45:
                            jz0Var.c = typedArrayObtainStyledAttributes.getFloat(index, jz0Var.c);
                            break;
                        case 46:
                            jz0Var.d = typedArrayObtainStyledAttributes.getFloat(index, jz0Var.d);
                            break;
                        case 47:
                            jz0Var.e = typedArrayObtainStyledAttributes.getFloat(index, jz0Var.e);
                            break;
                        case 48:
                            jz0Var.f = typedArrayObtainStyledAttributes.getFloat(index, jz0Var.f);
                            break;
                        case 49:
                            jz0Var.g = typedArrayObtainStyledAttributes.getDimension(index, jz0Var.g);
                            break;
                        case RequestError.RESPONSE_CODE_FAILURE /* 50 */:
                            jz0Var.h = typedArrayObtainStyledAttributes.getDimension(index, jz0Var.h);
                            break;
                        case 51:
                            jz0Var.j = typedArrayObtainStyledAttributes.getDimension(index, jz0Var.j);
                            break;
                        case 52:
                            jz0Var.k = typedArrayObtainStyledAttributes.getDimension(index, jz0Var.k);
                            break;
                        case 53:
                            jz0Var.l = typedArrayObtainStyledAttributes.getDimension(index, jz0Var.l);
                            break;
                        case 54:
                            gz0Var.Y = typedArrayObtainStyledAttributes.getInt(index, gz0Var.Y);
                            break;
                        case 55:
                            gz0Var.Z = typedArrayObtainStyledAttributes.getInt(index, gz0Var.Z);
                            break;
                        case 56:
                            gz0Var.a0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.a0);
                            break;
                        case 57:
                            gz0Var.b0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.b0);
                            break;
                        case 58:
                            gz0Var.c0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.c0);
                            break;
                        case 59:
                            gz0Var.d0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.d0);
                            break;
                        case 60:
                            jz0Var.b = typedArrayObtainStyledAttributes.getFloat(index, jz0Var.b);
                            break;
                        case 61:
                            gz0Var.A = m(typedArrayObtainStyledAttributes, index, gz0Var.A);
                            break;
                        case 62:
                            gz0Var.B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.B);
                            break;
                        case 63:
                            gz0Var.C = typedArrayObtainStyledAttributes.getFloat(index, gz0Var.C);
                            break;
                        case 64:
                            hz0Var.b = m(typedArrayObtainStyledAttributes, index, hz0Var.b);
                            break;
                        case 65:
                            if (typedArrayObtainStyledAttributes.peekValue(index).type != 3) {
                                hz0Var.d = g9.k[typedArrayObtainStyledAttributes.getInteger(index, 0)];
                            } else {
                                hz0Var.d = typedArrayObtainStyledAttributes.getString(index);
                            }
                            break;
                        case 66:
                            hz0Var.f = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 67:
                            hz0Var.h = typedArrayObtainStyledAttributes.getFloat(index, hz0Var.h);
                            break;
                        case 68:
                            iz0Var.e = typedArrayObtainStyledAttributes.getFloat(index, iz0Var.e);
                            break;
                        case 69:
                            gz0Var.e0 = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                            break;
                        case 70:
                            gz0Var.f0 = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                            break;
                        case 71:
                            o0.d("ConstraintSet", "CURRENTLY UNSUPPORTED");
                            break;
                        case 72:
                            gz0Var.g0 = typedArrayObtainStyledAttributes.getInt(index, gz0Var.g0);
                            break;
                        case 73:
                            gz0Var.h0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.h0);
                            break;
                        case 74:
                            gz0Var.k0 = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 75:
                            gz0Var.o0 = typedArrayObtainStyledAttributes.getBoolean(index, gz0Var.o0);
                            break;
                        case 76:
                            hz0Var.e = typedArrayObtainStyledAttributes.getInt(index, hz0Var.e);
                            break;
                        case 77:
                            gz0Var.l0 = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 78:
                            iz0Var.c = typedArrayObtainStyledAttributes.getInt(index, iz0Var.c);
                            break;
                        case 79:
                            hz0Var.g = typedArrayObtainStyledAttributes.getFloat(index, hz0Var.g);
                            break;
                        case 80:
                            gz0Var.m0 = typedArrayObtainStyledAttributes.getBoolean(index, gz0Var.m0);
                            break;
                        case 81:
                            gz0Var.n0 = typedArrayObtainStyledAttributes.getBoolean(index, gz0Var.n0);
                            break;
                        case 82:
                            hz0Var.c = typedArrayObtainStyledAttributes.getInteger(index, hz0Var.c);
                            break;
                        case 83:
                            jz0Var.i = m(typedArrayObtainStyledAttributes, index, jz0Var.i);
                            break;
                        case 84:
                            hz0Var.j = typedArrayObtainStyledAttributes.getInteger(index, hz0Var.j);
                            break;
                        case 85:
                            hz0Var.i = typedArrayObtainStyledAttributes.getFloat(index, hz0Var.i);
                            break;
                        case 86:
                            int i5 = typedArrayObtainStyledAttributes.peekValue(index).type;
                            if (i5 == 1) {
                                int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                                hz0Var.m = resourceId;
                                if (resourceId != -1) {
                                    hz0Var.l = -2;
                                }
                            } else if (i5 != 3) {
                                hz0Var.l = typedArrayObtainStyledAttributes.getInteger(index, hz0Var.m);
                            } else {
                                String string = typedArrayObtainStyledAttributes.getString(index);
                                hz0Var.k = string;
                                if (string.indexOf("/") <= 0) {
                                    hz0Var.l = -1;
                                } else {
                                    hz0Var.m = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                                    hz0Var.l = -2;
                                }
                            }
                            break;
                        case 87:
                            o0.q("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                            break;
                        case 88:
                        case 89:
                        case 90:
                        default:
                            o0.q("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                            break;
                        case 91:
                            gz0Var.r = m(typedArrayObtainStyledAttributes, index, gz0Var.r);
                            break;
                        case 92:
                            gz0Var.s = m(typedArrayObtainStyledAttributes, index, gz0Var.s);
                            break;
                        case 93:
                            gz0Var.M = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.M);
                            break;
                        case 94:
                            gz0Var.T = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, gz0Var.T);
                            break;
                        case 95:
                            n(gz0Var, typedArrayObtainStyledAttributes, index, 0);
                            break;
                        case 96:
                            n(gz0Var, typedArrayObtainStyledAttributes, index, 1);
                            break;
                        case 97:
                            gz0Var.p0 = typedArrayObtainStyledAttributes.getInt(index, gz0Var.p0);
                            break;
                    }
                    i2++;
                } else if (gz0Var.k0 != null) {
                    gz0Var.j0 = null;
                }
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        return cVar;
    }

    public static int m(TypedArray typedArray, int i2, int i3) {
        int resourceId = typedArray.getResourceId(i2, i3);
        return resourceId == -1 ? typedArray.getInt(i2, -1) : resourceId;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0044  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void n(java.lang.Object r7, android.content.res.TypedArray r8, int r9, int r10) {
        /*
            Method dump skipped, instruction units count: 370
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.d.n(java.lang.Object, android.content.res.TypedArray, int, int):void");
    }

    public static void o(ConstraintLayout.LayoutParams layoutParams, String str) {
        if (str != null) {
            int length = str.length();
            int iIndexOf = str.indexOf(44);
            int i2 = -1;
            if (iIndexOf > 0 && iIndexOf < length - 1) {
                String strSubstring = str.substring(0, iIndexOf);
                i2 = strSubstring.equalsIgnoreCase("W") ? 0 : strSubstring.equalsIgnoreCase("H") ? 1 : -1;
                i = iIndexOf + 1;
            }
            int iIndexOf2 = str.indexOf(58);
            try {
                if (iIndexOf2 < 0 || iIndexOf2 >= length - 1) {
                    String strSubstring2 = str.substring(i);
                    if (strSubstring2.length() > 0) {
                        Float.parseFloat(strSubstring2);
                    }
                } else {
                    String strSubstring3 = str.substring(i, iIndexOf2);
                    String strSubstring4 = str.substring(iIndexOf2 + 1);
                    if (strSubstring3.length() > 0 && strSubstring4.length() > 0) {
                        float f = Float.parseFloat(strSubstring3);
                        float f2 = Float.parseFloat(strSubstring4);
                        if (f > 0.0f && f2 > 0.0f) {
                            if (i2 == 1) {
                                Math.abs(f2 / f);
                            } else {
                                Math.abs(f / f2);
                            }
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
        }
        layoutParams.G = str;
    }

    public static void p(c cVar, TypedArray typedArray) {
        char c;
        int indexCount = typedArray.getIndexCount();
        fz0 fz0Var = new fz0();
        fz0Var.f2276a = new int[10];
        fz0Var.b = new int[10];
        fz0Var.c = 0;
        fz0Var.d = new int[10];
        fz0Var.e = new float[10];
        fz0Var.f = 0;
        fz0Var.g = new int[5];
        fz0Var.h = new String[5];
        fz0Var.i = 0;
        fz0Var.j = new int[4];
        fz0Var.k = new boolean[4];
        fz0Var.l = 0;
        cVar.h = fz0Var;
        hz0 hz0Var = cVar.d;
        hz0Var.f2725a = false;
        gz0 gz0Var = cVar.e;
        gz0Var.b = false;
        iz0 iz0Var = cVar.c;
        iz0Var.f3377a = false;
        jz0 jz0Var = cVar.f;
        jz0Var.f3602a = false;
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArray.getIndex(i2);
            int i3 = j.get(index);
            SparseIntArray sparseIntArray = i;
            switch (i3) {
                case 2:
                    c = 5;
                    fz0Var.b(2, typedArray.getDimensionPixelSize(index, gz0Var.J));
                    break;
                case 3:
                case 4:
                case 9:
                case 10:
                case Build.API_LEVELS.API_25 /* 25 */:
                case Build.API_LEVELS.API_26 /* 26 */:
                case Build.API_LEVELS.API_29 /* 29 */:
                case Build.API_LEVELS.API_30 /* 30 */:
                case 32:
                case Build.API_LEVELS.API_33 /* 33 */:
                case Build.API_LEVELS.API_35 /* 35 */:
                case Build.API_LEVELS.API_36 /* 36 */:
                case 61:
                case 88:
                case 89:
                case 90:
                case 91:
                case 92:
                default:
                    o0.q("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                    c = 5;
                    break;
                case 5:
                    c = 5;
                    fz0Var.c(5, typedArray.getString(index));
                    break;
                case 6:
                    fz0Var.b(6, typedArray.getDimensionPixelOffset(index, gz0Var.D));
                    c = 5;
                    break;
                case 7:
                    fz0Var.b(7, typedArray.getDimensionPixelOffset(index, gz0Var.E));
                    c = 5;
                    break;
                case 8:
                    fz0Var.b(8, typedArray.getDimensionPixelSize(index, gz0Var.K));
                    c = 5;
                    break;
                case 11:
                    fz0Var.b(11, typedArray.getDimensionPixelSize(index, gz0Var.Q));
                    c = 5;
                    break;
                case 12:
                    fz0Var.b(12, typedArray.getDimensionPixelSize(index, gz0Var.R));
                    c = 5;
                    break;
                case FlutterTextUtils.CARRIAGE_RETURN /* 13 */:
                    fz0Var.b(13, typedArray.getDimensionPixelSize(index, gz0Var.N));
                    c = 5;
                    break;
                case 14:
                    fz0Var.b(14, typedArray.getDimensionPixelSize(index, gz0Var.P));
                    c = 5;
                    break;
                case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                    fz0Var.b(15, typedArray.getDimensionPixelSize(index, gz0Var.S));
                    c = 5;
                    break;
                case 16:
                    fz0Var.b(16, typedArray.getDimensionPixelSize(index, gz0Var.O));
                    c = 5;
                    break;
                case 17:
                    fz0Var.b(17, typedArray.getDimensionPixelOffset(index, gz0Var.e));
                    c = 5;
                    break;
                case 18:
                    fz0Var.b(18, typedArray.getDimensionPixelOffset(index, gz0Var.f));
                    c = 5;
                    break;
                case 19:
                    fz0Var.a(typedArray.getFloat(index, gz0Var.g), 19);
                    c = 5;
                    break;
                case 20:
                    fz0Var.a(typedArray.getFloat(index, gz0Var.x), 20);
                    c = 5;
                    break;
                case Build.API_LEVELS.API_21 /* 21 */:
                    fz0Var.b(21, typedArray.getLayoutDimension(index, gz0Var.d));
                    c = 5;
                    break;
                case Build.API_LEVELS.API_22 /* 22 */:
                    fz0Var.b(22, h[typedArray.getInt(index, iz0Var.b)]);
                    c = 5;
                    break;
                case Build.API_LEVELS.API_23 /* 23 */:
                    fz0Var.b(23, typedArray.getLayoutDimension(index, gz0Var.c));
                    c = 5;
                    break;
                case 24:
                    fz0Var.b(24, typedArray.getDimensionPixelSize(index, gz0Var.G));
                    c = 5;
                    break;
                case Build.API_LEVELS.API_27 /* 27 */:
                    fz0Var.b(27, typedArray.getInt(index, gz0Var.F));
                    c = 5;
                    break;
                case Build.API_LEVELS.API_28 /* 28 */:
                    fz0Var.b(28, typedArray.getDimensionPixelSize(index, gz0Var.H));
                    c = 5;
                    break;
                case Build.API_LEVELS.API_31 /* 31 */:
                    fz0Var.b(31, typedArray.getDimensionPixelSize(index, gz0Var.L));
                    c = 5;
                    break;
                case Build.API_LEVELS.API_34 /* 34 */:
                    fz0Var.b(34, typedArray.getDimensionPixelSize(index, gz0Var.I));
                    c = 5;
                    break;
                case 37:
                    fz0Var.a(typedArray.getFloat(index, gz0Var.y), 37);
                    c = 5;
                    break;
                case 38:
                    int resourceId = typedArray.getResourceId(index, cVar.f315a);
                    cVar.f315a = resourceId;
                    fz0Var.b(38, resourceId);
                    c = 5;
                    break;
                case 39:
                    fz0Var.a(typedArray.getFloat(index, gz0Var.V), 39);
                    c = 5;
                    break;
                case RequestError.NETWORK_FAILURE /* 40 */:
                    fz0Var.a(typedArray.getFloat(index, gz0Var.U), 40);
                    c = 5;
                    break;
                case RequestError.NO_DEV_KEY /* 41 */:
                    fz0Var.b(41, typedArray.getInt(index, gz0Var.W));
                    c = 5;
                    break;
                case 42:
                    fz0Var.b(42, typedArray.getInt(index, gz0Var.X));
                    c = 5;
                    break;
                case 43:
                    fz0Var.a(typedArray.getFloat(index, iz0Var.d), 43);
                    c = 5;
                    break;
                case 44:
                    fz0Var.d(44, true);
                    fz0Var.a(typedArray.getDimension(index, jz0Var.n), 44);
                    c = 5;
                    break;
                case 45:
                    fz0Var.a(typedArray.getFloat(index, jz0Var.c), 45);
                    c = 5;
                    break;
                case 46:
                    fz0Var.a(typedArray.getFloat(index, jz0Var.d), 46);
                    c = 5;
                    break;
                case 47:
                    fz0Var.a(typedArray.getFloat(index, jz0Var.e), 47);
                    c = 5;
                    break;
                case 48:
                    fz0Var.a(typedArray.getFloat(index, jz0Var.f), 48);
                    c = 5;
                    break;
                case 49:
                    fz0Var.a(typedArray.getDimension(index, jz0Var.g), 49);
                    c = 5;
                    break;
                case RequestError.RESPONSE_CODE_FAILURE /* 50 */:
                    fz0Var.a(typedArray.getDimension(index, jz0Var.h), 50);
                    c = 5;
                    break;
                case 51:
                    fz0Var.a(typedArray.getDimension(index, jz0Var.j), 51);
                    c = 5;
                    break;
                case 52:
                    fz0Var.a(typedArray.getDimension(index, jz0Var.k), 52);
                    c = 5;
                    break;
                case 53:
                    fz0Var.a(typedArray.getDimension(index, jz0Var.l), 53);
                    c = 5;
                    break;
                case 54:
                    fz0Var.b(54, typedArray.getInt(index, gz0Var.Y));
                    c = 5;
                    break;
                case 55:
                    fz0Var.b(55, typedArray.getInt(index, gz0Var.Z));
                    c = 5;
                    break;
                case 56:
                    fz0Var.b(56, typedArray.getDimensionPixelSize(index, gz0Var.a0));
                    c = 5;
                    break;
                case 57:
                    fz0Var.b(57, typedArray.getDimensionPixelSize(index, gz0Var.b0));
                    c = 5;
                    break;
                case 58:
                    fz0Var.b(58, typedArray.getDimensionPixelSize(index, gz0Var.c0));
                    c = 5;
                    break;
                case 59:
                    fz0Var.b(59, typedArray.getDimensionPixelSize(index, gz0Var.d0));
                    c = 5;
                    break;
                case 60:
                    fz0Var.a(typedArray.getFloat(index, jz0Var.b), 60);
                    c = 5;
                    break;
                case 62:
                    fz0Var.b(62, typedArray.getDimensionPixelSize(index, gz0Var.B));
                    c = 5;
                    break;
                case 63:
                    fz0Var.a(typedArray.getFloat(index, gz0Var.C), 63);
                    c = 5;
                    break;
                case 64:
                    fz0Var.b(64, m(typedArray, index, hz0Var.b));
                    c = 5;
                    break;
                case 65:
                    if (typedArray.peekValue(index).type == 3) {
                        fz0Var.c(65, typedArray.getString(index));
                    } else {
                        fz0Var.c(65, g9.k[typedArray.getInteger(index, 0)]);
                    }
                    c = 5;
                    break;
                case 66:
                    fz0Var.b(66, typedArray.getInt(index, 0));
                    c = 5;
                    break;
                case 67:
                    fz0Var.a(typedArray.getFloat(index, hz0Var.h), 67);
                    c = 5;
                    break;
                case 68:
                    fz0Var.a(typedArray.getFloat(index, iz0Var.e), 68);
                    c = 5;
                    break;
                case 69:
                    fz0Var.a(typedArray.getFloat(index, 1.0f), 69);
                    c = 5;
                    break;
                case 70:
                    fz0Var.a(typedArray.getFloat(index, 1.0f), 70);
                    c = 5;
                    break;
                case 71:
                    o0.d("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    c = 5;
                    break;
                case 72:
                    fz0Var.b(72, typedArray.getInt(index, gz0Var.g0));
                    c = 5;
                    break;
                case 73:
                    fz0Var.b(73, typedArray.getDimensionPixelSize(index, gz0Var.h0));
                    c = 5;
                    break;
                case 74:
                    fz0Var.c(74, typedArray.getString(index));
                    c = 5;
                    break;
                case 75:
                    fz0Var.d(75, typedArray.getBoolean(index, gz0Var.o0));
                    c = 5;
                    break;
                case 76:
                    fz0Var.b(76, typedArray.getInt(index, hz0Var.e));
                    c = 5;
                    break;
                case 77:
                    fz0Var.c(77, typedArray.getString(index));
                    c = 5;
                    break;
                case 78:
                    fz0Var.b(78, typedArray.getInt(index, iz0Var.c));
                    c = 5;
                    break;
                case 79:
                    fz0Var.a(typedArray.getFloat(index, hz0Var.g), 79);
                    c = 5;
                    break;
                case 80:
                    fz0Var.d(80, typedArray.getBoolean(index, gz0Var.m0));
                    c = 5;
                    break;
                case 81:
                    fz0Var.d(81, typedArray.getBoolean(index, gz0Var.n0));
                    c = 5;
                    break;
                case 82:
                    fz0Var.b(82, typedArray.getInteger(index, hz0Var.c));
                    c = 5;
                    break;
                case 83:
                    fz0Var.b(83, m(typedArray, index, jz0Var.i));
                    c = 5;
                    break;
                case 84:
                    fz0Var.b(84, typedArray.getInteger(index, hz0Var.j));
                    c = 5;
                    break;
                case 85:
                    fz0Var.a(typedArray.getFloat(index, hz0Var.i), 85);
                    c = 5;
                    break;
                case 86:
                    int i4 = typedArray.peekValue(index).type;
                    if (i4 == 1) {
                        int resourceId2 = typedArray.getResourceId(index, -1);
                        hz0Var.m = resourceId2;
                        fz0Var.b(89, resourceId2);
                        if (hz0Var.m != -1) {
                            hz0Var.l = -2;
                            fz0Var.b(88, -2);
                        }
                    } else if (i4 == 3) {
                        String string = typedArray.getString(index);
                        hz0Var.k = string;
                        fz0Var.c(90, string);
                        if (hz0Var.k.indexOf("/") > 0) {
                            int resourceId3 = typedArray.getResourceId(index, -1);
                            hz0Var.m = resourceId3;
                            fz0Var.b(89, resourceId3);
                            hz0Var.l = -2;
                            fz0Var.b(88, -2);
                        } else {
                            hz0Var.l = -1;
                            fz0Var.b(88, -1);
                        }
                    } else {
                        int integer = typedArray.getInteger(index, hz0Var.m);
                        hz0Var.l = integer;
                        fz0Var.b(88, integer);
                    }
                    c = 5;
                    break;
                case 87:
                    o0.q("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                    c = 5;
                    break;
                case 93:
                    fz0Var.b(93, typedArray.getDimensionPixelSize(index, gz0Var.M));
                    c = 5;
                    break;
                case 94:
                    fz0Var.b(94, typedArray.getDimensionPixelSize(index, gz0Var.T));
                    c = 5;
                    break;
                case 95:
                    n(fz0Var, typedArray, index, 0);
                    c = 5;
                    break;
                case 96:
                    n(fz0Var, typedArray, index, 1);
                    c = 5;
                    break;
                case 97:
                    fz0Var.b(97, typedArray.getInt(index, gz0Var.p0));
                    c = 5;
                    break;
                case 98:
                    if (MotionLayout.u1) {
                        int resourceId4 = typedArray.getResourceId(index, cVar.f315a);
                        cVar.f315a = resourceId4;
                        if (resourceId4 == -1) {
                            cVar.b = typedArray.getString(index);
                        }
                    } else if (typedArray.peekValue(index).type == 3) {
                        cVar.b = typedArray.getString(index);
                    } else {
                        cVar.f315a = typedArray.getResourceId(index, cVar.f315a);
                    }
                    c = 5;
                    break;
                case 99:
                    fz0Var.d(99, typedArray.getBoolean(index, gz0Var.h));
                    c = 5;
                    break;
            }
        }
    }

    public final void a(MotionLayout motionLayout) {
        c cVar;
        int childCount = motionLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = motionLayout.getChildAt(i2);
            int id = childAt.getId();
            Integer numValueOf = Integer.valueOf(id);
            HashMap map = this.g;
            if (!map.containsKey(numValueOf)) {
                o0.q("ConstraintSet", "id unknown " + p01.J(childAt));
            } else if (this.f && id == -1) {
                ax6.u("All children of ConstraintLayout must have ids to use ConstraintSet");
                return;
            } else if (map.containsKey(Integer.valueOf(id)) && (cVar = (c) map.get(Integer.valueOf(id))) != null) {
                bz0.e(childAt, cVar.g);
            }
        }
    }

    public final void b(ConstraintLayout constraintLayout) {
        c(constraintLayout);
        constraintLayout.setConstraintSet(null);
        constraintLayout.requestLayout();
    }

    public final void c(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        HashMap map = this.g;
        HashSet<Integer> hashSet = new HashSet(map.keySet());
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            int id = childAt.getId();
            if (!map.containsKey(Integer.valueOf(id))) {
                o0.q("ConstraintSet", "id unknown " + p01.J(childAt));
            } else {
                if (this.f && id == -1) {
                    ax6.u("All children of ConstraintLayout must have ids to use ConstraintSet");
                    return;
                }
                if (id != -1 && map.containsKey(Integer.valueOf(id))) {
                    hashSet.remove(Integer.valueOf(id));
                    c cVar = (c) map.get(Integer.valueOf(id));
                    if (cVar != null) {
                        iz0 iz0Var = cVar.c;
                        gz0 gz0Var = cVar.e;
                        jz0 jz0Var = cVar.f;
                        if (childAt instanceof Barrier) {
                            gz0Var.i0 = 1;
                            Barrier barrier = (Barrier) childAt;
                            barrier.setId(id);
                            barrier.setType(gz0Var.g0);
                            barrier.setMargin(gz0Var.h0);
                            barrier.setAllowsGoneWidget(gz0Var.o0);
                            int[] iArr = gz0Var.j0;
                            if (iArr != null) {
                                barrier.setReferencedIds(iArr);
                            } else {
                                String str = gz0Var.k0;
                                if (str != null) {
                                    int[] iArrG = g(barrier, str);
                                    gz0Var.j0 = iArrG;
                                    barrier.setReferencedIds(iArrG);
                                }
                            }
                        }
                        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
                        layoutParams.a();
                        cVar.a(layoutParams);
                        bz0.e(childAt, cVar.g);
                        childAt.setLayoutParams(layoutParams);
                        if (iz0Var.c == 0) {
                            childAt.setVisibility(iz0Var.b);
                        }
                        childAt.setAlpha(iz0Var.d);
                        childAt.setRotation(jz0Var.b);
                        childAt.setRotationX(jz0Var.c);
                        childAt.setRotationY(jz0Var.d);
                        childAt.setScaleX(jz0Var.e);
                        childAt.setScaleY(jz0Var.f);
                        if (jz0Var.i != -1) {
                            if (((View) childAt.getParent()).findViewById(jz0Var.i) != null) {
                                float bottom = (r5.getBottom() + r5.getTop()) / 2.0f;
                                float right = (r5.getRight() + r5.getLeft()) / 2.0f;
                                if (childAt.getRight() - childAt.getLeft() > 0 && childAt.getBottom() - childAt.getTop() > 0) {
                                    childAt.setPivotX(right - childAt.getLeft());
                                    childAt.setPivotY(bottom - childAt.getTop());
                                }
                            }
                        } else {
                            if (!Float.isNaN(jz0Var.g)) {
                                childAt.setPivotX(jz0Var.g);
                            }
                            if (!Float.isNaN(jz0Var.h)) {
                                childAt.setPivotY(jz0Var.h);
                            }
                        }
                        childAt.setTranslationX(jz0Var.j);
                        childAt.setTranslationY(jz0Var.k);
                        childAt.setTranslationZ(jz0Var.l);
                        if (jz0Var.m) {
                            childAt.setElevation(jz0Var.n);
                        }
                    }
                }
            }
        }
        for (Integer num : hashSet) {
            c cVar2 = (c) map.get(num);
            if (cVar2 != null) {
                gz0 gz0Var2 = cVar2.e;
                if (gz0Var2.i0 == 1) {
                    Barrier barrier2 = new Barrier(constraintLayout.getContext());
                    barrier2.setId(num.intValue());
                    int[] iArr2 = gz0Var2.j0;
                    if (iArr2 != null) {
                        barrier2.setReferencedIds(iArr2);
                    } else {
                        String str2 = gz0Var2.k0;
                        if (str2 != null) {
                            int[] iArrG2 = g(barrier2, str2);
                            gz0Var2.j0 = iArrG2;
                            barrier2.setReferencedIds(iArrG2);
                        }
                    }
                    barrier2.setType(gz0Var2.g0);
                    barrier2.setMargin(gz0Var2.h0);
                    uz5 uz5Var = ConstraintLayout.h0;
                    ConstraintLayout.LayoutParams layoutParams2 = new ConstraintLayout.LayoutParams(-2, -2);
                    barrier2.q();
                    cVar2.a(layoutParams2);
                    constraintLayout.addView(barrier2, layoutParams2);
                }
                if (gz0Var2.f2502a) {
                    View guideline = new Guideline(constraintLayout.getContext());
                    guideline.setId(num.intValue());
                    uz5 uz5Var2 = ConstraintLayout.h0;
                    ConstraintLayout.LayoutParams layoutParams3 = new ConstraintLayout.LayoutParams(-2, -2);
                    cVar2.a(layoutParams3);
                    constraintLayout.addView(guideline, layoutParams3);
                }
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = constraintLayout.getChildAt(i3);
            if (childAt2 instanceof ConstraintHelper) {
                ((ConstraintHelper) childAt2).g(constraintLayout);
            }
        }
    }

    public final void e(ConstraintLayout constraintLayout) {
        int i2;
        HashMap map;
        int i3;
        d dVar = this;
        int childCount = constraintLayout.getChildCount();
        HashMap map2 = dVar.g;
        map2.clear();
        int i4 = 0;
        while (i4 < childCount) {
            View childAt = constraintLayout.getChildAt(i4);
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (dVar.f && id == -1) {
                ax6.u("All children of ConstraintLayout must have ids to use ConstraintSet");
                return;
            }
            if (!map2.containsKey(Integer.valueOf(id))) {
                map2.put(Integer.valueOf(id), new c());
            }
            c cVar = (c) map2.get(Integer.valueOf(id));
            if (cVar == null) {
                i2 = childCount;
                map = map2;
                i3 = i4;
            } else {
                iz0 iz0Var = cVar.c;
                gz0 gz0Var = cVar.e;
                jz0 jz0Var = cVar.f;
                i2 = childCount;
                HashMap map3 = new HashMap();
                map = map2;
                Class<?> cls = childAt.getClass();
                i3 = i4;
                HashMap map4 = dVar.e;
                for (String str : map4.keySet()) {
                    bz0 bz0Var = (bz0) map4.get(str);
                    HashMap map5 = map4;
                    try {
                        if (str.equals("BackgroundColor")) {
                            map3.put(str, new bz0(bz0Var, Integer.valueOf(((ColorDrawable) childAt.getBackground()).getColor())));
                        } else {
                            map3.put(str, new bz0(bz0Var, cls.getMethod("getMap" + str, null).invoke(childAt, null)));
                        }
                    } catch (IllegalAccessException e) {
                        StringBuilder sbQ = qe0.q(" Custom Attribute \"", str, "\" not found on ");
                        sbQ.append(cls.getName());
                        o0.e("TransitionLayout", sbQ.toString(), e);
                    } catch (NoSuchMethodException e2) {
                        o0.e("TransitionLayout", cls.getName() + " must have a method " + str, e2);
                    } catch (InvocationTargetException e3) {
                        StringBuilder sbQ2 = qe0.q(" Custom Attribute \"", str, "\" not found on ");
                        sbQ2.append(cls.getName());
                        o0.e("TransitionLayout", sbQ2.toString(), e3);
                    }
                    map4 = map5;
                }
                cVar.g = map3;
                cVar.c(id, layoutParams);
                iz0Var.b = childAt.getVisibility();
                iz0Var.d = childAt.getAlpha();
                jz0Var.b = childAt.getRotation();
                jz0Var.c = childAt.getRotationX();
                jz0Var.d = childAt.getRotationY();
                jz0Var.e = childAt.getScaleX();
                jz0Var.f = childAt.getScaleY();
                float pivotX = childAt.getPivotX();
                float pivotY = childAt.getPivotY();
                if (pivotX != 0.0d || pivotY != 0.0d) {
                    jz0Var.g = pivotX;
                    jz0Var.h = pivotY;
                }
                jz0Var.j = childAt.getTranslationX();
                jz0Var.k = childAt.getTranslationY();
                jz0Var.l = childAt.getTranslationZ();
                if (jz0Var.m) {
                    jz0Var.n = childAt.getElevation();
                }
                if (childAt instanceof Barrier) {
                    Barrier barrier = (Barrier) childAt;
                    gz0Var.o0 = barrier.getAllowsGoneWidget();
                    gz0Var.j0 = barrier.getReferencedIds();
                    gz0Var.g0 = barrier.getType();
                    gz0Var.h0 = barrier.getMargin();
                }
            }
            i4 = i3 + 1;
            dVar = this;
            childCount = i2;
            map2 = map;
        }
    }

    public final void f(int i2, int i3) {
        Integer numValueOf = Integer.valueOf(i2);
        HashMap map = this.g;
        if (!map.containsKey(numValueOf)) {
            map.put(Integer.valueOf(i2), new c());
        }
        c cVar = (c) map.get(Integer.valueOf(i2));
        if (cVar == null) {
            return;
        }
        gz0 gz0Var = cVar.e;
        gz0Var.n = i3;
        gz0Var.m = -1;
        gz0Var.q = -1;
        gz0Var.r = -1;
        gz0Var.s = -1;
    }

    public final c i(int i2) {
        Integer numValueOf = Integer.valueOf(i2);
        HashMap map = this.g;
        if (!map.containsKey(numValueOf)) {
            map.put(Integer.valueOf(i2), new c());
        }
        return (c) map.get(Integer.valueOf(i2));
    }

    public final c j(int i2) {
        Integer numValueOf = Integer.valueOf(i2);
        HashMap map = this.g;
        if (map.containsKey(numValueOf)) {
            return (c) map.get(Integer.valueOf(i2));
        }
        return null;
    }

    public final void k(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 2) {
                    String name = xml.getName();
                    c cVarH = h(context, Xml.asAttributeSet(xml), false);
                    if (name.equalsIgnoreCase("Guideline")) {
                        cVarH.e.f2502a = true;
                    }
                    this.g.put(Integer.valueOf(cVarH.f315a), cVarH);
                }
            }
        } catch (IOException e) {
            o0.e("ConstraintSet", "Error parsing resource: " + i2, e);
        } catch (XmlPullParserException e2) {
            o0.e("ConstraintSet", "Error parsing resource: " + i2, e2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:121:0x01af, code lost:
    
        continue;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void l(android.content.Context r10, android.content.res.XmlResourceParser r11) {
        /*
            Method dump skipped, instruction units count: 506
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.d.l(android.content.Context, android.content.res.XmlResourceParser):void");
    }
}

package androidx.compose.animation;

import androidx.compose.runtime.d;
import androidx.core.app.NotificationCompat;
import defpackage.ad4;
import defpackage.at4;
import defpackage.e42;
import defpackage.e94;
import defpackage.f11;
import defpackage.fm;
import defpackage.fu7;
import defpackage.gq3;
import defpackage.h94;
import defpackage.ip6;
import defpackage.iw0;
import defpackage.l12;
import defpackage.lh3;
import defpackage.m12;
import defpackage.nm;
import defpackage.o12;
import defpackage.oh1;
import defpackage.p01;
import defpackage.p56;
import defpackage.pm;
import defpackage.pn2;
import defpackage.q12;
import defpackage.qe0;
import defpackage.qm;
import defpackage.rb;
import defpackage.rm;
import defpackage.rw1;
import defpackage.sm;
import defpackage.sp6;
import defpackage.tm;
import defpackage.tp6;
import defpackage.u;
import defpackage.up6;
import defpackage.v12;
import defpackage.vq3;
import defpackage.wv0;
import defpackage.x36;
import defpackage.x95;
import defpackage.xb5;
import defpackage.xv0;
import defpackage.xw0;
import defpackage.zk2;
import defpackage.zr6;
import defpackage.zu0;
import defpackage.zv0;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.http2.Http2;
import okio.Segment;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final void a(sp6 sp6Var, Function1 function1, h94 h94Var, v12 v12Var, e42 e42Var, Function2 function2, zu0 zu0Var, iw0 iw0Var, int i) {
        int i2;
        int i3;
        int i4;
        boolean z;
        ip6 ip6Var;
        boolean z2;
        ip6 ip6VarB;
        boolean z3;
        zu0 zu0Var2 = zu0Var;
        ad4 ad4Var = sp6Var.d;
        iw0Var.a0(1912839215);
        if ((i & 6) == 0) {
            i2 = (iw0Var.f(sp6Var) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= iw0Var.h(function1) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= iw0Var.f(h94Var) ? NotificationCompat.FLAG_LOCAL_ONLY : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= iw0Var.f(v12Var) ? 2048 : Segment.SHARE_MINIMUM;
        }
        if ((i & 24576) == 0) {
            i2 |= iw0Var.f(e42Var) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE;
        }
        if ((196608 & i) == 0) {
            i2 |= iw0Var.h(function2) ? 131072 : 65536;
        }
        int i5 = i2 | 1572864;
        if ((12582912 & i) == 0) {
            i5 |= iw0Var.h(zu0Var2) ? 8388608 : 4194304;
        }
        if (!iw0Var.Q(i5 & 1, (4793491 & i5) != 4793490)) {
            iw0Var.T();
        } else if (((Boolean) function1.invoke(((x36) ad4Var).getValue())).booleanValue() || ((Boolean) function1.invoke(sp6Var.c())).booleanValue() || sp6Var.g() || sp6Var.d()) {
            iw0Var.Y(-232323267);
            int i6 = i5 & 14;
            int i7 = i6 | 48;
            int i8 = i7 & 14;
            boolean z4 = ((i8 ^ 6) > 4 && iw0Var.f(sp6Var)) || (i7 & 6) == 4;
            Object objL = iw0Var.L();
            Object obj = zv0.f7097a;
            if (z4 || objL == obj) {
                objL = sp6Var.c();
                iw0Var.i0(objL);
            }
            if (sp6Var.g()) {
                objL = sp6Var.c();
            }
            iw0Var.Y(1844425648);
            l12 l12VarD = d(sp6Var, function1, objL, iw0Var);
            iw0Var.q(false);
            Object value = ((x36) ad4Var).getValue();
            iw0Var.Y(1844425648);
            l12 l12VarD2 = d(sp6Var, function1, value, iw0Var);
            iw0Var.q(false);
            int i9 = i8 | 3072;
            int i10 = up6.f5932a;
            int i11 = (i9 & 14) ^ 6;
            boolean z5 = (i11 > 4 && iw0Var.f(sp6Var)) || (i9 & 6) == 4;
            Object objL2 = iw0Var.L();
            if (z5 || objL2 == obj) {
                i3 = i5;
                i4 = i9;
                objL2 = new sp6(new pn2(l12VarD, 19), sp6Var, oh1.p(new StringBuilder(), sp6Var.c, " > EnterExitTransition"));
                iw0Var.i0(objL2);
            } else {
                i3 = i5;
                i4 = i9;
            }
            sp6 sp6Var2 = (sp6) objL2;
            boolean zF = ((i11 > 4 && iw0Var.f(sp6Var)) || (i4 & 6) == 4) | iw0Var.f(sp6Var2);
            Object objL3 = iw0Var.L();
            if (zF || objL3 == obj) {
                objL3 = new vq3(22, sp6Var, sp6Var2);
                iw0Var.i0(objL3);
            }
            gq3.d(sp6Var2, (Function1) objL3, iw0Var);
            if (sp6Var.g()) {
                sp6Var2.j(l12VarD, l12VarD2);
            } else {
                sp6Var2.k(l12VarD2);
                ((x36) sp6Var2.k).setValue(Boolean.FALSE);
            }
            Object objI = d.i(function2, iw0Var);
            Object objC = sp6Var2.c();
            ad4 ad4Var2 = sp6Var2.d;
            x36 x36Var = (x36) ad4Var2;
            Object objInvoke = function2.invoke(objC, x36Var.getValue());
            boolean zF2 = iw0Var.f(sp6Var2) | iw0Var.f(objI);
            Object objL4 = iw0Var.L();
            f11 f11Var = null;
            if (zF2 || objL4 == obj) {
                objL4 = new u(sp6Var2, objI, f11Var, 1);
                iw0Var.i0(objL4);
            }
            Object obj2 = (Function2) objL4;
            Object objL5 = iw0Var.L();
            if (objL5 == obj) {
                objL5 = d.h(objInvoke);
                iw0Var.i0(objL5);
            }
            ad4 ad4Var3 = (ad4) objL5;
            Unit unit = Unit.f3760a;
            boolean zH = iw0Var.h(obj2);
            Object objL6 = iw0Var.L();
            if (zH || objL6 == obj) {
                objL6 = new xb5(obj2, ad4Var3, null, 4);
                iw0Var.i0(objL6);
            }
            gq3.f(iw0Var, unit, (Function2) objL6);
            Object objC2 = sp6Var2.c();
            l12 l12Var = l12.c;
            if (objC2 == l12Var && ((x36) ad4Var2).getValue() == l12Var && ((Boolean) ad4Var3.getValue()).booleanValue()) {
                iw0Var.Y(-230155437);
                z3 = false;
                iw0Var.q(false);
                zu0Var2 = zu0Var;
            } else {
                iw0Var.Y(-231293261);
                boolean z6 = i6 == 4;
                Object objL7 = iw0Var.L();
                if (z6 || objL7 == obj) {
                    objL7 = new tm();
                    iw0Var.i0(objL7);
                }
                tm tmVar = (tm) objL7;
                p56 p56Var = q12.f4927a;
                zr6 zr6Var = fu7.o;
                Object objL8 = iw0Var.L();
                if (objL8 == obj) {
                    objL8 = xw0.X;
                    iw0Var.i0(objL8);
                }
                Function0 function0 = (Function0) objL8;
                boolean zF3 = iw0Var.f(sp6Var2);
                Object objL9 = iw0Var.L();
                if (zF3 || objL9 == obj) {
                    objL9 = d.h(v12Var);
                    iw0Var.i0(objL9);
                }
                ad4 ad4Var4 = (ad4) objL9;
                if (sp6Var2.c() == x36Var.getValue() && sp6Var2.c() == l12.b) {
                    if (sp6Var2.g()) {
                        ad4Var4.setValue(v12Var);
                    } else {
                        ad4Var4.setValue(v12.b);
                    }
                } else if (x36Var.getValue() == l12.b) {
                    ad4Var4.setValue(((v12) ad4Var4.getValue()).a(v12Var));
                }
                v12 v12Var2 = (v12) ad4Var4.getValue();
                boolean zF4 = iw0Var.f(sp6Var2);
                Object objL10 = iw0Var.L();
                if (zF4 || objL10 == obj) {
                    objL10 = d.h(e42Var);
                    iw0Var.i0(objL10);
                }
                ad4 ad4Var5 = (ad4) objL10;
                if (sp6Var2.c() == x36Var.getValue() && sp6Var2.c() == l12.b) {
                    if (sp6Var2.g()) {
                        ad4Var5.setValue(e42Var);
                    } else {
                        ad4Var5.setValue(e42.b);
                    }
                } else if (x36Var.getValue() != l12.b) {
                    ad4Var5.setValue(((e42) ad4Var5.getValue()).a(e42Var));
                }
                e42 e42Var2 = (e42) ad4Var5.getValue();
                boolean z7 = (v12Var2.f6001a.b == null && e42Var2.f1861a.b == null) ? false : true;
                tp6 tp6Var = e42Var2.f1861a;
                if (z7) {
                    iw0Var.Y(133838277);
                    Object objL11 = iw0Var.L();
                    if (objL11 == obj) {
                        objL11 = "Built-in slide";
                        iw0Var.i0("Built-in slide");
                    }
                    ip6 ip6VarB2 = up6.b(sp6Var2, zr6Var, (String) objL11, iw0Var);
                    z = false;
                    iw0Var.q(false);
                    ip6Var = ip6VarB2;
                } else {
                    z = false;
                    iw0Var.Y(133944080);
                    iw0Var.q(false);
                    ip6Var = null;
                }
                iw0Var.Y(134146695);
                iw0Var.q(z);
                iw0Var.Y(134390727);
                iw0Var.q(z);
                boolean z8 = !false;
                if ((v12Var2.f6001a.f5729a == null && e42Var2.f1861a.f5729a == null) ? false : true) {
                    iw0Var.Y(-703859581);
                    zr6 zr6Var2 = fu7.i;
                    Object objL12 = iw0Var.L();
                    if (objL12 == obj) {
                        objL12 = "Built-in alpha";
                        iw0Var.i0("Built-in alpha");
                    }
                    ip6VarB = up6.b(sp6Var2, zr6Var2, (String) objL12, iw0Var);
                    z2 = false;
                    iw0Var.q(false);
                } else {
                    z2 = false;
                    iw0Var.Y(-703690136);
                    iw0Var.q(false);
                    ip6VarB = null;
                }
                iw0Var.Y(-703453048);
                iw0Var.q(z2);
                iw0Var.Y(-703203064);
                iw0Var.q(z2);
                boolean zH2 = iw0Var.h(ip6VarB) | iw0Var.f(v12Var2) | iw0Var.f(e42Var2) | iw0Var.h(null) | iw0Var.f(sp6Var2) | iw0Var.h(null);
                Object objL13 = iw0Var.L();
                if (zH2 || objL13 == obj) {
                    objL13 = new m12(ip6VarB, sp6Var2, v12Var2, e42Var2);
                    iw0Var.i0(objL13);
                }
                m12 m12Var = (m12) objL13;
                boolean zG = iw0Var.g(z8) | iw0Var.f(function0);
                Object objL14 = iw0Var.L();
                if (zG || objL14 == obj) {
                    objL14 = new o12(z8, function0);
                    iw0Var.i0(objL14);
                }
                h94 h94VarD = androidx.compose.ui.graphics.a.a((Function1) objL14).d(new EnterExitTransitionElement(sp6Var2, null, null, ip6Var, v12Var2, e42Var2, function0, m12Var));
                iw0Var.Y(-7429769);
                iw0Var.q(false);
                h94 h94VarD2 = h94Var.d(h94VarD.d(e94.f1898a));
                Object objL15 = iw0Var.L();
                if (objL15 == obj) {
                    objL15 = new fm(tmVar);
                    iw0Var.i0(objL15);
                }
                fm fmVar = (fm) objL15;
                int iHashCode = Long.hashCode(iw0Var.T);
                at4 at4VarL = iw0Var.l();
                h94 h94VarS = p01.S(iw0Var, h94VarD2);
                xv0.p.getClass();
                Function0 function02 = wv0.b;
                iw0Var.c0();
                if (iw0Var.S) {
                    iw0Var.k(function02);
                } else {
                    iw0Var.l0();
                }
                lh3.j(iw0Var, fmVar, wv0.e);
                lh3.j(iw0Var, at4VarL, wv0.d);
                rm rmVar = wv0.f;
                if (iw0Var.S || !Intrinsics.a(iw0Var.L(), Integer.valueOf(iHashCode))) {
                    qe0.v(iHashCode, iw0Var, iHashCode, rmVar);
                }
                lh3.j(iw0Var, h94VarS, wv0.c);
                zu0Var2 = zu0Var;
                zu0Var2.a(tmVar, iw0Var, Integer.valueOf((i3 >> 18) & 112));
                iw0Var.q(true);
                z3 = false;
                iw0Var.q(false);
            }
            iw0Var.q(z3);
        } else {
            iw0Var.Y(-230149485);
            iw0Var.q(false);
        }
        x95 x95VarS = iw0Var.s();
        if (x95VarS != null) {
            x95VarS.d = new nm(sp6Var, function1, h94Var, v12Var, e42Var, function2, zu0Var2, i);
        }
    }

    public static final void b(boolean z, h94 h94Var, v12 v12Var, e42 e42Var, String str, zu0 zu0Var, iw0 iw0Var, int i) {
        int i2;
        iw0Var.a0(-1448730565);
        if ((i & 6) == 0) {
            i2 = (iw0Var.g(z) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= iw0Var.f(h94Var) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= iw0Var.f(v12Var) ? NotificationCompat.FLAG_LOCAL_ONLY : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= iw0Var.f(e42Var) ? 2048 : Segment.SHARE_MINIMUM;
        }
        if ((i & 24576) == 0) {
            i2 |= iw0Var.f(str) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE;
        }
        if ((196608 & i) == 0) {
            i2 |= iw0Var.h(zu0Var) ? 131072 : 65536;
        }
        if (iw0Var.Q(i2 & 1, (74899 & i2) != 74898)) {
            sp6 sp6VarD = up6.d(Boolean.valueOf(z), str, iw0Var, (i2 & 14) | ((i2 >> 9) & 112));
            Object objL = iw0Var.L();
            if (objL == zv0.f7097a) {
                objL = rb.Z;
                iw0Var.i0(objL);
            }
            Function1 function1 = (Function1) objL;
            int i3 = i2 << 3;
            c(sp6VarD, function1, h94Var, v12Var, e42Var, zu0Var, iw0Var, (i3 & 57344) | (i3 & 896) | 48 | (i3 & 7168) | (i2 & 458752));
        } else {
            iw0Var.T();
        }
        x95 x95VarS = iw0Var.s();
        if (x95VarS != null) {
            x95VarS.d = new pm(z, h94Var, v12Var, e42Var, str, zu0Var, i);
        }
    }

    public static final void c(sp6 sp6Var, Function1 function1, h94 h94Var, v12 v12Var, e42 e42Var, zu0 zu0Var, iw0 iw0Var, int i) {
        int i2;
        v12 v12Var2;
        e42 e42Var2;
        zu0 zu0Var2;
        iw0Var.a0(1706321816);
        if ((i & 6) == 0) {
            i2 = (iw0Var.f(sp6Var) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= iw0Var.h(function1) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= iw0Var.f(h94Var) ? NotificationCompat.FLAG_LOCAL_ONLY : 128;
        }
        if ((i & 3072) == 0) {
            v12Var2 = v12Var;
            i2 |= iw0Var.f(v12Var2) ? 2048 : Segment.SHARE_MINIMUM;
        } else {
            v12Var2 = v12Var;
        }
        if ((i & 24576) == 0) {
            e42Var2 = e42Var;
            i2 |= iw0Var.f(e42Var2) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE;
        } else {
            e42Var2 = e42Var;
        }
        if ((i & 196608) == 0) {
            zu0Var2 = zu0Var;
            i2 |= iw0Var.h(zu0Var2) ? 131072 : 65536;
        } else {
            zu0Var2 = zu0Var;
        }
        if (iw0Var.Q(i2 & 1, (74899 & i2) != 74898)) {
            int i3 = i2 & 112;
            int i4 = i2 & 14;
            boolean z = (i3 == 32) | (i4 == 4);
            Object objL = iw0Var.L();
            rw1 rw1Var = zv0.f7097a;
            if (z || objL == rw1Var) {
                objL = new qm(function1, sp6Var);
                iw0Var.i0(objL);
            }
            h94 h94VarA = androidx.compose.ui.layout.a.a(h94Var, (zk2) objL);
            Object objL2 = iw0Var.L();
            if (objL2 == rw1Var) {
                objL2 = rm.b;
                iw0Var.i0(objL2);
            }
            a(sp6Var, function1, h94VarA, v12Var2, e42Var2, (Function2) objL2, zu0Var2, iw0Var, 196608 | i4 | i3 | (i2 & 7168) | (57344 & i2) | ((i2 << 6) & 29360128));
        } else {
            iw0Var.T();
        }
        x95 x95VarS = iw0Var.s();
        if (x95VarS != null) {
            x95VarS.d = new sm(sp6Var, function1, h94Var, v12Var, e42Var, zu0Var, i);
        }
    }

    public static final l12 d(sp6 sp6Var, Function1 function1, Object obj, iw0 iw0Var) {
        l12 l12Var;
        iw0Var.U(sp6Var, -422486105, 0, null);
        if (sp6Var.g()) {
            iw0Var.Y(-212146657);
            iw0Var.q(false);
            l12Var = ((Boolean) function1.invoke(obj)).booleanValue() ? l12.b : ((Boolean) function1.invoke(sp6Var.c())).booleanValue() ? l12.c : l12.f3842a;
        } else {
            iw0Var.Y(-211872524);
            Object objL = iw0Var.L();
            if (objL == zv0.f7097a) {
                objL = d.h(Boolean.FALSE);
                iw0Var.i0(objL);
            }
            ad4 ad4Var = (ad4) objL;
            if (((Boolean) function1.invoke(sp6Var.c())).booleanValue()) {
                ad4Var.setValue(Boolean.TRUE);
            }
            l12Var = ((Boolean) function1.invoke(obj)).booleanValue() ? l12.b : ((Boolean) ad4Var.getValue()).booleanValue() ? l12.c : l12.f3842a;
            iw0Var.q(false);
        }
        iw0Var.q(false);
        return l12Var;
    }
}

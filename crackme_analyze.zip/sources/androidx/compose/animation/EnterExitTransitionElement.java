package androidx.compose.animation;

import defpackage.e42;
import defpackage.g94;
import defpackage.ip6;
import defpackage.m12;
import defpackage.p94;
import defpackage.sp6;
import defpackage.u12;
import defpackage.v12;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/animation/EnterExitTransitionElement;", "Lp94;", "Lu12;", "animation"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class EnterExitTransitionElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final sp6 f219a;
    public final ip6 b;
    public final ip6 c;
    public final ip6 d;
    public final v12 e;
    public final e42 f;
    public final Function0 g;
    public final m12 h;

    public EnterExitTransitionElement(sp6 sp6Var, ip6 ip6Var, ip6 ip6Var2, ip6 ip6Var3, v12 v12Var, e42 e42Var, Function0 function0, m12 m12Var) {
        this.f219a = sp6Var;
        this.b = ip6Var;
        this.c = ip6Var2;
        this.d = ip6Var3;
        this.e = v12Var;
        this.f = e42Var;
        this.g = function0;
        this.h = m12Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof EnterExitTransitionElement) {
            EnterExitTransitionElement enterExitTransitionElement = (EnterExitTransitionElement) obj;
            if (this.f219a == enterExitTransitionElement.f219a && Intrinsics.a(this.b, enterExitTransitionElement.b) && Intrinsics.a(this.c, enterExitTransitionElement.c) && Intrinsics.a(this.d, enterExitTransitionElement.d) && this.e.equals(enterExitTransitionElement.e) && this.f.equals(enterExitTransitionElement.f) && Intrinsics.a(this.g, enterExitTransitionElement.g) && Intrinsics.a(this.h, enterExitTransitionElement.h)) {
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new u12(this.f219a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        u12 u12Var = (u12) g94Var;
        u12Var.d0 = this.f219a;
        u12Var.e0 = this.b;
        u12Var.f0 = this.c;
        u12Var.g0 = this.d;
        u12Var.h0 = this.e;
        u12Var.i0 = this.f;
        u12Var.j0 = this.g;
        u12Var.k0 = this.h;
    }

    public final int hashCode() {
        int iHashCode = this.f219a.hashCode() * 31;
        ip6 ip6Var = this.b;
        int iHashCode2 = (iHashCode + (ip6Var == null ? 0 : ip6Var.hashCode())) * 31;
        ip6 ip6Var2 = this.c;
        int iHashCode3 = (iHashCode2 + (ip6Var2 == null ? 0 : ip6Var2.hashCode())) * 31;
        ip6 ip6Var3 = this.d;
        return this.h.hashCode() + ((this.g.hashCode() + ((this.f.f1861a.hashCode() + ((this.e.f6001a.hashCode() + ((iHashCode3 + (ip6Var3 != null ? ip6Var3.hashCode() : 0)) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "EnterExitTransitionElement(transition=" + this.f219a + ", sizeAnimation=" + this.b + ", offsetAnimation=" + this.c + ", slideAnimation=" + this.d + ", enter=" + this.e + ", exit=" + this.f + ", isEnabled=" + this.g + ", graphicsLayerBlock=" + this.h + ')';
    }
}

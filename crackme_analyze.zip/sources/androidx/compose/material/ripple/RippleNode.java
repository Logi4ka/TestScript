package androidx.compose.material.ripple;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.compose.material3.a;
import androidx.compose.material3.b;
import defpackage.be3;
import defpackage.cj0;
import defpackage.co1;
import defpackage.dm;
import defpackage.do2;
import defpackage.ds0;
import defpackage.ej0;
import defpackage.eo0;
import defpackage.fc4;
import defpackage.fq3;
import defpackage.fs;
import defpackage.g94;
import defpackage.i16;
import defpackage.kh;
import defpackage.kk;
import defpackage.ld3;
import defpackage.lh1;
import defpackage.lu4;
import defpackage.ma3;
import defpackage.or0;
import defpackage.p15;
import defpackage.ps3;
import defpackage.q15;
import defpackage.q5;
import defpackage.r15;
import defpackage.rb4;
import defpackage.s15;
import defpackage.sg5;
import defpackage.st1;
import defpackage.tf;
import defpackage.tg5;
import defpackage.tt1;
import defpackage.uw0;
import defpackage.vk5;
import defpackage.yb5;
import defpackage.yj4;
import defpackage.zr0;
import io.flutter.embedding.android.KeyboardMap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b!\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004R\u0014\u0010\u0006\u001a\u00020\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Landroidx/compose/material/ripple/RippleNode;", "Lg94;", "Luw0;", "Lst1;", "Lld3;", "Lds0;", "color", "Lds0;", "material-ripple"}, k = 1, mv = {2, 0, 0}, xi = 48)
public abstract class RippleNode extends g94 implements uw0, st1, ld3 {
    private final ds0 color;
    public final rb4 d0;
    public final boolean e0;
    public final float f0;
    public final a g0;
    public eo0 h0;
    public float i0;
    public boolean k0;
    public long j0 = 0;
    public final fc4 l0 = new fc4();

    public RippleNode(rb4 rb4Var, boolean z, float f, b bVar, a aVar) {
        this.d0 = rb4Var;
        this.e0 = z;
        this.f0 = f;
        this.color = bVar;
        this.g0 = aVar;
    }

    public final void F0(s15 s15Var) {
        tg5 tg5Var;
        if (!(s15Var instanceof q15)) {
            if (s15Var instanceof r15) {
                tg5 tg5Var2 = ((kk) this).n0;
                if (tg5Var2 != null) {
                    tg5Var2.d();
                    return;
                }
                return;
            }
            if (!(s15Var instanceof p15) || (tg5Var = ((kk) this).n0) == null) {
                return;
            }
            tg5Var.d();
            return;
        }
        q15 q15Var = (q15) s15Var;
        long j = this.j0;
        float f = this.i0;
        kk kkVar = (kk) this;
        sg5 sg5Var = kkVar.m0;
        if (sg5Var == null) {
            Object obj = (View) lh1.s(kkVar, kh.f);
            while (!(obj instanceof ViewGroup)) {
                ViewParent parent = ((View) obj).getParent();
                if (!(parent instanceof View)) {
                    vk5.g(obj, "Couldn't find a valid parent for ", ". Are you overriding LocalView and providing a View that is not attached to the view hierarchy?");
                    return;
                }
                obj = parent;
            }
            ViewGroup viewGroup = (ViewGroup) obj;
            int childCount = viewGroup.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    sg5 sg5Var2 = new sg5(viewGroup.getContext());
                    viewGroup.addView(sg5Var2);
                    sg5Var = sg5Var2;
                    break;
                } else {
                    View childAt = viewGroup.getChildAt(i);
                    if (childAt instanceof sg5) {
                        sg5Var = (sg5) childAt;
                        break;
                    }
                    i++;
                }
            }
            kkVar.m0 = sg5Var;
        }
        ArrayList arrayList = sg5Var.b;
        lu4 lu4Var = sg5Var.d;
        LinkedHashMap linkedHashMap = (LinkedHashMap) lu4Var.b;
        LinkedHashMap linkedHashMap2 = (LinkedHashMap) lu4Var.b;
        LinkedHashMap linkedHashMap3 = (LinkedHashMap) lu4Var.c;
        tg5 tg5Var3 = (tg5) linkedHashMap.get(kkVar);
        int i2 = 1;
        if (tg5Var3 == null) {
            ArrayList arrayList2 = sg5Var.c;
            arrayList2.getClass();
            tg5Var3 = (tg5) (arrayList2.isEmpty() ? null : arrayList2.remove(0));
            if (tg5Var3 == null) {
                if (sg5Var.e > or0.g(arrayList)) {
                    tg5Var3 = new tg5(sg5Var.getContext());
                    sg5Var.addView(tg5Var3);
                    arrayList.add(tg5Var3);
                } else {
                    tg5Var3 = (tg5) arrayList.get(sg5Var.e);
                    kk kkVar2 = (kk) linkedHashMap3.get(tg5Var3);
                    if (kkVar2 != null) {
                        kkVar2.n0 = null;
                        lh1.E(kkVar2);
                        tg5 tg5Var4 = (tg5) linkedHashMap2.get(kkVar2);
                        if (tg5Var4 != null) {
                        }
                        linkedHashMap2.remove(kkVar2);
                        tg5Var3.c();
                    }
                }
                int i3 = sg5Var.e;
                if (i3 < sg5Var.f5443a - 1) {
                    sg5Var.e = i3 + 1;
                } else {
                    sg5Var.e = 0;
                }
            }
            linkedHashMap2.put(kkVar, tg5Var3);
            linkedHashMap3.put(tg5Var3, kkVar);
        }
        tg5 tg5Var5 = tg5Var3;
        int iB = ps3.b(f);
        long jA = kkVar.color.a();
        kkVar.g0.invoke();
        tg5Var5.b(q15Var, kkVar.e0, j, iB, jA, new q5(kkVar, i2));
        kkVar.n0 = tg5Var5;
        lh1.E(kkVar);
    }

    @Override // defpackage.st1
    public final void c0(be3 be3Var) {
        ej0 ej0Var = be3Var.f572a;
        be3Var.a();
        eo0 eo0Var = this.h0;
        if (eo0Var != null) {
            float f = this.i0;
            long jA = this.color.a();
            float fFloatValue = ((Number) ((dm) eo0Var.c).d()).floatValue();
            if (fFloatValue > 0.0f) {
                long jB = zr0.b(fFloatValue, jA);
                if (eo0Var.f1988a) {
                    float fD = i16.d(ej0Var.d());
                    float fB = i16.b(ej0Var.d());
                    fs fsVar = ej0Var.b;
                    long jQ = fsVar.q();
                    fsVar.n().d();
                    try {
                        ((fs) ((do2) fsVar.f2228a).b).n().k(0.0f, 0.0f, fD, fB, 1);
                        tt1.m0(be3Var, jB, f, 0L, 124);
                    } finally {
                        fsVar.n().n();
                        fsVar.E(jQ);
                    }
                } else {
                    tt1.m0(be3Var, jB, f, 0L, 124);
                }
            }
        }
        kk kkVar = (kk) this;
        cj0 cj0VarN = ej0Var.b.n();
        tg5 tg5Var = kkVar.n0;
        if (tg5Var != null) {
            long j = kkVar.j0;
            int iB = ps3.b(kkVar.i0);
            long jA2 = kkVar.color.a();
            kkVar.g0.invoke();
            tg5Var.e(iB, j, jA2);
            tg5Var.draw(tf.a(cj0VarN));
        }
    }

    @Override // defpackage.ld3
    public final void o(long j) {
        float fW;
        this.k0 = true;
        co1 co1Var = ma3.O(this).l0;
        this.j0 = fq3.K(j);
        float f = this.f0;
        if (Float.isNaN(f)) {
            long j2 = this.j0;
            float fD = i16.d(j2);
            fW = yj4.d((((long) Float.floatToRawIntBits(i16.b(j2))) & KeyboardMap.kValueMask) | (Float.floatToRawIntBits(fD) << 32)) / 2.0f;
            if (this.e0) {
                fW += co1Var.W(10.0f);
            }
        } else {
            fW = co1Var.W(f);
        }
        this.i0 = fW;
        fc4 fc4Var = this.l0;
        Object[] objArr = fc4Var.f2137a;
        int i = fc4Var.b;
        for (int i2 = 0; i2 < i; i2++) {
            F0((s15) objArr[i2]);
        }
        fc4Var.c();
    }

    @Override // defpackage.g94
    public final boolean u0() {
        return false;
    }

    @Override // defpackage.g94
    public final void x0() {
        fq3.u(t0(), null, new yb5(this, null, 1), 3);
    }
}

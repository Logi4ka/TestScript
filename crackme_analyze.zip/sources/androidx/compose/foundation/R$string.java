package androidx.compose.foundation;

/* JADX INFO: loaded from: classes2.dex */
public final class R$string {
    public static int autofill = 2131820585;
    public static int tooltip_description = 2131821003;
    public static int tooltip_label = 2131821004;

    private R$string() {
    }
}

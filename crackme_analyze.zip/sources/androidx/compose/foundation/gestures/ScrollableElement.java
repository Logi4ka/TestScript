package androidx.compose.foundation.gestures;

import defpackage.dp5;
import defpackage.ep5;
import defpackage.fm6;
import defpackage.g94;
import defpackage.ln4;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/gestures/ScrollableElement;", "Lp94;", "Ldp5;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class ScrollableElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ep5 f232a;
    public final ln4 b;
    public final boolean c;
    public final boolean d;

    public ScrollableElement(ep5 ep5Var, ln4 ln4Var, boolean z, boolean z2) {
        this.f232a = ep5Var;
        this.b = ln4Var;
        this.c = z;
        this.d = z2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ScrollableElement)) {
            return false;
        }
        ScrollableElement scrollableElement = (ScrollableElement) obj;
        return Intrinsics.a(this.f232a, scrollableElement.f232a) && this.b == scrollableElement.b && this.c == scrollableElement.c && this.d == scrollableElement.d;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new dp5(null, null, null, null, this.b, this.f232a, this.c, this.d);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((dp5) g94Var).M0(null, null, null, null, this.b, this.f232a, this.c, this.d);
    }

    public final int hashCode() {
        return fm6.f(fm6.f((this.b.hashCode() + (this.f232a.hashCode() * 31)) * 961, 31, this.c), 29791, this.d);
    }
}

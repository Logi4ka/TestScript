package androidx.compose.foundation.gestures;

import defpackage.h94;
import defpackage.li6;
import defpackage.ln4;
import defpackage.qp4;
import defpackage.wo5;
import defpackage.xo5;
import defpackage.ym5;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ym5 f233a = new ym5(7);
    public static final xo5 b = new xo5();
    public static final wo5 c = new wo5();
    public static final qp4 d = new qp4(1);

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object a(defpackage.kp5 r11, long r12, defpackage.h11 r14) {
        /*
            boolean r0 = r14 instanceof defpackage.yo5
            if (r0 == 0) goto L13
            r0 = r14
            yo5 r0 = (defpackage.yo5) r0
            int r1 = r0.d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.d = r1
            goto L18
        L13:
            yo5 r0 = new yo5
            r0.<init>(r14)
        L18:
            java.lang.Object r14 = r0.c
            ge1 r1 = defpackage.ge1.f2376a
            int r2 = r0.d
            r3 = 1
            if (r2 == 0) goto L34
            if (r2 != r3) goto L2d
            mb5 r11 = r0.b
            kp5 r12 = r0.f6784a
            defpackage.ku7.L(r14)
            r8 = r11
            r11 = r12
            goto L55
        L2d:
            java.lang.String r11 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.vk5.k(r11)
            r11 = 0
            return r11
        L34:
            defpackage.ku7.L(r14)
            mb5 r8 = new mb5
            r8.<init>()
            fd4 r14 = defpackage.fd4.f2141a
            r r4 = new r
            r9 = 0
            r10 = 4
            r5 = r11
            r6 = r12
            r4.<init>(r5, r6, r8, r9, r10)
            r0.f6784a = r5
            r0.b = r8
            r0.d = r3
            java.lang.Object r11 = r5.f(r14, r4, r0)
            if (r11 != r1) goto L54
            return r1
        L54:
            r11 = r5
        L55:
            float r12 = r8.f4123a
            long r11 = r11.h(r12)
            yj4 r13 = new yj4
            r13.<init>(r11)
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.gestures.a.a(kp5, long, h11):java.lang.Object");
    }

    public static h94 b(li6 li6Var, ln4 ln4Var, boolean z, boolean z2) {
        return new ScrollableElement(li6Var, ln4Var, z, z2);
    }
}

package androidx.compose.foundation;

import defpackage.e94;
import defpackage.h94;
import defpackage.iw0;
import defpackage.rb4;
import defpackage.t03;
import defpackage.yg5;
import defpackage.zk2;
import defpackage.zv0;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b implements zk2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ t03 f230a;
    public final /* synthetic */ boolean b;
    public final /* synthetic */ yg5 c;
    public final /* synthetic */ Function0 d;

    public b(t03 t03Var, boolean z, yg5 yg5Var, Function0 function0) {
        this.f230a = t03Var;
        this.b = z;
        this.c = yg5Var;
        this.d = function0;
    }

    @Override // defpackage.zk2
    public final Object a(Object obj, Object obj2, Object obj3) {
        iw0 iw0Var = (iw0) obj2;
        ((Number) obj3).intValue();
        iw0Var.Y(-1525724089);
        Object objL = iw0Var.L();
        if (objL == zv0.f7097a) {
            objL = new rb4();
            iw0Var.i0(objL);
        }
        rb4 rb4Var = (rb4) objL;
        h94 h94VarD = c.a(e94.f1898a, rb4Var, this.f230a).d(new ClickableElement(rb4Var, null, false, this.b, null, this.c, this.d));
        iw0Var.q(false);
        return h94VarD;
    }
}

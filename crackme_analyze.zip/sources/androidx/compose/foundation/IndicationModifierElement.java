package androidx.compose.foundation;

import defpackage.g94;
import defpackage.kn1;
import defpackage.p94;
import defpackage.rb4;
import defpackage.s03;
import defpackage.t03;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/IndicationModifierElement;", "Lp94;", "Ls03;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class IndicationModifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final rb4 f226a;
    public final t03 b;

    public IndicationModifierElement(rb4 rb4Var, t03 t03Var) {
        this.f226a = rb4Var;
        this.b = t03Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IndicationModifierElement)) {
            return false;
        }
        IndicationModifierElement indicationModifierElement = (IndicationModifierElement) obj;
        return Intrinsics.a(this.f226a, indicationModifierElement.f226a) && Intrinsics.a(this.b, indicationModifierElement.b);
    }

    @Override // defpackage.p94
    public final g94 f() {
        kn1 kn1VarA = this.b.a(this.f226a);
        s03 s03Var = new s03();
        s03Var.f0 = kn1VarA;
        s03Var.F0(kn1VarA);
        return s03Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        s03 s03Var = (s03) g94Var;
        kn1 kn1VarA = this.b.a(this.f226a);
        s03Var.G0(s03Var.f0);
        s03Var.f0 = kn1VarA;
        s03Var.F0(kn1VarA);
    }

    public final int hashCode() {
        return this.b.hashCode() + (this.f226a.hashCode() * 31);
    }
}

package androidx.compose.foundation;

import defpackage.h94;
import defpackage.nf1;
import defpackage.rb4;
import defpackage.t03;
import defpackage.zw0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final zw0 f231a = new zw0(new nf1(19));

    public static final h94 a(h94 h94Var, rb4 rb4Var, t03 t03Var) {
        return t03Var == null ? h94Var : h94Var.d(new IndicationModifierElement(rb4Var, t03Var));
    }
}

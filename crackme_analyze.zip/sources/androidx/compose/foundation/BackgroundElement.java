package androidx.compose.foundation;

import defpackage.fx6;
import defpackage.g20;
import defpackage.g94;
import defpackage.gx6;
import defpackage.ky5;
import defpackage.lh1;
import defpackage.oh1;
import defpackage.p94;
import defpackage.zr0;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/BackgroundElement;", "Lp94;", "Lg20;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class BackgroundElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f220a;
    public final float b = 1.0f;
    public final ky5 c;

    public BackgroundElement(long j, ky5 ky5Var) {
        this.f220a = j;
        this.c = ky5Var;
    }

    public final boolean equals(Object obj) {
        BackgroundElement backgroundElement = obj instanceof BackgroundElement ? (BackgroundElement) obj : null;
        return backgroundElement != null && zr0.c(this.f220a, backgroundElement.f220a) && this.b == backgroundElement.b && Intrinsics.a(this.c, backgroundElement.c);
    }

    @Override // defpackage.p94
    public final g94 f() {
        g20 g20Var = new g20();
        g20Var.d0 = this.f220a;
        g20Var.e0 = this.c;
        g20Var.f0 = 9205357640488583168L;
        return g20Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        g20 g20Var = (g20) g94Var;
        g20Var.d0 = this.f220a;
        g20Var.e0 = this.c;
        lh1.E(g20Var);
    }

    public final int hashCode() {
        int i = zr0.h;
        fx6 fx6Var = gx6.b;
        return this.c.hashCode() + oh1.c(Long.hashCode(this.f220a) * 961, this.b, 31);
    }
}

package androidx.compose.foundation.relocation;

import defpackage.h94;
import defpackage.i90;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(h94 h94Var, i90 i90Var) {
        return h94Var.d(new BringIntoViewRequesterElement(i90Var));
    }
}

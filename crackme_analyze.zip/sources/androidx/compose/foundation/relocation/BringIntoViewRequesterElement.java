package androidx.compose.foundation.relocation;

import defpackage.g94;
import defpackage.i90;
import defpackage.j90;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;", "Lp94;", "Lj90;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class BringIntoViewRequesterElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i90 f254a;

    public BringIntoViewRequesterElement(i90 i90Var) {
        this.f254a = i90Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof BringIntoViewRequesterElement) {
            return Intrinsics.a(this.f254a, ((BringIntoViewRequesterElement) obj).f254a);
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        j90 j90Var = new j90();
        j90Var.d0 = this.f254a;
        return j90Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        j90 j90Var = (j90) g94Var;
        i90 i90Var = j90Var.d0;
        if (i90Var != null) {
            i90Var.f2794a.j(j90Var);
        }
        i90 i90Var2 = this.f254a;
        if (i90Var2 != null) {
            i90Var2.f2794a.b(j90Var);
        }
        j90Var.d0 = i90Var2;
    }

    public final int hashCode() {
        return this.f254a.hashCode();
    }
}

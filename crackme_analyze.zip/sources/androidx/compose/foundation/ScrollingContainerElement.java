package androidx.compose.foundation;

import defpackage.cc2;
import defpackage.ep5;
import defpackage.fm6;
import defpackage.fp5;
import defpackage.g94;
import defpackage.ji;
import defpackage.ln4;
import defpackage.p94;
import defpackage.q90;
import defpackage.rb4;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/ScrollingContainerElement;", "Lp94;", "Lfp5;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class ScrollingContainerElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ep5 f228a;
    public final ln4 b;
    public final boolean c;
    public final cc2 d;
    public final rb4 e;
    public final q90 f;
    public final boolean g;
    public final ji h;

    public ScrollingContainerElement(ji jiVar, q90 q90Var, cc2 cc2Var, rb4 rb4Var, ln4 ln4Var, ep5 ep5Var, boolean z, boolean z2) {
        this.f228a = ep5Var;
        this.b = ln4Var;
        this.c = z;
        this.d = cc2Var;
        this.e = rb4Var;
        this.f = q90Var;
        this.g = z2;
        this.h = jiVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || ScrollingContainerElement.class != obj.getClass()) {
            return false;
        }
        ScrollingContainerElement scrollingContainerElement = (ScrollingContainerElement) obj;
        return Intrinsics.a(this.f228a, scrollingContainerElement.f228a) && this.b == scrollingContainerElement.b && this.c == scrollingContainerElement.c && Intrinsics.a(this.d, scrollingContainerElement.d) && Intrinsics.a(this.e, scrollingContainerElement.e) && Intrinsics.a(this.f, scrollingContainerElement.f) && this.g == scrollingContainerElement.g && Intrinsics.a(this.h, scrollingContainerElement.h);
    }

    @Override // defpackage.p94
    public final g94 f() {
        fp5 fp5Var = new fp5();
        fp5Var.f0 = this.f228a;
        fp5Var.g0 = this.b;
        fp5Var.h0 = this.c;
        fp5Var.i0 = this.d;
        fp5Var.j0 = this.e;
        fp5Var.k0 = this.f;
        fp5Var.l0 = this.g;
        fp5Var.m0 = this.h;
        return fp5Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        rb4 rb4Var = this.e;
        ((fp5) g94Var).K0(this.h, this.f, this.d, rb4Var, this.b, this.f228a, this.g, this.c);
    }

    public final int hashCode() {
        int iF = fm6.f(fm6.f((this.b.hashCode() + (this.f228a.hashCode() * 31)) * 31, 31, this.c), 31, false);
        cc2 cc2Var = this.d;
        int iHashCode = (iF + (cc2Var != null ? cc2Var.hashCode() : 0)) * 31;
        rb4 rb4Var = this.e;
        int iHashCode2 = (iHashCode + (rb4Var != null ? rb4Var.hashCode() : 0)) * 31;
        q90 q90Var = this.f;
        int iF2 = fm6.f((iHashCode2 + (q90Var != null ? q90Var.hashCode() : 0)) * 31, 31, this.g);
        ji jiVar = this.h;
        return iF2 + (jiVar != null ? jiVar.hashCode() : 0);
    }
}

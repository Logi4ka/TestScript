package androidx.compose.foundation;

import defpackage.fm6;
import defpackage.g94;
import defpackage.p94;
import defpackage.qo5;
import defpackage.uo5;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/ScrollingLayoutElement;", "Lp94;", "Lqo5;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ScrollingLayoutElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final uo5 f229a;

    public ScrollingLayoutElement(uo5 uo5Var) {
        this.f229a = uo5Var;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof ScrollingLayoutElement) {
            return this.f229a == ((ScrollingLayoutElement) obj).f229a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        qo5 qo5Var = new qo5();
        qo5Var.d0 = this.f229a;
        qo5Var.e0 = true;
        return qo5Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        qo5 qo5Var = (qo5) g94Var;
        qo5Var.d0 = this.f229a;
        qo5Var.e0 = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + fm6.f(this.f229a.hashCode() * 31, 31, false);
    }
}

package androidx.compose.foundation.lazy.layout;

import defpackage.g90;
import defpackage.h94;
import defpackage.ln4;
import defpackage.wf3;
import defpackage.yp0;
import defpackage.z43;
import defpackage.z45;
import defpackage.ze3;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    public static final h94 c(ze3 ze3Var, g90 g90Var, ln4 ln4Var) {
        return new LazyLayoutBeyondBoundsModifierElement(ze3Var, g90Var, ln4Var);
    }

    public static final h94 d(h94 h94Var, z45 z45Var, wf3 wf3Var, ln4 ln4Var, boolean z) {
        return h94Var.d(new LazyLayoutSemanticsModifier(z45Var, wf3Var, ln4Var, z));
    }

    public abstract yp0 a();

    public Object b(int i) {
        Object objInvoke;
        z43 z43VarF = a().f(i);
        int i2 = i - z43VarF.f6891a;
        Function1 key = z43VarF.c.getKey();
        return (key == null || (objInvoke = key.invoke(Integer.valueOf(i2))) == null) ? new DefaultLazyKey(i) : objInvoke;
    }
}

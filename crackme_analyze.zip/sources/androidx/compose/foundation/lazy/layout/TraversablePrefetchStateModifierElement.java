package androidx.compose.foundation.lazy.layout;

import defpackage.cr6;
import defpackage.g94;
import defpackage.p94;
import defpackage.uf3;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0083\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/lazy/layout/TraversablePrefetchStateModifierElement;", "Lp94;", "Lcr6;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class TraversablePrefetchStateModifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final uf3 f250a;

    public TraversablePrefetchStateModifierElement(uf3 uf3Var) {
        this.f250a = uf3Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof TraversablePrefetchStateModifierElement) && Intrinsics.a(this.f250a, ((TraversablePrefetchStateModifierElement) obj).f250a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        cr6 cr6Var = new cr6();
        cr6Var.d0 = this.f250a;
        return cr6Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((cr6) g94Var).d0 = this.f250a;
    }

    public final int hashCode() {
        return this.f250a.hashCode();
    }

    public final String toString() {
        return "TraversablePrefetchStateModifierElement(prefetchState=" + this.f250a + ')';
    }
}

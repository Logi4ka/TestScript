package androidx.compose.foundation.lazy.layout;

import defpackage.fm6;
import defpackage.g90;
import defpackage.g94;
import defpackage.ln4;
import defpackage.p94;
import defpackage.ye3;
import defpackage.ze3;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsModifierElement;", "Lp94;", "Lye3;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class LazyLayoutBeyondBoundsModifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ze3 f247a;
    public final g90 b;
    public final ln4 c;

    public LazyLayoutBeyondBoundsModifierElement(ze3 ze3Var, g90 g90Var, ln4 ln4Var) {
        this.f247a = ze3Var;
        this.b = g90Var;
        this.c = ln4Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LazyLayoutBeyondBoundsModifierElement)) {
            return false;
        }
        LazyLayoutBeyondBoundsModifierElement lazyLayoutBeyondBoundsModifierElement = (LazyLayoutBeyondBoundsModifierElement) obj;
        return Intrinsics.a(this.f247a, lazyLayoutBeyondBoundsModifierElement.f247a) && Intrinsics.a(this.b, lazyLayoutBeyondBoundsModifierElement.b) && this.c == lazyLayoutBeyondBoundsModifierElement.c;
    }

    @Override // defpackage.p94
    public final g94 f() {
        ye3 ye3Var = new ye3();
        ye3Var.d0 = this.f247a;
        ye3Var.e0 = this.b;
        ye3Var.f0 = this.c;
        return ye3Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ye3 ye3Var = (ye3) g94Var;
        ye3Var.d0 = this.f247a;
        ye3Var.e0 = this.b;
        ye3Var.f0 = this.c;
    }

    public final int hashCode() {
        return this.c.hashCode() + fm6.f((this.b.hashCode() + (this.f247a.hashCode() * 31)) * 31, 31, false);
    }
}

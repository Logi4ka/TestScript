package androidx.compose.foundation.lazy.layout;

import defpackage.ac4;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ac4 f253a;
    public final Object[] b;
    public final int c;

    /* JADX WARN: Removed duplicated region for block: B:31:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00dd A[LOOP:1: B:28:0x00bd->B:34:0x00dd, LOOP_END] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public e(kotlin.ranges.IntRange r13, androidx.compose.foundation.lazy.layout.b r14) {
        /*
            Method dump skipped, instruction units count: 233
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.lazy.layout.e.<init>(kotlin.ranges.IntRange, androidx.compose.foundation.lazy.layout.b):void");
    }

    public final int a(Object obj) {
        ac4 ac4Var = this.f253a;
        int iD = ac4Var.d(obj);
        if (iD >= 0) {
            return ac4Var.c[iD];
        }
        return -1;
    }
}

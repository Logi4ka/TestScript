package androidx.compose.foundation.lazy.layout;

import android.view.View;
import androidx.compose.foundation.R$id;
import defpackage.ad4;
import defpackage.am5;
import defpackage.ff3;
import defpackage.g15;
import defpackage.gj0;
import defpackage.gq3;
import defpackage.h94;
import defpackage.hl;
import defpackage.i15;
import defpackage.iw0;
import defpackage.jf3;
import defpackage.jk;
import defpackage.kh;
import defpackage.lh1;
import defpackage.pn2;
import defpackage.rw1;
import defpackage.s96;
import defpackage.uf3;
import defpackage.vf3;
import defpackage.yl;
import defpackage.zk2;
import defpackage.zv0;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class d implements zk2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ uf3 f252a;
    public final /* synthetic */ h94 b;
    public final /* synthetic */ jf3 c;
    public final /* synthetic */ ad4 d;

    public d(uf3 uf3Var, h94 h94Var, jf3 jf3Var, ad4 ad4Var) {
        this.f252a = uf3Var;
        this.b = h94Var;
        this.c = jf3Var;
        this.d = ad4Var;
    }

    @Override // defpackage.zk2
    public final Object a(Object obj, Object obj2, Object obj3) {
        h94 h94VarD;
        am5 am5Var = (am5) obj;
        iw0 iw0Var = (iw0) obj2;
        ((Number) obj3).intValue();
        Object objL = iw0Var.L();
        rw1 rw1Var = zv0.f7097a;
        if (objL == rw1Var) {
            objL = new ff3(am5Var, new hl(this.d, 4));
            iw0Var.i0(objL);
        }
        ff3 ff3Var = (ff3) objL;
        Object objL2 = iw0Var.L();
        if (objL2 == rw1Var) {
            objL2 = new s96(new pn2(ff3Var));
            iw0Var.i0(objL2);
        }
        s96 s96Var = (s96) objL2;
        uf3 uf3Var = this.f252a;
        if (uf3Var != null) {
            iw0Var.Y(1743490539);
            iw0Var.Y(887527095);
            Object obj4 = i15.f2746a;
            if (obj4 != null) {
                iw0Var.Y(1345648624);
                iw0Var.q(false);
            } else {
                iw0Var.Y(1345697697);
                View view = (View) iw0Var.j(kh.f);
                boolean zF = iw0Var.f(view);
                Object objL3 = iw0Var.L();
                if (zF || objL3 == rw1Var) {
                    Object tag = view.getTag(R$id.compose_prefetch_scheduler);
                    g15 jkVar = tag instanceof g15 ? (g15) tag : null;
                    if (jkVar == null) {
                        jkVar = new jk(view);
                        view.setTag(R$id.compose_prefetch_scheduler, jkVar);
                    }
                    objL3 = jkVar;
                    iw0Var.i0(objL3);
                }
                obj4 = (g15) objL3;
                iw0Var.q(false);
            }
            Object obj5 = obj4;
            iw0Var.q(false);
            Object[] objArr = {uf3Var, ff3Var, s96Var, obj5};
            boolean zF2 = iw0Var.f(uf3Var) | iw0Var.h(ff3Var) | iw0Var.h(s96Var) | iw0Var.h(obj5);
            Object objL4 = iw0Var.L();
            if (zF2 || objL4 == rw1Var) {
                yl ylVar = new yl(uf3Var, ff3Var, s96Var, obj5, 5);
                iw0Var.i0(ylVar);
                objL4 = ylVar;
            }
            gq3.e(objArr, (Function1) objL4, iw0Var);
            iw0Var.q(false);
        } else {
            iw0Var.Y(1744076749);
            iw0Var.q(false);
        }
        int i = vf3.f6082a;
        h94 h94Var = this.b;
        if (uf3Var != null && (h94VarD = h94Var.d(new TraversablePrefetchStateModifierElement(uf3Var))) != null) {
            h94Var = h94VarD;
        }
        boolean zF3 = iw0Var.f(ff3Var);
        jf3 jf3Var = this.c;
        boolean zF4 = zF3 | iw0Var.f(jf3Var);
        Object objL5 = iw0Var.L();
        if (zF4 || objL5 == rw1Var) {
            objL5 = new gj0(13, ff3Var, jf3Var);
            iw0Var.i0(objL5);
        }
        lh1.f(s96Var, h94Var, (Function2) objL5, iw0Var, 8);
        return Unit.f3760a;
    }
}

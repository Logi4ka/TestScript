package androidx.compose.foundation.lazy.layout;

import defpackage.bc4;
import defpackage.cf3;
import defpackage.df3;
import defpackage.g94;
import defpackage.h94;
import defpackage.hn5;
import defpackage.in5;
import defpackage.kg3;
import defpackage.ng3;
import defpackage.p94;
import defpackage.sc4;
import defpackage.sr0;
import defpackage.tc4;
import defpackage.tu4;
import io.flutter.embedding.android.KeyboardMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final sc4 f251a;
    public e b;
    public final tc4 c;
    public final ArrayList d;
    public final ArrayList e;
    public final ArrayList f;
    public final ArrayList g;
    public final ArrayList h;
    public final h94 i;

    public c() {
        long[] jArr = hn5.f2651a;
        this.f251a = new sc4();
        tc4 tc4Var = in5.f2885a;
        this.c = new tc4();
        this.d = new ArrayList();
        this.e = new ArrayList();
        this.f = new ArrayList();
        this.g = new ArrayList();
        this.h = new ArrayList();
        this.i = new p94(this) { // from class: androidx.compose.foundation.lazy.layout.LazyLayoutItemAnimator$DisplayingDisappearingItemsElement

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final c f248a;

            {
                this.f248a = this;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return (obj instanceof LazyLayoutItemAnimator$DisplayingDisappearingItemsElement) && this.f248a == ((LazyLayoutItemAnimator$DisplayingDisappearingItemsElement) obj).f248a;
            }

            @Override // defpackage.p94
            public final g94 f() {
                cf3 cf3Var = new cf3();
                cf3Var.d0 = this.f248a;
                return cf3Var;
            }

            @Override // defpackage.p94
            public final void g(g94 g94Var) {
                cf3 cf3Var = (cf3) g94Var;
                c cVar = cf3Var.d0;
                c cVar2 = this.f248a;
                if (Intrinsics.a(cVar, cVar2) || !cf3Var.f2347a.c0) {
                    return;
                }
                c cVar3 = cf3Var.d0;
                cVar3.c();
                cVar3.b = null;
                cf3Var.d0 = cVar2;
            }

            public final int hashCode() {
                return this.f248a.hashCode();
            }

            public final String toString() {
                return "DisplayingDisappearingItemsElement(animator=" + this.f248a + ')';
            }
        };
    }

    public static int e(int[] iArr, ng3 ng3Var) {
        ng3Var.getClass();
        int i = iArr[0] + ng3Var.l;
        iArr[0] = i;
        return Math.max(0, i);
    }

    public final long a() {
        ArrayList arrayList = this.h;
        if (arrayList.size() <= 0) {
            return 0L;
        }
        bc4.t(arrayList.get(0));
        throw null;
    }

    public final void b(int i, int i2, ArrayList arrayList, e eVar, kg3 kg3Var, boolean z, boolean z2, int i3, int i4) {
        int i5;
        int i6;
        long j;
        int i7;
        int i8;
        int i9;
        int iA;
        int i10;
        int i11;
        int i12;
        tc4 tc4Var;
        e eVar2 = this.b;
        this.b = eVar;
        int size = arrayList.size();
        for (int i13 = 0; i13 < size; i13++) {
            ng3 ng3Var = (ng3) arrayList.get(i13);
            int size2 = ng3Var.b.size();
            for (int i14 = 0; i14 < size2; i14++) {
                ((tu4) ng3Var.b.get(i14)).x();
            }
        }
        sc4 sc4Var = this.f251a;
        if (sc4Var.i()) {
            c();
            return;
        }
        boolean z3 = z || !z2;
        Object[] objArr = sc4Var.b;
        long[] jArr = sc4Var.f5418a;
        int length = jArr.length - 2;
        tc4 tc4Var2 = this.c;
        int i15 = 8;
        boolean z4 = z3;
        if (length >= 0) {
            int i16 = 0;
            while (true) {
                long j2 = jArr[i16];
                tc4 tc4Var3 = tc4Var2;
                if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i17 = 8 - ((~(i16 - length)) >>> 31);
                    long j3 = j2;
                    int i18 = 0;
                    while (i18 < i17) {
                        if ((j3 & 255) < 128) {
                            tc4Var = tc4Var3;
                            tc4Var.a(objArr[(i16 << 3) + i18]);
                        } else {
                            tc4Var = tc4Var3;
                        }
                        j3 >>= 8;
                        i18++;
                        tc4Var3 = tc4Var;
                    }
                    tc4Var2 = tc4Var3;
                    if (i17 != 8) {
                        break;
                    }
                } else {
                    tc4Var2 = tc4Var3;
                }
                if (i16 == length) {
                    break;
                } else {
                    i16++;
                }
            }
        }
        int size3 = arrayList.size();
        for (int i19 = 0; i19 < size3; i19++) {
            ng3 ng3Var2 = (ng3) arrayList.get(i19);
            Object obj = ng3Var2.g;
            List list = ng3Var2.b;
            tc4Var2.l(obj);
            int size4 = list.size();
            for (int i20 = 0; i20 < size4; i20++) {
                ((tu4) list.get(i20)).x();
            }
            bc4.t(sc4Var.k(ng3Var2.g));
        }
        int[] iArr = new int[1];
        ArrayList arrayList2 = this.e;
        ArrayList arrayList3 = this.d;
        if (z4 && eVar2 != null) {
            if (arrayList3.isEmpty()) {
                i12 = 0;
            } else {
                if (arrayList3.size() > 1) {
                    sr0.o(arrayList3, new df3(eVar2, 2));
                }
                if (arrayList3.size() > 0) {
                    ng3 ng3Var3 = (ng3) arrayList3.get(0);
                    e(iArr, ng3Var3);
                    Object objG = sc4Var.g(ng3Var3.g);
                    objG.getClass();
                    bc4.t(objG);
                    ng3Var3.a(0);
                    throw null;
                }
                i12 = 0;
                Arrays.fill(iArr, 0, 1, 0);
            }
            if (!arrayList2.isEmpty()) {
                if (arrayList2.size() > 1) {
                    sr0.o(arrayList2, new df3(eVar2, i12));
                }
                if (arrayList2.size() > 0) {
                    ng3 ng3Var4 = (ng3) arrayList2.get(i12);
                    e(iArr, ng3Var4);
                    Object objG2 = sc4Var.g(ng3Var4.g);
                    objG2.getClass();
                    bc4.t(objG2);
                    ng3Var4.a(i12);
                    throw null;
                }
                Arrays.fill(iArr, i12, 1, i12);
            }
        }
        Object[] objArr2 = tc4Var2.b;
        long[] jArr2 = tc4Var2.f5649a;
        int length2 = jArr2.length - 2;
        if (length2 >= 0) {
            int i21 = 0;
            while (true) {
                long j4 = jArr2[i21];
                if ((((~j4) << 7) & j4 & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i22 = 8 - ((~(i21 - length2)) >>> 31);
                    int i23 = 0;
                    while (i23 < i22) {
                        if ((j4 & 255) < 128) {
                            i11 = i15;
                            bc4.t(sc4Var.g(objArr2[(i21 << 3) + i23]));
                        } else {
                            i11 = i15;
                        }
                        j4 >>= i11;
                        i23++;
                        i15 = i11;
                    }
                    i10 = i15;
                    if (i22 != i10) {
                        break;
                    }
                } else {
                    i10 = i15;
                }
                if (i21 == length2) {
                    break;
                }
                i21++;
                i15 = i10;
            }
        }
        ArrayList arrayList4 = this.f;
        if (arrayList4.isEmpty()) {
            i5 = i;
            i6 = i2;
            j = KeyboardMap.kValueMask;
            i7 = 1;
        } else {
            if (arrayList4.size() > 1) {
                sr0.o(arrayList4, new df3(eVar, 3));
            }
            int size5 = arrayList4.size();
            for (int i24 = 0; i24 < size5; i24++) {
                ng3 ng3Var5 = (ng3) arrayList4.get(i24);
                Object objG3 = sc4Var.g(ng3Var5.g);
                objG3.getClass();
                bc4.t(objG3);
                ng3Var5.c((z ? (int) (((ng3) CollectionsKt.B(arrayList)).a(0) & KeyboardMap.kValueMask) : 0) - e(iArr, ng3Var5), i, i2);
                if (z4) {
                    d(ng3Var5, true);
                    throw null;
                }
            }
            i5 = i;
            i6 = i2;
            j = KeyboardMap.kValueMask;
            i7 = 1;
            Arrays.fill(iArr, 0, 1, 0);
        }
        ArrayList arrayList5 = this.g;
        if (!arrayList5.isEmpty()) {
            if (arrayList5.size() > i7) {
                sr0.o(arrayList5, new df3(eVar, i7));
            }
            int size6 = arrayList5.size();
            int i25 = 0;
            while (i25 < size6) {
                ng3 ng3Var6 = (ng3) arrayList5.get(i25);
                Object objG4 = sc4Var.g(ng3Var6.g);
                objG4.getClass();
                bc4.t(objG4);
                int iE = e(iArr, ng3Var6);
                if (z) {
                    ng3 ng3Var7 = (ng3) CollectionsKt.F(arrayList);
                    i8 = size6;
                    i9 = i25;
                    iA = ((int) (ng3Var7.a(0) & j)) + ng3Var7.l;
                } else {
                    i8 = size6;
                    i9 = i25;
                    iA = 0;
                }
                ng3Var6.c((iA - ng3Var6.l) + iE, i5, i6);
                if (z4) {
                    d(ng3Var6, true);
                    throw null;
                }
                i25 = i9 + 1;
                size6 = i8;
            }
        }
        Collections.reverse(arrayList4);
        arrayList.addAll(0, arrayList4);
        arrayList.addAll(arrayList5);
        arrayList3.clear();
        arrayList2.clear();
        arrayList4.clear();
        arrayList5.clear();
        tc4Var2.b();
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0048  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c() {
        /*
            r14 = this;
            sc4 r14 = r14.f251a
            boolean r0 = r14.j()
            if (r0 == 0) goto L50
            java.lang.Object[] r0 = r14.c
            long[] r1 = r14.f5418a
            int r2 = r1.length
            int r2 = r2 + (-2)
            if (r2 < 0) goto L4d
            r3 = 0
            r4 = r3
        L13:
            r5 = r1[r4]
            long r7 = ~r5
            r9 = 7
            long r7 = r7 << r9
            long r7 = r7 & r5
            r9 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r7 = r7 & r9
            int r7 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r7 == 0) goto L48
            int r7 = r4 - r2
            int r7 = ~r7
            int r7 = r7 >>> 31
            r8 = 8
            int r7 = 8 - r7
            r9 = r3
        L2d:
            if (r9 >= r7) goto L46
            r10 = 255(0xff, double:1.26E-321)
            long r10 = r10 & r5
            r12 = 128(0x80, double:6.32E-322)
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 < 0) goto L3c
            long r5 = r5 >> r8
            int r9 = r9 + 1
            goto L2d
        L3c:
            int r14 = r4 << 3
            int r14 = r14 + r9
            r14 = r0[r14]
            defpackage.bc4.t(r14)
            r14 = 0
            throw r14
        L46:
            if (r7 != r8) goto L4d
        L48:
            if (r4 == r2) goto L4d
            int r4 = r4 + 1
            goto L13
        L4d:
            r14.a()
        L50:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.lazy.layout.c.c():void");
    }

    public final void d(ng3 ng3Var, boolean z) {
        Object objG = this.f251a.g(ng3Var.g);
        objG.getClass();
        bc4.t(objG);
        throw null;
    }
}

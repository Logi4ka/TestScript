package androidx.compose.foundation.lazy.layout;

import defpackage.cg3;
import defpackage.fm6;
import defpackage.g94;
import defpackage.h08;
import defpackage.ln4;
import defpackage.p94;
import defpackage.wf3;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/lazy/layout/LazyLayoutSemanticsModifier;", "Lp94;", "Lcg3;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class LazyLayoutSemanticsModifier extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function0 f249a;
    public final wf3 b;
    public final ln4 c;
    public final boolean d;

    public LazyLayoutSemanticsModifier(Function0 function0, wf3 wf3Var, ln4 ln4Var, boolean z) {
        this.f249a = function0;
        this.b = wf3Var;
        this.c = ln4Var;
        this.d = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LazyLayoutSemanticsModifier)) {
            return false;
        }
        LazyLayoutSemanticsModifier lazyLayoutSemanticsModifier = (LazyLayoutSemanticsModifier) obj;
        return this.f249a == lazyLayoutSemanticsModifier.f249a && Intrinsics.a(this.b, lazyLayoutSemanticsModifier.b) && this.c == lazyLayoutSemanticsModifier.c && this.d == lazyLayoutSemanticsModifier.d;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new cg3(this.f249a, this.b, this.c, this.d);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        cg3 cg3Var = (cg3) g94Var;
        cg3Var.d0 = this.f249a;
        cg3Var.e0 = this.b;
        ln4 ln4Var = cg3Var.f0;
        ln4 ln4Var2 = this.c;
        if (ln4Var != ln4Var2) {
            cg3Var.f0 = ln4Var2;
            h08.Q(cg3Var);
        }
        boolean z = cg3Var.g0;
        boolean z2 = this.d;
        if (z == z2) {
            return;
        }
        cg3Var.g0 = z2;
        cg3Var.F0();
        h08.Q(cg3Var);
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + fm6.f((this.c.hashCode() + ((this.b.hashCode() + (this.f249a.hashCode() * 31)) * 31)) * 31, 31, this.d);
    }
}

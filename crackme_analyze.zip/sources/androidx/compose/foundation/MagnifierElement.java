package androidx.compose.foundation;

import android.view.View;
import defpackage.co1;
import defpackage.fm6;
import defpackage.fq3;
import defpackage.fs5;
import defpackage.g94;
import defpackage.i94;
import defpackage.is1;
import defpackage.ma3;
import defpackage.oh1;
import defpackage.p94;
import defpackage.qe0;
import defpackage.tp3;
import defpackage.up3;
import defpackage.uv4;
import defpackage.zi6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/MagnifierElement;", "Lp94;", "Ltp3;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class MagnifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i94 f227a;
    public final zi6 b;
    public final uv4 c;

    public MagnifierElement(i94 i94Var, zi6 zi6Var, uv4 uv4Var) {
        this.f227a = i94Var;
        this.b = zi6Var;
        this.c = uv4Var;
    }

    public final boolean equals(Object obj) {
        return this == obj;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new tp3(this.f227a, this.b, this.c);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        tp3 tp3Var = (tp3) g94Var;
        tp3Var.getClass();
        uv4 uv4Var = tp3Var.f0;
        View view = tp3Var.g0;
        co1 co1Var = tp3Var.h0;
        tp3Var.d0 = this.f227a;
        tp3Var.e0 = this.b;
        uv4 uv4Var2 = this.c;
        tp3Var.f0 = uv4Var2;
        View viewA = fq3.A(tp3Var);
        co1 co1Var2 = ma3.O(tp3Var).l0;
        if (tp3Var.i0 != null) {
            fs5 fs5Var = up3.f5929a;
            if (((!Float.isNaN(Float.NaN) || !Float.isNaN(Float.NaN)) && !uv4Var2.a()) || !is1.a(Float.NaN, Float.NaN) || !is1.a(Float.NaN, Float.NaN) || !uv4Var2.equals(uv4Var) || !viewA.equals(view) || !Intrinsics.a(co1Var2, co1Var)) {
                tp3Var.G0();
            }
        }
        tp3Var.H0();
    }

    public final int hashCode() {
        return this.c.hashCode() + ((this.b.hashCode() + fm6.f(oh1.c(oh1.c(qe0.e(9205357640488583168L, fm6.f(oh1.c(this.f227a.hashCode() * 961, Float.NaN, 31), 31, true), 31), Float.NaN, 31), Float.NaN, 31), 31, true)) * 31);
    }
}

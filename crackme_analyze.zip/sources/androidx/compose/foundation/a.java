package androidx.compose.foundation;

import android.view.KeyEvent;
import defpackage.bu2;
import defpackage.cc2;
import defpackage.e94;
import defpackage.ep5;
import defpackage.h94;
import defpackage.hv2;
import defpackage.ji;
import defpackage.ky5;
import defpackage.ln4;
import defpackage.ma3;
import defpackage.p01;
import defpackage.rb4;
import defpackage.vo4;
import defpackage.x93;
import defpackage.yg5;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(h94 h94Var, long j, ky5 ky5Var) {
        return h94Var.d(new BackgroundElement(j, ky5Var));
    }

    public static h94 b(h94 h94Var, rb4 rb4Var, androidx.compose.material3.c cVar, boolean z, yg5 yg5Var, Function0 function0, int i) {
        h94 h94VarD;
        if ((i & 4) != 0) {
            z = true;
        }
        boolean z2 = z;
        if ((i & 16) != 0) {
            yg5Var = null;
        }
        yg5 yg5Var2 = yg5Var;
        if (cVar != null) {
            h94VarD = new ClickableElement(rb4Var, cVar, false, z2, null, yg5Var2, function0);
        } else if (cVar == null) {
            h94VarD = new ClickableElement(rb4Var, null, false, z2, null, yg5Var2, function0);
        } else {
            e94 e94Var = e94.f1898a;
            h94VarD = rb4Var != null ? c.a(e94Var, rb4Var, cVar).d(new ClickableElement(rb4Var, null, false, z2, null, yg5Var2, function0)) : p01.i(e94Var, new b(cVar, z2, yg5Var2, function0));
        }
        return h94Var.d(h94VarD);
    }

    public static h94 c(h94 h94Var, boolean z, String str, Function0 function0, int i) {
        if ((i & 2) != 0) {
            str = null;
        }
        return h94Var.d(new ClickableElement(null, null, true, z, str, null, function0));
    }

    public static h94 d(h94 h94Var, rb4 rb4Var, Function0 function0) {
        return h94Var.d(new CombinedClickableElement(rb4Var, function0));
    }

    public static final h94 e(h94 h94Var) {
        return h94Var.d(FocusGroupElement.f224a);
    }

    public static final h94 f(h94 h94Var, boolean z) {
        return h94Var.d(z ? new FocusableElement() : e94.f1898a);
    }

    public static h94 h(h94 h94Var, rb4 rb4Var) {
        return h94Var.d(new HoverableElement(rb4Var));
    }

    public static final boolean i(KeyEvent keyEvent) {
        long jW = ma3.w(keyEvent);
        int i = x93.p;
        return x93.a(jW, x93.h) || x93.a(jW, x93.k) || x93.a(jW, x93.o) || x93.a(jW, x93.j);
    }

    public static final h94 j(h94 h94Var, ep5 ep5Var, ln4 ln4Var, boolean z, cc2 cc2Var, rb4 rb4Var, boolean z2, ji jiVar, vo4 vo4Var) {
        ln4 ln4Var2 = ln4.f3960a;
        e94 e94Var = e94.f1898a;
        return h94Var.d(ln4Var == ln4Var2 ? bu2.j(e94Var, hv2.c) : bu2.j(e94Var, hv2.b)).d(new ScrollingContainerElement(jiVar, vo4Var, cc2Var, rb4Var, ln4Var, ep5Var, z, z2));
    }
}

package androidx.compose.foundation;

import defpackage.fm6;
import defpackage.g94;
import defpackage.p94;
import defpackage.rb4;
import defpackage.t03;
import defpackage.wp0;
import defpackage.yg5;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/ClickableElement;", "Lp94;", "Lwp0;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class ClickableElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final rb4 f222a;
    public final t03 b;
    public final boolean c;
    public final boolean d;
    public final String e;
    public final yg5 f;
    public final Function0 g;

    public ClickableElement(rb4 rb4Var, t03 t03Var, boolean z, boolean z2, String str, yg5 yg5Var, Function0 function0) {
        this.f222a = rb4Var;
        this.b = t03Var;
        this.c = z;
        this.d = z2;
        this.e = str;
        this.f = yg5Var;
        this.g = function0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || ClickableElement.class != obj.getClass()) {
            return false;
        }
        ClickableElement clickableElement = (ClickableElement) obj;
        return Intrinsics.a(this.f222a, clickableElement.f222a) && Intrinsics.a(this.b, clickableElement.b) && this.c == clickableElement.c && this.d == clickableElement.d && Intrinsics.a(this.e, clickableElement.e) && Intrinsics.a(this.f, clickableElement.f) && this.g == clickableElement.g;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new wp0(this.f222a, this.b, this.c, this.d, this.e, this.f, this.g);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((wp0) g94Var).R0(this.f222a, this.b, this.c, this.d, this.e, this.f, this.g);
    }

    public final int hashCode() {
        rb4 rb4Var = this.f222a;
        int iHashCode = (rb4Var != null ? rb4Var.hashCode() : 0) * 31;
        t03 t03Var = this.b;
        int iF = fm6.f(fm6.f((iHashCode + (t03Var != null ? t03Var.hashCode() : 0)) * 31, 31, this.c), 31, this.d);
        String str = this.e;
        int iHashCode2 = (iF + (str != null ? str.hashCode() : 0)) * 31;
        yg5 yg5Var = this.f;
        return this.g.hashCode() + ((iHashCode2 + (yg5Var != null ? Integer.hashCode(yg5Var.f6734a) : 0)) * 31);
    }
}

package androidx.compose.foundation.text.contextmenu.modifier;

import defpackage.f8;
import defpackage.g8;
import defpackage.g94;
import defpackage.gj0;
import defpackage.p94;
import defpackage.y;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/text/contextmenu/modifier/AddTextContextMenuDataComponentsWithContextElement;", "Lp94;", "Lg8;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class AddTextContextMenuDataComponentsWithContextElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final gj0 f255a;

    public AddTextContextMenuDataComponentsWithContextElement(gj0 gj0Var) {
        this.f255a = gj0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof AddTextContextMenuDataComponentsWithContextElement) {
            return this.f255a == ((AddTextContextMenuDataComponentsWithContextElement) obj).f255a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        g8 g8Var = new g8();
        g8Var.f0 = this.f255a;
        y yVar = new y(g8Var, 3);
        f8 f8Var = new f8();
        f8Var.d0 = yVar;
        g8Var.F0(f8Var);
        return g8Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((g8) g94Var).f0 = this.f255a;
    }

    public final int hashCode() {
        return this.f255a.hashCode();
    }
}

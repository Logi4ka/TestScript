package androidx.compose.foundation.text.contextmenu.modifier;

import defpackage.gj0;
import defpackage.h94;
import defpackage.hd1;
import defpackage.ni6;
import defpackage.oi6;
import defpackage.z95;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(h94 h94Var, gj0 gj0Var) {
        return h94Var.d(new AddTextContextMenuDataComponentsWithContextElement(gj0Var));
    }

    public static final h94 b(ni6 ni6Var) {
        return new TextContextMenuGestureElement(ni6Var);
    }

    public static final h94 c(h94 h94Var, z95 z95Var, ni6 ni6Var, oi6 oi6Var, hd1 hd1Var) {
        return h94Var.d(new TextContextMenuToolbarHandlerElement(z95Var, ni6Var, oi6Var, hd1Var));
    }
}

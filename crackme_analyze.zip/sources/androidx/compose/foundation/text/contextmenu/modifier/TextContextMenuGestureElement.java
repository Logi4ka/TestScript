package androidx.compose.foundation.text.contextmenu.modifier;

import defpackage.g94;
import defpackage.gh6;
import defpackage.ni6;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureElement;", "Lp94;", "Lgh6;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class TextContextMenuGestureElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ni6 f256a;

    public TextContextMenuGestureElement(ni6 ni6Var) {
        this.f256a = ni6Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof TextContextMenuGestureElement) {
            return this.f256a == ((TextContextMenuGestureElement) obj).f256a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new gh6(this.f256a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((gh6) g94Var).f0 = this.f256a;
    }

    public final int hashCode() {
        return this.f256a.hashCode();
    }
}

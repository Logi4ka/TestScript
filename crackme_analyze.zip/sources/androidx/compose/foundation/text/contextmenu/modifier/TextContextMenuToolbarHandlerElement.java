package androidx.compose.foundation.text.contextmenu.modifier;

import defpackage.g94;
import defpackage.hd1;
import defpackage.ni6;
import defpackage.oi6;
import defpackage.p94;
import defpackage.rh6;
import defpackage.z95;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuToolbarHandlerElement;", "Lp94;", "Lrh6;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class TextContextMenuToolbarHandlerElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final z95 f257a;
    public final ni6 b;
    public final oi6 c;
    public final hd1 d;

    public TextContextMenuToolbarHandlerElement(z95 z95Var, ni6 ni6Var, oi6 oi6Var, hd1 hd1Var) {
        this.f257a = z95Var;
        this.b = ni6Var;
        this.c = oi6Var;
        this.d = hd1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextContextMenuToolbarHandlerElement)) {
            return false;
        }
        TextContextMenuToolbarHandlerElement textContextMenuToolbarHandlerElement = (TextContextMenuToolbarHandlerElement) obj;
        return this.f257a == textContextMenuToolbarHandlerElement.f257a && this.b == textContextMenuToolbarHandlerElement.b && this.c == textContextMenuToolbarHandlerElement.c && this.d == textContextMenuToolbarHandlerElement.d;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new rh6(this.f257a, this.b, this.c, this.d);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        rh6 rh6Var = (rh6) g94Var;
        rh6Var.f0.b = null;
        z95 z95Var = this.f257a;
        rh6Var.f0 = z95Var;
        z95Var.b = rh6Var;
        rh6Var.g0 = this.b;
        rh6Var.h0 = this.c;
        rh6Var.i0 = this.d;
    }

    public final int hashCode() {
        return this.d.hashCode() + ((this.c.hashCode() + ((this.b.hashCode() + (this.f257a.hashCode() * 31)) * 31)) * 31);
    }
}

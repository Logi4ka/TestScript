package androidx.compose.foundation.text.handwriting;

import androidx.compose.ui.input.pointer.StylusHoverIconModifierElement;
import defpackage.e94;
import defpackage.h94;
import defpackage.k96;
import defpackage.ms1;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ms1 f259a = new ms1();

    public static final h94 a(boolean z, boolean z2, Function0 function0) {
        h94 stylusHoverIconModifierElement = e94.f1898a;
        if (!z || !k96.f3670a) {
            return stylusHoverIconModifierElement;
        }
        if (z2) {
            stylusHoverIconModifierElement = new StylusHoverIconModifierElement(f259a);
        }
        return stylusHoverIconModifierElement.d(new StylusHandwritingElement(function0));
    }
}

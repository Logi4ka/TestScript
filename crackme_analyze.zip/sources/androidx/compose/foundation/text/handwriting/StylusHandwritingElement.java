package androidx.compose.foundation.text.handwriting;

import defpackage.g94;
import defpackage.j96;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/text/handwriting/StylusHandwritingElement;", "Lp94;", "Lj96;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class StylusHandwritingElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function0 f258a;

    public StylusHandwritingElement(Function0 function0) {
        this.f258a = function0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof StylusHandwritingElement) {
            return this.f258a == ((StylusHandwritingElement) obj).f258a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new j96(this.f258a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((j96) g94Var).f0 = this.f258a;
    }

    public final int hashCode() {
        return this.f258a.hashCode();
    }
}

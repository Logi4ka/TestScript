package androidx.compose.foundation.text.input.internal;

import defpackage.bj6;
import defpackage.bp6;
import defpackage.fi3;
import defpackage.fm6;
import defpackage.g94;
import defpackage.gk6;
import defpackage.h08;
import defpackage.p94;
import defpackage.pd1;
import defpackage.rd1;
import defpackage.sc0;
import defpackage.sz2;
import defpackage.tf2;
import defpackage.vi6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/text/input/internal/CoreTextFieldSemanticsModifier;", "Lp94;", "Lrd1;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class CoreTextFieldSemanticsModifier extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final bp6 f260a;
    public final bj6 b;
    public final fi3 c;
    public final boolean d;
    public final sc0 e;
    public final vi6 f;
    public final sz2 g;
    public final tf2 h;

    public CoreTextFieldSemanticsModifier(bp6 bp6Var, bj6 bj6Var, fi3 fi3Var, boolean z, sc0 sc0Var, vi6 vi6Var, sz2 sz2Var, tf2 tf2Var) {
        this.f260a = bp6Var;
        this.b = bj6Var;
        this.c = fi3Var;
        this.d = z;
        this.e = sc0Var;
        this.f = vi6Var;
        this.g = sz2Var;
        this.h = tf2Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof CoreTextFieldSemanticsModifier) {
            CoreTextFieldSemanticsModifier coreTextFieldSemanticsModifier = (CoreTextFieldSemanticsModifier) obj;
            if (this.f260a.equals(coreTextFieldSemanticsModifier.f260a) && Intrinsics.a(this.b, coreTextFieldSemanticsModifier.b) && this.c == coreTextFieldSemanticsModifier.c && this.d == coreTextFieldSemanticsModifier.d && Intrinsics.a(this.e, coreTextFieldSemanticsModifier.e) && this.f == coreTextFieldSemanticsModifier.f && Intrinsics.a(this.g, coreTextFieldSemanticsModifier.g) && Intrinsics.a(this.h, coreTextFieldSemanticsModifier.h)) {
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        rd1 rd1Var = new rd1();
        rd1Var.f0 = this.f260a;
        rd1Var.g0 = this.b;
        rd1Var.h0 = this.c;
        rd1Var.i0 = this.d;
        rd1Var.j0 = this.e;
        vi6 vi6Var = this.f;
        rd1Var.k0 = vi6Var;
        rd1Var.l0 = this.g;
        rd1Var.m0 = this.h;
        vi6Var.f = new pd1(rd1Var, 4);
        return rd1Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        rd1 rd1Var = (rd1) g94Var;
        boolean z = rd1Var.i0;
        sz2 sz2Var = rd1Var.l0;
        vi6 vi6Var = rd1Var.k0;
        rd1Var.f0 = this.f260a;
        bj6 bj6Var = this.b;
        rd1Var.g0 = bj6Var;
        rd1Var.h0 = this.c;
        boolean z2 = this.d;
        rd1Var.i0 = z2;
        rd1Var.j0 = this.e;
        vi6 vi6Var2 = this.f;
        rd1Var.k0 = vi6Var2;
        sz2 sz2Var2 = this.g;
        rd1Var.l0 = sz2Var2;
        rd1Var.m0 = this.h;
        if (z2 != z || z2 != z || !Intrinsics.a(sz2Var2, sz2Var) || !gk6.c(bj6Var.b)) {
            h08.Q(rd1Var);
        }
        if (vi6Var2 != vi6Var) {
            vi6Var2.f = new pd1(rd1Var, 0);
        }
    }

    public final int hashCode() {
        return this.h.hashCode() + ((this.g.hashCode() + ((this.f.hashCode() + ((this.e.hashCode() + fm6.f(fm6.f(fm6.f((this.c.hashCode() + ((this.b.hashCode() + (this.f260a.hashCode() * 31)) * 31)) * 31, 31, false), 31, this.d), 31, false)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "CoreTextFieldSemanticsModifier(transformedText=" + this.f260a + ", value=" + this.b + ", state=" + this.c + ", readOnly=false, enabled=" + this.d + ", isPassword=false, offsetMapping=" + this.e + ", manager=" + this.f + ", imeOptions=" + this.g + ", focusRequester=" + this.h + ')';
    }
}

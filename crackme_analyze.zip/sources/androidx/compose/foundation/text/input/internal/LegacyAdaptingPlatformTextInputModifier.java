package androidx.compose.foundation.text.input.internal;

import defpackage.fi3;
import defpackage.g94;
import defpackage.ij;
import defpackage.mh3;
import defpackage.p94;
import defpackage.s13;
import defpackage.vi6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/text/input/internal/LegacyAdaptingPlatformTextInputModifier;", "Lp94;", "Lmh3;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class LegacyAdaptingPlatformTextInputModifier extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ij f261a;
    public final fi3 b;
    public final vi6 c;

    public LegacyAdaptingPlatformTextInputModifier(ij ijVar, fi3 fi3Var, vi6 vi6Var) {
        this.f261a = ijVar;
        this.b = fi3Var;
        this.c = vi6Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof LegacyAdaptingPlatformTextInputModifier) {
            LegacyAdaptingPlatformTextInputModifier legacyAdaptingPlatformTextInputModifier = (LegacyAdaptingPlatformTextInputModifier) obj;
            return Intrinsics.a(this.f261a, legacyAdaptingPlatformTextInputModifier.f261a) && this.b == legacyAdaptingPlatformTextInputModifier.b && this.c == legacyAdaptingPlatformTextInputModifier.c;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new mh3(this.f261a, this.b, this.c);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) throws Throwable {
        mh3 mh3Var = (mh3) g94Var;
        if (mh3Var.c0) {
            mh3Var.d0.c();
            mh3Var.d0.k(mh3Var);
        }
        ij ijVar = this.f261a;
        mh3Var.d0 = ijVar;
        if (mh3Var.c0) {
            if (ijVar.f2859a != null) {
                s13.c("Expected textInputModifierNode to be null");
            }
            ijVar.f2859a = mh3Var;
        }
        mh3Var.e0 = this.b;
        mh3Var.f0 = this.c;
    }

    public final int hashCode() {
        return this.c.hashCode() + ((this.b.hashCode() + (this.f261a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "LegacyAdaptingPlatformTextInputModifier(serviceAdapter=" + this.f261a + ", legacyTextFieldState=" + this.b + ", textFieldSelectionManager=" + this.c + ')';
    }
}

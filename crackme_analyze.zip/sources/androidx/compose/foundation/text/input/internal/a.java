package androidx.compose.foundation.text.input.internal;

import defpackage.fi3;
import defpackage.h94;
import defpackage.ij;
import defpackage.vi6;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(h94 h94Var, ij ijVar, fi3 fi3Var, vi6 vi6Var) {
        return h94Var.d(new LegacyAdaptingPlatformTextInputModifier(ijVar, fi3Var, vi6Var));
    }
}

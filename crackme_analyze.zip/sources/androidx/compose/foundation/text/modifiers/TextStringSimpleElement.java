package androidx.compose.foundation.text.modifiers;

import defpackage.bc4;
import defpackage.ds0;
import defpackage.fm6;
import defpackage.g94;
import defpackage.hg2;
import defpackage.nk6;
import defpackage.oh1;
import defpackage.ok6;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001R\u0016\u0010\u0004\u001a\u0004\u0018\u00010\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;", "Lp94;", "Lnk6;", "Lds0;", "color", "Lds0;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class TextStringSimpleElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f263a;
    public final ok6 b;
    public final hg2 c;
    private final ds0 color = null;
    public final int d;
    public final boolean e;
    public final int f;
    public final int g;

    public TextStringSimpleElement(String str, ok6 ok6Var, hg2 hg2Var, int i, boolean z, int i2, int i3) {
        this.f263a = str;
        this.b = ok6Var;
        this.c = hg2Var;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = i3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextStringSimpleElement)) {
            return false;
        }
        TextStringSimpleElement textStringSimpleElement = (TextStringSimpleElement) obj;
        return Intrinsics.a(this.color, textStringSimpleElement.color) && Intrinsics.a(this.f263a, textStringSimpleElement.f263a) && Intrinsics.a(this.b, textStringSimpleElement.b) && Intrinsics.a(this.c, textStringSimpleElement.c) && this.d == textStringSimpleElement.d && this.e == textStringSimpleElement.e && this.f == textStringSimpleElement.f && this.g == textStringSimpleElement.g;
    }

    @Override // defpackage.p94
    public final g94 f() {
        ds0 ds0Var = this.color;
        nk6 nk6Var = new nk6();
        nk6Var.d0 = this.f263a;
        nk6Var.e0 = this.b;
        nk6Var.f0 = this.c;
        nk6Var.g0 = this.d;
        nk6Var.h0 = this.e;
        nk6Var.i0 = this.f;
        nk6Var.j0 = this.g;
        nk6Var.k0 = ds0Var;
        return nk6Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0026  */
    @Override // defpackage.p94
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void g(defpackage.g94 r11) {
        /*
            r10 = this;
            nk6 r11 = (defpackage.nk6) r11
            ds0 r0 = r10.color
            ds0 r1 = r11.k0
            boolean r1 = kotlin.jvm.internal.Intrinsics.a(r0, r1)
            r11.k0 = r0
            r0 = 0
            r2 = 1
            ok6 r3 = r10.b
            if (r1 == 0) goto L26
            ok6 r1 = r11.e0
            if (r3 == r1) goto L21
            c56 r4 = r3.f4618a
            c56 r1 = r1.f4618a
            boolean r1 = r4.b(r1)
            if (r1 == 0) goto L26
            goto L24
        L21:
            r3.getClass()
        L24:
            r1 = r0
            goto L27
        L26:
            r1 = r2
        L27:
            java.lang.String r4 = r11.d0
            java.lang.String r5 = r10.f263a
            boolean r4 = kotlin.jvm.internal.Intrinsics.a(r4, r5)
            if (r4 == 0) goto L32
            goto L38
        L32:
            r11.d0 = r5
            r0 = 0
            r11.o0 = r0
            r0 = r2
        L38:
            ok6 r4 = r11.e0
            boolean r4 = r4.c(r3)
            r4 = r4 ^ r2
            r11.e0 = r3
            int r3 = r11.j0
            int r5 = r10.g
            if (r3 == r5) goto L4a
            r11.j0 = r5
            r4 = r2
        L4a:
            int r3 = r11.i0
            int r5 = r10.f
            if (r3 == r5) goto L53
            r11.i0 = r5
            r4 = r2
        L53:
            boolean r3 = r11.h0
            boolean r5 = r10.e
            if (r3 == r5) goto L5c
            r11.h0 = r5
            r4 = r2
        L5c:
            hg2 r3 = r11.f0
            hg2 r5 = r10.c
            boolean r3 = kotlin.jvm.internal.Intrinsics.a(r3, r5)
            if (r3 != 0) goto L69
            r11.f0 = r5
            r4 = r2
        L69:
            int r3 = r11.g0
            int r10 = r10.d
            if (r3 != r10) goto L71
            r2 = r4
            goto L73
        L71:
            r11.g0 = r10
        L73:
            if (r0 != 0) goto L77
            if (r2 == 0) goto La3
        L77:
            eq4 r10 = r11.F0()
            java.lang.String r3 = r11.d0
            ok6 r4 = r11.e0
            hg2 r5 = r11.f0
            int r6 = r11.g0
            boolean r7 = r11.h0
            int r8 = r11.i0
            int r9 = r11.j0
            r10.f2002a = r3
            r10.b = r4
            r10.c = r5
            r10.d = r6
            r10.e = r7
            r10.f = r8
            r10.g = r9
            long r3 = r10.s
            r5 = 2
            long r3 = r3 << r5
            r5 = 2
            long r3 = r3 | r5
            r10.s = r3
            r10.c()
        La3:
            boolean r10 = r11.c0
            if (r10 != 0) goto La8
            goto Lc2
        La8:
            if (r0 != 0) goto Lb0
            if (r1 == 0) goto Lb3
            lk6 r10 = r11.n0
            if (r10 == 0) goto Lb3
        Lb0:
            defpackage.h08.Q(r11)
        Lb3:
            if (r0 != 0) goto Lb7
            if (r2 == 0) goto Lbd
        Lb7:
            defpackage.gq3.F(r11)
            defpackage.lh1.E(r11)
        Lbd:
            if (r1 == 0) goto Lc2
            defpackage.lh1.E(r11)
        Lc2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.text.modifiers.TextStringSimpleElement.g(g94):void");
    }

    public final int hashCode() {
        int iF = (((fm6.f(oh1.d(this.d, (this.c.hashCode() + bc4.c(this.f263a.hashCode() * 31, 31, this.b)) * 31, 31), 31, this.e) + this.f) * 31) + this.g) * 31;
        ds0 ds0Var = this.color;
        return iF + (ds0Var != null ? ds0Var.hashCode() : 0);
    }
}

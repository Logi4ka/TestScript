package androidx.compose.foundation.text.modifiers;

import defpackage.bc4;
import defpackage.ds0;
import defpackage.fm6;
import defpackage.g94;
import defpackage.hg2;
import defpackage.oh1;
import defpackage.ok6;
import defpackage.p94;
import defpackage.qg6;
import defpackage.vn;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001R\u0016\u0010\u0004\u001a\u0004\u0018\u00010\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;", "Lp94;", "Lqg6;", "Lds0;", "color", "Lds0;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class TextAnnotatedStringElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final vn f262a;
    public final ok6 b;
    public final hg2 c;
    private final ds0 color = null;
    public final Function1 d;
    public final int e;
    public final boolean f;
    public final int g;
    public final int h;
    public final List i;
    public final Function1 j;
    public final Function1 k;

    public TextAnnotatedStringElement(vn vnVar, ok6 ok6Var, hg2 hg2Var, Function1 function1, int i, boolean z, int i2, int i3, List list, Function1 function12, Function1 function13) {
        this.f262a = vnVar;
        this.b = ok6Var;
        this.c = hg2Var;
        this.d = function1;
        this.e = i;
        this.f = z;
        this.g = i2;
        this.h = i3;
        this.i = list;
        this.j = function12;
        this.k = function13;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextAnnotatedStringElement)) {
            return false;
        }
        TextAnnotatedStringElement textAnnotatedStringElement = (TextAnnotatedStringElement) obj;
        return Intrinsics.a(this.color, textAnnotatedStringElement.color) && Intrinsics.a(this.f262a, textAnnotatedStringElement.f262a) && Intrinsics.a(this.b, textAnnotatedStringElement.b) && Intrinsics.a(this.i, textAnnotatedStringElement.i) && Intrinsics.a(this.c, textAnnotatedStringElement.c) && this.d == textAnnotatedStringElement.d && this.k == textAnnotatedStringElement.k && this.e == textAnnotatedStringElement.e && this.f == textAnnotatedStringElement.f && this.g == textAnnotatedStringElement.g && this.h == textAnnotatedStringElement.h && this.j == textAnnotatedStringElement.j;
    }

    @Override // defpackage.p94
    public final g94 f() {
        ds0 ds0Var = this.color;
        qg6 qg6Var = new qg6();
        qg6Var.d0 = this.f262a;
        qg6Var.e0 = this.b;
        qg6Var.f0 = this.c;
        qg6Var.g0 = this.d;
        qg6Var.h0 = this.e;
        qg6Var.i0 = this.f;
        qg6Var.j0 = this.g;
        qg6Var.k0 = this.h;
        qg6Var.l0 = this.i;
        qg6Var.m0 = this.j;
        qg6Var.n0 = ds0Var;
        qg6Var.o0 = this.k;
        return qg6Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x002a  */
    @Override // defpackage.p94
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void g(defpackage.g94 r17) {
        /*
            Method dump skipped, instruction units count: 307
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.foundation.text.modifiers.TextAnnotatedStringElement.g(g94):void");
    }

    public final int hashCode() {
        int iHashCode = (this.c.hashCode() + bc4.c(this.f262a.hashCode() * 31, 31, this.b)) * 31;
        Function1 function1 = this.d;
        int iF = (((fm6.f(oh1.d(this.e, (iHashCode + (function1 != null ? function1.hashCode() : 0)) * 31, 31), 31, this.f) + this.g) * 31) + this.h) * 31;
        List list = this.i;
        int iHashCode2 = (iF + (list != null ? list.hashCode() : 0)) * 31;
        Function1 function12 = this.j;
        int iHashCode3 = (iHashCode2 + (function12 != null ? function12.hashCode() : 0)) * 961;
        ds0 ds0Var = this.color;
        int iHashCode4 = (iHashCode3 + (ds0Var != null ? ds0Var.hashCode() : 0)) * 31;
        Function1 function13 = this.k;
        return iHashCode4 + (function13 != null ? function13.hashCode() : 0);
    }
}

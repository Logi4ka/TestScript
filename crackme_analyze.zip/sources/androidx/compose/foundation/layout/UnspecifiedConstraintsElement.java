package androidx.compose.foundation.layout;

import defpackage.g94;
import defpackage.is1;
import defpackage.jz6;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/UnspecifiedConstraintsElement;", "Lp94;", "Ljz6;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class UnspecifiedConstraintsElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f242a;
    public final float b;

    public UnspecifiedConstraintsElement(float f, float f2) {
        this.f242a = f;
        this.b = f2;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof UnspecifiedConstraintsElement)) {
            return false;
        }
        UnspecifiedConstraintsElement unspecifiedConstraintsElement = (UnspecifiedConstraintsElement) obj;
        return is1.a(this.f242a, unspecifiedConstraintsElement.f242a) && is1.a(this.b, unspecifiedConstraintsElement.b);
    }

    @Override // defpackage.p94
    public final g94 f() {
        jz6 jz6Var = new jz6();
        jz6Var.d0 = this.f242a;
        jz6Var.e0 = this.b;
        return jz6Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        jz6 jz6Var = (jz6) g94Var;
        jz6Var.d0 = this.f242a;
        jz6Var.e0 = this.b;
    }

    public final int hashCode() {
        return Float.hashCode(this.b) + (Float.hashCode(this.f242a) * 31);
    }
}

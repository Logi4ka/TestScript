package androidx.compose.foundation.layout;

import defpackage.g50;
import defpackage.g94;
import defpackage.n80;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/BoxChildDataElement;", "Lp94;", "Ln80;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class BoxChildDataElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g50 f235a;

    public BoxChildDataElement(g50 g50Var) {
        this.f235a = g50Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        BoxChildDataElement boxChildDataElement = obj instanceof BoxChildDataElement ? (BoxChildDataElement) obj : null;
        return boxChildDataElement != null && this.f235a.equals(boxChildDataElement.f235a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        n80 n80Var = new n80();
        n80Var.d0 = this.f235a;
        return n80Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((n80) g94Var).d0 = this.f235a;
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + (this.f235a.hashCode() * 31);
    }
}

package androidx.compose.foundation.layout;

import defpackage.ak4;
import defpackage.ev3;
import defpackage.g94;
import defpackage.is1;
import defpackage.ma3;
import defpackage.oh1;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/OffsetElement;", "Lp94;", "Lak4;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class OffsetElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f238a;

    public OffsetElement(float f, ev3 ev3Var) {
        this.f238a = f;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        OffsetElement offsetElement = obj instanceof OffsetElement ? (OffsetElement) obj : null;
        return offsetElement != null && is1.a(this.f238a, offsetElement.f238a) && is1.a(0.0f, 0.0f);
    }

    @Override // defpackage.p94
    public final g94 f() {
        ak4 ak4Var = new ak4();
        ak4Var.d0 = this.f238a;
        ak4Var.e0 = true;
        return ak4Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ak4 ak4Var = (ak4) g94Var;
        float f = ak4Var.d0;
        float f2 = this.f238a;
        if (!is1.a(f, f2) || !is1.a(0.0f, 0.0f) || !ak4Var.e0) {
            ma3.O(ak4Var).a0(false);
        }
        ak4Var.d0 = f2;
        ak4Var.e0 = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + oh1.c(Float.hashCode(this.f238a) * 31, 0.0f, 31);
    }

    public final String toString() {
        return "OffsetModifierElement(x=" + ((Object) is1.b(this.f238a)) + ", y=" + ((Object) is1.b(0.0f)) + ", rtlAware=true)";
    }
}

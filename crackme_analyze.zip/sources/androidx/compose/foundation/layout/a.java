package androidx.compose.foundation.layout;

import defpackage.c53;
import defpackage.ev3;
import defpackage.h94;
import defpackage.lo4;
import defpackage.nz0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static lo4 a(float f, int i) {
        if ((i & 1) != 0) {
            f = 0.0f;
        }
        return new lo4(f, 0.0f, f, 0.0f);
    }

    public static final lo4 b(float f, float f2, float f3, float f4) {
        return new lo4(f, f2, f3, f4);
    }

    public static h94 c(float f) {
        return new AspectRatioElement(f);
    }

    public static final boolean d(long j, int i, int i2) {
        int iJ = nz0.j(j);
        if (i > nz0.h(j) || iJ > i) {
            return false;
        }
        return i2 <= nz0.g(j) && nz0.i(j) <= i2;
    }

    public static h94 e(float f) {
        return new OffsetElement(f, new ev3(23));
    }

    public static final h94 f(h94 h94Var, lo4 lo4Var) {
        return h94Var.d(new PaddingValuesElement(lo4Var, new ev3(29)));
    }

    public static final h94 g(h94 h94Var, float f) {
        return h94Var.d(new PaddingElement(f, f, f, f, new ev3(28)));
    }

    public static final h94 h(h94 h94Var, float f, float f2) {
        return h94Var.d(new PaddingElement(f, f2, f, f2, new ev3(26)));
    }

    public static h94 i(h94 h94Var, float f, float f2, int i) {
        if ((i & 1) != 0) {
            f = 0.0f;
        }
        if ((i & 2) != 0) {
            f2 = 0.0f;
        }
        return h(h94Var, f, f2);
    }

    public static final h94 j(h94 h94Var, float f, float f2, float f3, float f4) {
        return h94Var.d(new PaddingElement(f, f2, f3, f4, new ev3(27)));
    }

    public static h94 k(h94 h94Var, float f, float f2, float f3, float f4, int i) {
        if ((i & 1) != 0) {
            f = 0.0f;
        }
        if ((i & 2) != 0) {
            f2 = 0.0f;
        }
        if ((i & 4) != 0) {
            f3 = 0.0f;
        }
        if ((i & 8) != 0) {
            f4 = 0.0f;
        }
        return j(h94Var, f, f2, f3, f4);
    }

    public static final h94 l(h94 h94Var) {
        c53 c53Var = c53.f735a;
        return h94Var.d(new IntrinsicWidthElement());
    }
}

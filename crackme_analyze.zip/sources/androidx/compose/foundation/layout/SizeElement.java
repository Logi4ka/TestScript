package androidx.compose.foundation.layout;

import defpackage.g94;
import defpackage.is1;
import defpackage.k16;
import defpackage.oh1;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/SizeElement;", "Lp94;", "Lk16;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class SizeElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f241a;
    public final float b;
    public final float c;
    public final float d;
    public final boolean e;

    public SizeElement(float f, float f2, float f3, float f4, boolean z) {
        this.f241a = f;
        this.b = f2;
        this.c = f3;
        this.d = f4;
        this.e = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SizeElement)) {
            return false;
        }
        SizeElement sizeElement = (SizeElement) obj;
        return is1.a(this.f241a, sizeElement.f241a) && is1.a(this.b, sizeElement.b) && is1.a(this.c, sizeElement.c) && is1.a(this.d, sizeElement.d) && this.e == sizeElement.e;
    }

    @Override // defpackage.p94
    public final g94 f() {
        k16 k16Var = new k16();
        k16Var.d0 = this.f241a;
        k16Var.e0 = this.b;
        k16Var.f0 = this.c;
        k16Var.g0 = this.d;
        k16Var.h0 = this.e;
        return k16Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        k16 k16Var = (k16) g94Var;
        k16Var.d0 = this.f241a;
        k16Var.e0 = this.b;
        k16Var.f0 = this.c;
        k16Var.g0 = this.d;
        k16Var.h0 = this.e;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.e) + oh1.c(oh1.c(oh1.c(Float.hashCode(this.f241a) * 31, this.b, 31), this.c, 31), this.d, 31);
    }

    public /* synthetic */ SizeElement(float f, float f2, boolean z) {
        this(Float.NaN, f, Float.NaN, f2, z);
    }
}

package androidx.compose.foundation.layout;

import defpackage.bv2;
import defpackage.e50;
import defpackage.g94;
import defpackage.p94;
import defpackage.pa0;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/HorizontalAlignElement;", "Lp94;", "Lbv2;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class HorizontalAlignElement extends p94 {
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof HorizontalAlignElement ? (HorizontalAlignElement) obj : null) == null) {
            return false;
        }
        e50 e50Var = pa0.e0;
        return e50Var.equals(e50Var);
    }

    @Override // defpackage.p94
    public final g94 f() {
        e50 e50Var = pa0.e0;
        bv2 bv2Var = new bv2();
        bv2Var.d0 = e50Var;
        return bv2Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((bv2) g94Var).d0 = pa0.e0;
    }

    public final int hashCode() {
        return Float.hashCode(0.0f);
    }
}

package androidx.compose.foundation.layout;

import defpackage.d06;
import defpackage.g94;
import defpackage.hc;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/WithAlignmentLineElement;", "Lp94;", "Ld06;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class WithAlignmentLineElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final hc f243a;

    public WithAlignmentLineElement(hc hcVar) {
        this.f243a = hcVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        WithAlignmentLineElement withAlignmentLineElement = obj instanceof WithAlignmentLineElement ? (WithAlignmentLineElement) obj : null;
        if (withAlignmentLineElement == null) {
            return false;
        }
        return Intrinsics.a(this.f243a, withAlignmentLineElement.f243a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        d06 d06Var = new d06();
        d06Var.d0 = this.f243a;
        return d06Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((d06) g94Var).d0 = this.f243a;
    }

    public final int hashCode() {
        return this.f243a.hashCode();
    }
}

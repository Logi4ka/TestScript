package androidx.compose.foundation.layout;

import defpackage.ev3;
import defpackage.g94;
import defpackage.lo4;
import defpackage.mo4;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/PaddingValuesElement;", "Lp94;", "Lmo4;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class PaddingValuesElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lo4 f240a;

    public PaddingValuesElement(lo4 lo4Var, ev3 ev3Var) {
        this.f240a = lo4Var;
    }

    public final boolean equals(Object obj) {
        PaddingValuesElement paddingValuesElement = obj instanceof PaddingValuesElement ? (PaddingValuesElement) obj : null;
        if (paddingValuesElement == null) {
            return false;
        }
        return Intrinsics.a(this.f240a, paddingValuesElement.f240a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        mo4 mo4Var = new mo4();
        mo4Var.d0 = this.f240a;
        return mo4Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((mo4) g94Var).d0 = this.f240a;
    }

    public final int hashCode() {
        return this.f240a.hashCode();
    }
}

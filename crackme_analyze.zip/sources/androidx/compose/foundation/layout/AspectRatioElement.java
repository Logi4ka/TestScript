package androidx.compose.foundation.layout;

import defpackage.g94;
import defpackage.gw;
import defpackage.n13;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/AspectRatioElement;", "Lp94;", "Lgw;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class AspectRatioElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f234a;

    public AspectRatioElement(float f) {
        this.f234a = f;
        if (f > 0.0f) {
            return;
        }
        n13.a("aspectRatio " + f + " must be > 0");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        AspectRatioElement aspectRatioElement = obj instanceof AspectRatioElement ? (AspectRatioElement) obj : null;
        if (aspectRatioElement == null || this.f234a != aspectRatioElement.f234a) {
            return false;
        }
        ((AspectRatioElement) obj).getClass();
        return true;
    }

    @Override // defpackage.p94
    public final g94 f() {
        gw gwVar = new gw();
        gwVar.d0 = this.f234a;
        return gwVar;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((gw) g94Var).d0 = this.f234a;
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + (Float.hashCode(this.f234a) * 31);
    }
}

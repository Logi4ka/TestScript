package androidx.compose.foundation.layout;

import defpackage.c53;
import defpackage.e53;
import defpackage.g94;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/IntrinsicWidthElement;", "Lp94;", "Le53;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class IntrinsicWidthElement extends p94 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof IntrinsicWidthElement ? (IntrinsicWidthElement) obj : null) == null) {
            return false;
        }
        c53 c53Var = c53.f735a;
        return true;
    }

    @Override // defpackage.p94
    public final g94 f() {
        c53 c53Var = c53.b;
        e53 e53Var = new e53();
        e53Var.d0 = c53Var;
        e53Var.e0 = true;
        return e53Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        e53 e53Var = (e53) g94Var;
        e53Var.d0 = c53.b;
        e53Var.e0 = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + (c53.b.hashCode() * 31);
    }
}

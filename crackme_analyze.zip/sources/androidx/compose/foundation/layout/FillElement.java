package androidx.compose.foundation.layout;

import defpackage.g94;
import defpackage.p94;
import defpackage.pa2;
import defpackage.vp1;
import kotlin.Metadata;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/FillElement;", "Lp94;", "Lpa2;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class FillElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final vp1 f236a;

    public FillElement(vp1 vp1Var) {
        this.f236a = vp1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof FillElement) {
            return this.f236a == ((FillElement) obj).f236a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        pa2 pa2Var = new pa2();
        pa2Var.d0 = this.f236a;
        pa2Var.e0 = 1.0f;
        return pa2Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        pa2 pa2Var = (pa2) g94Var;
        pa2Var.d0 = this.f236a;
        pa2Var.e0 = 1.0f;
    }

    public final int hashCode() {
        return Float.hashCode(1.0f) + (this.f236a.hashCode() * 31);
    }
}

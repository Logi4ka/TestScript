package androidx.compose.foundation.layout;

import defpackage.fm6;
import defpackage.g94;
import defpackage.p94;
import defpackage.ul7;
import defpackage.vp1;
import kotlin.Metadata;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/WrapContentElement;", "Lp94;", "Lul7;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class WrapContentElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final vp1 f244a;
    public final Function2 b;
    public final Object c;

    public WrapContentElement(vp1 vp1Var, Function2 function2, Object obj) {
        this.f244a = vp1Var;
        this.b = function2;
        this.c = obj;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || WrapContentElement.class != obj.getClass()) {
            return false;
        }
        WrapContentElement wrapContentElement = (WrapContentElement) obj;
        return this.f244a == wrapContentElement.f244a && this.c.equals(wrapContentElement.c);
    }

    @Override // defpackage.p94
    public final g94 f() {
        ul7 ul7Var = new ul7();
        ul7Var.d0 = this.f244a;
        ul7Var.e0 = this.b;
        return ul7Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ul7 ul7Var = (ul7) g94Var;
        ul7Var.d0 = this.f244a;
        ul7Var.e0 = this.b;
    }

    public final int hashCode() {
        return this.c.hashCode() + fm6.f(this.f244a.hashCode() * 31, 31, false);
    }
}

package androidx.compose.foundation.layout;

import defpackage.g94;
import defpackage.is1;
import defpackage.ko4;
import defpackage.n13;
import defpackage.oh1;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/PaddingElement;", "Lp94;", "Lko4;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class PaddingElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f239a;
    public final float b;
    public final float c;
    public final float d;
    public final Function1 e;

    public PaddingElement(float f, float f2, float f3, float f4, Function1 function1) {
        this.f239a = f;
        this.b = f2;
        this.c = f3;
        this.d = f4;
        this.e = function1;
        boolean z = true;
        boolean z2 = (f >= 0.0f || Float.isNaN(f)) & (f2 >= 0.0f || Float.isNaN(f2)) & (f3 >= 0.0f || Float.isNaN(f3));
        if (f4 < 0.0f && !Float.isNaN(f4)) {
            z = false;
        }
        if (!z2 || !z) {
            n13.a("Padding must be non-negative");
        }
    }

    public final boolean equals(Object obj) {
        PaddingElement paddingElement = obj instanceof PaddingElement ? (PaddingElement) obj : null;
        return paddingElement != null && is1.a(this.f239a, paddingElement.f239a) && is1.a(this.b, paddingElement.b) && is1.a(this.c, paddingElement.c) && is1.a(this.d, paddingElement.d);
    }

    @Override // defpackage.p94
    public final g94 f() {
        ko4 ko4Var = new ko4();
        ko4Var.d0 = this.f239a;
        ko4Var.e0 = this.b;
        ko4Var.f0 = this.c;
        ko4Var.g0 = this.d;
        ko4Var.h0 = true;
        return ko4Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ko4 ko4Var = (ko4) g94Var;
        ko4Var.d0 = this.f239a;
        ko4Var.e0 = this.b;
        ko4Var.f0 = this.c;
        ko4Var.g0 = this.d;
        ko4Var.h0 = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + oh1.c(oh1.c(oh1.c(Float.hashCode(this.f239a) * 31, this.b, 31), this.c, 31), this.d, 31);
    }
}

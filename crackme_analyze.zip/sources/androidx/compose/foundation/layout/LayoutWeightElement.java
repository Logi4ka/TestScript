package androidx.compose.foundation.layout;

import defpackage.g94;
import defpackage.oe3;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/layout/LayoutWeightElement;", "Lp94;", "Loe3;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class LayoutWeightElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f237a;
    public final boolean b;

    public LayoutWeightElement(float f, boolean z) {
        this.f237a = f;
        this.b = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        LayoutWeightElement layoutWeightElement = obj instanceof LayoutWeightElement ? (LayoutWeightElement) obj : null;
        return layoutWeightElement != null && this.f237a == layoutWeightElement.f237a && this.b == layoutWeightElement.b;
    }

    @Override // defpackage.p94
    public final g94 f() {
        oe3 oe3Var = new oe3();
        oe3Var.d0 = this.f237a;
        oe3Var.e0 = this.b;
        return oe3Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        oe3 oe3Var = (oe3) g94Var;
        oe3Var.d0 = this.f237a;
        oe3Var.e0 = this.b;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.b) + (Float.hashCode(this.f237a) * 31);
    }
}

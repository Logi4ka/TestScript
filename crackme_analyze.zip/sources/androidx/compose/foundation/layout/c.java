package androidx.compose.foundation.layout;

import defpackage.d7;
import defpackage.e50;
import defpackage.f50;
import defpackage.h94;
import defpackage.pa0;
import defpackage.vp1;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final FillElement f245a;
    public static final FillElement b;
    public static final WrapContentElement c;
    public static final WrapContentElement d;
    public static final WrapContentElement e;
    public static final WrapContentElement f;

    static {
        vp1 vp1Var = vp1.b;
        f245a = new FillElement(vp1Var);
        b = new FillElement(vp1.c);
        e50 e50Var = pa0.e0;
        int i = 23;
        c = new WrapContentElement(vp1Var, new d7(e50Var, i), e50Var);
        e50 e50Var2 = pa0.d0;
        d = new WrapContentElement(vp1Var, new d7(e50Var2, i), e50Var2);
        f50 f50Var = pa0.b0;
        vp1 vp1Var2 = vp1.f6137a;
        int i2 = 24;
        e = new WrapContentElement(vp1Var2, new d7(f50Var, i2), f50Var);
        f50 f50Var2 = pa0.Z;
        f = new WrapContentElement(vp1Var2, new d7(f50Var2, i2), f50Var2);
    }

    public static final h94 a(h94 h94Var, float f2, float f3) {
        return h94Var.d(new UnspecifiedConstraintsElement(f2, f3));
    }

    public static final h94 b(h94 h94Var, float f2) {
        return h94Var.d(new SizeElement(f2, f2, true));
    }

    public static final h94 c(h94 h94Var, float f2, float f3) {
        return h94Var.d(new SizeElement(f2, f3, true));
    }

    public static h94 d(h94 h94Var, float f2) {
        return h94Var.d(new SizeElement(f2, Float.NaN, false));
    }

    public static final h94 e(h94 h94Var, float f2) {
        return h94Var.d(new SizeElement(f2, f2, f2, f2, false));
    }

    public static h94 f(h94 h94Var, float f2, float f3, float f4, float f5, int i) {
        return h94Var.d(new SizeElement(f2, (i & 2) != 0 ? Float.NaN : f3, (i & 4) != 0 ? Float.NaN : f4, (i & 8) != 0 ? Float.NaN : f5, false));
    }

    public static final h94 g(h94 h94Var, float f2) {
        return h94Var.d(new SizeElement(f2, f2, f2, f2, true));
    }

    public static final h94 h(h94 h94Var, float f2, float f3) {
        return h94Var.d(new SizeElement(f2, f3, f2, f3, true));
    }

    public static final h94 i(h94 h94Var) {
        return h94Var.d(new SizeElement(112.0f, 48.0f, 280.0f, 48.0f, true));
    }

    public static h94 j(h94 h94Var) {
        f50 f50Var = pa0.b0;
        return h94Var.d(Intrinsics.a(f50Var, f50Var) ? e : Intrinsics.a(f50Var, pa0.Z) ? f : new WrapContentElement(vp1.f6137a, new d7(f50Var, 24), f50Var));
    }

    public static h94 k(h94 h94Var) {
        e50 e50Var = pa0.f0;
        return h94Var.d(e50Var.equals(pa0.e0) ? c : e50Var.equals(pa0.d0) ? d : new WrapContentElement(vp1.b, new d7(e50Var, 23), e50Var));
    }
}

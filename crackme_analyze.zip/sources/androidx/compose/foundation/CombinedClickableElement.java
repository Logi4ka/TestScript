package androidx.compose.foundation;

import defpackage.et0;
import defpackage.fm6;
import defpackage.g94;
import defpackage.jc6;
import defpackage.p94;
import defpackage.rb4;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/CombinedClickableElement;", "Lp94;", "Let0;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class CombinedClickableElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final rb4 f223a;
    public final Function0 b;

    public CombinedClickableElement(rb4 rb4Var, Function0 function0) {
        this.f223a = rb4Var;
        this.b = function0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || CombinedClickableElement.class != obj.getClass()) {
            return false;
        }
        CombinedClickableElement combinedClickableElement = (CombinedClickableElement) obj;
        return Intrinsics.a(this.f223a, combinedClickableElement.f223a) && this.b == combinedClickableElement.b;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new et0(this.f223a, this.b);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        jc6 jc6Var;
        et0 et0Var = (et0) g94Var;
        et0Var.getClass();
        boolean z = !et0Var.k0;
        et0Var.R0(this.f223a, null, false, true, null, null, this.b);
        if (!z || (jc6Var = et0Var.o0) == null) {
            return;
        }
        jc6Var.H0();
    }

    public final int hashCode() {
        rb4 rb4Var = this.f223a;
        return Boolean.hashCode(true) + ((this.b.hashCode() + fm6.f(fm6.f((rb4Var != null ? rb4Var.hashCode() : 0) * 961, 31, false), 29791, true)) * 923521);
    }
}

package androidx.compose.foundation;

import defpackage.bg2;
import defpackage.g94;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/FocusableElement;", "Lp94;", "Lbg2;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class FocusableElement extends p94 {
    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof FocusableElement);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new bg2(null, 1, null);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((bg2) g94Var).K0(null);
    }

    public final int hashCode() {
        return 0;
    }
}

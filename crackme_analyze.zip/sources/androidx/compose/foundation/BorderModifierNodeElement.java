package androidx.compose.foundation;

import defpackage.d70;
import defpackage.g94;
import defpackage.hd0;
import defpackage.is1;
import defpackage.ky5;
import defpackage.l46;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/BorderModifierNodeElement;", "Lp94;", "Ld70;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class BorderModifierNodeElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f221a;
    public final l46 b;
    public final ky5 c;

    public BorderModifierNodeElement(float f, l46 l46Var, ky5 ky5Var) {
        this.f221a = f;
        this.b = l46Var;
        this.c = ky5Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof BorderModifierNodeElement)) {
            return false;
        }
        BorderModifierNodeElement borderModifierNodeElement = (BorderModifierNodeElement) obj;
        return is1.a(this.f221a, borderModifierNodeElement.f221a) && this.b.equals(borderModifierNodeElement.b) && Intrinsics.a(this.c, borderModifierNodeElement.c);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new d70(this.f221a, this.b, this.c);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        d70 d70Var = (d70) g94Var;
        float f = d70Var.g0;
        hd0 hd0Var = d70Var.j0;
        float f2 = this.f221a;
        if (!is1.a(f, f2)) {
            d70Var.g0 = f2;
            hd0Var.F0();
        }
        l46 l46Var = d70Var.h0;
        l46 l46Var2 = this.b;
        if (!Intrinsics.a(l46Var, l46Var2)) {
            d70Var.h0 = l46Var2;
            hd0Var.F0();
        }
        ky5 ky5Var = d70Var.i0;
        ky5 ky5Var2 = this.c;
        if (Intrinsics.a(ky5Var, ky5Var2)) {
            return;
        }
        d70Var.i0 = ky5Var2;
        hd0Var.F0();
    }

    public final int hashCode() {
        return this.c.hashCode() + ((this.b.hashCode() + (Float.hashCode(this.f221a) * 31)) * 31);
    }

    public final String toString() {
        return "BorderModifierNodeElement(width=" + ((Object) is1.b(this.f221a)) + ", brush=" + this.b + ", shape=" + this.c + ')';
    }
}

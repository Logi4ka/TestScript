package androidx.compose.foundation;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int compose_prefetch_scheduler = 2131296405;

    private R$id() {
    }
}

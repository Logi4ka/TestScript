package androidx.compose.foundation;

import defpackage.g94;
import defpackage.lf2;
import defpackage.p94;
import defpackage.zf2;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÂ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/FocusGroupElement;", "Lp94;", "Llf2;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class FocusGroupElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final FocusGroupElement f224a = new FocusGroupElement();

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // defpackage.p94
    public final g94 f() {
        lf2 lf2Var = new lf2();
        lf2Var.F0(new zf2(2, null, 4));
        return lf2Var;
    }

    @Override // defpackage.p94
    public final /* bridge */ /* synthetic */ void g(g94 g94Var) {
    }

    public final int hashCode() {
        return -1063782265;
    }
}

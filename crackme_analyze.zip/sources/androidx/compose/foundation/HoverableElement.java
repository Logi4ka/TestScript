package androidx.compose.foundation;

import defpackage.g94;
import defpackage.p94;
import defpackage.qv2;
import defpackage.rb4;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/foundation/HoverableElement;", "Lp94;", "Lqv2;", "foundation_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class HoverableElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final rb4 f225a;

    public HoverableElement(rb4 rb4Var) {
        this.f225a = rb4Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof HoverableElement) && Intrinsics.a(((HoverableElement) obj).f225a, this.f225a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        qv2 qv2Var = new qv2();
        qv2Var.d0 = this.f225a;
        return qv2Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        qv2 qv2Var = (qv2) g94Var;
        rb4 rb4Var = qv2Var.d0;
        rb4 rb4Var2 = this.f225a;
        if (Intrinsics.a(rb4Var, rb4Var2)) {
            return;
        }
        qv2Var.H0();
        qv2Var.d0 = rb4Var2;
    }

    public final int hashCode() {
        return this.f225a.hashCode() * 31;
    }
}

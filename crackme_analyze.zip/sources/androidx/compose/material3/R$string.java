package androidx.compose.material3;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int m3c_bottom_sheet_collapse_description = 2131820821;
    public static int m3c_bottom_sheet_dismiss_description = 2131820822;
    public static int m3c_bottom_sheet_drag_handle_description = 2131820823;
    public static int m3c_bottom_sheet_expand_description = 2131820824;
    public static int m3c_bottom_sheet_pane_title = 2131820825;
    public static int m3c_date_input_headline = 2131820826;
    public static int m3c_date_input_headline_description = 2131820827;
    public static int m3c_date_input_invalid_for_pattern = 2131820828;
    public static int m3c_date_input_invalid_not_allowed = 2131820829;
    public static int m3c_date_input_invalid_year_range = 2131820830;
    public static int m3c_date_input_label = 2131820831;
    public static int m3c_date_input_no_input_description = 2131820832;
    public static int m3c_date_input_title = 2131820833;
    public static int m3c_date_picker_headline = 2131820834;
    public static int m3c_date_picker_headline_description = 2131820835;
    public static int m3c_date_picker_navigate_to_year_description = 2131820836;
    public static int m3c_date_picker_no_selection_description = 2131820837;
    public static int m3c_date_picker_scroll_to_earlier_years = 2131820838;
    public static int m3c_date_picker_scroll_to_later_years = 2131820839;
    public static int m3c_date_picker_switch_to_calendar_mode = 2131820840;
    public static int m3c_date_picker_switch_to_day_selection = 2131820841;
    public static int m3c_date_picker_switch_to_input_mode = 2131820842;
    public static int m3c_date_picker_switch_to_next_month = 2131820843;
    public static int m3c_date_picker_switch_to_previous_month = 2131820844;
    public static int m3c_date_picker_switch_to_year_selection = 2131820845;
    public static int m3c_date_picker_title = 2131820846;
    public static int m3c_date_picker_today_description = 2131820847;
    public static int m3c_date_picker_year_picker_pane_title = 2131820848;
    public static int m3c_date_range_input_invalid_range_input = 2131820849;
    public static int m3c_date_range_input_title = 2131820850;
    public static int m3c_date_range_picker_day_in_range = 2131820851;
    public static int m3c_date_range_picker_end_headline = 2131820852;
    public static int m3c_date_range_picker_scroll_to_next_month = 2131820853;
    public static int m3c_date_range_picker_scroll_to_previous_month = 2131820854;
    public static int m3c_date_range_picker_start_headline = 2131820855;
    public static int m3c_date_range_picker_title = 2131820856;
    public static int m3c_dialog = 2131820857;
    public static int m3c_dropdown_menu_collapsed = 2131820858;
    public static int m3c_dropdown_menu_expanded = 2131820859;
    public static int m3c_dropdown_menu_toggle = 2131820860;
    public static int m3c_floating_toolbar_collapse = 2131820861;
    public static int m3c_floating_toolbar_expand = 2131820862;
    public static int m3c_search_bar_search = 2131820863;
    public static int m3c_snackbar_dismiss = 2131820864;
    public static int m3c_snackbar_pane_title = 2131820865;
    public static int m3c_suggestions_available = 2131820866;
    public static int m3c_time_input_dialog_title = 2131820867;
    public static int m3c_time_picker_am = 2131820868;
    public static int m3c_time_picker_dialog_title = 2131820869;
    public static int m3c_time_picker_hour = 2131820870;
    public static int m3c_time_picker_hour_24h_suffix = 2131820871;
    public static int m3c_time_picker_hour_selection = 2131820872;
    public static int m3c_time_picker_hour_suffix = 2131820873;
    public static int m3c_time_picker_hour_text_field = 2131820874;
    public static int m3c_time_picker_minute = 2131820875;
    public static int m3c_time_picker_minute_selection = 2131820876;
    public static int m3c_time_picker_minute_suffix = 2131820877;
    public static int m3c_time_picker_minute_text_field = 2131820878;
    public static int m3c_time_picker_period_toggle_description = 2131820879;
    public static int m3c_time_picker_pm = 2131820880;
    public static int m3c_time_picker_toggle_keyboard = 2131820881;
    public static int m3c_time_picker_toggle_touch = 2131820882;
    public static int m3c_tooltip_long_press_label = 2131820883;
    public static int m3c_tooltip_pane_description = 2131820884;
    public static int m3c_wide_navigation_rail_close_rail = 2131820885;
    public static int m3c_wide_navigation_rail_pane_title = 2131820886;

    private R$string() {
    }
}

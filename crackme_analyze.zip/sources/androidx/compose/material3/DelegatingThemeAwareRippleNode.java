package androidx.compose.material3;

import defpackage.ds0;
import defpackage.kk;
import defpackage.ln1;
import defpackage.p01;
import defpackage.rb4;
import defpackage.uw0;
import defpackage.wj4;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0002\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Landroidx/compose/material3/DelegatingThemeAwareRippleNode;", "Lln1;", "Luw0;", "Lwj4;", "Lds0;", "color", "Lds0;", "material3"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class DelegatingThemeAwareRippleNode extends ln1 implements uw0, wj4 {
    private final ds0 color;
    public final rb4 f0;
    public final boolean g0;
    public final float h0 = Float.NaN;
    public kk i0;

    public DelegatingThemeAwareRippleNode(rb4 rb4Var, boolean z, ds0 ds0Var) {
        this.f0 = rb4Var;
        this.g0 = z;
        this.color = ds0Var;
    }

    @Override // defpackage.wj4
    public final void Z() {
        p01.U(this, new a(this, 0));
    }

    @Override // defpackage.g94
    public final void x0() {
        p01.U(this, new a(this, 0));
    }
}

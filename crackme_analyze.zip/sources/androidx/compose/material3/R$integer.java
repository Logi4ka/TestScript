package androidx.compose.material3;

/* JADX INFO: loaded from: classes.dex */
public final class R$integer {
    public static int m3c_window_layout_in_display_cutout_mode = 2131361831;

    private R$integer() {
    }
}

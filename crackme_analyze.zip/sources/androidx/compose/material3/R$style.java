package androidx.compose.material3;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static int EdgeToEdgeFloatingDialogTheme = 2131886376;
    public static int EdgeToEdgeFloatingDialogWindowTheme = 2131886377;

    private R$style() {
    }
}

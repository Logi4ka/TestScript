package androidx.compose.material3.internal;

import defpackage.fo0;
import defpackage.g94;
import defpackage.h08;
import defpackage.p5;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/material3/internal/ChildSemanticsNodeElement;", "Lp94;", "Lfo0;", "material3"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ChildSemanticsNodeElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p5 f268a;

    public ChildSemanticsNodeElement(p5 p5Var) {
        this.f268a = p5Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof ChildSemanticsNodeElement) {
            return this.f268a == ((ChildSemanticsNodeElement) obj).f268a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        fo0 fo0Var = new fo0();
        fo0Var.d0 = this.f268a;
        return fo0Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        fo0 fo0Var = (fo0) g94Var;
        fo0Var.d0 = this.f268a;
        h08.Q(fo0Var);
    }

    public final int hashCode() {
        return this.f268a.hashCode();
    }
}

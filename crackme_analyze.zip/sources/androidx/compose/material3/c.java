package androidx.compose.material3;

import defpackage.fx6;
import defpackage.gx6;
import defpackage.is1;
import defpackage.kn1;
import defpackage.oh1;
import defpackage.rb4;
import defpackage.t03;
import defpackage.wg5;
import defpackage.zr0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class c implements t03 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f267a;
    public final long b;

    public c(long j, boolean z) {
        this.f267a = z;
        this.b = j;
    }

    @Override // defpackage.t03
    public final kn1 a(rb4 rb4Var) {
        return new DelegatingThemeAwareRippleNode(rb4Var, this.f267a, new wg5(this));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        if (this.f267a == cVar.f267a && is1.a(Float.NaN, Float.NaN)) {
            return zr0.c(this.b, cVar.b);
        }
        return false;
    }

    @Override // defpackage.t03
    public final int hashCode() {
        int iC = oh1.c(Boolean.hashCode(this.f267a) * 31, Float.NaN, 961);
        int i = zr0.h;
        fx6 fx6Var = gx6.b;
        return Long.hashCode(this.b) + iC;
    }
}

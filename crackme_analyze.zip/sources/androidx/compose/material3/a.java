package androidx.compose.material3;

import defpackage.gq3;
import defpackage.kk;
import defpackage.lh1;
import defpackage.rb4;
import defpackage.rg5;
import defpackage.ug5;
import defpackage.vg5;
import defpackage.xr6;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Function0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f265a;
    public final /* synthetic */ DelegatingThemeAwareRippleNode b;

    public /* synthetic */ a(DelegatingThemeAwareRippleNode delegatingThemeAwareRippleNode, int i) {
        this.f265a = i;
        this.b = delegatingThemeAwareRippleNode;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        int i = this.f265a;
        DelegatingThemeAwareRippleNode delegatingThemeAwareRippleNode = this.b;
        switch (i) {
            case 0:
                rg5 rg5Var = (rg5) lh1.s(delegatingThemeAwareRippleNode, ug5.f5874a);
                kk kkVar = delegatingThemeAwareRippleNode.i0;
                if (rg5Var == null) {
                    if (kkVar != null) {
                        delegatingThemeAwareRippleNode.G0(kkVar);
                    }
                    delegatingThemeAwareRippleNode.i0 = null;
                } else if (kkVar == null) {
                    b bVar = new b(delegatingThemeAwareRippleNode);
                    a aVar = new a(delegatingThemeAwareRippleNode, 1);
                    rb4 rb4Var = delegatingThemeAwareRippleNode.f0;
                    boolean z = delegatingThemeAwareRippleNode.g0;
                    float f = delegatingThemeAwareRippleNode.h0;
                    xr6 xr6Var = vg5.f6091a;
                    kk kkVar2 = new kk(rb4Var, z, f, bVar, aVar);
                    delegatingThemeAwareRippleNode.F0(kkVar2);
                    delegatingThemeAwareRippleNode.i0 = kkVar2;
                }
                return Unit.f3760a;
            default:
                return gq3.e;
        }
    }
}

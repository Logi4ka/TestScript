package androidx.compose.material3;

import defpackage.ds0;
import defpackage.lh1;
import defpackage.rg5;
import defpackage.ug5;
import defpackage.wz0;
import defpackage.zr0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b implements ds0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ DelegatingThemeAwareRippleNode f266a;

    public b(DelegatingThemeAwareRippleNode delegatingThemeAwareRippleNode) {
        this.f266a = delegatingThemeAwareRippleNode;
    }

    @Override // defpackage.ds0
    public final long a() {
        DelegatingThemeAwareRippleNode delegatingThemeAwareRippleNode = this.f266a;
        long jA = delegatingThemeAwareRippleNode.color.a();
        if (jA != 16) {
            return jA;
        }
        rg5 rg5Var = (rg5) lh1.s(delegatingThemeAwareRippleNode, ug5.f5874a);
        if (rg5Var != null) {
            long j = rg5Var.f5223a;
            if (j != 16) {
                return j;
            }
        }
        return ((zr0) lh1.s(delegatingThemeAwareRippleNode, wz0.f6403a)).f7072a;
    }
}

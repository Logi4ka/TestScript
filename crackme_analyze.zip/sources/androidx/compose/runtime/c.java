package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.pa0;
import defpackage.qe0;
import defpackage.vk5;
import defpackage.y36;
import defpackage.zq0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class c implements Parcelable.ClassLoaderCreator {
    public static ParcelableSnapshotMutableState a(Parcel parcel, ClassLoader classLoader) {
        y36 y36Var;
        if (classLoader == null) {
            classLoader = c.class.getClassLoader();
        }
        Object value = parcel.readValue(classLoader);
        int i = parcel.readInt();
        if (i == 0) {
            y36Var = zq0.c0;
        } else if (i == 1) {
            y36Var = pa0.t0;
        } else {
            if (i != 2) {
                vk5.k(qe0.j(i, "Unsupported MutableState policy ", " was restored"));
                return null;
            }
            y36Var = zq0.e0;
        }
        return new ParcelableSnapshotMutableState(value, y36Var);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        return a(parcel, null);
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        return new ParcelableSnapshotMutableState[i];
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return a(parcel, classLoader);
    }
}

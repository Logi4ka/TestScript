package androidx.compose.runtime;

import defpackage.ab4;
import defpackage.ad4;
import defpackage.as6;
import defpackage.at4;
import defpackage.bb4;
import defpackage.do2;
import defpackage.iw0;
import defpackage.jt;
import defpackage.mw0;
import defpackage.nw0;
import defpackage.tc4;
import defpackage.tw0;
import defpackage.x36;
import defpackage.x95;
import defpackage.zb2;
import defpackage.zq0;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class a extends nw0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f269a;
    public final boolean b;
    public final boolean c;
    public HashSet d;
    public final LinkedHashSet e = new LinkedHashSet();
    public final ad4 f = new ParcelableSnapshotMutableState(at4.i, zq0.e0);
    public final /* synthetic */ iw0 g;

    public a(iw0 iw0Var, long j, boolean z, boolean z2, do2 do2Var) {
        this.g = iw0Var;
        this.f269a = j;
        this.b = z;
        this.c = z2;
    }

    @Override // defpackage.nw0
    public final void a(tw0 tw0Var, Function2 function2) {
        this.g.b.a(tw0Var, function2);
    }

    @Override // defpackage.nw0
    public final tc4 b(tw0 tw0Var, zb2 zb2Var, Function2 function2) {
        return this.g.b.b(tw0Var, zb2Var, function2);
    }

    @Override // defpackage.nw0
    public final void c(bb4 bb4Var) {
        this.g.b.c(bb4Var);
    }

    @Override // defpackage.nw0
    public final void d() {
        iw0 iw0Var = this.g;
        iw0Var.A--;
    }

    @Override // defpackage.nw0
    public final boolean e() {
        return this.g.b.e();
    }

    @Override // defpackage.nw0
    public final boolean f() {
        return this.b;
    }

    @Override // defpackage.nw0
    public final boolean g() {
        return this.c;
    }

    @Override // defpackage.nw0
    public final long h() {
        return this.f269a;
    }

    @Override // defpackage.nw0
    public final mw0 i() {
        return this.g.h;
    }

    @Override // defpackage.nw0
    public final at4 j() {
        return (at4) ((x36) this.f).getValue();
    }

    @Override // defpackage.nw0
    public final CoroutineContext k() {
        return this.g.b.k();
    }

    @Override // defpackage.nw0
    public final void l(bb4 bb4Var) {
        this.g.b.l(bb4Var);
    }

    @Override // defpackage.nw0
    public final void m(tw0 tw0Var) {
        iw0 iw0Var = this.g;
        iw0Var.b.m(iw0Var.h);
        iw0Var.b.m(tw0Var);
    }

    @Override // defpackage.nw0
    public final void n(bb4 bb4Var, ab4 ab4Var, jt jtVar) {
        this.g.b.n(bb4Var, ab4Var, jtVar);
    }

    @Override // defpackage.nw0
    public final ab4 o(bb4 bb4Var) {
        return this.g.b.o(bb4Var);
    }

    @Override // defpackage.nw0
    public final tc4 p(tw0 tw0Var, zb2 zb2Var, tc4 tc4Var) {
        return this.g.b.p(tw0Var, zb2Var, tc4Var);
    }

    @Override // defpackage.nw0
    public final void q(Set set) {
        HashSet hashSet = this.d;
        if (hashSet == null) {
            hashSet = new HashSet();
            this.d = hashSet;
        }
        hashSet.add(set);
    }

    @Override // defpackage.nw0
    public final void r(iw0 iw0Var) {
        this.e.add(iw0Var);
    }

    @Override // defpackage.nw0
    public final void s(x95 x95Var) {
        this.g.b.s(x95Var);
    }

    @Override // defpackage.nw0
    public final void t(tw0 tw0Var) {
        this.g.b.t(tw0Var);
    }

    @Override // defpackage.nw0
    public final void u() {
        this.g.A++;
    }

    @Override // defpackage.nw0
    public final void v(iw0 iw0Var) {
        HashSet<Set> hashSet = this.d;
        if (hashSet != null) {
            for (Set set : hashSet) {
                iw0Var.getClass();
                set.remove(iw0Var.c);
            }
        }
        as6.a(this.e).remove(iw0Var);
    }

    @Override // defpackage.nw0
    public final void w(tw0 tw0Var) {
        this.g.b.w(tw0Var);
    }

    public final void x() {
        LinkedHashSet<iw0> linkedHashSet = this.e;
        if (linkedHashSet.isEmpty()) {
            return;
        }
        HashSet hashSet = this.d;
        if (hashSet != null) {
            for (iw0 iw0Var : linkedHashSet) {
                Iterator it = hashSet.iterator();
                while (it.hasNext()) {
                    ((Set) it.next()).remove(iw0Var.c);
                }
            }
        }
        linkedHashSet.clear();
    }
}

package androidx.compose.runtime;

import defpackage.ad4;
import defpackage.ci1;
import defpackage.dd4;
import defpackage.f12;
import defpackage.gx5;
import defpackage.hw0;
import defpackage.iw0;
import defpackage.no1;
import defpackage.pa0;
import defpackage.q36;
import defpackage.u36;
import defpackage.y36;
import defpackage.z36;
import defpackage.zv0;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class d {
    public static final dd4 a() {
        gx5 gx5Var = z36.b;
        dd4 dd4Var = (dd4) gx5Var.g();
        if (dd4Var != null) {
            return dd4Var;
        }
        dd4 dd4Var2 = new dd4(new hw0[0]);
        gx5Var.A(dd4Var2);
        return dd4Var2;
    }

    public static final no1 b(y36 y36Var, Function0 function0) {
        gx5 gx5Var = z36.f6885a;
        return new no1(y36Var, function0);
    }

    public static final no1 c(Function0 function0) {
        gx5 gx5Var = z36.f6885a;
        return new no1(null, function0);
    }

    public static final q36 d(float f) {
        return new ParcelableSnapshotMutableFloatState(f);
    }

    public static final q36 e(int i) {
        return new ParcelableSnapshotMutableIntState(i);
    }

    public static final u36 f(long j) {
        return new ParcelableSnapshotMutableLongState(j);
    }

    public static final ad4 g(Object obj, y36 y36Var) {
        return new ParcelableSnapshotMutableState(obj, y36Var);
    }

    public static ad4 h(Object obj) {
        return new ParcelableSnapshotMutableState(obj, pa0.t0);
    }

    public static final ad4 i(Object obj, iw0 iw0Var) {
        Object objL = iw0Var.L();
        if (objL == zv0.f7097a) {
            objL = h(obj);
            iw0Var.i0(objL);
        }
        ad4 ad4Var = (ad4) objL;
        ad4Var.setValue(obj);
        return ad4Var;
    }

    public static final ci1 j(Function0 function0) {
        return new ci1(new f12(function0, null), 2);
    }
}

package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.e36;
import defpackage.lo2;
import defpackage.n36;
import defpackage.q36;
import defpackage.r36;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002¨\u0006\u0003"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;", "Lq36;", "Landroid/os/Parcelable;", "runtime"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class ParcelableSnapshotMutableFloatState extends q36 implements Parcelable {
    public static final Parcelable.Creator<ParcelableSnapshotMutableFloatState> CREATOR = new b(1);

    public ParcelableSnapshotMutableFloatState(float f) {
        super(1);
        e36 e36VarK = n36.k();
        r36 r36Var = new r36(f, e36VarK.g());
        if (!(e36VarK instanceof lo2)) {
            r36Var.b = new r36(f, 1L);
        }
        this.c = r36Var;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeFloat(l());
    }
}

package androidx.compose.runtime;

import defpackage.ax0;
import defpackage.bh3;
import defpackage.bq;
import defpackage.cw1;
import defpackage.d76;
import defpackage.pa0;
import defpackage.x36;
import defpackage.y36;
import defpackage.z87;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final bh3 f271a;

    public e(Function0 function0) {
        this.f271a = new bh3(function0);
    }

    public abstract bq a(Object obj);

    public z87 b() {
        return this.f271a;
    }

    public final z87 c(bq bqVar, z87 z87Var) {
        z87 z87Var2 = null;
        z87Var2 = null;
        z87Var2 = null;
        z87Var2 = null;
        z87Var2 = null;
        z87Var2 = null;
        if (z87Var instanceof cw1) {
            if (bqVar.d) {
                cw1 cw1Var = (cw1) z87Var;
                ((x36) cw1Var.f1559a).setValue(bqVar.c());
                z87Var2 = cw1Var;
            }
        } else if (z87Var instanceof d76) {
            if ((bqVar.c || bqVar.b != null) && !bqVar.d) {
                d76 d76Var = (d76) z87Var;
                if (Intrinsics.a(bqVar.c(), d76Var.f1640a)) {
                    z87Var2 = d76Var;
                }
            }
        } else if (z87Var instanceof ax0) {
            bqVar.getClass();
        }
        if (z87Var2 != null) {
            return z87Var2;
        }
        if (!bqVar.d) {
            return new d76(bqVar.c());
        }
        Object obj = bqVar.b;
        y36 y36Var = (y36) bqVar.f639a;
        if (y36Var == null) {
            y36Var = pa0.t0;
        }
        return new cw1(new ParcelableSnapshotMutableState(obj, y36Var));
    }
}

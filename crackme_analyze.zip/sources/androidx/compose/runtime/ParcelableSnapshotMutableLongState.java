package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.e36;
import defpackage.lo2;
import defpackage.n36;
import defpackage.t36;
import defpackage.u36;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002¨\u0006\u0003"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;", "Lu36;", "Landroid/os/Parcelable;", "runtime"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class ParcelableSnapshotMutableLongState extends u36 implements Parcelable {
    public static final Parcelable.Creator<ParcelableSnapshotMutableLongState> CREATOR = new b(3);

    public ParcelableSnapshotMutableLongState(long j) {
        e36 e36VarK = n36.k();
        t36 t36Var = new t36(e36VarK.g(), j);
        if (!(e36VarK instanceof lo2)) {
            t36Var.b = new t36(1L, j);
        }
        this.b = t36Var;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(l());
    }
}

package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.e36;
import defpackage.lo2;
import defpackage.n36;
import defpackage.q36;
import defpackage.s36;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002¨\u0006\u0003"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;", "Lq36;", "Landroid/os/Parcelable;", "runtime"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class ParcelableSnapshotMutableIntState extends q36 implements Parcelable {
    public static final Parcelable.Creator<ParcelableSnapshotMutableIntState> CREATOR = new b(2);

    public ParcelableSnapshotMutableIntState(int i) {
        super(2);
        e36 e36VarK = n36.k();
        s36 s36Var = new s36(i, e36VarK.g());
        if (!(e36VarK instanceof lo2)) {
            s36Var.b = new s36(i, 1L);
        }
        this.c = s36Var;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(n());
    }
}

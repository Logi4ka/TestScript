package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.e36;
import defpackage.lo2;
import defpackage.n36;
import defpackage.p36;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f270a;

    public /* synthetic */ b(int i) {
        this.f270a = i;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f270a) {
            case 0:
                double d = parcel.readDouble();
                ParcelableSnapshotMutableDoubleState parcelableSnapshotMutableDoubleState = new ParcelableSnapshotMutableDoubleState(0);
                e36 e36VarK = n36.k();
                p36 p36Var = new p36(e36VarK.g(), d);
                if (!(e36VarK instanceof lo2)) {
                    p36Var.b = new p36(1L, d);
                }
                parcelableSnapshotMutableDoubleState.c = p36Var;
                return parcelableSnapshotMutableDoubleState;
            case 1:
                return new ParcelableSnapshotMutableFloatState(parcel.readFloat());
            case 2:
                return new ParcelableSnapshotMutableIntState(parcel.readInt());
            default:
                return new ParcelableSnapshotMutableLongState(parcel.readLong());
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        switch (this.f270a) {
            case 0:
                return new ParcelableSnapshotMutableDoubleState[i];
            case 1:
                return new ParcelableSnapshotMutableFloatState[i];
            case 2:
                return new ParcelableSnapshotMutableIntState[i];
            default:
                return new ParcelableSnapshotMutableLongState[i];
        }
    }
}

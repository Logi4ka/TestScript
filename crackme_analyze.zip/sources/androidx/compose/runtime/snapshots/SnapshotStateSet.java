package androidx.compose.runtime.snapshots;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.a46;
import defpackage.a76;
import defpackage.au4;
import defpackage.bu4;
import defpackage.e36;
import defpackage.fu7;
import defpackage.h08;
import defpackage.n36;
import defpackage.n93;
import defpackage.t66;
import defpackage.vk5;
import defpackage.w66;
import defpackage.z66;
import java.util.Collection;
import java.util.Iterator;
import java.util.RandomAccess;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u00022\u00020\u00032\b\u0012\u0004\u0012\u00028\u00000\u00042\u00060\u0005j\u0002`\u0006¨\u0006\u0007"}, d2 = {"Landroidx/compose/runtime/snapshots/SnapshotStateSet;", "T", "Landroid/os/Parcelable;", "Lt66;", HttpUrl.FRAGMENT_ENCODE_SET, "Ljava/util/RandomAccess;", "Lkotlin/collections/RandomAccess;", "runtime"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class SnapshotStateSet<T> implements Parcelable, t66, Set<T>, RandomAccess, n93 {
    public static final Parcelable.Creator<SnapshotStateSet<Object>> CREATOR = new a46(4);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public a76 f273a;

    @Override // defpackage.t66
    public final w66 a() {
        return this.f273a;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        int i;
        au4 au4Var;
        e36 e36VarK;
        boolean zH;
        do {
            synchronized (h08.e) {
                a76 a76Var = this.f273a;
                a76Var.getClass();
                a76 a76Var2 = (a76) n36.i(a76Var);
                i = a76Var2.d;
                au4Var = a76Var2.c;
            }
            au4Var.getClass();
            au4 au4VarA = au4Var.a(obj);
            if (au4VarA.equals(au4Var)) {
                return false;
            }
            a76 a76Var3 = this.f273a;
            a76Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zH = h08.h((a76) n36.w(a76Var3, this, e36VarK), i, au4VarA);
            }
            n36.n(e36VarK, this);
        } while (!zH);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        int i;
        au4 au4Var;
        e36 e36VarK;
        boolean zH;
        do {
            synchronized (h08.e) {
                a76 a76Var = this.f273a;
                a76Var.getClass();
                a76 a76Var2 = (a76) n36.i(a76Var);
                i = a76Var2.d;
                au4Var = a76Var2.c;
            }
            au4Var.getClass();
            bu4 bu4Var = new bu4(au4Var);
            bu4Var.addAll(collection);
            au4 au4VarB = bu4Var.b();
            if (au4VarB.equals(au4Var)) {
                return false;
            }
            a76 a76Var3 = this.f273a;
            a76Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zH = h08.h((a76) n36.w(a76Var3, this, e36VarK), i, au4VarB);
            }
            n36.n(e36VarK, this);
        } while (!zH);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        e36 e36VarK;
        a76 a76Var = this.f273a;
        a76Var.getClass();
        synchronized (n36.c) {
            e36VarK = n36.k();
            a76 a76Var2 = (a76) n36.w(a76Var, this, e36VarK);
            synchronized (h08.e) {
                a76Var2.c = au4.e;
                a76Var2.d++;
            }
        }
        n36.n(e36VarK, this);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        return h08.M(this).c.contains(obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        return h08.M(this).c.containsAll(collection);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // defpackage.t66
    public final void e(w66 w66Var) {
        w66Var.b = this.f273a;
        this.f273a = (a76) w66Var;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        return h08.M(this).c.isEmpty();
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new z66(this, h08.M(this).c.iterator());
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        int i;
        au4 au4Var;
        e36 e36VarK;
        boolean zH;
        do {
            synchronized (h08.e) {
                a76 a76Var = this.f273a;
                a76Var.getClass();
                a76 a76Var2 = (a76) n36.i(a76Var);
                i = a76Var2.d;
                au4Var = a76Var2.c;
            }
            au4Var.getClass();
            au4 au4VarB = au4Var.b(obj);
            if (au4VarB.equals(au4Var)) {
                return false;
            }
            a76 a76Var3 = this.f273a;
            a76Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zH = h08.h((a76) n36.w(a76Var3, this, e36VarK), i, au4VarB);
            }
            n36.n(e36VarK, this);
        } while (!zH);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean removeAll(Collection collection) {
        int i;
        au4 au4Var;
        e36 e36VarK;
        boolean zH;
        do {
            synchronized (h08.e) {
                a76 a76Var = this.f273a;
                a76Var.getClass();
                a76 a76Var2 = (a76) n36.i(a76Var);
                i = a76Var2.d;
                au4Var = a76Var2.c;
            }
            au4Var.getClass();
            bu4 bu4Var = new bu4(au4Var);
            bu4Var.removeAll(collection);
            au4 au4VarB = bu4Var.b();
            if (au4VarB.equals(au4Var)) {
                return false;
            }
            a76 a76Var3 = this.f273a;
            a76Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zH = h08.h((a76) n36.w(a76Var3, this, e36VarK), i, au4VarB);
            }
            n36.n(e36VarK, this);
        } while (!zH);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        int i;
        au4 au4Var;
        boolean zRetainAll;
        e36 e36VarK;
        boolean zH;
        do {
            synchronized (h08.e) {
                a76 a76Var = this.f273a;
                a76Var.getClass();
                a76 a76Var2 = (a76) n36.i(a76Var);
                i = a76Var2.d;
                au4Var = a76Var2.c;
            }
            if (au4Var == null) {
                vk5.k("No set to mutate");
                return false;
            }
            bu4 bu4Var = new bu4(au4Var);
            zRetainAll = bu4Var.retainAll(CollectionsKt.V(collection));
            au4 au4VarB = bu4Var.b();
            if (au4VarB.equals(au4Var)) {
                break;
            }
            a76 a76Var3 = this.f273a;
            a76Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zH = h08.h((a76) n36.w(a76Var3, this, e36VarK), i, au4VarB);
            }
            n36.n(e36VarK, this);
        } while (!zH);
        return zRetainAll;
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        return h08.M(this).c.size();
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        return fu7.R(this);
    }

    public final String toString() {
        a76 a76Var = this.f273a;
        a76Var.getClass();
        return "SnapshotStateSet(value=" + ((a76) n36.i(a76Var)).c + ")@" + hashCode();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        au4 au4Var = h08.M(this).c;
        parcel.writeInt(size());
        Iterator it = au4Var.iterator();
        if (it.hasNext()) {
            parcel.writeValue(it.next());
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        return fu7.S(this, objArr);
    }
}

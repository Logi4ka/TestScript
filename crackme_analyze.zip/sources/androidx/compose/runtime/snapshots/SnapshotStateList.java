package androidx.compose.runtime.snapshots;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.a46;
import defpackage.b1;
import defpackage.bx7;
import defpackage.d1;
import defpackage.e36;
import defpackage.ey4;
import defpackage.f26;
import defpackage.fu7;
import defpackage.gu4;
import defpackage.ik0;
import defpackage.l93;
import defpackage.lo2;
import defpackage.m96;
import defpackage.n36;
import defpackage.pu2;
import defpackage.s66;
import defpackage.t66;
import defpackage.w66;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u00022\u00020\u00032\b\u0012\u0004\u0012\u00028\u00000\u00042\u00060\u0005j\u0002`\u0006¨\u0006\u0007"}, d2 = {"Landroidx/compose/runtime/snapshots/SnapshotStateList;", "T", "Landroid/os/Parcelable;", "Lt66;", HttpUrl.FRAGMENT_ENCODE_SET, "Ljava/util/RandomAccess;", "Lkotlin/collections/RandomAccess;", "runtime"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class SnapshotStateList<T> implements Parcelable, t66, List<T>, RandomAccess, l93 {
    public static final Parcelable.Creator<SnapshotStateList<Object>> CREATOR = new a46(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public s66 f272a;

    public SnapshotStateList(d1 d1Var) {
        e36 e36VarK = n36.k();
        s66 s66Var = new s66(e36VarK.g(), d1Var);
        if (!(e36VarK instanceof lo2)) {
            s66Var.b = new s66(1L, d1Var);
        }
        this.f272a = s66Var;
    }

    @Override // defpackage.t66
    public final w66 a() {
        return this.f272a;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean add(Object obj) {
        int i;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            d1 d1VarB = d1Var.b(obj);
            if (d1VarB.equals(d1Var)) {
                return false;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i, d1VarB, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean addAll(Collection collection) {
        int i;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            d1 d1VarC = d1Var.c(collection);
            if (Intrinsics.a(d1VarC, d1Var)) {
                return false;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i, d1VarC, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final void clear() {
        e36 e36VarK;
        s66 s66Var = this.f272a;
        s66Var.getClass();
        synchronized (n36.c) {
            e36VarK = n36.k();
            s66 s66Var2 = (s66) n36.w(s66Var, this, e36VarK);
            synchronized (bx7.d) {
                s66Var2.c = f26.b;
                s66Var2.d++;
                s66Var2.e++;
            }
        }
        n36.n(e36VarK, this);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean contains(Object obj) {
        return bx7.w(this).c.contains(obj);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean containsAll(Collection collection) {
        return bx7.w(this).c.containsAll(collection);
    }

    public final void d(int i, int i2) {
        int i3;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i3 = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            gu4 gu4VarD = d1Var.d();
            gu4VarD.subList(i, i2).clear();
            d1 d1VarC = gu4VarD.c();
            if (Intrinsics.a(d1VarC, d1Var)) {
                return;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i3, d1VarC, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // defpackage.t66
    public final void e(w66 w66Var) {
        w66Var.b = this.f272a;
        this.f272a = (s66) w66Var;
    }

    @Override // java.util.List
    public final Object get(int i) {
        return bx7.w(this).c.get(i);
    }

    @Override // java.util.List
    public final int indexOf(Object obj) {
        return bx7.w(this).c.indexOf(obj);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean isEmpty() {
        return bx7.w(this).c.isEmpty();
    }

    @Override // java.util.List, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return listIterator();
    }

    @Override // java.util.List
    public final int lastIndexOf(Object obj) {
        return bx7.w(this).c.lastIndexOf(obj);
    }

    @Override // java.util.List
    public final ListIterator listIterator() {
        return new pu2(this, 0);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean remove(Object obj) {
        int i;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            int iIndexOf = d1Var.indexOf(obj);
            d1 d1VarF = iIndexOf != -1 ? d1Var.f(iIndexOf) : d1Var;
            if (d1VarF.equals(d1Var)) {
                return false;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i, d1VarF, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean removeAll(Collection collection) {
        int i;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            d1 d1VarE = d1Var.e(new b1(0, collection));
            if (Intrinsics.a(d1VarE, d1Var)) {
                return false;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i, d1VarE, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean retainAll(Collection collection) {
        return bx7.K(this, new b1(3, collection));
    }

    @Override // java.util.List
    public final Object set(int i, Object obj) {
        int i2;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        Object obj2 = get(i);
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i2 = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            d1 d1VarH = d1Var.h(i, obj);
            if (d1VarH.equals(d1Var)) {
                break;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i2, d1VarH, false);
            }
            n36.n(e36VarK, this);
        } while (!zG);
        return obj2;
    }

    @Override // java.util.List, java.util.Collection
    public final int size() {
        return bx7.w(this).c.size();
    }

    @Override // java.util.List
    public final List subList(int i, int i2) {
        if (!(i >= 0 && i <= i2 && i2 <= size())) {
            ey4.a("fromIndex or toIndex are out of bounds");
        }
        return new m96(this, i, i2);
    }

    @Override // java.util.List, java.util.Collection
    public final Object[] toArray() {
        return fu7.R(this);
    }

    public final String toString() {
        s66 s66Var = this.f272a;
        s66Var.getClass();
        return "SnapshotStateList(value=" + ((s66) n36.i(s66Var)).c + ")@" + hashCode();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        d1 d1Var = bx7.w(this).c;
        int size = d1Var.size();
        parcel.writeInt(size);
        for (int i2 = 0; i2 < size; i2++) {
            parcel.writeValue(d1Var.get(i2));
        }
    }

    @Override // java.util.List, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        return fu7.S(this, objArr);
    }

    @Override // java.util.List
    public final ListIterator listIterator(int i) {
        return new pu2(this, i);
    }

    public SnapshotStateList() {
        this(f26.b);
    }

    @Override // java.util.List
    public final void add(int i, Object obj) {
        int i2;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i2 = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            d1 d1VarA = d1Var.a(i, obj);
            if (d1VarA.equals(d1Var)) {
                return;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i2, d1VarA, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
    }

    @Override // java.util.List
    public final boolean addAll(int i, Collection collection) {
        return bx7.K(this, new ik0(i, collection, 3));
    }

    @Override // java.util.List
    public final Object remove(int i) {
        int i2;
        d1 d1Var;
        e36 e36VarK;
        boolean zG;
        Object obj = get(i);
        do {
            synchronized (bx7.d) {
                s66 s66Var = this.f272a;
                s66Var.getClass();
                s66 s66Var2 = (s66) n36.i(s66Var);
                i2 = s66Var2.d;
                d1Var = s66Var2.c;
            }
            d1Var.getClass();
            d1 d1VarF = d1Var.f(i);
            if (d1VarF.equals(d1Var)) {
                break;
            }
            s66 s66Var3 = this.f272a;
            s66Var3.getClass();
            synchronized (n36.c) {
                e36VarK = n36.k();
                zG = bx7.g((s66) n36.w(s66Var3, this, e36VarK), i2, d1VarF, true);
            }
            n36.n(e36VarK, this);
        } while (!zG);
        return obj;
    }
}

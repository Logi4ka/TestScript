package androidx.compose.ui.node;

import defpackage.ae3;
import defpackage.ce3;
import defpackage.cj0;
import defpackage.dd4;
import defpackage.do4;
import defpackage.ep3;
import defpackage.g94;
import defpackage.hc;
import defpackage.jp2;
import defpackage.lf6;
import defpackage.p01;
import defpackage.p88;
import defpackage.pn2;
import defpackage.tu4;
import defpackage.v13;
import defpackage.wd3;
import defpackage.yd3;
import defpackage.ys3;
import defpackage.zr0;
import defpackage.zs3;
import io.flutter.embedding.android.KeyboardMap;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class a extends NodeCoordinator {
    public static final p88 F0;
    public final lf6 D0;
    public v13 E0;

    static {
        p88 p88VarC = p01.c();
        int i = zr0.h;
        p88VarC.g(zr0.d);
        p88VarC.m(1.0f);
        p88VarC.o(1);
        F0 = p88VarC;
    }

    public a(LayoutNode layoutNode) {
        super(layoutNode);
        lf6 lf6Var = new lf6();
        lf6Var.d = 0;
        this.D0 = lf6Var;
        lf6Var.v = this;
        this.E0 = layoutNode.i != null ? new v13(this) : null;
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final void J0() {
        if (this.E0 == null) {
            this.E0 = new v13(this);
        }
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final ep3 M0() {
        return this.E0;
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final g94 O0() {
        return this.D0;
    }

    @Override // defpackage.us3
    public final int P(int i) {
        pn2 pn2VarW = this.d0.w();
        zs3 zs3VarM = pn2VarW.m();
        LayoutNode layoutNode = (LayoutNode) pn2VarW.b;
        return zs3VarM.f(layoutNode.getOuterCoordinator$ui_release(), layoutNode.n(), i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0040  */
    /* JADX WARN: Removed duplicated region for block: B:94:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [g94] */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v12 */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5, types: [g94] */
    /* JADX WARN: Type inference failed for: r3v6, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r3v9 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11, types: [dd4] */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v16 */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8, types: [dd4] */
    /* JADX WARN: Type inference failed for: r5v9 */
    @Override // androidx.compose.ui.node.NodeCoordinator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void U0(defpackage.bh4 r17, long r18, defpackage.ru2 r20, int r21, boolean r22) {
        /*
            Method dump skipped, instruction units count: 270
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.node.a.U0(bh4, long, ru2, int, boolean):void");
    }

    @Override // defpackage.us3
    public final int b(int i) {
        pn2 pn2VarW = this.d0.w();
        zs3 zs3VarM = pn2VarW.m();
        LayoutNode layoutNode = (LayoutNode) pn2VarW.b;
        return zs3VarM.j(layoutNode.getOuterCoordinator$ui_release(), layoutNode.n(), i);
    }

    @Override // defpackage.tu4
    public final void c0(long j, float f, Function1 function1) {
        e1(j, f, function1);
        if (this.X) {
            return;
        }
        this.d0.t0.p.t0();
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final void d1(cj0 cj0Var, jp2 jp2Var) {
        LayoutNode layoutNode = this.d0;
        do4 do4VarA = ce3.a(layoutNode);
        dd4 dd4VarB = layoutNode.B();
        Object[] objArr = dd4VarB.f1699a;
        int i = dd4VarB.c;
        for (int i2 = 0; i2 < i; i2++) {
            LayoutNode layoutNode2 = (LayoutNode) objArr[i2];
            if (layoutNode2.M()) {
                layoutNode2.j(cj0Var, jp2Var);
            }
        }
        if (do4VarA.getShowLayoutBounds()) {
            long j = this.c;
            cj0Var.f(0.5f, 0.5f, ((int) (j >> 32)) - 0.5f, ((int) (j & KeyboardMap.kValueMask)) - 0.5f, F0);
        }
    }

    @Override // defpackage.us3
    public final int l(int i) {
        pn2 pn2VarW = this.d0.w();
        zs3 zs3VarM = pn2VarW.m();
        LayoutNode layoutNode = (LayoutNode) pn2VarW.b;
        return zs3VarM.e(layoutNode.getOuterCoordinator$ui_release(), layoutNode.n(), i);
    }

    @Override // defpackage.us3
    public final int n(int i) {
        pn2 pn2VarW = this.d0.w();
        zs3 zs3VarM = pn2VarW.m();
        LayoutNode layoutNode = (LayoutNode) pn2VarW.b;
        return zs3VarM.g(layoutNode.getOuterCoordinator$ui_release(), layoutNode.n(), i);
    }

    @Override // defpackage.cp3
    public final int o0(hc hcVar) {
        v13 v13Var = this.E0;
        if (v13Var != null) {
            return v13Var.o0(hcVar);
        }
        ys3 ys3Var = this.d0.t0.p;
        ae3 ae3Var = ys3Var.m0;
        if (!ys3Var.b0) {
            if (ys3Var.f.d == wd3.f6285a) {
                ae3Var.f = true;
                if (ae3Var.b) {
                    ys3Var.k0 = true;
                    ys3Var.l0 = true;
                }
            } else {
                ae3Var.g = true;
            }
        }
        ys3Var.e().Y = true;
        ys3Var.D();
        ys3Var.e().Y = false;
        Integer num = (Integer) ae3Var.i.get(hcVar);
        if (num != null) {
            return num.intValue();
        }
        return Integer.MIN_VALUE;
    }

    @Override // defpackage.us3
    public final tu4 t(long j) {
        h0(j);
        LayoutNode layoutNode = this.d0;
        dd4 dd4VarC = layoutNode.C();
        Object[] objArr = dd4VarC.f1699a;
        int i = dd4VarC.c;
        for (int i2 = 0; i2 < i; i2++) {
            ((LayoutNode) objArr[i2]).t0.p.Z = yd3.c;
        }
        h1(layoutNode.j0.c(this, layoutNode.n(), j));
        Z0();
        return this;
    }
}

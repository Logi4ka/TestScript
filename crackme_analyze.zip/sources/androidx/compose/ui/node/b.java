package androidx.compose.ui.node;

import androidx.core.app.NotificationCompat;
import defpackage.ac4;
import defpackage.ax6;
import defpackage.c43;
import defpackage.ce3;
import defpackage.cj0;
import defpackage.ep3;
import defpackage.fq3;
import defpackage.g94;
import defpackage.hc;
import defpackage.jp2;
import defpackage.p01;
import defpackage.p88;
import defpackage.td3;
import defpackage.tu4;
import defpackage.u33;
import defpackage.ud3;
import defpackage.zr0;
import io.flutter.embedding.android.KeyboardMap;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b extends NodeCoordinator {
    public static final p88 F0;
    public td3 D0;
    public ud3 E0;

    static {
        p88 p88VarC = p01.c();
        int i = zr0.h;
        p88VarC.g(zr0.e);
        p88VarC.m(1.0f);
        p88VarC.o(1);
        F0 = p88VarC;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public b(LayoutNode layoutNode, td3 td3Var) {
        super(layoutNode);
        this.D0 = td3Var;
        this.E0 = layoutNode.i != null ? new ud3(this) : null;
        if ((((g94) td3Var).f2347a.c & NotificationCompat.FLAG_GROUP_SUMMARY) == 0) {
            return;
        }
        ax6.w();
        throw null;
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final void J0() {
        if (this.E0 == null) {
            this.E0 = new ud3(this);
        }
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final ep3 M0() {
        return this.E0;
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final g94 O0() {
        return ((g94) this.D0).f2347a;
    }

    @Override // defpackage.us3
    public final int P(int i) {
        td3 td3Var = this.D0;
        NodeCoordinator nodeCoordinator = this.e0;
        nodeCoordinator.getClass();
        return td3Var.X(this, nodeCoordinator, i);
    }

    @Override // defpackage.us3
    public final int b(int i) {
        td3 td3Var = this.D0;
        NodeCoordinator nodeCoordinator = this.e0;
        nodeCoordinator.getClass();
        return td3Var.R(this, nodeCoordinator, i);
    }

    @Override // defpackage.tu4
    public final void c0(long j, float f, Function1 function1) {
        e1(j, f, function1);
        if (this.X) {
            return;
        }
        a1();
        w0().b();
        this.e0.getClass();
    }

    @Override // androidx.compose.ui.node.NodeCoordinator
    public final void d1(cj0 cj0Var, jp2 jp2Var) {
        NodeCoordinator nodeCoordinator;
        NodeCoordinator nodeCoordinator2 = this.e0;
        nodeCoordinator2.getClass();
        nodeCoordinator2.H0(cj0Var, jp2Var);
        if (!ce3.a(this.d0).getShowLayoutBounds() || (nodeCoordinator = this.e0) == null) {
            return;
        }
        if (c43.a(this.c, nodeCoordinator.c) && u33.a(nodeCoordinator.o0, 0L)) {
            return;
        }
        long j = this.c;
        cj0Var.f(0.5f, 0.5f, ((int) (j >> 32)) - 0.5f, ((int) (j & KeyboardMap.kValueMask)) - 0.5f, F0);
    }

    @Override // defpackage.us3
    public final int l(int i) {
        td3 td3Var = this.D0;
        NodeCoordinator nodeCoordinator = this.e0;
        nodeCoordinator.getClass();
        return td3Var.f0(this, nodeCoordinator, i);
    }

    @Override // defpackage.us3
    public final int n(int i) {
        td3 td3Var = this.D0;
        NodeCoordinator nodeCoordinator = this.e0;
        nodeCoordinator.getClass();
        return td3Var.e(this, nodeCoordinator, i);
    }

    @Override // defpackage.cp3
    public final int o0(hc hcVar) {
        ud3 ud3Var = this.E0;
        if (ud3Var == null) {
            return fq3.d(this, hcVar);
        }
        ac4 ac4Var = ud3Var.i0;
        int iD = ac4Var.d(hcVar);
        if (iD >= 0) {
            return ac4Var.c[iD];
        }
        return Integer.MIN_VALUE;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void q1(td3 td3Var) {
        if (td3Var.equals(this.D0) || (((g94) td3Var).f2347a.c & NotificationCompat.FLAG_GROUP_SUMMARY) == 0) {
            this.D0 = td3Var;
        } else {
            ax6.w();
        }
    }

    @Override // defpackage.us3
    public final tu4 t(long j) {
        h0(j);
        td3 td3Var = this.D0;
        NodeCoordinator nodeCoordinator = this.e0;
        nodeCoordinator.getClass();
        h1(td3Var.b(this, nodeCoordinator, j));
        Z0();
        return this;
    }
}

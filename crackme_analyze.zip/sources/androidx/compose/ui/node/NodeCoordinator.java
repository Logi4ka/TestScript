package androidx.compose.ui.node;

import android.os.Build;
import android.view.ViewParent;
import androidx.compose.ui.platform.AndroidComposeView;
import androidx.core.app.NotificationCompat;
import defpackage.ac4;
import defpackage.ah4;
import defpackage.at3;
import defpackage.bb1;
import defpackage.be3;
import defpackage.bh4;
import defpackage.bx7;
import defpackage.ce3;
import defpackage.cg5;
import defpackage.ch4;
import defpackage.cj0;
import defpackage.co1;
import defpackage.co4;
import defpackage.cp3;
import defpackage.dd4;
import defpackage.dd7;
import defpackage.do4;
import defpackage.e36;
import defpackage.ej0;
import defpackage.eo4;
import defpackage.ep3;
import defpackage.fc4;
import defpackage.fh;
import defpackage.fh4;
import defpackage.fh5;
import defpackage.fp3;
import defpackage.fq3;
import defpackage.fs;
import defpackage.g;
import defpackage.g94;
import defpackage.gq3;
import defpackage.ha5;
import defpackage.hc;
import defpackage.ip2;
import defpackage.jo;
import defpackage.jp2;
import defpackage.kd3;
import defpackage.kp2;
import defpackage.ku7;
import defpackage.ld3;
import defpackage.lf6;
import defpackage.ln1;
import defpackage.lp2;
import defpackage.ma3;
import defpackage.mp2;
import defpackage.na1;
import defpackage.nd3;
import defpackage.nn4;
import defpackage.od3;
import defpackage.on4;
import defpackage.p13;
import defpackage.pb5;
import defpackage.pn4;
import defpackage.qe0;
import defpackage.qp7;
import defpackage.qs3;
import defpackage.rc4;
import defpackage.ru2;
import defpackage.sj4;
import defpackage.st1;
import defpackage.tj;
import defpackage.u33;
import defpackage.ui;
import defpackage.us3;
import defpackage.vk5;
import defpackage.wq4;
import defpackage.yj4;
import defpackage.yo6;
import defpackage.zr0;
import io.flutter.embedding.android.KeyboardMap;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.Map;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.http2.Http2;
import okio.Segment;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class NodeCoordinator extends cp3 implements us3, nd3, eo4 {
    public static final float[] A0;
    public static final na1 B0;
    public static final bb1 C0;
    public static final cg5 y0;
    public static final kd3 z0;
    public final LayoutNode d0;
    public NodeCoordinator e0;
    public NodeCoordinator f0;
    public boolean g0;
    public boolean h0;
    public Function1 i0;
    public co1 j0;
    public od3 k0;
    public at3 m0;
    public ac4 n0;
    public float p0;
    public rc4 q0;
    public kd3 r0;
    public jp2 s0;
    public cj0 t0;
    public fh u0;
    public boolean w0;
    public co4 x0;
    public float l0 = 0.8f;
    public long o0 = 0;
    public final ch4 v0 = new ch4(this, 1);

    static {
        cg5 cg5Var = new cg5();
        cg5Var.b = 1.0f;
        cg5Var.c = 1.0f;
        cg5Var.d = 1.0f;
        long j = mp2.f4203a;
        cg5Var.f = j;
        cg5Var.i = j;
        cg5Var.v = 8.0f;
        cg5Var.w = yo6.f6785a;
        cg5Var.X = ma3.o;
        cg5Var.Z = 9205357640488583168L;
        cg5Var.b0 = gq3.c();
        cg5Var.c0 = od3.f4581a;
        cg5Var.d0 = 3;
        y0 = cg5Var;
        z0 = new kd3();
        A0 = qs3.a();
        int i = 21;
        B0 = new na1(i);
        C0 = new bb1(i);
    }

    public NodeCoordinator(LayoutNode layoutNode) {
        this.d0 = layoutNode;
        this.j0 = layoutNode.l0;
        this.k0 = layoutNode.m0;
    }

    public static NodeCoordinator i1(nd3 nd3Var) {
        NodeCoordinator nodeCoordinator;
        fp3 fp3Var = nd3Var instanceof fp3 ? (fp3) nd3Var : null;
        if (fp3Var != null && (nodeCoordinator = fp3Var.f2212a.d0) != null) {
            return nodeCoordinator;
        }
        nd3Var.getClass();
        return (NodeCoordinator) nd3Var;
    }

    @Override // defpackage.cp3
    public final void C0() {
        c0(this.o0, this.p0, this.i0);
    }

    public final void D0(NodeCoordinator nodeCoordinator, rc4 rc4Var, boolean z) {
        if (nodeCoordinator == this) {
            return;
        }
        NodeCoordinator nodeCoordinator2 = this.f0;
        if (nodeCoordinator2 != null) {
            nodeCoordinator2.D0(nodeCoordinator, rc4Var, z);
        }
        long j = this.o0;
        float f = (int) (j >> 32);
        rc4Var.b -= f;
        rc4Var.d -= f;
        float f2 = (int) (j & KeyboardMap.kValueMask);
        rc4Var.c -= f2;
        rc4Var.e -= f2;
        co4 co4Var = this.x0;
        if (co4Var != null) {
            lp2 lp2Var = (lp2) co4Var;
            float[] fArrA = lp2Var.a();
            if (!lp2Var.h0) {
                if (fArrA == null) {
                    rc4Var.b = 0.0f;
                    rc4Var.c = 0.0f;
                    rc4Var.d = 0.0f;
                    rc4Var.e = 0.0f;
                } else {
                    qs3.c(fArrA, rc4Var);
                }
            }
            if (this.h0 && z) {
                long j2 = this.c;
                rc4Var.e(0.0f, 0.0f, (int) (j2 >> 32), (int) (j2 & KeyboardMap.kValueMask));
            }
        }
    }

    public final long E0(NodeCoordinator nodeCoordinator, long j) {
        if (nodeCoordinator == this) {
            return j;
        }
        NodeCoordinator nodeCoordinator2 = this.f0;
        return (nodeCoordinator2 == null || Intrinsics.a(nodeCoordinator, nodeCoordinator2)) ? L0(j) : L0(nodeCoordinator2.E0(nodeCoordinator, j));
    }

    public final long F0(long j) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j >> 32)) - Z();
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask)) - X();
        return (((long) Float.floatToRawIntBits(Math.max(0.0f, fIntBitsToFloat / 2.0f))) << 32) | (((long) Float.floatToRawIntBits(Math.max(0.0f, fIntBitsToFloat2 / 2.0f))) & KeyboardMap.kValueMask);
    }

    @Override // defpackage.nd3
    public final long G(nd3 nd3Var, long j) {
        return X0(nd3Var, j);
    }

    public final float G0(long j, long j2) {
        if (Z() >= Float.intBitsToFloat((int) (j2 >> 32)) && X() >= Float.intBitsToFloat((int) (j2 & KeyboardMap.kValueMask))) {
            return Float.POSITIVE_INFINITY;
        }
        long jF0 = F0(j2);
        float fIntBitsToFloat = Float.intBitsToFloat((int) (jF0 >> 32));
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (jF0 & KeyboardMap.kValueMask));
        float fIntBitsToFloat3 = Float.intBitsToFloat((int) (j >> 32));
        float fMax = Math.max(0.0f, fIntBitsToFloat3 < 0.0f ? -fIntBitsToFloat3 : fIntBitsToFloat3 - Z());
        float fIntBitsToFloat4 = Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask));
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fMax)) << 32) | (((long) Float.floatToRawIntBits(Math.max(0.0f, fIntBitsToFloat4 < 0.0f ? -fIntBitsToFloat4 : fIntBitsToFloat4 - X()))) & KeyboardMap.kValueMask);
        if (fIntBitsToFloat > 0.0f || fIntBitsToFloat2 > 0.0f) {
            int i = (int) (jFloatToRawIntBits >> 32);
            if (Float.intBitsToFloat(i) <= fIntBitsToFloat) {
                int i2 = (int) (jFloatToRawIntBits & KeyboardMap.kValueMask);
                if (Float.intBitsToFloat(i2) <= fIntBitsToFloat2) {
                    float fIntBitsToFloat5 = Float.intBitsToFloat(i);
                    float fIntBitsToFloat6 = Float.intBitsToFloat(i2);
                    return (fIntBitsToFloat6 * fIntBitsToFloat6) + (fIntBitsToFloat5 * fIntBitsToFloat5);
                }
            }
        }
        return Float.POSITIVE_INFINITY;
    }

    @Override // defpackage.nd3
    public final long H(long j) {
        if (!O0().c0) {
            p13.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        return X0(ma3.q(this), ((AndroidComposeView) ce3.a(this.d0)).D(j));
    }

    public final void H0(cj0 cj0Var, jp2 jp2Var) {
        co4 co4Var = this.x0;
        if (co4Var == null) {
            long j = this.o0;
            float f = (int) (j >> 32);
            float f2 = (int) (j & KeyboardMap.kValueMask);
            cj0Var.l(f, f2);
            I0(cj0Var, jp2Var);
            cj0Var.l(-f, -f2);
            return;
        }
        lp2 lp2Var = (lp2) co4Var;
        ej0 ej0Var = lp2Var.b0;
        lp2Var.g();
        lp2Var.i0 = lp2Var.f3971a.f3547a.L() > 0.0f;
        fs fsVar = ej0Var.b;
        fsVar.A(cj0Var);
        fsVar.b = jp2Var;
        qp7.o(ej0Var, lp2Var.f3971a);
    }

    @Override // defpackage.nd3
    public final ha5 I(nd3 nd3Var, boolean z) {
        if (!O0().c0) {
            p13.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        if (!nd3Var.g()) {
            p13.b("LayoutCoordinates " + nd3Var + " is not attached!");
        }
        NodeCoordinator nodeCoordinatorI1 = i1(nd3Var);
        nodeCoordinatorI1.Y0();
        NodeCoordinator nodeCoordinatorK0 = K0(nodeCoordinatorI1);
        rc4 rc4Var = this.q0;
        if (rc4Var == null) {
            rc4Var = new rc4();
            this.q0 = rc4Var;
        }
        rc4Var.b = 0.0f;
        rc4Var.c = 0.0f;
        rc4Var.d = (int) (nd3Var.k() >> 32);
        rc4Var.e = (int) (nd3Var.k() & KeyboardMap.kValueMask);
        while (nodeCoordinatorI1 != nodeCoordinatorK0) {
            nodeCoordinatorI1.f1(rc4Var, z, false);
            if (rc4Var.f()) {
                return ha5.e;
            }
            nodeCoordinatorI1 = nodeCoordinatorI1.f0;
            nodeCoordinatorI1.getClass();
        }
        D0(nodeCoordinatorK0, rc4Var, z);
        return new ha5(rc4Var.b, rc4Var.c, rc4Var.d, rc4Var.e);
    }

    public final void I0(cj0 cj0Var, jp2 jp2Var) {
        NodeCoordinator nodeCoordinator;
        cj0 cj0Var2;
        jp2 jp2Var2;
        g94 g94VarP0 = P0(4);
        if (g94VarP0 == null) {
            d1(cj0Var, jp2Var);
            return;
        }
        LayoutNode layoutNode = this.d0;
        layoutNode.getClass();
        be3 sharedDrawScope = ce3.a(layoutNode).getSharedDrawScope();
        long jK = fq3.K(this.c);
        sharedDrawScope.getClass();
        dd4 dd4Var = null;
        while (g94VarP0 != null) {
            if (g94VarP0 instanceof st1) {
                nodeCoordinator = this;
                cj0Var2 = cj0Var;
                jp2Var2 = jp2Var;
                sharedDrawScope.b(cj0Var2, jK, nodeCoordinator, (st1) g94VarP0, jp2Var2);
            } else {
                nodeCoordinator = this;
                cj0Var2 = cj0Var;
                jp2Var2 = jp2Var;
                if ((g94VarP0.c & 4) != 0 && (g94VarP0 instanceof ln1)) {
                    int i = 0;
                    for (g94 g94Var = ((ln1) g94VarP0).e0; g94Var != null; g94Var = g94Var.f) {
                        if ((g94Var.c & 4) != 0) {
                            i++;
                            if (i == 1) {
                                g94VarP0 = g94Var;
                            } else {
                                if (dd4Var == null) {
                                    dd4Var = new dd4(new g94[16]);
                                }
                                if (g94VarP0 != null) {
                                    dd4Var.b(g94VarP0);
                                    g94VarP0 = null;
                                }
                                dd4Var.b(g94Var);
                            }
                        }
                    }
                    if (i == 1) {
                    }
                }
                cj0Var = cj0Var2;
                this = nodeCoordinator;
                jp2Var = jp2Var2;
            }
            g94VarP0 = ma3.f(dd4Var);
            cj0Var = cj0Var2;
            this = nodeCoordinator;
            jp2Var = jp2Var2;
        }
    }

    public abstract void J0();

    @Override // defpackage.nd3
    public final long K(long j) {
        if (!O0().c0) {
            p13.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        Y0();
        while (this != null) {
            j = this.j1(j);
            this = this.f0;
        }
        return j;
    }

    public final NodeCoordinator K0(NodeCoordinator nodeCoordinator) {
        LayoutNode layoutNodeX = nodeCoordinator.d0;
        LayoutNode layoutNode = this.d0;
        if (layoutNodeX == layoutNode) {
            g94 g94VarO0 = nodeCoordinator.O0();
            g94 g94VarO02 = O0();
            if (!g94VarO02.f2347a.c0) {
                p13.b("visitLocalAncestors called on an unattached node");
            }
            for (g94 g94Var = g94VarO02.f2347a.e; g94Var != null; g94Var = g94Var.e) {
                if ((g94Var.c & 2) != 0 && g94Var == g94VarO0) {
                    return nodeCoordinator;
                }
            }
            return this;
        }
        while (layoutNodeX.c0 > layoutNode.c0) {
            layoutNodeX = layoutNodeX.x();
            layoutNodeX.getClass();
        }
        LayoutNode layoutNodeX2 = layoutNode;
        while (layoutNodeX2.c0 > layoutNodeX.c0) {
            layoutNodeX2 = layoutNodeX2.x();
            layoutNodeX2.getClass();
        }
        while (layoutNodeX != layoutNodeX2) {
            layoutNodeX = layoutNodeX.x();
            layoutNodeX2 = layoutNodeX2.x();
            if (layoutNodeX == null || layoutNodeX2 == null) {
                g.l("layouts are not part of the same hierarchy");
                return null;
            }
        }
        if (layoutNodeX2 != layoutNode) {
            if (layoutNodeX != nodeCoordinator.d0) {
                return (a) layoutNodeX.s0.d;
            }
            return nodeCoordinator;
        }
        return this;
    }

    public final long L0(long j) {
        long j2 = this.o0;
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j >> 32)) - ((int) (j2 >> 32));
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask)) - ((int) (j2 & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32);
        co4 co4Var = this.x0;
        if (co4Var != null) {
            lp2 lp2Var = (lp2) co4Var;
            float[] fArrA = lp2Var.a();
            if (fArrA == null) {
                return 9187343241974906880L;
            }
            if (!lp2Var.h0) {
                return qs3.b(jFloatToRawIntBits, fArrA);
            }
        }
        return jFloatToRawIntBits;
    }

    public abstract ep3 M0();

    public final long N0() {
        return this.j0.j0(this.d0.n0.d());
    }

    public abstract g94 O0();

    public final g94 P0(int i) {
        boolean zG = fh4.g(i);
        g94 g94VarO0 = O0();
        if (!zG && (g94VarO0 = g94VarO0.e) == null) {
            return null;
        }
        for (g94 g94VarQ0 = Q0(zG); g94VarQ0 != null && (g94VarQ0.d & i) != 0; g94VarQ0 = g94VarQ0.f) {
            if ((g94VarQ0.c & i) != 0) {
                return g94VarQ0;
            }
            if (g94VarQ0 == g94VarO0) {
                return null;
            }
        }
        return null;
    }

    @Override // defpackage.co1
    public final float Q() {
        return this.d0.l0.Q();
    }

    public final g94 Q0(boolean z) {
        g94 g94VarO0;
        LayoutNode layoutNode = this.d0;
        if (layoutNode.getOuterCoordinator$ui_release() == this) {
            return (g94) layoutNode.s0.i;
        }
        NodeCoordinator nodeCoordinator = this.f0;
        if (!z) {
            if (nodeCoordinator != null) {
                return nodeCoordinator.O0();
            }
            return null;
        }
        if (nodeCoordinator == null || (g94VarO0 = nodeCoordinator.O0()) == null) {
            return null;
        }
        return g94VarO0.f;
    }

    public final void R0(g94 g94Var, bh4 bh4Var, long j, ru2 ru2Var, int i, boolean z) {
        if (g94Var == null) {
            U0(bh4Var, j, ru2Var, i, z);
            return;
        }
        int i2 = ru2Var.c;
        fc4 fc4Var = ru2Var.f5301a;
        ru2Var.b(i2 + 1, fc4Var.b);
        ru2Var.c++;
        fc4Var.a(g94Var);
        ru2Var.b.a(ma3.b(-1.0f, z, false));
        R0(ku7.g(g94Var, bh4Var.g()), bh4Var, j, ru2Var, i, z);
        ru2Var.c = i2;
    }

    public final void S0(g94 g94Var, bh4 bh4Var, long j, ru2 ru2Var, int i, boolean z, float f) {
        if (g94Var == null) {
            U0(bh4Var, j, ru2Var, i, z);
            return;
        }
        int i2 = ru2Var.c;
        fc4 fc4Var = ru2Var.f5301a;
        ru2Var.b(i2 + 1, fc4Var.b);
        ru2Var.c++;
        fc4Var.a(g94Var);
        ru2Var.b.a(ma3.b(f, z, false));
        c1(ku7.g(g94Var, bh4Var.g()), bh4Var, j, ru2Var, i, z, f, true);
        ru2Var.c = i2;
    }

    public final void T0(bh4 bh4Var, long j, ru2 ru2Var, int i, boolean z) {
        boolean z2;
        boolean z3;
        g94 g94VarP0 = P0(bh4Var.g());
        if (!p1(j)) {
            if (i == 1) {
                float fG0 = G0(j, N0());
                if ((Float.floatToRawIntBits(fG0) & jo.API_PRIORITY_OTHER) < 2139095040) {
                    if (ru2Var.c != ru2Var.f5301a.b - 1) {
                        if (bx7.l(ru2Var.a(), ma3.b(fG0, false, false)) <= 0) {
                            return;
                        }
                    }
                    S0(g94VarP0, bh4Var, j, ru2Var, i, false, fG0);
                    return;
                }
                return;
            }
            return;
        }
        if (g94VarP0 == null) {
            U0(bh4Var, j, ru2Var, i, z);
            return;
        }
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask));
        if (fIntBitsToFloat >= 0.0f && fIntBitsToFloat2 >= 0.0f && fIntBitsToFloat < Z() && fIntBitsToFloat2 < X()) {
            R0(g94VarP0, bh4Var, j, ru2Var, i, z);
            return;
        }
        float fG02 = i == 1 ? G0(j, N0()) : Float.POSITIVE_INFINITY;
        if ((Float.floatToRawIntBits(fG02) & jo.API_PRIORITY_OTHER) < 2139095040) {
            if (ru2Var.c != ru2Var.f5301a.b - 1) {
                z2 = z;
                if (bx7.l(ru2Var.a(), ma3.b(fG02, z2, false)) > 0) {
                }
                c1(g94VarP0, bh4Var, j, ru2Var, i, z2, fG02, z3);
            }
            z2 = z;
            z3 = true;
            c1(g94VarP0, bh4Var, j, ru2Var, i, z2, fG02, z3);
        }
        z2 = z;
        z3 = false;
        c1(g94VarP0, bh4Var, j, ru2Var, i, z2, fG02, z3);
    }

    public void U0(bh4 bh4Var, long j, ru2 ru2Var, int i, boolean z) {
        NodeCoordinator nodeCoordinator = this.e0;
        if (nodeCoordinator != null) {
            nodeCoordinator.T0(bh4Var, nodeCoordinator.L0(j), ru2Var, i, z);
        }
    }

    public final void V0() {
        co4 co4Var = this.x0;
        if (co4Var != null) {
            ((lp2) co4Var).c();
            return;
        }
        NodeCoordinator nodeCoordinator = this.f0;
        if (nodeCoordinator != null) {
            nodeCoordinator.V0();
        }
    }

    public final boolean W0() {
        if (this.x0 != null && this.l0 <= 0.0f) {
            return true;
        }
        NodeCoordinator nodeCoordinator = this.f0;
        if (nodeCoordinator != null) {
            return nodeCoordinator.W0();
        }
        return false;
    }

    public final long X0(nd3 nd3Var, long j) {
        if (nd3Var instanceof fp3) {
            fp3 fp3Var = (fp3) nd3Var;
            fp3Var.f2212a.d0.Y0();
            return fp3Var.b(this, j ^ (-9223372034707292160L)) ^ (-9223372034707292160L);
        }
        NodeCoordinator nodeCoordinatorI1 = i1(nd3Var);
        nodeCoordinatorI1.Y0();
        NodeCoordinator nodeCoordinatorK0 = K0(nodeCoordinatorI1);
        while (nodeCoordinatorI1 != nodeCoordinatorK0) {
            j = nodeCoordinatorI1.j1(j);
            nodeCoordinatorI1 = nodeCoordinatorI1.f0;
            nodeCoordinatorI1.getClass();
        }
        return E0(nodeCoordinatorK0, j);
    }

    public final void Y0() {
        this.d0.t0.b();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v13 */
    /* JADX WARN: Type inference failed for: r7v14 */
    /* JADX WARN: Type inference failed for: r7v15 */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v5, types: [g94] */
    /* JADX WARN: Type inference failed for: r7v7, types: [g94] */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r7v9, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v10 */
    /* JADX WARN: Type inference failed for: r8v11 */
    /* JADX WARN: Type inference failed for: r8v2, types: [dd4] */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v4 */
    /* JADX WARN: Type inference failed for: r8v5 */
    /* JADX WARN: Type inference failed for: r8v6, types: [dd4] */
    /* JADX WARN: Type inference failed for: r8v8 */
    /* JADX WARN: Type inference failed for: r8v9 */
    /* JADX WARN: Type inference failed for: r9v5 */
    public final void Z0() {
        g94 g94VarO0;
        boolean zG = fh4.g(128);
        g94 g94VarQ0 = Q0(zG);
        if (g94VarQ0 == null || (g94VarQ0.f2347a.d & 128) == 0) {
            return;
        }
        e36 e36VarO = bb1.o();
        Function1 function1E = e36VarO != null ? e36VarO.e() : null;
        e36 e36VarQ = bb1.q(e36VarO);
        try {
            if (!zG) {
                g94VarO0 = O0().e;
                if (g94VarO0 == null) {
                }
            }
            g94VarO0 = O0();
            for (g94 g94VarQ02 = Q0(zG); g94VarQ02 != null; g94VarQ02 = g94VarQ02.f) {
                if ((g94VarQ02.d & 128) == 0) {
                    break;
                }
                if ((g94VarQ02.c & 128) != 0) {
                    ?? F = g94VarQ02;
                    ?? dd4Var = 0;
                    while (F != 0) {
                        if (F instanceof ld3) {
                            ((ld3) F).o(this.c);
                        } else if ((F.c & 128) != 0 && (F instanceof ln1)) {
                            g94 g94Var = ((ln1) F).e0;
                            int i = 0;
                            F = F;
                            dd4Var = dd4Var;
                            while (g94Var != null) {
                                if ((g94Var.c & 128) != 0) {
                                    i++;
                                    dd4Var = dd4Var;
                                    if (i == 1) {
                                        F = g94Var;
                                    } else {
                                        if (dd4Var == 0) {
                                            dd4Var = new dd4(new g94[16]);
                                        }
                                        if (F != 0) {
                                            dd4Var.b(F);
                                            F = 0;
                                        }
                                        dd4Var.b(g94Var);
                                    }
                                }
                                g94Var = g94Var.f;
                                F = F;
                                dd4Var = dd4Var;
                            }
                            if (i == 1) {
                            }
                        }
                        F = ma3.f(dd4Var);
                    }
                }
                if (g94VarQ02 == g94VarO0) {
                    break;
                }
            }
        } finally {
            bb1.s(e36VarO, e36VarQ, function1E);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1, types: [g94] */
    /* JADX WARN: Type inference failed for: r4v10 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4, types: [g94] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r4v7 */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v3, types: [dd4] */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v6, types: [dd4] */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference failed for: r6v4 */
    public final void a1() {
        boolean zG = fh4.g(128);
        g94 g94VarO0 = O0();
        if (!zG && (g94VarO0 = g94VarO0.e) == null) {
            return;
        }
        for (g94 g94VarQ0 = Q0(zG); g94VarQ0 != null && (g94VarQ0.d & 128) != 0; g94VarQ0 = g94VarQ0.f) {
            if ((g94VarQ0.c & 128) != 0) {
                ?? F = g94VarQ0;
                ?? dd4Var = 0;
                while (F != 0) {
                    if (F instanceof ld3) {
                        ((ld3) F).k(this);
                    } else if ((F.c & 128) != 0 && (F instanceof ln1)) {
                        g94 g94Var = ((ln1) F).e0;
                        int i = 0;
                        F = F;
                        dd4Var = dd4Var;
                        while (g94Var != null) {
                            if ((g94Var.c & 128) != 0) {
                                i++;
                                dd4Var = dd4Var;
                                if (i == 1) {
                                    F = g94Var;
                                } else {
                                    if (dd4Var == 0) {
                                        dd4Var = new dd4(new g94[16]);
                                    }
                                    if (F != 0) {
                                        dd4Var.b(F);
                                        F = 0;
                                    }
                                    dd4Var.b(g94Var);
                                }
                            }
                            g94Var = g94Var.f;
                            F = F;
                            dd4Var = dd4Var;
                        }
                        if (i == 1) {
                        }
                    }
                    F = ma3.f(dd4Var);
                }
            }
            if (g94VarQ0 == g94VarO0) {
                return;
            }
        }
    }

    public final void b1() {
        this.g0 = true;
        this.v0.invoke();
        g1();
        if (u33.a(this.o0, 0L)) {
            return;
        }
        this.d0.R();
    }

    @Override // defpackage.nd3
    public final long c(long j) {
        long jK = K(j);
        AndroidComposeView androidComposeView = (AndroidComposeView) ce3.a(this.d0);
        androidComposeView.z();
        return qs3.b(jK, androidComposeView.J0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0189 A[PHI: r3
  0x0189: PHI (r3v17 ??) = (r3v1 ??), (r3v1 ??), (r3v19 ??) binds: [B:52:0x0155, B:54:0x0159, B:68:0x0183] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1, types: [g94] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v20 */
    /* JADX WARN: Type inference failed for: r2v21 */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v5, types: [g94] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v17, types: [dd4] */
    /* JADX WARN: Type inference failed for: r3v18 */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21, types: [dd4] */
    /* JADX WARN: Type inference failed for: r3v27 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29 */
    /* JADX WARN: Type inference failed for: r3v30 */
    /* JADX WARN: Type inference failed for: r3v31 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c1(defpackage.g94 r18, defpackage.bh4 r19, long r20, defpackage.ru2 r22, int r23, boolean r24, float r25, boolean r26) {
        /*
            Method dump skipped, instruction units count: 635
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.node.NodeCoordinator.c1(g94, bh4, long, ru2, int, boolean, float, boolean):void");
    }

    public abstract void d1(cj0 cj0Var, jp2 jp2Var);

    public final void e1(long j, float f, Function1 function1) {
        n1(function1, false);
        boolean zA = u33.a(this.o0, j);
        LayoutNode layoutNode = this.d0;
        if (!zA) {
            ((AndroidComposeView) ce3.a(layoutNode)).I(-4.0f);
            this.o0 = j;
            layoutNode.t0.p.q0();
            co4 co4Var = this.x0;
            if (co4Var != null) {
                ((lp2) co4Var).d(j);
            } else {
                NodeCoordinator nodeCoordinator = this.f0;
                if (nodeCoordinator != null) {
                    nodeCoordinator.V0();
                }
            }
            layoutNode.R();
            cp3.A0(this);
            do4 do4Var = layoutNode.b0;
            if (do4Var != null) {
                ((AndroidComposeView) do4Var).v(layoutNode);
            }
        }
        this.p0 = f;
        if (!this.Y) {
            q0(w0());
        }
        if (this == layoutNode.getOuterCoordinator$ui_release()) {
            ce3.a(layoutNode).getRectManager().g(layoutNode, !layoutNode.t0.p.Y);
        }
    }

    public final void f1(rc4 rc4Var, boolean z, boolean z2) {
        co4 co4Var = this.x0;
        if (co4Var != null) {
            if (this.h0) {
                if (z2) {
                    long jN0 = N0();
                    float fIntBitsToFloat = Float.intBitsToFloat((int) (jN0 >> 32)) / 2.0f;
                    float fIntBitsToFloat2 = Float.intBitsToFloat((int) (jN0 & KeyboardMap.kValueMask)) / 2.0f;
                    long j = this.c;
                    rc4Var.e(-fIntBitsToFloat, -fIntBitsToFloat2, ((int) (j >> 32)) + fIntBitsToFloat, ((int) (j & KeyboardMap.kValueMask)) + fIntBitsToFloat2);
                } else if (z) {
                    long j2 = this.c;
                    rc4Var.e(0.0f, 0.0f, (int) (j2 >> 32), (int) (j2 & KeyboardMap.kValueMask));
                }
                if (rc4Var.f()) {
                    return;
                }
            }
            lp2 lp2Var = (lp2) co4Var;
            float[] fArrB = lp2Var.b();
            if (!lp2Var.h0) {
                if (fArrB == null) {
                    rc4Var.b = 0.0f;
                    rc4Var.c = 0.0f;
                    rc4Var.d = 0.0f;
                    rc4Var.e = 0.0f;
                } else {
                    qs3.c(fArrB, rc4Var);
                }
            }
        }
        long j3 = this.o0;
        float f = (int) (j3 >> 32);
        rc4Var.b += f;
        rc4Var.d += f;
        float f2 = (int) (j3 & KeyboardMap.kValueMask);
        rc4Var.c += f2;
        rc4Var.e += f2;
    }

    @Override // defpackage.nd3
    public final boolean g() {
        return O0().c0;
    }

    public final void g1() {
        if (this.x0 != null) {
            n1(null, false);
            this.d0.a0(false);
        }
    }

    @Override // defpackage.co1
    public final float getDensity() {
        return this.d0.l0.getDensity();
    }

    @Override // defpackage.a53
    public final od3 getLayoutDirection() {
        return this.d0.m0;
    }

    @Override // defpackage.nd3
    public final void h(float[] fArr) {
        do4 do4VarA = ce3.a(this.d0);
        NodeCoordinator nodeCoordinatorI1 = i1(ma3.q(this));
        m1(nodeCoordinatorI1, fArr);
        if (do4VarA instanceof AndroidComposeView) {
            ((AndroidComposeView) do4VarA).q(fArr);
            return;
        }
        long jO = nodeCoordinatorI1.o(0L);
        if ((9223372034707292159L & jO) != 9205357640488583168L) {
            qs3.f(fArr, Float.intBitsToFloat((int) (jO >> 32)), Float.intBitsToFloat((int) (jO & KeyboardMap.kValueMask)));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v5 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1, types: [g94] */
    /* JADX WARN: Type inference failed for: r8v12 */
    /* JADX WARN: Type inference failed for: r8v13 */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v4, types: [g94] */
    /* JADX WARN: Type inference failed for: r8v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v6 */
    /* JADX WARN: Type inference failed for: r8v7 */
    /* JADX WARN: Type inference failed for: r8v8 */
    /* JADX WARN: Type inference failed for: r8v9 */
    /* JADX WARN: Type inference failed for: r9v13 */
    /* JADX WARN: Type inference failed for: r9v14 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v3 */
    /* JADX WARN: Type inference failed for: r9v4 */
    /* JADX WARN: Type inference failed for: r9v5, types: [dd4] */
    /* JADX WARN: Type inference failed for: r9v6 */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8, types: [dd4] */
    public final void h1(at3 at3Var) {
        NodeCoordinator nodeCoordinator;
        at3 at3Var2 = this.m0;
        if (at3Var != at3Var2) {
            this.m0 = at3Var;
            LayoutNode layoutNode = this.d0;
            int i = 0;
            if (at3Var2 == null || at3Var.getWidth() != at3Var2.getWidth() || at3Var.getHeight() != at3Var2.getHeight()) {
                int width = at3Var.getWidth();
                int height = at3Var.getHeight();
                co4 co4Var = this.x0;
                if (co4Var != null) {
                    ((lp2) co4Var).e((((long) width) << 32) | (((long) height) & KeyboardMap.kValueMask));
                } else if (layoutNode.M() && (nodeCoordinator = this.f0) != null) {
                    nodeCoordinator.V0();
                }
                f0((((long) height) & KeyboardMap.kValueMask) | (((long) width) << 32));
                if (this.i0 != null) {
                    o1(false);
                }
                boolean zG = fh4.g(4);
                g94 g94VarO0 = O0();
                if (zG || (g94VarO0 = g94VarO0.e) != null) {
                    for (g94 g94VarQ0 = Q0(zG); g94VarQ0 != null && (g94VarQ0.d & 4) != 0; g94VarQ0 = g94VarQ0.f) {
                        if ((g94VarQ0.c & 4) != 0) {
                            ?? F = g94VarQ0;
                            ?? dd4Var = 0;
                            while (F != 0) {
                                if (F instanceof st1) {
                                    ((st1) F).H();
                                } else if ((F.c & 4) != 0 && (F instanceof ln1)) {
                                    g94 g94Var = ((ln1) F).e0;
                                    int i2 = 0;
                                    F = F;
                                    dd4Var = dd4Var;
                                    while (g94Var != null) {
                                        if ((g94Var.c & 4) != 0) {
                                            i2++;
                                            dd4Var = dd4Var;
                                            if (i2 == 1) {
                                                F = g94Var;
                                            } else {
                                                if (dd4Var == 0) {
                                                    dd4Var = new dd4(new g94[16]);
                                                }
                                                if (F != 0) {
                                                    dd4Var.b(F);
                                                    F = 0;
                                                }
                                                dd4Var.b(g94Var);
                                            }
                                        }
                                        g94Var = g94Var.f;
                                        F = F;
                                        dd4Var = dd4Var;
                                    }
                                    if (i2 == 1) {
                                    }
                                }
                                F = ma3.f(dd4Var);
                            }
                        }
                        if (g94VarQ0 == g94VarO0) {
                            break;
                        }
                    }
                }
                do4 do4Var = layoutNode.b0;
                if (do4Var != null) {
                    ((AndroidComposeView) do4Var).v(layoutNode);
                }
            }
            ac4 ac4Var = this.n0;
            if ((ac4Var == null || ac4Var.e == 0) && at3Var.a().isEmpty()) {
                return;
            }
            ac4 ac4Var2 = this.n0;
            Map mapA = at3Var.a();
            if (ac4Var2 != null && ac4Var2.e == mapA.size()) {
                Object[] objArr = ac4Var2.b;
                int[] iArr = ac4Var2.c;
                long[] jArr = ac4Var2.f77a;
                int length = jArr.length - 2;
                if (length < 0) {
                    return;
                }
                int i3 = 0;
                loop0: while (true) {
                    long j = jArr[i3];
                    if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i4 = 8 - ((~(i3 - length)) >>> 31);
                        for (int i5 = i; i5 < i4; i5++) {
                            if ((255 & j) < 128) {
                                int i6 = (i3 << 3) + i5;
                                Object obj = objArr[i6];
                                int i7 = iArr[i6];
                                Integer num = (Integer) mapA.get((hc) obj);
                                if (num == null || num.intValue() != i7) {
                                    break loop0;
                                }
                            }
                            j >>= 8;
                        }
                        if (i4 != 8) {
                            return;
                        }
                    }
                    if (i3 == length) {
                        return;
                    }
                    i3++;
                    i = 0;
                }
            }
            layoutNode.t0.p.m0.f();
            ac4 ac4Var3 = this.n0;
            if (ac4Var3 == null) {
                ac4 ac4Var4 = sj4.f5463a;
                ac4Var3 = new ac4();
                this.n0 = ac4Var3;
            }
            ac4Var3.a();
            for (Map.Entry entry : at3Var.a().entrySet()) {
                ac4Var3.h(((Number) entry.getValue()).intValue(), entry.getKey());
            }
        }
    }

    @Override // defpackage.nd3
    public final void j(nd3 nd3Var, float[] fArr) {
        NodeCoordinator nodeCoordinatorI1 = i1(nd3Var);
        nodeCoordinatorI1.Y0();
        NodeCoordinator nodeCoordinatorK0 = K0(nodeCoordinatorI1);
        qs3.d(fArr);
        nodeCoordinatorI1.m1(nodeCoordinatorK0, fArr);
        l1(nodeCoordinatorK0, fArr);
    }

    public final long j1(long j) {
        co4 co4Var = this.x0;
        if (co4Var != null) {
            lp2 lp2Var = (lp2) co4Var;
            float[] fArrB = lp2Var.b();
            if (!lp2Var.h0) {
                j = qs3.b(j, fArrB);
            }
        }
        long j2 = this.o0;
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j >> 32)) + ((int) (j2 >> 32));
        return (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask)) + ((int) (j2 & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32);
    }

    @Override // defpackage.nd3
    public final long k() {
        return this.c;
    }

    public final ha5 k1() {
        if (O0().c0) {
            nd3 nd3VarQ = ma3.q(this);
            rc4 rc4Var = this.q0;
            if (rc4Var == null) {
                rc4Var = new rc4();
                this.q0 = rc4Var;
            }
            long jF0 = F0(N0());
            int i = (int) (jF0 >> 32);
            rc4Var.b = -Float.intBitsToFloat(i);
            int i2 = (int) (jF0 & KeyboardMap.kValueMask);
            rc4Var.c = -Float.intBitsToFloat(i2);
            rc4Var.d = Float.intBitsToFloat(i) + Z();
            rc4Var.e = Float.intBitsToFloat(i2) + X();
            while (this != nd3VarQ) {
                this.f1(rc4Var, false, true);
                if (!rc4Var.f()) {
                    this = this.f0;
                    this.getClass();
                }
            }
            return new ha5(rc4Var.b, rc4Var.c, rc4Var.d, rc4Var.e);
        }
        return ha5.e;
    }

    public final void l1(NodeCoordinator nodeCoordinator, float[] fArr) {
        float[] fArrA;
        if (Intrinsics.a(nodeCoordinator, this)) {
            return;
        }
        NodeCoordinator nodeCoordinator2 = this.f0;
        nodeCoordinator2.getClass();
        nodeCoordinator2.l1(nodeCoordinator, fArr);
        if (!u33.a(this.o0, 0L)) {
            float[] fArr2 = A0;
            qs3.d(fArr2);
            long j = this.o0;
            qs3.f(fArr2, -((int) (j >> 32)), -((int) (j & KeyboardMap.kValueMask)));
            qs3.e(fArr, fArr2);
        }
        co4 co4Var = this.x0;
        if (co4Var == null || (fArrA = ((lp2) co4Var).a()) == null) {
            return;
        }
        qs3.e(fArr, fArrA);
    }

    public final void m1(NodeCoordinator nodeCoordinator, float[] fArr) {
        while (!this.equals(nodeCoordinator)) {
            co4 co4Var = this.x0;
            if (co4Var != null) {
                qs3.e(fArr, ((lp2) co4Var).b());
            }
            if (!u33.a(this.o0, 0L)) {
                float[] fArr2 = A0;
                qs3.d(fArr2);
                qs3.f(fArr2, (int) (r0 >> 32), (int) (r0 & KeyboardMap.kValueMask));
                qs3.e(fArr, fArr2);
            }
            this = this.f0;
            this.getClass();
        }
    }

    public final void n1(Function1 function1, boolean z) {
        do4 do4Var;
        dd4 dd4Var;
        Reference referencePoll;
        fh fhVar;
        dd4 dd4Var2;
        Reference referencePoll2;
        Object obj;
        int i = 0;
        LayoutNode layoutNode = this.d0;
        boolean z2 = (!z && this.i0 == function1 && Intrinsics.a(this.j0, layoutNode.l0) && this.k0 == layoutNode.m0) ? false : true;
        this.j0 = layoutNode.l0;
        this.k0 = layoutNode.m0;
        boolean zL = layoutNode.L();
        ch4 ch4Var = this.v0;
        if (!zL || function1 == null) {
            this.i0 = null;
            co4 co4Var = this.x0;
            if (co4Var != null) {
                lp2 lp2Var = (lp2) co4Var;
                if (!fq3.t(lp2Var.b())) {
                    layoutNode.R();
                }
                lp2Var.d = null;
                lp2Var.e = null;
                lp2Var.i = true;
                lp2Var.f(false);
                ip2 ip2Var = lp2Var.b;
                if (ip2Var != null) {
                    ip2Var.a(lp2Var.f3971a);
                    AndroidComposeView androidComposeView = lp2Var.c;
                    dd7 dd7Var = androidComposeView.i1;
                    do {
                        ReferenceQueue referenceQueue = (ReferenceQueue) dd7Var.c;
                        dd4Var = (dd4) dd7Var.b;
                        referencePoll = referenceQueue.poll();
                        if (referencePoll != null) {
                            dd4Var.j(referencePoll);
                        }
                    } while (referencePoll != null);
                    dd4Var.b(new WeakReference(lp2Var, (ReferenceQueue) dd7Var.c));
                    androidComposeView.p0.remove(lp2Var);
                }
                layoutNode.w0 = true;
                ch4Var.invoke();
                if (O0().c0 && layoutNode.M() && (do4Var = layoutNode.b0) != null) {
                    ((AndroidComposeView) do4Var).v(layoutNode);
                }
            }
            this.x0 = null;
            this.w0 = false;
            return;
        }
        this.i0 = function1;
        if (this.x0 != null) {
            if (z2 && o1(true)) {
                layoutNode.R();
                ce3.a(layoutNode).getRectManager().f(layoutNode);
                return;
            }
            return;
        }
        do4 do4VarA = ce3.a(layoutNode);
        fh fhVar2 = this.u0;
        if (fhVar2 == null) {
            fh fhVar3 = new fh(4, this, new ch4(this, i));
            this.u0 = fhVar3;
            fhVar = fhVar3;
        } else {
            fhVar = fhVar2;
        }
        AndroidComposeView androidComposeView2 = (AndroidComposeView) do4VarA;
        dd7 dd7Var2 = androidComposeView2.i1;
        do {
            ReferenceQueue referenceQueue2 = (ReferenceQueue) dd7Var2.c;
            dd4Var2 = (dd4) dd7Var2.b;
            referencePoll2 = referenceQueue2.poll();
            if (referencePoll2 != null) {
                dd4Var2.j(referencePoll2);
            }
        } while (referencePoll2 != null);
        while (true) {
            int i2 = dd4Var2.c;
            if (i2 == 0) {
                obj = null;
                break;
            } else {
                obj = ((Reference) dd4Var2.k(i2 - 1)).get();
                if (obj != null) {
                    break;
                }
            }
        }
        co4 lp2Var2 = (co4) obj;
        if (lp2Var2 != null) {
            lp2 lp2Var3 = (lp2) lp2Var2;
            ip2 ip2Var2 = lp2Var3.b;
            if (ip2Var2 == null) {
                throw qe0.f("currently reuse is only supported when we manage the layer lifecycle");
            }
            if (!lp2Var3.f3971a.s) {
                p13.a("layer should have been released before reuse");
            }
            lp2Var3.f3971a = ip2Var2.b();
            lp2Var3.i = false;
            lp2Var3.d = fhVar;
            lp2Var3.e = ch4Var;
            lp2Var3.f0 = false;
            lp2Var3.g0 = false;
            lp2Var3.h0 = true;
            qs3.d(lp2Var3.v);
            float[] fArr = lp2Var3.w;
            if (fArr != null) {
                qs3.d(fArr);
            }
            lp2Var3.d0 = yo6.f6785a;
            lp2Var3.i0 = false;
            lp2Var3.f = 9223372034707292159L;
            lp2Var3.e0 = null;
            lp2Var3.c0 = 0;
        } else {
            lp2Var2 = new lp2(androidComposeView2.getGraphicsContext().b(), androidComposeView2.getGraphicsContext(), androidComposeView2, fhVar, ch4Var);
        }
        lp2 lp2Var4 = (lp2) lp2Var2;
        lp2Var4.e(this.c);
        lp2Var4.d(this.o0);
        this.x0 = lp2Var2;
        o1(true);
        layoutNode.w0 = true;
        ch4Var.invoke();
    }

    @Override // defpackage.nd3
    public final long o(long j) {
        if (!O0().c0) {
            p13.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        return ((AndroidComposeView) ce3.a(this.d0)).r(K(j));
    }

    public final boolean o1(boolean z) {
        LayoutNode layoutNode;
        long j;
        boolean z2;
        do4 do4Var;
        Function0 function0;
        Function0 function02;
        co4 co4Var = this.x0;
        Function1 function1 = this.i0;
        if (co4Var == null) {
            if (function1 == null) {
                return false;
            }
            p13.b("null layer with a non-null layerBlock");
            return false;
        }
        if (function1 == null) {
            throw qe0.f("updateLayerParameters requires a non-null layerBlock");
        }
        cg5 cg5Var = y0;
        cg5Var.e(1.0f);
        cg5Var.f(1.0f);
        cg5Var.a(1.0f);
        cg5Var.g(0.0f);
        long j2 = mp2.f4203a;
        cg5Var.b(j2);
        cg5Var.j(j2);
        if (cg5Var.v != 8.0f) {
            cg5Var.f807a |= 2048;
            cg5Var.v = 8.0f;
        }
        long j3 = yo6.f6785a;
        cg5Var.k(j3);
        cg5Var.h(ma3.o);
        cg5Var.c(false);
        if (cg5Var.d0 != 3) {
            cg5Var.f807a |= 524288;
            cg5Var.d0 = 3;
        }
        cg5Var.Z = 9205357640488583168L;
        cg5Var.e0 = null;
        cg5Var.f807a = 0;
        LayoutNode layoutNode2 = this.d0;
        cg5Var.b0 = layoutNode2.l0;
        cg5Var.c0 = layoutNode2.m0;
        cg5Var.Z = fq3.K(this.c);
        ce3.a(layoutNode2).getSnapshotObserver().a(this, ah4.c, new ui(function1, 15));
        kd3 kd3Var = this.r0;
        if (kd3Var == null) {
            kd3Var = new kd3();
            this.r0 = kd3Var;
        }
        kd3 kd3Var2 = z0;
        kd3Var2.getClass();
        kd3Var2.f3690a = kd3Var.f3690a;
        kd3Var2.b = kd3Var.b;
        kd3Var2.c = kd3Var.c;
        kd3Var2.d = kd3Var.d;
        float f = cg5Var.b;
        kd3Var.f3690a = f;
        kd3Var.b = cg5Var.c;
        kd3Var.c = cg5Var.v;
        long j4 = cg5Var.w;
        kd3Var.d = j4;
        lp2 lp2Var = (lp2) co4Var;
        AndroidComposeView androidComposeView = lp2Var.c;
        int i = cg5Var.f807a | lp2Var.c0;
        lp2Var.Z = cg5Var.c0;
        lp2Var.Y = cg5Var.b0;
        int i2 = i & 4096;
        if (i2 != 0) {
            lp2Var.d0 = j4;
        }
        if ((i & 1) != 0) {
            kp2 kp2Var = lp2Var.f3971a.f3547a;
            if (kp2Var.c() != f) {
                kp2Var.y(f);
            }
        }
        if ((i & 2) != 0) {
            jp2 jp2Var = lp2Var.f3971a;
            float f2 = cg5Var.c;
            kp2 kp2Var2 = jp2Var.f3547a;
            if (kp2Var2.M() != f2) {
                kp2Var2.k(f2);
            }
        }
        if ((i & 4) != 0) {
            jp2 jp2Var2 = lp2Var.f3971a;
            float f3 = cg5Var.d;
            kp2 kp2Var3 = jp2Var2.f3547a;
            if (kp2Var3.b() != f3) {
                kp2Var3.r(f3);
            }
        }
        if ((i & 8) != 0) {
            kp2 kp2Var4 = lp2Var.f3971a.f3547a;
            if (kp2Var4.B() != 0.0f) {
                kp2Var4.C();
            }
        }
        if ((i & 16) != 0) {
            kp2 kp2Var5 = lp2Var.f3971a.f3547a;
            if (kp2Var5.s() != 0.0f) {
                kp2Var5.t();
            }
        }
        if ((i & 32) != 0) {
            jp2 jp2Var3 = lp2Var.f3971a;
            float f4 = cg5Var.e;
            kp2 kp2Var6 = jp2Var3.f3547a;
            if (kp2Var6.L() != f4) {
                kp2Var6.d(f4);
                jp2Var3.g = true;
                jp2Var3.a();
            }
            if (cg5Var.e > 0.0f && !lp2Var.i0 && (function02 = lp2Var.e) != null) {
                function02.invoke();
            }
        }
        if ((i & 64) != 0) {
            jp2 jp2Var4 = lp2Var.f3971a;
            long j5 = cg5Var.f;
            kp2 kp2Var7 = jp2Var4.f3547a;
            layoutNode = layoutNode2;
            if (!zr0.c(j5, kp2Var7.p())) {
                kp2Var7.w(j5);
            }
        } else {
            layoutNode = layoutNode2;
        }
        if ((i & 128) != 0) {
            jp2 jp2Var5 = lp2Var.f3971a;
            long j6 = cg5Var.i;
            kp2 kp2Var8 = jp2Var5.f3547a;
            if (!zr0.c(j6, kp2Var8.v())) {
                kp2Var8.I(j6);
            }
        }
        if ((i & Segment.SHARE_MINIMUM) != 0) {
            kp2 kp2Var9 = lp2Var.f3971a.f3547a;
            if (kp2Var9.n() != 0.0f) {
                kp2Var9.H();
            }
        }
        if ((i & NotificationCompat.FLAG_LOCAL_ONLY) != 0) {
            kp2 kp2Var10 = lp2Var.f3971a.f3547a;
            if (kp2Var10.E() != 0.0f) {
                kp2Var10.q();
            }
        }
        if ((i & NotificationCompat.FLAG_GROUP_SUMMARY) != 0) {
            kp2 kp2Var11 = lp2Var.f3971a.f3547a;
            if (kp2Var11.l() != 0.0f) {
                kp2Var11.u();
            }
        }
        if ((i & 2048) != 0) {
            jp2 jp2Var6 = lp2Var.f3971a;
            float f5 = cg5Var.v;
            kp2 kp2Var12 = jp2Var6.f3547a;
            if (kp2Var12.z() != f5) {
                kp2Var12.K(f5);
            }
        }
        if (i2 != 0) {
            long j7 = lp2Var.d0;
            boolean z3 = j7 == j3;
            jp2 jp2Var7 = lp2Var.f3971a;
            if (z3) {
                long j8 = jp2Var7.v;
                j = KeyboardMap.kValueMask;
                if (!yj4.c(j8, 9205357640488583168L)) {
                    jp2Var7.v = 9205357640488583168L;
                    jp2Var7.f3547a.o(9205357640488583168L);
                }
            } else {
                j = KeyboardMap.kValueMask;
                long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j7 >> 32)) * ((int) (lp2Var.f >> 32)))) << 32) | (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (lp2Var.d0 & KeyboardMap.kValueMask)) * ((int) (lp2Var.f & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask);
                if (!yj4.c(jp2Var7.v, jFloatToRawIntBits)) {
                    jp2Var7.v = jFloatToRawIntBits;
                    jp2Var7.f3547a.o(jFloatToRawIntBits);
                }
            }
        } else {
            j = KeyboardMap.kValueMask;
        }
        if ((i & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
            jp2 jp2Var8 = lp2Var.f3971a;
            boolean z4 = cg5Var.Y;
            if (jp2Var8.w != z4) {
                jp2Var8.w = z4;
                jp2Var8.g = true;
                jp2Var8.a();
            }
        }
        if ((131072 & i) != 0) {
            kp2 kp2Var13 = lp2Var.f3971a.f3547a;
        }
        if ((262144 & i) != 0) {
            kp2 kp2Var14 = lp2Var.f3971a.f3547a;
            if (!Intrinsics.a(kp2Var14.j(), null)) {
                kp2Var14.x();
            }
        }
        if ((i & 524288) != 0) {
            jp2 jp2Var9 = lp2Var.f3971a;
            int i3 = cg5Var.d0;
            kp2 kp2Var15 = jp2Var9.f3547a;
            if (kp2Var15.N() != i3) {
                kp2Var15.f(i3);
            }
        }
        if ((32768 & i) != 0) {
            kp2 kp2Var16 = lp2Var.f3971a.f3547a;
            if (kp2Var16.i() != 0) {
                kp2Var16.G(0);
            }
        }
        if ((i & 7963) != 0) {
            lp2Var.f0 = true;
            lp2Var.g0 = true;
        }
        if (Intrinsics.a(lp2Var.e0, cg5Var.e0)) {
            z2 = false;
        } else {
            gq3 gq3Var = cg5Var.e0;
            lp2Var.e0 = gq3Var;
            if (gq3Var != null) {
                jp2 jp2Var10 = lp2Var.f3971a;
                if (gq3Var instanceof on4) {
                    ha5 ha5Var = ((on4) gq3Var).j;
                    float f6 = ha5Var.f2578a;
                    float f7 = ha5Var.b;
                    jp2Var10.f(0.0f, (((long) Float.floatToRawIntBits(f6)) << 32) | (((long) Float.floatToRawIntBits(f7)) & j), (((long) Float.floatToRawIntBits(ha5Var.c - f6)) << 32) | (((long) Float.floatToRawIntBits(ha5Var.d - f7)) & j));
                } else if (gq3Var instanceof nn4) {
                    tj tjVar = ((nn4) gq3Var).j;
                    jp2Var10.k = null;
                    jp2Var10.i = 9205357640488583168L;
                    jp2Var10.h = 0L;
                    jp2Var10.j = 0.0f;
                    jp2Var10.g = true;
                    jp2Var10.n = false;
                    jp2Var10.l = tjVar;
                    jp2Var10.a();
                } else {
                    if (!(gq3Var instanceof pn4)) {
                        g.a();
                        return false;
                    }
                    pn4 pn4Var = (pn4) gq3Var;
                    tj tjVar2 = pn4Var.k;
                    if (tjVar2 != null) {
                        jp2Var10.k = null;
                        jp2Var10.i = 9205357640488583168L;
                        jp2Var10.h = 0L;
                        jp2Var10.j = 0.0f;
                        jp2Var10.g = true;
                        jp2Var10.n = false;
                        jp2Var10.l = tjVar2;
                        jp2Var10.a();
                    } else {
                        fh5 fh5Var = pn4Var.j;
                        float f8 = fh5Var.b;
                        float f9 = fh5Var.f2163a;
                        jp2Var10.f(Float.intBitsToFloat((int) (fh5Var.h >> 32)), (((long) Float.floatToRawIntBits(f9)) << 32) | (((long) Float.floatToRawIntBits(f8)) & j), (((long) Float.floatToRawIntBits(fh5Var.c - f9)) << 32) | (((long) Float.floatToRawIntBits(fh5Var.d - f8)) & j));
                    }
                }
                if ((gq3Var instanceof nn4) && Build.VERSION.SDK_INT < 33 && (function0 = lp2Var.e) != null) {
                    function0.invoke();
                }
            }
            z2 = true;
        }
        lp2Var.c0 = cg5Var.f807a;
        if (i != 0 || z2) {
            if (Build.VERSION.SDK_INT >= 26) {
                ViewParent parent = androidComposeView.getParent();
                if (parent != null) {
                    parent.onDescendantInvalidated(androidComposeView, androidComposeView);
                }
            } else {
                androidComposeView.invalidate();
            }
            if (androidComposeView.f) {
                androidComposeView.I(0.0f);
            }
        }
        boolean z5 = this.h0;
        boolean z6 = cg5Var.Y;
        this.h0 = z6;
        this.l0 = cg5Var.d;
        boolean z7 = kd3Var2.f3690a == kd3Var.f3690a && kd3Var2.b == kd3Var.b && kd3Var2.c == kd3Var.c && kd3Var2.d == kd3Var.d;
        boolean z8 = !z7;
        if (z && ((!z7 || z5 != z6) && (do4Var = layoutNode.b0) != null)) {
            ((AndroidComposeView) do4Var).v(layoutNode);
        }
        return z8;
    }

    /* JADX WARN: Removed duplicated region for block: B:62:0x017d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean p1(long r24) {
        /*
            Method dump skipped, instruction units count: 435
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.node.NodeCoordinator.p1(long):boolean");
    }

    @Override // defpackage.eo4
    public final boolean r() {
        return (this.x0 == null || this.g0 || !this.d0.L()) ? false : true;
    }

    @Override // defpackage.cp3
    public final cp3 r0() {
        return this.e0;
    }

    @Override // defpackage.cp3
    public final nd3 t0() {
        return this;
    }

    @Override // defpackage.cp3
    public final boolean u0() {
        return this.m0 != null;
    }

    @Override // defpackage.nd3
    public final long v(long j) {
        if (!O0().c0) {
            p13.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        nd3 nd3VarQ = ma3.q(this);
        AndroidComposeView androidComposeView = (AndroidComposeView) ce3.a(this.d0);
        androidComposeView.z();
        return X0(nd3VarQ, yj4.e(qs3.b(j, androidComposeView.K0), nd3VarQ.K(0L)));
    }

    @Override // defpackage.cp3
    public final LayoutNode v0() {
        return this.d0;
    }

    @Override // defpackage.cp3
    public final at3 w0() {
        at3 at3Var = this.m0;
        if (at3Var != null) {
            return at3Var;
        }
        vk5.k("Asking for measurement result of unmeasured layout modifier");
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v5, types: [g94] */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r1v9, types: [g94] */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v10 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v3, types: [dd4] */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6, types: [dd4] */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r5v5 */
    @Override // defpackage.tu4, defpackage.us3
    public final Object x() {
        LayoutNode layoutNode = this.d0;
        if (!layoutNode.s0.j(64)) {
            return null;
        }
        O0();
        pb5 pb5Var = new pb5();
        for (g94 g94Var = (lf6) layoutNode.s0.f; g94Var != null; g94Var = g94Var.e) {
            if ((g94Var.c & 64) != 0) {
                ?? F = g94Var;
                ?? dd4Var = 0;
                while (F != 0) {
                    if (F instanceof wq4) {
                        pb5Var.f4783a = ((wq4) F).r0(pb5Var.f4783a);
                    } else if ((F.c & 64) != 0 && (F instanceof ln1)) {
                        g94 g94Var2 = ((ln1) F).e0;
                        int i = 0;
                        F = F;
                        dd4Var = dd4Var;
                        while (g94Var2 != null) {
                            if ((g94Var2.c & 64) != 0) {
                                i++;
                                dd4Var = dd4Var;
                                if (i == 1) {
                                    F = g94Var2;
                                } else {
                                    if (dd4Var == 0) {
                                        dd4Var = new dd4(new g94[16]);
                                    }
                                    if (F != 0) {
                                        dd4Var.b(F);
                                        F = 0;
                                    }
                                    dd4Var.b(g94Var2);
                                }
                            }
                            g94Var2 = g94Var2.f;
                            F = F;
                            dd4Var = dd4Var;
                        }
                        if (i == 1) {
                        }
                    }
                    F = ma3.f(dd4Var);
                }
            }
        }
        return pb5Var.f4783a;
    }

    @Override // defpackage.cp3
    public final cp3 x0() {
        return this.f0;
    }

    @Override // defpackage.cp3
    public final long y0() {
        return this.o0;
    }

    @Override // defpackage.nd3
    public final nd3 z() {
        if (!O0().c0) {
            p13.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        Y0();
        return this.d0.getOuterCoordinator$ui_release().f0;
    }
}

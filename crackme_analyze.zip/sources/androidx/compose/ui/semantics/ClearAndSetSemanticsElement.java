package androidx.compose.ui.semantics;

import defpackage.g94;
import defpackage.p94;
import defpackage.rr5;
import defpackage.sr5;
import defpackage.yc1;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003¨\u0006\u0004"}, d2 = {"Landroidx/compose/ui/semantics/ClearAndSetSemanticsElement;", "Lp94;", "Lyc1;", "Lsr5;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ClearAndSetSemanticsElement extends p94 implements sr5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function1 f301a;

    public ClearAndSetSemanticsElement(Function1 function1) {
        this.f301a = function1;
    }

    @Override // defpackage.sr5
    public final rr5 e() {
        rr5 rr5Var = new rr5();
        rr5Var.c = false;
        rr5Var.d = true;
        this.f301a.invoke(rr5Var);
        return rr5Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof ClearAndSetSemanticsElement) {
            return this.f301a == ((ClearAndSetSemanticsElement) obj).f301a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new yc1(false, true, this.f301a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((yc1) g94Var).f0 = this.f301a;
    }

    public final int hashCode() {
        return this.f301a.hashCode();
    }
}

package androidx.compose.ui.semantics;

import defpackage.g94;
import defpackage.p94;
import defpackage.rr5;
import defpackage.sr5;
import defpackage.yc1;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003¨\u0006\u0004"}, d2 = {"Landroidx/compose/ui/semantics/AppendedSemanticsElement;", "Lp94;", "Lyc1;", "Lsr5;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class AppendedSemanticsElement extends p94 implements sr5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f300a;
    public final Function1 b;

    public AppendedSemanticsElement(Function1 function1, boolean z) {
        this.f300a = z;
        this.b = function1;
    }

    @Override // defpackage.sr5
    public final rr5 e() {
        rr5 rr5Var = new rr5();
        rr5Var.c = this.f300a;
        this.b.invoke(rr5Var);
        return rr5Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AppendedSemanticsElement)) {
            return false;
        }
        AppendedSemanticsElement appendedSemanticsElement = (AppendedSemanticsElement) obj;
        return this.f300a == appendedSemanticsElement.f300a && this.b == appendedSemanticsElement.b;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new yc1(this.f300a, false, this.b);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        yc1 yc1Var = (yc1) g94Var;
        yc1Var.d0 = this.f300a;
        yc1Var.f0 = this.b;
    }

    public final int hashCode() {
        return this.b.hashCode() + (Boolean.hashCode(this.f300a) * 31);
    }
}

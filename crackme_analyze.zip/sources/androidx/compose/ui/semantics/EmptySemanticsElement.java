package androidx.compose.ui.semantics;

import defpackage.g94;
import defpackage.p94;
import defpackage.uz1;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/semantics/EmptySemanticsElement;", "Lp94;", "Luz1;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class EmptySemanticsElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final uz1 f302a;

    public EmptySemanticsElement(uz1 uz1Var) {
        this.f302a = uz1Var;
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return this.f302a;
    }

    @Override // defpackage.p94
    public final /* bridge */ /* synthetic */ void g(g94 g94Var) {
    }

    public final int hashCode() {
        return System.identityHashCode(this);
    }
}

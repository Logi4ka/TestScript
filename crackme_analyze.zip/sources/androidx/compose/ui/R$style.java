package androidx.compose.ui;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static int DialogWindowTheme = 2131886375;
    public static int FloatingDialogWindowTheme = 2131886378;

    private R$style() {
    }
}

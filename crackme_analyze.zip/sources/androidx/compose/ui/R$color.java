package androidx.compose.ui;

/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static int vector_tint_color = 2131100459;
    public static int vector_tint_theme_color = 2131100460;

    private R$color() {
    }
}

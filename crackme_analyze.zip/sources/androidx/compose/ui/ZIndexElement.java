package androidx.compose.ui;

import defpackage.g94;
import defpackage.gn7;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/ZIndexElement;", "Lp94;", "Lgn7;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class ZIndexElement extends p94 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof ZIndexElement) && Float.compare(1.0f, 1.0f) == 0;
    }

    @Override // defpackage.p94
    public final g94 f() {
        gn7 gn7Var = new gn7();
        gn7Var.d0 = 1.0f;
        return gn7Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((gn7) g94Var).d0 = 1.0f;
    }

    public final int hashCode() {
        return Float.hashCode(1.0f);
    }

    public final String toString() {
        return "ZIndexElement(zIndex=1.0)";
    }
}

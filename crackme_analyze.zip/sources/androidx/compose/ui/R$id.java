package androidx.compose.ui;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int accessibility_custom_action_0 = 2131296274;
    public static int accessibility_custom_action_1 = 2131296275;
    public static int accessibility_custom_action_10 = 2131296276;
    public static int accessibility_custom_action_11 = 2131296277;
    public static int accessibility_custom_action_12 = 2131296278;
    public static int accessibility_custom_action_13 = 2131296279;
    public static int accessibility_custom_action_14 = 2131296280;
    public static int accessibility_custom_action_15 = 2131296281;
    public static int accessibility_custom_action_16 = 2131296282;
    public static int accessibility_custom_action_17 = 2131296283;
    public static int accessibility_custom_action_18 = 2131296284;
    public static int accessibility_custom_action_19 = 2131296285;
    public static int accessibility_custom_action_2 = 2131296286;
    public static int accessibility_custom_action_20 = 2131296287;
    public static int accessibility_custom_action_21 = 2131296288;
    public static int accessibility_custom_action_22 = 2131296289;
    public static int accessibility_custom_action_23 = 2131296290;
    public static int accessibility_custom_action_24 = 2131296291;
    public static int accessibility_custom_action_25 = 2131296292;
    public static int accessibility_custom_action_26 = 2131296293;
    public static int accessibility_custom_action_27 = 2131296294;
    public static int accessibility_custom_action_28 = 2131296295;
    public static int accessibility_custom_action_29 = 2131296296;
    public static int accessibility_custom_action_3 = 2131296297;
    public static int accessibility_custom_action_30 = 2131296298;
    public static int accessibility_custom_action_31 = 2131296299;
    public static int accessibility_custom_action_4 = 2131296300;
    public static int accessibility_custom_action_5 = 2131296301;
    public static int accessibility_custom_action_6 = 2131296302;
    public static int accessibility_custom_action_7 = 2131296303;
    public static int accessibility_custom_action_8 = 2131296304;
    public static int accessibility_custom_action_9 = 2131296305;
    public static int androidx_compose_ui_view_composition_context = 2131296345;
    public static int compose_view_saveable_id_tag = 2131296406;
    public static int consume_window_insets_tag = 2131296410;
    public static int hide_in_inspector_tag = 2131296507;
    public static int inspection_slot_table_set = 2131296542;
    public static int wrapped_composition_tag = 2131296942;

    private R$id() {
    }
}

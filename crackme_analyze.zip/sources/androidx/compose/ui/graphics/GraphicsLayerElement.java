package androidx.compose.ui.graphics;

import androidx.compose.ui.node.NodeCoordinator;
import defpackage.bc4;
import defpackage.ds5;
import defpackage.fm6;
import defpackage.fx6;
import defpackage.g94;
import defpackage.gx6;
import defpackage.ky5;
import defpackage.ma3;
import defpackage.oh1;
import defpackage.p01;
import defpackage.p94;
import defpackage.qe0;
import defpackage.w06;
import defpackage.yo6;
import defpackage.zr0;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/graphics/GraphicsLayerElement;", "Lp94;", "Lw06;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class GraphicsLayerElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f284a;
    public final float b;
    public final long c;
    public final ky5 d;
    public final boolean e;
    public final long f;
    public final long g;

    public GraphicsLayerElement(float f, float f2, long j, ky5 ky5Var, boolean z, long j2, long j3) {
        this.f284a = f;
        this.b = f2;
        this.c = j;
        this.d = ky5Var;
        this.e = z;
        this.f = j2;
        this.g = j3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof GraphicsLayerElement) {
            GraphicsLayerElement graphicsLayerElement = (GraphicsLayerElement) obj;
            if (Float.compare(1.0f, 1.0f) == 0 && Float.compare(1.0f, 1.0f) == 0 && Float.compare(this.f284a, graphicsLayerElement.f284a) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(this.b, graphicsLayerElement.b) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(8.0f, 8.0f) == 0) {
                long j = graphicsLayerElement.c;
                int i = yo6.b;
                if (this.c == j && Intrinsics.a(this.d, graphicsLayerElement.d) && this.e == graphicsLayerElement.e && zr0.c(this.f, graphicsLayerElement.f) && zr0.c(this.g, graphicsLayerElement.g)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        w06 w06Var = new w06();
        w06Var.d0 = 1.0f;
        w06Var.e0 = 1.0f;
        w06Var.f0 = this.f284a;
        w06Var.g0 = this.b;
        w06Var.h0 = 8.0f;
        w06Var.i0 = this.c;
        w06Var.j0 = this.d;
        w06Var.k0 = this.e;
        w06Var.l0 = this.f;
        w06Var.m0 = this.g;
        w06Var.n0 = 3;
        w06Var.o0 = new ds5(w06Var, 3);
        return w06Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        w06 w06Var = (w06) g94Var;
        w06Var.d0 = 1.0f;
        w06Var.e0 = 1.0f;
        w06Var.f0 = this.f284a;
        w06Var.g0 = this.b;
        w06Var.h0 = 8.0f;
        w06Var.i0 = this.c;
        w06Var.j0 = this.d;
        w06Var.k0 = this.e;
        w06Var.l0 = this.f;
        w06Var.m0 = this.g;
        w06Var.n0 = 3;
        NodeCoordinator nodeCoordinator = ma3.M(w06Var, 2).e0;
        if (nodeCoordinator != null) {
            nodeCoordinator.n1(w06Var.o0, true);
        }
    }

    public final int hashCode() {
        int iC = oh1.c(oh1.c(oh1.c(oh1.c(oh1.c(oh1.c(oh1.c(oh1.c(oh1.c(Float.hashCode(1.0f) * 31, 1.0f, 31), this.f284a, 31), 0.0f, 31), 0.0f, 31), this.b, 31), 0.0f, 31), 0.0f, 31), 0.0f, 31), 8.0f, 31);
        int i = yo6.b;
        int iF = fm6.f((this.d.hashCode() + qe0.e(this.c, iC, 31)) * 31, 961, this.e);
        int i2 = zr0.h;
        fx6 fx6Var = gx6.b;
        return oh1.d(3, oh1.d(0, qe0.e(this.g, qe0.e(this.f, iF, 31), 31), 31), 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("GraphicsLayerElement(scaleX=1.0, scaleY=1.0, alpha=");
        sb.append(this.f284a);
        sb.append(", translationX=0.0, translationY=0.0, shadowElevation=");
        sb.append(this.b);
        sb.append(", rotationX=0.0, rotationY=0.0, rotationZ=0.0, cameraDistance=8.0, transformOrigin=");
        sb.append((Object) yo6.a(this.c));
        sb.append(", shape=");
        sb.append(this.d);
        sb.append(", clip=");
        sb.append(this.e);
        sb.append(", renderEffect=null, ambientShadowColor=");
        bc4.s(this.f, ", spotShadowColor=", sb);
        sb.append((Object) zr0.i(this.g));
        sb.append(", compositingStrategy=CompositingStrategy(value=0), blendMode=");
        sb.append((Object) p01.l0(3));
        sb.append(", colorFilter=null)");
        return sb.toString();
    }
}

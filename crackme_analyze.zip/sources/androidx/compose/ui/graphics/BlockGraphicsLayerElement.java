package androidx.compose.ui.graphics;

import androidx.compose.ui.node.NodeCoordinator;
import defpackage.g94;
import defpackage.l60;
import defpackage.ma3;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/graphics/BlockGraphicsLayerElement;", "Lp94;", "Ll60;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class BlockGraphicsLayerElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function1 f283a;

    public BlockGraphicsLayerElement(Function1 function1) {
        this.f283a = function1;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof BlockGraphicsLayerElement) {
            return this.f283a == ((BlockGraphicsLayerElement) obj).f283a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new l60(this.f283a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        l60 l60Var = (l60) g94Var;
        l60Var.d0 = this.f283a;
        NodeCoordinator nodeCoordinator = ma3.M(l60Var, 2).e0;
        if (nodeCoordinator != null) {
            nodeCoordinator.n1(l60Var.d0, true);
        }
    }

    public final int hashCode() {
        return this.f283a.hashCode();
    }
}

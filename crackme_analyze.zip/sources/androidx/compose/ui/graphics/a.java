package androidx.compose.ui.graphics;

import defpackage.h94;
import defpackage.ky5;
import defpackage.ma3;
import defpackage.mp2;
import defpackage.yo6;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(Function1 function1) {
        return new BlockGraphicsLayerElement(function1);
    }

    public static final h94 b(h94 h94Var, float f, float f2, long j, ky5 ky5Var, boolean z, long j2, long j3) {
        return h94Var.d(new GraphicsLayerElement(f, f2, j, ky5Var, z, j2, j3));
    }

    public static h94 c(h94 h94Var, float f, ky5 ky5Var, int i) {
        if ((i & 4) != 0) {
            f = 1.0f;
        }
        float f2 = f;
        long j = yo6.f6785a;
        if ((i & 2048) != 0) {
            ky5Var = ma3.o;
        }
        long j2 = mp2.f4203a;
        return b(h94Var, f2, 0.0f, j, ky5Var, true, j2, j2);
    }
}

package androidx.compose.ui.graphics.painter;

import defpackage.c43;
import defpackage.fq3;
import defpackage.g;
import defpackage.i60;
import defpackage.qe0;
import defpackage.tt1;
import defpackage.u33;
import defpackage.wi;
import defpackage.yp4;
import io.flutter.embedding.android.KeyboardMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Landroidx/compose/ui/graphics/painter/BitmapPainter;", "Lyp4;", "ui-graphics_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class BitmapPainter extends yp4 {
    public float X;
    public i60 Y;
    public final wi f;
    public final long i;
    public int v = 1;
    public final long w;

    public BitmapPainter(wi wiVar, long j) {
        int i;
        this.f = wiVar;
        this.i = j;
        int i2 = (int) (j >> 32);
        if (i2 < 0 || (i = (int) (KeyboardMap.kValueMask & j)) < 0 || i2 > wiVar.f6311a.getWidth() || i > wiVar.f6311a.getHeight()) {
            g.l("Failed requirement.");
            throw null;
        }
        this.w = j;
        this.X = 1.0f;
    }

    @Override // defpackage.yp4
    public final boolean d(float f) {
        this.X = f;
        return true;
    }

    @Override // defpackage.yp4
    public final boolean e(i60 i60Var) {
        this.Y = i60Var;
        return true;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof BitmapPainter)) {
            return false;
        }
        BitmapPainter bitmapPainter = (BitmapPainter) obj;
        return Intrinsics.a(this.f, bitmapPainter.f) && u33.a(0L, 0L) && c43.a(this.i, bitmapPainter.i) && this.v == bitmapPainter.v;
    }

    @Override // defpackage.yp4
    /* JADX INFO: renamed from: h */
    public final long getW() {
        return fq3.K(this.w);
    }

    public final int hashCode() {
        return Integer.hashCode(this.v) + qe0.e(this.i, qe0.e(0L, this.f.hashCode() * 31, 31), 31);
    }

    @Override // defpackage.yp4
    public final void i(tt1 tt1Var) {
        tt1.y(tt1Var, this.f, this.i, (((long) Math.round(Float.intBitsToFloat((int) (tt1Var.d() >> 32)))) << 32) | (((long) Math.round(Float.intBitsToFloat((int) (tt1Var.d() & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask), this.X, this.Y, this.v, 328);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("BitmapPainter(image=");
        sb.append(this.f);
        sb.append(", srcOffset=");
        sb.append((Object) u33.d(0L));
        sb.append(", srcSize=");
        sb.append((Object) c43.b(this.i));
        sb.append(", filterQuality=");
        int i = this.v;
        sb.append((Object) (i == 0 ? "None" : i == 1 ? "Low" : i == 2 ? "Medium" : i == 3 ? "High" : "Unknown"));
        sb.append(')');
        return sb.toString();
    }
}

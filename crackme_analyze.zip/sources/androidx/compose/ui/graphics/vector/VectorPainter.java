package androidx.compose.ui.graphics.vector;

import androidx.compose.runtime.d;
import defpackage.ad4;
import defpackage.do2;
import defpackage.fs;
import defpackage.g97;
import defpackage.i16;
import defpackage.i60;
import defpackage.mw0;
import defpackage.od3;
import defpackage.q36;
import defpackage.sp2;
import defpackage.tt1;
import defpackage.w67;
import defpackage.x36;
import defpackage.yp4;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Landroidx/compose/ui/graphics/vector/VectorPainter;", "Lyp4;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class VectorPainter extends yp4 {
    public final q36 X;
    public float Y;
    public i60 Z;
    public int b0;
    public final ad4 f = d.h(new i16(0));
    public final ad4 i = d.h(Boolean.FALSE);
    public final g97 v;
    public mw0 w;

    public VectorPainter(sp2 sp2Var) {
        g97 g97Var = new g97(sp2Var);
        g97Var.f = new w67(this, 3);
        this.v = g97Var;
        this.X = d.e(0);
        this.Y = 1.0f;
        this.b0 = -1;
    }

    @Override // defpackage.yp4
    public final boolean d(float f) {
        this.Y = f;
        return true;
    }

    @Override // defpackage.yp4
    public final boolean e(i60 i60Var) {
        this.Z = i60Var;
        return true;
    }

    @Override // defpackage.yp4
    /* JADX INFO: renamed from: h */
    public final long getW() {
        return ((i16) ((x36) this.f).getValue()).f2747a;
    }

    @Override // defpackage.yp4
    public final void i(tt1 tt1Var) {
        i60 i60Var = this.Z;
        g97 g97Var = this.v;
        if (i60Var == null) {
            i60Var = (i60) ((x36) g97Var.g).getValue();
        }
        if (((Boolean) ((x36) this.i).getValue()).booleanValue() && tt1Var.getLayoutDirection() == od3.b) {
            long jG0 = tt1Var.g0();
            fs fsVarY = tt1Var.Y();
            long jQ = fsVarY.q();
            fsVarY.n().d();
            try {
                ((do2) fsVarY.f2228a).p(-1.0f, 1.0f, jG0);
                g97Var.e(tt1Var, this.Y, i60Var);
            } finally {
                fsVarY.n().n();
                fsVarY.E(jQ);
            }
        } else {
            g97Var.e(tt1Var, this.Y, i60Var);
        }
        this.b0 = this.X.n();
    }
}

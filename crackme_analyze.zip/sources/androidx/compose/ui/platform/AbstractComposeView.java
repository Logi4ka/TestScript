package androidx.compose.ui.platform;

import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.compose.ui.R$id;
import com.google.firebase.analytics.FirebaseAnalytics;
import defpackage.a60;
import defpackage.aa5;
import defpackage.b0;
import defpackage.b26;
import defpackage.ba4;
import defpackage.bd6;
import defpackage.bl7;
import defpackage.ca4;
import defpackage.cl7;
import defpackage.da5;
import defpackage.do4;
import defpackage.ej3;
import defpackage.el7;
import defpackage.fl7;
import defpackage.fq3;
import defpackage.fu7;
import defpackage.i11;
import defpackage.iw0;
import defpackage.jo2;
import defpackage.kx4;
import defpackage.ms0;
import defpackage.ms2;
import defpackage.ns2;
import defpackage.nw0;
import defpackage.o06;
import defpackage.os4;
import defpackage.os5;
import defpackage.p13;
import defpackage.pb5;
import defpackage.pg;
import defpackage.pl;
import defpackage.pt2;
import defpackage.rc7;
import defpackage.rw1;
import defpackage.sc7;
import defpackage.si3;
import defpackage.tc7;
import defpackage.v94;
import defpackage.vk5;
import defpackage.xl7;
import defpackage.y01;
import defpackage.yb5;
import defpackage.yl7;
import defpackage.zu0;
import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.d;
import kotlin.coroutines.g;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0011\b'\u0018\u00002\u00020\u0001B'\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\r\u001a\u00020\f2\b\u0010\u000b\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\r\u0010\u000eJ\u0015\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0015\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0015\u0010\u0016R(\u0010\u001d\u001a\u0004\u0018\u00010\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u00178\u0002@BX\u0082\u000e¢\u0006\f\n\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR(\u0010!\u001a\u0004\u0018\u00010\n2\b\u0010\u0018\u001a\u0004\u0018\u00010\n8\u0002@BX\u0082\u000e¢\u0006\f\n\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010\u000eR$\u0010'\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\"8\u0002@\u0002X\u0082\u000e¢\u0006\f\n\u0004\b#\u0010$\u0012\u0004\b%\u0010&R0\u0010.\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00138\u0006@FX\u0087\u000e¢\u0006\u0018\n\u0004\b(\u0010)\u0012\u0004\b-\u0010&\u001a\u0004\b*\u0010+\"\u0004\b,\u0010\u0016R\u0014\u00100\u001a\u00020\u00138TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b/\u0010+R\u0011\u00102\u001a\u00020\u00138F¢\u0006\u0006\u001a\u0004\b1\u0010+¨\u00063"}, d2 = {"Landroidx/compose/ui/platform/AbstractComposeView;", "Landroid/view/ViewGroup;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", HttpUrl.FRAGMENT_ENCODE_SET, "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "Lnw0;", "parent", HttpUrl.FRAGMENT_ENCODE_SET, "setParentCompositionContext", "(Lnw0;)V", "Ltc7;", "strategy", "setViewCompositionStrategy", "(Ltc7;)V", HttpUrl.FRAGMENT_ENCODE_SET, "isTransitionGroup", "setTransitionGroup", "(Z)V", "Landroid/os/IBinder;", FirebaseAnalytics.Param.VALUE, "b", "Landroid/os/IBinder;", "setPreviousAttachedWindowToken", "(Landroid/os/IBinder;)V", "previousAttachedWindowToken", "d", "Lnw0;", "setParentContext", "parentContext", "Lkotlin/Function0;", "e", "Lkotlin/jvm/functions/Function0;", "getDisposeViewCompositionStrategy$annotations", "()V", "disposeViewCompositionStrategy", "f", "Z", "getShowLayoutBounds", "()Z", "setShowLayoutBounds", "getShowLayoutBounds$annotations", "showLayoutBounds", "getShouldCreateCompositionOnAttachedToWindow", "shouldCreateCompositionOnAttachedToWindow", "getHasComposition", "hasComposition", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public abstract class AbstractComposeView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakReference f296a;

    /* JADX INFO: renamed from: b, reason: from kotlin metadata */
    public IBinder previousAttachedWindowToken;
    public xl7 c;

    /* JADX INFO: renamed from: d, reason: from kotlin metadata */
    public nw0 parentContext;
    public sc7 e;

    /* JADX INFO: renamed from: f, reason: from kotlin metadata */
    public boolean showLayoutBounds;
    public boolean i;
    public boolean v;

    public AbstractComposeView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setClipChildren(false);
        setClipToPadding(false);
        setImportantForAccessibility(1);
        pg pgVar = new pg(this, 7);
        addOnAttachStateChangeListener(pgVar);
        rc7 rc7Var = new rc7(this);
        kx4.b(this).f4020a.add(rc7Var);
        this.e = new sc7(0, this, pgVar, rc7Var);
    }

    private static /* synthetic */ void getDisposeViewCompositionStrategy$annotations() {
    }

    public static /* synthetic */ void getShowLayoutBounds$annotations() {
    }

    private final void setParentContext(nw0 nw0Var) {
        if (this.parentContext != nw0Var) {
            this.parentContext = nw0Var;
            if (nw0Var != null) {
                this.f296a = null;
            }
            xl7 xl7Var = this.c;
            if (xl7Var != null) {
                xl7Var.dispose();
                this.c = null;
                if (isAttachedToWindow()) {
                    d();
                }
            }
        }
    }

    private final void setPreviousAttachedWindowToken(IBinder iBinder) {
        if (this.previousAttachedWindowToken != iBinder) {
            this.previousAttachedWindowToken = iBinder;
            this.f296a = null;
        }
    }

    public abstract void a(int i, iw0 iw0Var);

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        b();
        super.addView(view);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams) {
        b();
        return super.addViewInLayout(view, i, layoutParams);
    }

    public final void b() {
        if (this.i) {
            return;
        }
        throw new UnsupportedOperationException("Cannot add views to " + getClass().getSimpleName() + "; only Compose content is supported");
    }

    public final void c() {
        xl7 xl7Var = this.c;
        if (xl7Var != null) {
            xl7Var.dispose();
        }
        this.c = null;
        requestLayout();
    }

    public final void d() {
        if (this.c == null) {
            boolean z = false;
            byte b = 0;
            try {
                this.i = true;
                this.c = yl7.a(this, g(), new zu0(-656146368, new b0(this, b == true ? 1 : 0), true));
            } finally {
                this.i = false;
            }
        }
    }

    public void e(int i, int i2, int i3, int i4, boolean z) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.layout(getPaddingLeft(), getPaddingTop(), (i3 - i) - getPaddingRight(), (i4 - i2) - getPaddingBottom());
        }
    }

    public void f(int i, int i2) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            super.onMeasure(i, i2);
            return;
        }
        childAt.measure(View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight()), View.MeasureSpec.getMode(i)), View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - getPaddingTop()) - getPaddingBottom()), View.MeasureSpec.getMode(i2)));
        setMeasuredDimension(getPaddingRight() + getPaddingLeft() + childAt.getMeasuredWidth(), getPaddingBottom() + getPaddingTop() + childAt.getMeasuredHeight());
    }

    public final nw0 g() {
        da5 da5Var;
        CoroutineContext coroutineContext;
        os4 os4Var;
        nw0 nw0VarB = this.parentContext;
        if (nw0VarB == null) {
            nw0VarB = fl7.b(this);
            if (nw0VarB == null) {
                Object parent = getParent();
                while (nw0VarB == null && (parent instanceof View)) {
                    View view = (View) parent;
                    nw0VarB = fl7.b(view);
                    parent = view.getParent();
                }
            }
            boolean z = false;
            if (nw0VarB != null) {
                nw0 nw0Var = (!(nw0VarB instanceof da5) || ((aa5) ((da5) nw0VarB).t.getValue()).compareTo(aa5.b) > 0) ? nw0VarB : null;
                if (nw0Var != null) {
                    this.f296a = new WeakReference(nw0Var);
                }
            } else {
                nw0VarB = null;
            }
            if (nw0VarB == null) {
                WeakReference weakReference = this.f296a;
                if (weakReference == null || (nw0VarB = (nw0) weakReference.get()) == null || ((nw0VarB instanceof da5) && ((aa5) ((da5) nw0VarB).t.getValue()).compareTo(aa5.b) <= 0)) {
                    nw0VarB = null;
                }
                if (nw0VarB == null) {
                    if (!isAttachedToWindow()) {
                        p13.b("Cannot locate windowRecomposer; View " + this + " is not attached to a window");
                    }
                    View view2 = this;
                    Object parent2 = getParent();
                    while (parent2 instanceof View) {
                        View view3 = (View) parent2;
                        if (view3.getId() == 16908290) {
                            break;
                        }
                        view2 = view3;
                        parent2 = view3.getParent();
                    }
                    nw0 nw0VarB2 = fl7.b(view2);
                    if (nw0VarB2 == null) {
                        ((bl7) cl7.f838a.get()).getClass();
                        CoroutineContext coroutineContext2 = g.f3765a;
                        i11 i11Var = d.W;
                        coroutineContext2.getClass();
                        i11Var.getClass();
                        bd6 bd6Var = pl.b0;
                        if (Looper.myLooper() == Looper.getMainLooper()) {
                            coroutineContext = (CoroutineContext) pl.b0.getValue();
                        } else {
                            coroutineContext = (CoroutineContext) pl.c0.get();
                            if (coroutineContext == null) {
                                vk5.k("no AndroidUiDispatcher for this thread");
                                return null;
                            }
                        }
                        CoroutineContext coroutineContextPlus = coroutineContext.plus(coroutineContext2);
                        v94 v94Var = (v94) coroutineContextPlus.get(rw1.Z);
                        if (v94Var != null) {
                            os4Var = new os4(v94Var);
                            a60 a60Var = os4Var.b;
                            synchronized (a60Var.b) {
                                a60Var.f39a = false;
                            }
                        } else {
                            os4Var = null;
                        }
                        pb5 pb5Var = new pb5();
                        CoroutineContext ca4Var = (ba4) coroutineContextPlus.get(pt2.Z);
                        if (ca4Var == null) {
                            ca4Var = new ca4();
                            pb5Var.f4783a = ca4Var;
                        }
                        if (os4Var != null) {
                            coroutineContext2 = os4Var;
                        }
                        CoroutineContext coroutineContextPlus2 = coroutineContextPlus.plus(coroutineContext2).plus(ca4Var);
                        da5Var = new da5(coroutineContextPlus2);
                        synchronized (da5Var.b) {
                            da5Var.s = true;
                        }
                        y01 y01VarF = fu7.f(coroutineContextPlus2);
                        ej3 ej3VarI = os5.i(view2);
                        si3 lifecycle = ej3VarI != null ? ej3VarI.getLifecycle() : null;
                        if (lifecycle == null) {
                            p13.c("ViewTreeLifecycleOwner not found from " + view2);
                            ms0.a();
                            return null;
                        }
                        view2.addOnAttachStateChangeListener(new o06(view2, da5Var));
                        lifecycle.a(new el7(y01VarF, os4Var, da5Var, pb5Var, view2));
                        view2.setTag(R$id.androidx_compose_ui_view_composition_context, da5Var);
                        jo2 jo2Var = jo2.f3540a;
                        Handler handler = view2.getHandler();
                        int i = ns2.f4440a;
                        view2.addOnAttachStateChangeListener(new pg(fq3.u(jo2Var, new ms2(handler, "windowRecomposer cleanup", false).f, new yb5(da5Var, view2, z ? 1 : 0, 11), 2), 8));
                    } else {
                        if (!(nw0VarB2 instanceof da5)) {
                            vk5.k("root viewTreeParentCompositionContext is not a Recomposer");
                            return null;
                        }
                        da5Var = (da5) nw0VarB2;
                    }
                    da5 da5Var2 = ((aa5) da5Var.t.getValue()).compareTo(aa5.b) > 0 ? da5Var : null;
                    if (da5Var2 != null) {
                        this.f296a = new WeakReference(da5Var2);
                    }
                    return da5Var;
                }
            }
        }
        return nw0VarB;
    }

    public final boolean getHasComposition() {
        return this.c != null;
    }

    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return true;
    }

    public final boolean getShowLayoutBounds() {
        return this.showLayoutBounds;
    }

    @Override // android.view.ViewGroup
    public final boolean isTransitionGroup() {
        return !this.v || super.isTransitionGroup();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setPreviousAttachedWindowToken(getWindowToken());
        if (getShouldCreateCompositionOnAttachedToWindow()) {
            d();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        e(i, i2, i3, i4, z);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        d();
        f(i, i2);
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.setLayoutDirection(i);
        }
    }

    public final void setParentCompositionContext(nw0 parent) {
        setParentContext(parent);
    }

    public final void setShowLayoutBounds(boolean z) {
        this.showLayoutBounds = z;
        KeyEvent.Callback childAt = getChildAt(0);
        if (childAt != null) {
            ((do4) childAt).setShowLayoutBounds(z);
        }
    }

    @Override // android.view.ViewGroup
    public void setTransitionGroup(boolean isTransitionGroup) {
        super.setTransitionGroup(isTransitionGroup);
        this.v = true;
    }

    public final void setViewCompositionStrategy(tc7 strategy) {
        sc7 sc7Var = this.e;
        if (sc7Var != null) {
            sc7Var.invoke();
        }
        ((b26) strategy).getClass();
        pg pgVar = new pg(this, 7);
        addOnAttachStateChangeListener(pgVar);
        rc7 rc7Var = new rc7(this);
        kx4.b(this).f4020a.add(rc7Var);
        this.e = new sc7(0, this, pgVar, rc7Var);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        b();
        super.addView(view, i);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        b();
        return super.addViewInLayout(view, i, layoutParams, z);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, int i2) {
        b();
        super.addView(view, i, i2);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        b();
        super.addView(view, layoutParams);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        b();
        super.addView(view, i, layoutParams);
    }

    public /* synthetic */ AbstractComposeView(Context context, AttributeSet attributeSet, int i, int i2) {
        this(context, (i & 2) != 0 ? null : attributeSet, 0);
    }

    public AbstractComposeView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 4, 0);
    }
}

package androidx.compose.ui.platform;

import defpackage.g94;
import defpackage.kg6;
import defpackage.p94;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/platform/TestTagElement;", "Lp94;", "Lkg6;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class TestTagElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f299a;

    public TestTagElement(String str) {
        this.f299a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TestTagElement)) {
            return false;
        }
        return this.f299a.equals(((TestTagElement) obj).f299a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        kg6 kg6Var = new kg6();
        kg6Var.d0 = this.f299a;
        return kg6Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((kg6) g94Var).d0 = this.f299a;
    }

    public final int hashCode() {
        return this.f299a.hashCode();
    }
}

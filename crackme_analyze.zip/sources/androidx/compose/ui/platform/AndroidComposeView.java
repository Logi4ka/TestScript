package androidx.compose.ui.platform;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.os.Looper;
import android.os.StrictMode;
import android.os.Trace;
import android.util.LongSparseArray;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.ScrollCaptureTarget;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.ViewTreeObserver;
import android.view.animation.AnimationUtils;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.translation.TranslationRequestValue;
import android.view.translation.ViewTranslationRequest;
import androidx.compose.runtime.d;
import androidx.compose.ui.R$id;
import androidx.compose.ui.layout.b;
import androidx.compose.ui.node.LayoutNode;
import androidx.compose.ui.node.NodeCoordinator;
import androidx.compose.ui.platform.AndroidComposeView;
import androidx.compose.ui.semantics.EmptySemanticsElement;
import androidx.lifecycle.DefaultLifecycleObserver;
import com.google.firebase.analytics.FirebaseAnalytics;
import defpackage.a3;
import defpackage.ad4;
import defpackage.ag;
import defpackage.ah4;
import defpackage.ah5;
import defpackage.as5;
import defpackage.ax6;
import defpackage.b33;
import defpackage.be3;
import defpackage.bg;
import defpackage.bh;
import defpackage.bh5;
import defpackage.bj6;
import defpackage.bk1;
import defpackage.bs5;
import defpackage.c46;
import defpackage.cg;
import defpackage.ch;
import defpackage.ch3;
import defpackage.co1;
import defpackage.co4;
import defpackage.cx4;
import defpackage.da4;
import defpackage.dd4;
import defpackage.dd7;
import defpackage.de3;
import defpackage.df2;
import defpackage.dg;
import defpackage.dh5;
import defpackage.do4;
import defpackage.dp3;
import defpackage.dv7;
import defpackage.dx4;
import defpackage.e94;
import defpackage.ea4;
import defpackage.ea5;
import defpackage.eg;
import defpackage.ej3;
import defpackage.eo0;
import defpackage.eo1;
import defpackage.ew;
import defpackage.f23;
import defpackage.f90;
import defpackage.fa5;
import defpackage.fc4;
import defpackage.fg2;
import defpackage.fj0;
import defpackage.fo4;
import defpackage.fq3;
import defpackage.fs;
import defpackage.fu7;
import defpackage.fx4;
import defpackage.fx6;
import defpackage.g;
import defpackage.g10;
import defpackage.g23;
import defpackage.g46;
import defpackage.g94;
import defpackage.gg;
import defpackage.gi;
import defpackage.gk6;
import defpackage.gq3;
import defpackage.gx6;
import defpackage.h08;
import defpackage.h10;
import defpackage.h23;
import defpackage.h94;
import defpackage.ha5;
import defpackage.hf2;
import defpackage.hg2;
import defpackage.hj4;
import defpackage.hw5;
import defpackage.i10;
import defpackage.i23;
import defpackage.ig;
import defpackage.ij4;
import defpackage.ij6;
import defpackage.ip2;
import defpackage.ja5;
import defpackage.jc6;
import defpackage.jd7;
import defpackage.jg;
import defpackage.jj4;
import defpackage.jo;
import defpackage.jo5;
import defpackage.kf;
import defpackage.kf2;
import defpackage.kg;
import defpackage.kj6;
import defpackage.ko1;
import defpackage.ko5;
import defpackage.kw7;
import defpackage.l10;
import defpackage.l94;
import defpackage.lf6;
import defpackage.lg;
import defpackage.lj7;
import defpackage.ln1;
import defpackage.lp2;
import defpackage.lu4;
import defpackage.m10;
import defpackage.ma3;
import defpackage.mb;
import defpackage.mc;
import defpackage.mh;
import defpackage.mj7;
import defpackage.ml;
import defpackage.mn4;
import defpackage.mo;
import defpackage.n36;
import defpackage.nf;
import defpackage.no1;
import defpackage.nt0;
import defpackage.nv5;
import defpackage.nz0;
import defpackage.o6;
import defpackage.od3;
import defpackage.oh;
import defpackage.os5;
import defpackage.ou2;
import defpackage.p13;
import defpackage.p94;
import defpackage.pb4;
import defpackage.pb5;
import defpackage.pk6;
import defpackage.po;
import defpackage.q16;
import defpackage.q23;
import defpackage.qc7;
import defpackage.qe0;
import defpackage.qf;
import defpackage.qf2;
import defpackage.qp7;
import defpackage.qr5;
import defpackage.qs3;
import defpackage.r2;
import defpackage.rb;
import defpackage.rf2;
import defpackage.rk6;
import defpackage.rr5;
import defpackage.ru2;
import defpackage.rw1;
import defpackage.ry1;
import defpackage.s53;
import defpackage.sf;
import defpackage.si;
import defpackage.si3;
import defpackage.su4;
import defpackage.sz2;
import defpackage.t33;
import defpackage.td0;
import defpackage.th4;
import defpackage.tl3;
import defpackage.tm5;
import defpackage.tp;
import defpackage.tv0;
import defpackage.uc7;
import defpackage.ud0;
import defpackage.ug;
import defpackage.ui;
import defpackage.ul;
import defpackage.un1;
import defpackage.uo;
import defpackage.uu4;
import defpackage.uz1;
import defpackage.vc7;
import defpackage.vd0;
import defpackage.vf;
import defpackage.vg;
import defpackage.vh7;
import defpackage.vk5;
import defpackage.vn;
import defpackage.vs2;
import defpackage.vs3;
import defpackage.wf;
import defpackage.wg;
import defpackage.wl;
import defpackage.wr5;
import defpackage.ws3;
import defpackage.x36;
import defpackage.xb;
import defpackage.xf;
import defpackage.xj;
import defpackage.xq1;
import defpackage.xw0;
import defpackage.y33;
import defpackage.yd3;
import defpackage.yf;
import defpackage.yj;
import defpackage.yo3;
import defpackage.yr5;
import defpackage.ys3;
import defpackage.yw4;
import defpackage.yz1;
import defpackage.z1;
import defpackage.z95;
import defpackage.zf;
import defpackage.zf2;
import defpackage.zg;
import defpackage.zg5;
import defpackage.zi1;
import defpackage.zk1;
import defpackage.zq0;
import defpackage.zr5;
import defpackage.zw4;
import io.flutter.embedding.android.KeyboardMap;
import io.sentry.android.core.o0;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.HttpUrl;
import okhttp3.internal.http2.Http2;
import okio.Segment;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000ú\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\b\u0001\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u0005:\u0003¤\u0002\u0016J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u0011\u0010\n\u001a\u0004\u0018\u00010\tH\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u0019\u0010\u0013\u001a\u00020\u000e2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J!\u0010\u0018\u001a\u00020\u000e2\u0012\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u000e0\u0015¢\u0006\u0004\b\u0018\u0010\u0019J\u0017\u0010\u001c\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001a\u001a\u00020\u0006¢\u0006\u0004\b\u001c\u0010\u001dR\u001a\u0010#\u001a\u00020\u001e8\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001f\u0010 \u001a\u0004\b!\u0010\"R+\u0010,\u001a\u00020$2\u0006\u0010%\u001a\u00020$8V@RX\u0096\u008e\u0002¢\u0006\u0012\n\u0004\b&\u0010'\u001a\u0004\b(\u0010)\"\u0004\b*\u0010+R\u001a\u00102\u001a\u00020-8\u0016X\u0096\u0004¢\u0006\f\n\u0004\b.\u0010/\u001a\u0004\b0\u00101R*\u0010;\u001a\u0002032\u0006\u00104\u001a\u0002038\u0016@VX\u0096\u000e¢\u0006\u0012\n\u0004\b5\u00106\u001a\u0004\b7\u00108\"\u0004\b9\u0010:R\u001a\u0010A\u001a\u00020<8\u0016X\u0096\u0004¢\u0006\f\n\u0004\b=\u0010>\u001a\u0004\b?\u0010@R\u001a\u0010G\u001a\u00020B8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bC\u0010D\u001a\u0004\bE\u0010FR\u0017\u0010M\u001a\u00020H8\u0006¢\u0006\f\n\u0004\bI\u0010J\u001a\u0004\bK\u0010LR \u0010U\u001a\u00020N8\u0016X\u0096\u0004¢\u0006\u0012\n\u0004\bO\u0010P\u0012\u0004\bS\u0010T\u001a\u0004\bQ\u0010RR \u0010[\u001a\b\u0012\u0004\u0012\u00020N0V8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bW\u0010X\u001a\u0004\bY\u0010ZR\u001a\u0010a\u001a\u00020\\8\u0016X\u0096\u0004¢\u0006\f\n\u0004\b]\u0010^\u001a\u0004\b_\u0010`R\u001a\u0010g\u001a\u00020b8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bc\u0010d\u001a\u0004\be\u0010fR\u001a\u0010m\u001a\u00020h8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bi\u0010j\u001a\u0004\bk\u0010lR\"\u0010u\u001a\u00020n8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bo\u0010p\u001a\u0004\bq\u0010r\"\u0004\bs\u0010tR\u001a\u0010{\u001a\u00020v8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bw\u0010x\u001a\u0004\by\u0010zR\u001c\u0010\u0081\u0001\u001a\u00020|8\u0016X\u0096\u0004¢\u0006\r\n\u0004\b}\u0010~\u001a\u0005\b\u007f\u0010\u0080\u0001R \u0010\u0087\u0001\u001a\u00030\u0082\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0083\u0001\u0010\u0084\u0001\u001a\u0006\b\u0085\u0001\u0010\u0086\u0001R5\u0010\u008e\u0001\u001a\u000f\u0012\u0005\u0012\u00030\u0088\u0001\u0012\u0004\u0012\u00020\u000e0\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0017\n\u0006\b\u0089\u0001\u0010\u008a\u0001\u001a\u0006\b\u008b\u0001\u0010\u008c\u0001\"\u0005\b\u008d\u0001\u0010\u0019R\"\u0010\u0094\u0001\u001a\u0005\u0018\u00010\u008f\u00018\u0000X\u0080\u0004¢\u0006\u0010\n\u0006\b\u0090\u0001\u0010\u0091\u0001\u001a\u0006\b\u0092\u0001\u0010\u0093\u0001R \u0010\u009a\u0001\u001a\u00030\u0095\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0096\u0001\u0010\u0097\u0001\u001a\u0006\b\u0098\u0001\u0010\u0099\u0001R \u0010 \u0001\u001a\u00030\u009b\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u009c\u0001\u0010\u009d\u0001\u001a\u0006\b\u009e\u0001\u0010\u009f\u0001R \u0010¦\u0001\u001a\u00030¡\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b¢\u0001\u0010£\u0001\u001a\u0006\b¤\u0001\u0010¥\u0001R1\u0010¯\u0001\u001a\u00030§\u00018V@\u0016X\u0096\u000e¢\u0006\u001f\n\u0006\b¨\u0001\u0010©\u0001\u0012\u0005\b®\u0001\u0010T\u001a\u0006\bª\u0001\u0010«\u0001\"\u0006\b¬\u0001\u0010\u00ad\u0001R/\u0010¶\u0001\u001a\u00020\f8\u0000@\u0000X\u0081\u000e¢\u0006\u001e\n\u0006\b°\u0001\u0010±\u0001\u0012\u0005\bµ\u0001\u0010T\u001a\u0006\b²\u0001\u0010³\u0001\"\u0005\b´\u0001\u0010\u0010R5\u0010¼\u0001\u001a\u0004\u0018\u00010\u00162\b\u0010%\u001a\u0004\u0018\u00010\u00168B@BX\u0082\u008e\u0002¢\u0006\u0017\n\u0005\b·\u0001\u0010'\u001a\u0006\b¸\u0001\u0010¹\u0001\"\u0006\bº\u0001\u0010»\u0001R\"\u0010À\u0001\u001a\u0004\u0018\u00010\u00168FX\u0086\u0084\u0002¢\u0006\u0010\n\u0006\b½\u0001\u0010¾\u0001\u001a\u0006\b¿\u0001\u0010¹\u0001R'\u0010Ç\u0001\u001a\u00030Á\u00018\u0016X\u0097\u0004¢\u0006\u0017\n\u0006\bÂ\u0001\u0010Ã\u0001\u0012\u0005\bÆ\u0001\u0010T\u001a\u0006\bÄ\u0001\u0010Å\u0001R \u0010Í\u0001\u001a\u00030È\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bÉ\u0001\u0010Ê\u0001\u001a\u0006\bË\u0001\u0010Ì\u0001R'\u0010Ô\u0001\u001a\u00030Î\u00018\u0016X\u0097\u0004¢\u0006\u0017\n\u0006\bÏ\u0001\u0010Ð\u0001\u0012\u0005\bÓ\u0001\u0010T\u001a\u0006\bÑ\u0001\u0010Ò\u0001R3\u0010Û\u0001\u001a\u00030Õ\u00012\u0007\u0010%\u001a\u00030Õ\u00018V@RX\u0096\u008e\u0002¢\u0006\u0017\n\u0005\bÖ\u0001\u0010'\u001a\u0006\b×\u0001\u0010Ø\u0001\"\u0006\bÙ\u0001\u0010Ú\u0001R3\u0010â\u0001\u001a\u00030Ü\u00012\u0007\u0010%\u001a\u00030Ü\u00018V@RX\u0096\u008e\u0002¢\u0006\u0017\n\u0005\bÝ\u0001\u0010'\u001a\u0006\bÞ\u0001\u0010ß\u0001\"\u0006\bà\u0001\u0010á\u0001R \u0010è\u0001\u001a\u00030ã\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bä\u0001\u0010å\u0001\u001a\u0006\bæ\u0001\u0010ç\u0001R \u0010î\u0001\u001a\u00030é\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bê\u0001\u0010ë\u0001\u001a\u0006\bì\u0001\u0010í\u0001R \u0010ô\u0001\u001a\u00030ï\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bð\u0001\u0010ñ\u0001\u001a\u0006\bò\u0001\u0010ó\u0001R \u0010ú\u0001\u001a\u00030õ\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bö\u0001\u0010÷\u0001\u001a\u0006\bø\u0001\u0010ù\u0001R\u0017\u0010ý\u0001\u001a\u00020\u001b8VX\u0096\u0004¢\u0006\b\u001a\u0006\bû\u0001\u0010ü\u0001R\u0018\u0010\u0081\u0002\u001a\u00030þ\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\bÿ\u0001\u0010\u0080\u0002R*\u0010\u0082\u0002\u001a\u0004\u0018\u00010\u00118\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0006\b\u0082\u0002\u0010\u0083\u0002\u001a\u0006\b\u0084\u0002\u0010\u0085\u0002\"\u0005\b\u0086\u0002\u0010\u0014R\u001a\u0010\u008a\u0002\u001a\u0005\u0018\u00010\u0087\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u0088\u0002\u0010\u0089\u0002R\u001a\u0010\u008e\u0002\u001a\u0005\u0018\u00010\u008b\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u008c\u0002\u0010\u008d\u0002R\u0018\u0010\u0092\u0002\u001a\u00030\u008f\u00028@X\u0080\u0004¢\u0006\b\u001a\u0006\b\u0090\u0002\u0010\u0091\u0002R\u0017\u0010\u0094\u0002\u001a\u00020\f8VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u0093\u0002\u0010³\u0001R\u0018\u0010\u0096\u0002\u001a\u00030§\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u0095\u0002\u0010«\u0001R\u0018\u0010\u009a\u0002\u001a\u00030\u0097\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u0098\u0002\u0010\u0099\u0002R\u0018\u0010\u009e\u0002\u001a\u00030\u009b\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u009c\u0002\u0010\u009d\u0002R\u0018\u0010 \u0002\u001a\u00030§\u00018@X\u0080\u0004¢\u0006\b\u001a\u0006\b\u009f\u0002\u0010«\u0001R\u0019\u0010£\u0002\u001a\u0004\u0018\u00010\u00008VX\u0096\u0004¢\u0006\b\u001a\u0006\b¡\u0002\u0010¢\u0002¨\u0006¥\u0002"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView;", "Landroid/view/ViewGroup;", "Ldo4;", HttpUrl.FRAGMENT_ENCODE_SET, "Landroidx/lifecycle/DefaultLifecycleObserver;", "Lmn4;", HttpUrl.FRAGMENT_ENCODE_SET, "getImportantForAutofill", "()I", "Lha5;", "getEmbeddedViewFocusRect", "()Lha5;", HttpUrl.FRAGMENT_ENCODE_SET, "intervalMillis", HttpUrl.FRAGMENT_ENCODE_SET, "setAccessibilityEventBatchIntervalMillis", "(J)V", "Lzg5;", "handler", "setUncaughtExceptionHandler", "(Lzg5;)V", "Lkotlin/Function1;", "Lbg;", "callback", "setOnViewTreeOwnersAvailable", "(Lkotlin/jvm/functions/Function1;)V", "accessibilityId", "Landroid/view/View;", "findViewByAccessibilityIdTraversal", "(I)Landroid/view/View;", "Lbe3;", "c", "Lbe3;", "getSharedDrawScope", "()Lbe3;", "sharedDrawScope", "Lco1;", "<set-?>", "d", "Lad4;", "getDensity", "()Lco1;", "setDensity", "(Lco1;)V", "density", "Lqf2;", "i", "Lqf2;", "getFocusOwner", "()Lqf2;", "focusOwner", "Lkotlin/coroutines/CoroutineContext;", FirebaseAnalytics.Param.VALUE, "v", "Lkotlin/coroutines/CoroutineContext;", "getCoroutineContext", "()Lkotlin/coroutines/CoroutineContext;", "setCoroutineContext", "(Lkotlin/coroutines/CoroutineContext;)V", "coroutineContext", "Lgi;", "w", "Lgi;", "getDragAndDropManager", "()Lgi;", "dragAndDropManager", "Luc7;", "d0", "Luc7;", "getViewConfiguration", "()Luc7;", "viewConfiguration", "Lq23;", "e0", "Lq23;", "getInsetsListener", "()Lq23;", "insetsListener", "Landroidx/compose/ui/node/LayoutNode;", "f0", "Landroidx/compose/ui/node/LayoutNode;", "getRoot", "()Landroidx/compose/ui/node/LayoutNode;", "getRoot$annotations", "()V", "root", "Lpb4;", "g0", "Lpb4;", "getLayoutNodes", "()Lpb4;", "layoutNodes", "Lja5;", "h0", "Lja5;", "getRectManager", "()Lja5;", "rectManager", "Lah5;", "i0", "Lah5;", "getRootForTest", "()Lah5;", "rootForTest", "Las5;", "j0", "Las5;", "getSemanticsOwner", "()Las5;", "semanticsOwner", "Loh;", "l0", "Loh;", "getContentCaptureManager$ui_release", "()Loh;", "setContentCaptureManager$ui_release", "(Loh;)V", "contentCaptureManager", "Lnf;", "m0", "Lnf;", "getAccessibilityManager", "()Lnf;", "accessibilityManager", "Lip2;", "n0", "Lip2;", "getGraphicsContext", "()Lip2;", "graphicsContext", "Lm10;", "o0", "Lm10;", "getAutofillTree", "()Lm10;", "autofillTree", "Landroid/content/res/Configuration;", "u0", "Lkotlin/jvm/functions/Function1;", "getConfigurationChangeObserver", "()Lkotlin/jvm/functions/Function1;", "setConfigurationChangeObserver", "configurationChangeObserver", "Lqf;", "w0", "Lqf;", "get_autofillManager$ui_release", "()Lqf;", "_autofillManager", "Lwf;", "y0", "Lwf;", "getClipboardManager", "()Lwf;", "clipboardManager", "Lvf;", "z0", "Lvf;", "getClipboard", "()Lvf;", "clipboard", "Lfo4;", "A0", "Lfo4;", "getSnapshotObserver", "()Lfo4;", "snapshotObserver", HttpUrl.FRAGMENT_ENCODE_SET, "B0", "Z", "getShowLayoutBounds", "()Z", "setShowLayoutBounds", "(Z)V", "getShowLayoutBounds$annotations", "showLayoutBounds", "L0", "J", "getLastMatrixRecalculationAnimationTime$ui_release", "()J", "setLastMatrixRecalculationAnimationTime$ui_release", "getLastMatrixRecalculationAnimationTime$ui_release$annotations", "lastMatrixRecalculationAnimationTime", "O0", "get_viewTreeOwners", "()Lbg;", "set_viewTreeOwners", "(Lbg;)V", "_viewTreeOwners", "P0", "Lk66;", "getViewTreeOwners", "viewTreeOwners", "Lij6;", "V0", "Lij6;", "getTextInputService", "()Lij6;", "getTextInputService$annotations", "textInputService", "Lg46;", "X0", "Lg46;", "getSoftwareKeyboardController", "()Lg46;", "softwareKeyboardController", "Lfg2;", "Y0", "Lfg2;", "getFontLoader", "()Lfg2;", "getFontLoader$annotations", "fontLoader", "Lhg2;", "Z0", "getFontFamilyResolver", "()Lhg2;", "setFontFamilyResolver", "(Lhg2;)V", "fontFamilyResolver", "Lod3;", "b1", "getLayoutDirection", "()Lod3;", "setLayoutDirection", "(Lod3;)V", "layoutDirection", "Lvs2;", "c1", "Lvs2;", "getHapticFeedBack", "()Lvs2;", "hapticFeedBack", "Ll94;", "e1", "Ll94;", "getModifierLocalManager", "()Ll94;", "modifierLocalManager", "Lpk6;", "f1", "Lpk6;", "getTextToolbar", "()Lpk6;", "textToolbar", "Lzw4;", "u1", "Lzw4;", "getPointerIconService", "()Lzw4;", "pointerIconService", "getView", "()Landroid/view/View;", "view", "Llj7;", "getWindowInfo", "()Llj7;", "windowInfo", "uncaughtExceptionHandler", "Lzg5;", "getUncaughtExceptionHandler$ui_release", "()Lzg5;", "setUncaughtExceptionHandler$ui_release", "Lg10;", "getAutofill", "()Lg10;", "autofill", "Ll10;", "getAutofillManager", "()Ll10;", "autofillManager", "Lwl;", "getAndroidViewsHandler$ui_release", "()Lwl;", "androidViewsHandler", "getMeasureIteration", "measureIteration", "getHasPendingMeasureOrLayout", "hasPendingMeasureOrLayout", "Lsu4;", "getPlacementScope", "()Lsu4;", "placementScope", "Lh23;", "getInputModeManager", "()Lh23;", "inputModeManager", "getScrollCaptureInProgress$ui_release", "scrollCaptureInProgress", "getOutOfFrameExecutor", "()Landroidx/compose/ui/platform/AndroidComposeView;", "outOfFrameExecutor", "qp7", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class AndroidComposeView extends ViewGroup implements do4, ah5, DefaultLifecycleObserver, mn4 {
    public static Method A1;
    public static Class v1;
    public static Method w1;
    public static Method x1;
    public static final fc4 y1 = new fc4();
    public static xb z1;

    /* JADX INFO: renamed from: A0, reason: from kotlin metadata */
    public final fo4 snapshotObserver;

    /* JADX INFO: renamed from: B0, reason: from kotlin metadata */
    public boolean showLayoutBounds;
    public wl C0;
    public nz0 D0;
    public boolean E0;
    public final ws3 F0;
    public long G0;
    public final int[] H0;
    public final float[] I0;
    public final float[] J0;
    public final float[] K0;

    /* JADX INFO: renamed from: L0, reason: from kotlin metadata */
    public long lastMatrixRecalculationAnimationTime;
    public boolean M0;
    public long N0;

    /* JADX INFO: renamed from: O0, reason: from kotlin metadata */
    public final ad4 _viewTreeOwners;
    public final no1 P0;
    public Function1 Q0;
    public final yf R0;
    public final zf S0;
    public final ag T0;
    public final kj6 U0;

    /* JADX INFO: renamed from: V0, reason: from kotlin metadata */
    public final ij6 textInputService;
    public final AtomicReference W0;
    public final un1 X0;
    public final rw1 Y0;

    /* JADX INFO: renamed from: Z0, reason: from kotlin metadata */
    public final ad4 fontFamilyResolver;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f297a;
    public int a1;
    public final boolean b;
    public final ch3 b0;

    /* JADX INFO: renamed from: b1, reason: from kotlin metadata */
    public final ad4 layoutDirection;

    /* JADX INFO: renamed from: c, reason: from kotlin metadata */
    public final be3 sharedDrawScope;
    public final fj0 c0;
    public final zk1 c1;

    /* JADX INFO: renamed from: d, reason: from kotlin metadata */
    public final ad4 density;
    public final ul d0;
    public final i23 d1;
    public final View e;

    /* JADX INFO: renamed from: e0, reason: from kotlin metadata */
    public final q23 insetsListener;

    /* JADX INFO: renamed from: e1, reason: from kotlin metadata */
    public final l94 modifierLocalManager;
    public final boolean f;

    /* JADX INFO: renamed from: f0, reason: from kotlin metadata */
    public final LayoutNode root;
    public final ml f1;

    /* JADX INFO: renamed from: g0, reason: from kotlin metadata */
    public final pb4 layoutNodes;
    public MotionEvent g1;

    /* JADX INFO: renamed from: h0, reason: from kotlin metadata */
    public final ja5 rectManager;
    public long h1;
    public final rf2 i;
    public final AndroidComposeView i0;
    public final dd7 i1;

    /* JADX INFO: renamed from: j0, reason: from kotlin metadata */
    public final as5 semanticsOwner;
    public final fc4 j1;
    public final ug k0;
    public float k1;

    /* JADX INFO: renamed from: l0, reason: from kotlin metadata */
    public oh contentCaptureManager;
    public float l1;

    /* JADX INFO: renamed from: m0, reason: from kotlin metadata */
    public final nf accessibilityManager;
    public final lg m1;
    public final si n0;
    public final o6 n1;

    /* JADX INFO: renamed from: o0, reason: from kotlin metadata */
    public final m10 autofillTree;
    public boolean o1;
    public final ArrayList p0;
    public final kg p1;
    public ArrayList q0;
    public final td0 q1;
    public boolean r0;
    public boolean r1;
    public final da4 s0;
    public final xq1 s1;
    public final eo0 t0;
    public View t1;

    /* JADX INFO: renamed from: u0, reason: from kotlin metadata */
    public Function1 configurationChangeObserver;
    public final ig u1;

    /* JADX INFO: renamed from: v, reason: from kotlin metadata */
    public CoroutineContext coroutineContext;
    public final nv5 v0;

    /* JADX INFO: renamed from: w, reason: from kotlin metadata */
    public final gi dragAndDropManager;

    /* JADX INFO: renamed from: w0, reason: from kotlin metadata */
    public final qf _autofillManager;
    public boolean x0;

    /* JADX INFO: renamed from: y0, reason: from kotlin metadata */
    public final wf clipboardManager;

    /* JADX INFO: renamed from: z0, reason: from kotlin metadata */
    public final vf clipboard;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Type inference failed for: r1v34, types: [zf] */
    /* JADX WARN: Type inference failed for: r1v35, types: [ag] */
    public AndroidComposeView(Context context, CoroutineContext coroutineContext) {
        nv5 nv5Var;
        qf qfVar;
        super(context);
        final AndroidComposeView androidComposeView = this;
        androidComposeView.f297a = 9205357640488583168L;
        int i = 1;
        androidComposeView.b = true;
        androidComposeView.sharedDrawScope = new be3();
        eo1 eo1VarO = kw7.o(context);
        zq0 zq0Var = zq0.e0;
        androidComposeView.density = d.g(eo1VarO, zq0Var);
        int i2 = Build.VERSION.SDK_INT;
        int i3 = 0;
        boolean z = i2 >= 35;
        androidComposeView.f = z;
        uz1 uz1Var = new uz1();
        EmptySemanticsElement emptySemanticsElement = new EmptySemanticsElement(uz1Var);
        p94 p94Var = new p94() { // from class: androidx.compose.ui.platform.AndroidComposeView$bringIntoViewNode$1
            public final boolean equals(Object obj) {
                return obj == this;
            }

            @Override // defpackage.p94
            public final g94 f() {
                f90 f90Var = new f90();
                f90Var.d0 = this.f298a;
                return f90Var;
            }

            @Override // defpackage.p94
            public final void g(g94 g94Var) {
                ((f90) g94Var).d0 = this.f298a;
            }

            public final int hashCode() {
                return this.f298a.hashCode();
            }
        };
        androidComposeView.i = new rf2(androidComposeView, androidComposeView);
        androidComposeView.coroutineContext = coroutineContext;
        androidComposeView.dragAndDropManager = new gi();
        androidComposeView.b0 = new ch3();
        h94 h94VarA = androidx.compose.ui.input.key.a.a(e94.f1898a, new cg(androidComposeView, i));
        h94 h94VarA2 = androidx.compose.ui.input.rotary.a.a();
        androidComposeView.c0 = new fj0();
        androidComposeView.d0 = new ul(ViewConfiguration.get(context));
        q23 q23Var = new q23();
        androidComposeView.insetsListener = q23Var;
        LayoutNode layoutNode = new LayoutNode(3);
        layoutNode.i0(bh5.c);
        layoutNode.f0(androidComposeView.getDensity());
        layoutNode.k0(androidComposeView.getViewConfiguration());
        layoutNode.j0(b.b(q23Var).d(emptySemanticsElement).d(h94VarA2).d(h94VarA).d(((rf2) androidComposeView.getFocusOwner()).e).d(androidComposeView.getDragAndDropManager().c).d(p94Var));
        androidComposeView.root = layoutNode;
        pb4 pb4Var = t33.f5590a;
        androidComposeView.layoutNodes = new pb4();
        androidComposeView.m0getLayoutNodes();
        androidComposeView.rectManager = new ja5();
        androidComposeView.i0 = androidComposeView;
        androidComposeView.semanticsOwner = new as5(androidComposeView.getRoot(), uz1Var, androidComposeView.m0getLayoutNodes());
        ug ugVar = new ug(androidComposeView);
        androidComposeView.k0 = ugVar;
        androidComposeView.contentCaptureManager = new oh(androidComposeView, new dg(0, androidComposeView, ch.class, "getContentCaptureSessionCompat", "getContentCaptureSessionCompat(Landroid/view/View;)Landroidx/compose/ui/platform/coreshims/ContentCaptureSessionCompat;", 1, 0));
        nf nfVar = new nf();
        Object systemService = context.getSystemService("accessibility");
        systemService.getClass();
        androidComposeView.accessibilityManager = nfVar;
        androidComposeView.n0 = new si(androidComposeView);
        androidComposeView.autofillTree = new m10();
        androidComposeView.p0 = new ArrayList();
        androidComposeView.s0 = new da4();
        LayoutNode root = androidComposeView.getRoot();
        eo0 eo0Var = new eo0();
        eo0Var.b = root;
        eo0Var.c = new ou2((androidx.compose.ui.node.a) root.s0.d);
        eo0Var.d = new yz1(20);
        eo0Var.e = new ru2();
        androidComposeView.t0 = eo0Var;
        androidComposeView.configurationChangeObserver = rb.c;
        if (e()) {
            m10 autofillTree = androidComposeView.getAutofillTree();
            nv5Var = new nv5();
            nv5Var.f4480a = androidComposeView;
            nv5Var.b = autofillTree;
            AutofillManager autofillManagerH = r2.h(androidComposeView.getContext().getSystemService(r2.k()));
            if (autofillManagerH == null) {
                vk5.k("Autofill service could not be located.");
                throw null;
            }
            nv5Var.c = autofillManagerH;
            androidComposeView.setImportantForAutofill(1);
            a3 a3VarE = q16.e(androidComposeView);
            AutofillId autofillIdE = a3VarE != null ? h10.e(a3VarE.f19a) : null;
            if (autofillIdE == null) {
                throw qe0.f("Required value was null.");
            }
            nv5Var.d = autofillIdE;
        } else {
            nv5Var = null;
        }
        androidComposeView.v0 = nv5Var;
        int i4 = 26;
        if (e()) {
            AutofillManager autofillManagerH2 = r2.h(context.getSystemService(r2.k()));
            if (autofillManagerH2 == null) {
                throw qe0.f("Autofill service could not be located.");
            }
            androidComposeView = this;
            qfVar = new qf(new bk1(autofillManagerH2, i4), getSemanticsOwner(), this, getRectManager(), context.getPackageName());
        } else {
            qfVar = null;
        }
        androidComposeView._autofillManager = qfVar;
        androidComposeView.clipboardManager = new wf(context);
        androidComposeView.clipboard = new vf(androidComposeView.getClipboardManager());
        int i5 = 2;
        androidComposeView.snapshotObserver = new fo4(new cg(androidComposeView, i5));
        androidComposeView.F0 = new ws3(androidComposeView.getRoot());
        androidComposeView.G0 = 9223372034707292159L;
        androidComposeView.H0 = new int[]{0, 0};
        float[] fArrA = qs3.a();
        androidComposeView.I0 = fArrA;
        androidComposeView.J0 = qs3.a();
        androidComposeView.K0 = qs3.a();
        androidComposeView.lastMatrixRecalculationAnimationTime = -1L;
        androidComposeView.N0 = 9187343241974906880L;
        androidComposeView._viewTreeOwners = d.h(null);
        androidComposeView.P0 = d.c(new kg(androidComposeView, i));
        androidComposeView.R0 = new yf(androidComposeView, i3);
        androidComposeView.S0 = new ViewTreeObserver.OnScrollChangedListener() { // from class: zf
            @Override // android.view.ViewTreeObserver.OnScrollChangedListener
            public final void onScrollChanged() {
                Class cls = AndroidComposeView.v1;
                this.f6991a.H();
            }
        };
        androidComposeView.T0 = new ViewTreeObserver.OnTouchModeChangeListener() { // from class: ag
            @Override // android.view.ViewTreeObserver.OnTouchModeChangeListener
            public final void onTouchModeChanged(boolean z2) {
                ((x36) this.f97a.d1.f2752a).setValue(new g23(z2 ? 1 : 2));
            }
        };
        kj6 kj6Var = new kj6(androidComposeView.getView(), androidComposeView);
        androidComposeView.U0 = kj6Var;
        androidComposeView.textInputService = new ij6(kj6Var);
        androidComposeView.W0 = new AtomicReference(null);
        androidComposeView.X0 = new un1(androidComposeView.getTextInputService());
        androidComposeView.Y0 = new rw1(21);
        androidComposeView.fontFamilyResolver = d.g(ew.n(context), zq0Var);
        androidComposeView.a1 = i2 >= 31 ? context.getResources().getConfiguration().fontWeightAdjustment : 0;
        int layoutDirection = context.getResources().getConfiguration().getLayoutDirection();
        od3 od3Var = layoutDirection != 0 ? layoutDirection != 1 ? null : od3.b : od3.f4581a;
        androidComposeView.layoutDirection = d.h(od3Var == null ? od3.f4581a : od3Var);
        androidComposeView.c1 = new zk1(androidComposeView, 1);
        androidComposeView.d1 = new i23(androidComposeView.isInTouchMode() ? 1 : 2, new cg(androidComposeView, i3));
        androidComposeView.modifierLocalManager = new l94(androidComposeView);
        ml mlVar = new ml();
        new ui(mlVar, i5);
        rk6[] rk6VarArr = rk6.f5250a;
        androidComposeView.f1 = mlVar;
        androidComposeView.i1 = new dd7(3);
        androidComposeView.j1 = new fc4();
        androidComposeView.m1 = new lg(androidComposeView, i3);
        androidComposeView.n1 = new o6(androidComposeView, i);
        androidComposeView.p1 = new kg(androidComposeView, i3);
        androidComposeView.q1 = i2 < 29 ? new ud0(fArrA) : new vd0();
        androidComposeView.addOnAttachStateChangeListener(androidComposeView.contentCaptureManager);
        androidComposeView.setWillNotDraw(false);
        androidComposeView.setFocusable(true);
        if (i2 >= 26) {
            bh.f585a.a(androidComposeView, 1, false);
        }
        androidComposeView.setFocusableInTouchMode(true);
        androidComposeView.setClipChildren(false);
        qc7.o(androidComposeView, ugVar);
        androidComposeView.setOnDragListener(androidComposeView.getDragAndDropManager());
        androidComposeView.getRoot().e(androidComposeView);
        if (i2 >= 29) {
            wg.f6299a.a(androidComposeView);
        }
        if (z) {
            View view = new View(context);
            view.setLayoutParams(new ViewGroup.LayoutParams(1, 1));
            view.setTag(R$id.hide_in_inspector_tag, Boolean.TRUE);
            androidComposeView.e = view;
            androidComposeView.addView(view, -1);
        }
        androidComposeView.s1 = i2 >= 31 ? new xq1(27) : null;
        androidComposeView.u1 = new ig(androidComposeView);
    }

    public static boolean e() {
        return Build.VERSION.SDK_INT >= 26;
    }

    public static void f(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            if (childAt instanceof AndroidComposeView) {
                ((AndroidComposeView) childAt).u();
            } else if (childAt instanceof ViewGroup) {
                f((ViewGroup) childAt);
            }
        }
    }

    @ko1
    public static /* synthetic */ void getFontLoader$annotations() {
    }

    public static /* synthetic */ void getLastMatrixRecalculationAnimationTime$ui_release$annotations() {
    }

    public static /* synthetic */ void getRoot$annotations() {
    }

    public static /* synthetic */ void getShowLayoutBounds$annotations() {
    }

    @ko1
    public static /* synthetic */ void getTextInputService$annotations() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final bg get_viewTreeOwners() {
        return (bg) ((x36) this._viewTreeOwners).getValue();
    }

    public static long h(int i) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        if (mode == Integer.MIN_VALUE) {
            fx6 fx6Var = gx6.b;
            return size;
        }
        if (mode == 0) {
            fx6 fx6Var2 = gx6.b;
            return 2147483647L;
        }
        if (mode != 1073741824) {
            ax6.v();
            return 0L;
        }
        long j = size;
        fx6 fx6Var3 = gx6.b;
        return j | (j << 32);
    }

    public static View i(int i, View view) throws NoSuchMethodException {
        if (Build.VERSION.SDK_INT < 29) {
            Method declaredMethod = View.class.getDeclaredMethod("getAccessibilityViewId", null);
            declaredMethod.setAccessible(true);
            if (Intrinsics.a(declaredMethod.invoke(view, null), Integer.valueOf(i))) {
                return view;
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    View viewI = i(i, viewGroup.getChildAt(i2));
                    if (viewI != null) {
                        return viewI;
                    }
                }
            }
        }
        return null;
    }

    public static void l(LayoutNode layoutNode) {
        layoutNode.G();
        dd4 dd4VarC = layoutNode.C();
        Object[] objArr = dd4VarC.f1699a;
        int i = dd4VarC.c;
        for (int i2 = 0; i2 < i; i2++) {
            l((LayoutNode) objArr[i2]);
        }
    }

    public static boolean n(MotionEvent motionEvent) {
        boolean z = (Float.floatToRawIntBits(motionEvent.getX()) & jo.API_PRIORITY_OTHER) >= 2139095040 || (Float.floatToRawIntBits(motionEvent.getY()) & jo.API_PRIORITY_OTHER) >= 2139095040 || (Float.floatToRawIntBits(motionEvent.getRawX()) & jo.API_PRIORITY_OTHER) >= 2139095040 || (Float.floatToRawIntBits(motionEvent.getRawY()) & jo.API_PRIORITY_OTHER) >= 2139095040;
        if (!z) {
            int pointerCount = motionEvent.getPointerCount();
            for (int i = 1; i < pointerCount; i++) {
                z = (Float.floatToRawIntBits(motionEvent.getX(i)) & jo.API_PRIORITY_OTHER) >= 2139095040 || (Float.floatToRawIntBits(motionEvent.getY(i)) & jo.API_PRIORITY_OTHER) >= 2139095040 || (Build.VERSION.SDK_INT >= 29 && !ea4.f1904a.a(motionEvent, i));
                if (z) {
                    break;
                }
            }
        }
        return z;
    }

    private void setDensity(co1 co1Var) {
        ((x36) this.density).setValue(co1Var);
    }

    private void setFontFamilyResolver(hg2 hg2Var) {
        ((x36) this.fontFamilyResolver).setValue(hg2Var);
    }

    private void setLayoutDirection(od3 od3Var) {
        ((x36) this.layoutDirection).setValue(od3Var);
    }

    private final void set_viewTreeOwners(bg bgVar) {
        ((x36) this._viewTreeOwners).setValue(bgVar);
    }

    public final void A(MotionEvent motionEvent) {
        this.lastMatrixRecalculationAnimationTime = AnimationUtils.currentAnimationTimeMillis();
        td0 td0Var = this.q1;
        float[] fArr = this.J0;
        td0Var.a(this, fArr);
        qp7.C(fArr, this.K0);
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        long jB = qs3.b((((long) Float.floatToRawIntBits(x)) << 32) | (((long) Float.floatToRawIntBits(y)) & KeyboardMap.kValueMask), fArr);
        float rawX = motionEvent.getRawX() - Float.intBitsToFloat((int) (jB >> 32));
        float rawY = motionEvent.getRawY() - Float.intBitsToFloat((int) (jB & KeyboardMap.kValueMask));
        this.N0 = (((long) Float.floatToRawIntBits(rawX)) << 32) | (((long) Float.floatToRawIntBits(rawY)) & KeyboardMap.kValueMask);
    }

    public final boolean B() {
        if (isFocused() || hasFocus()) {
            return true;
        }
        return super.requestFocus(130, null);
    }

    public final void C(LayoutNode layoutNode) {
        if (isLayoutRequested() || !isAttachedToWindow()) {
            return;
        }
        if (layoutNode != null) {
            while (layoutNode != null && layoutNode.t() == yd3.f6721a) {
                if (!this.E0) {
                    LayoutNode layoutNodeX = layoutNode.x();
                    if (layoutNodeX == null) {
                        break;
                    }
                    long j = ((androidx.compose.ui.node.a) layoutNodeX.s0.d).d;
                    if (nz0.f(j) && nz0.e(j)) {
                        break;
                    }
                }
                layoutNode = layoutNode.x();
            }
            if (layoutNode == getRoot()) {
                requestLayout();
                return;
            }
        }
        if (getWidth() == 0 || getHeight() == 0) {
            requestLayout();
        } else {
            invalidate();
        }
    }

    public final long D(long j) {
        z();
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j >> 32)) - Float.intBitsToFloat((int) (this.N0 >> 32));
        return qs3.b((((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask)) - Float.intBitsToFloat((int) (this.N0 & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32), this.K0);
    }

    public final int E(MotionEvent motionEvent) {
        Object obj;
        if (this.r1) {
            this.r1 = false;
            int metaState = motionEvent.getMetaState();
            this.b0.getClass();
            ((x36) mj7.f4172a).setValue(new fx4(metaState));
        }
        da4 da4Var = this.s0;
        lu4 lu4VarA = da4Var.a(motionEvent, this);
        eo0 eo0Var = this.t0;
        if (lu4VarA == null) {
            if (!eo0Var.f1988a) {
                ((yo3) ((yz1) eo0Var.d).b).a();
                ((ou2) eo0Var.c).c();
            }
            return 0;
        }
        List list = (List) lu4VarA.b;
        int size = list.size() - 1;
        if (size >= 0) {
            while (true) {
                int i = size - 1;
                obj = list.get(size);
                if (((cx4) obj).e) {
                    break;
                }
                if (i < 0) {
                    break;
                }
                size = i;
            }
            obj = null;
        } else {
            obj = null;
        }
        cx4 cx4Var = (cx4) obj;
        if (cx4Var != null) {
            this.f297a = cx4Var.d;
        }
        int iA = eo0Var.a(lu4VarA, this, o(motionEvent));
        lu4VarA.c = null;
        int actionMasked = motionEvent.getActionMasked();
        if ((actionMasked != 0 && actionMasked != 5) || (iA & 1) != 0) {
            return iA;
        }
        int pointerId = motionEvent.getPointerId(motionEvent.getActionIndex());
        da4Var.c.delete(pointerId);
        da4Var.b.delete(pointerId);
        return iA;
    }

    public final void F(MotionEvent motionEvent, int i, long j, boolean z) {
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = -1;
        if (actionMasked != 1) {
            if (actionMasked == 6) {
                actionIndex = motionEvent.getActionIndex();
            }
        } else if (i != 9 && i != 10) {
            actionIndex = 0;
        }
        int pointerCount = motionEvent.getPointerCount() - (actionIndex >= 0 ? 1 : 0);
        if (pointerCount == 0) {
            return;
        }
        MotionEvent.PointerProperties[] pointerPropertiesArr = new MotionEvent.PointerProperties[pointerCount];
        for (int i2 = 0; i2 < pointerCount; i2++) {
            pointerPropertiesArr[i2] = new MotionEvent.PointerProperties();
        }
        MotionEvent.PointerCoords[] pointerCoordsArr = new MotionEvent.PointerCoords[pointerCount];
        for (int i3 = 0; i3 < pointerCount; i3++) {
            pointerCoordsArr[i3] = new MotionEvent.PointerCoords();
        }
        int i4 = 0;
        while (i4 < pointerCount) {
            int i5 = ((actionIndex < 0 || i4 < actionIndex) ? 0 : 1) + i4;
            motionEvent.getPointerProperties(i5, pointerPropertiesArr[i4]);
            MotionEvent.PointerCoords pointerCoords = pointerCoordsArr[i4];
            motionEvent.getPointerCoords(i5, pointerCoords);
            float f = pointerCoords.x;
            long jR = r((((long) Float.floatToRawIntBits(pointerCoords.y)) & KeyboardMap.kValueMask) | (((long) Float.floatToRawIntBits(f)) << 32));
            pointerCoords.x = Float.intBitsToFloat((int) (jR >> 32));
            pointerCoords.y = Float.intBitsToFloat((int) (jR & KeyboardMap.kValueMask));
            i4++;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent.getDownTime() == motionEvent.getEventTime() ? j : motionEvent.getDownTime(), j, i, pointerCount, pointerPropertiesArr, pointerCoordsArr, motionEvent.getMetaState(), z ? 0 : motionEvent.getButtonState(), motionEvent.getXPrecision(), motionEvent.getYPrecision(), motionEvent.getDeviceId(), motionEvent.getEdgeFlags(), motionEvent.getSource(), motionEvent.getFlags());
        lu4 lu4VarA = this.s0.a(motionEventObtain, this);
        lu4VarA.getClass();
        this.t0.a(lu4VarA, this, true);
        motionEventObtain.recycle();
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void G(kotlin.jvm.functions.Function2 r9, defpackage.h11 r10) {
        /*
            r8 = this;
            boolean r0 = r10 instanceof defpackage.mg
            if (r0 == 0) goto L13
            r0 = r10
            mg r0 = (defpackage.mg) r0
            int r1 = r0.c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.c = r1
            goto L18
        L13:
            mg r0 = new mg
            r0.<init>(r8, r10)
        L18:
            java.lang.Object r10 = r0.f4150a
            ge1 r1 = defpackage.ge1.f2376a
            int r2 = r0.c
            r3 = 1
            if (r2 == 0) goto L2d
            if (r2 == r3) goto L29
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.vk5.k(r8)
            return
        L29:
            defpackage.ku7.L(r10)
            goto L4b
        L2d:
            defpackage.ku7.L(r10)
            r10 = r3
            cg r3 = new cg
            r2 = 3
            r3.<init>(r8, r2)
            r0.c = r10
            hj r2 = new hj
            r6 = 0
            r7 = 21
            java.util.concurrent.atomic.AtomicReference r4 = r8.W0
            r5 = r9
            r2.<init>(r3, r4, r5, r6, r7)
            java.lang.Object r8 = defpackage.fu7.v(r2, r0)
            if (r8 != r1) goto L4b
            return
        L4b:
            defpackage.ms0.a()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.platform.AndroidComposeView.G(kotlin.jvm.functions.Function2, h11):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0044  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void H() {
        /*
            r18 = this;
            r0 = r18
            int[] r1 = r0.H0
            r0.getLocationOnScreen(r1)
            long r2 = r0.G0
            r4 = 32
            long r5 = r2 >> r4
            int r5 = (int) r5
            r6 = 4294967295(0xffffffff, double:2.1219957905E-314)
            long r2 = r2 & r6
            int r2 = (int) r2
            r3 = 0
            r8 = r1[r3]
            r9 = 1
            if (r5 != r8) goto L27
            r10 = r1[r9]
            if (r2 != r10) goto L27
            long r10 = r0.lastMatrixRecalculationAnimationTime
            r12 = 0
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 >= 0) goto L44
        L27:
            r1 = r1[r9]
            long r10 = (long) r8
            long r10 = r10 << r4
            long r12 = (long) r1
            long r12 = r12 & r6
            long r10 = r10 | r12
            r0.G0 = r10
            r1 = 2147483647(0x7fffffff, float:NaN)
            if (r5 == r1) goto L44
            if (r2 == r1) goto L44
            androidx.compose.ui.node.LayoutNode r1 = r0.getRoot()
            de3 r1 = r1.t0
            ys3 r1 = r1.p
            r1.q0()
            r1 = r9
            goto L45
        L44:
            r1 = r3
        L45:
            r0.z()
            android.view.View r2 = r0.t1
            if (r2 != 0) goto L52
            android.view.View r2 = r0.getRootView()
            r0.t1 = r2
        L52:
            ja5 r5 = r0.getRectManager()
            long r10 = r0.G0
            long r12 = r0.N0
            long r12 = defpackage.f53.S(r12)
            int r8 = r2.getWidth()
            int r2 = r2.getHeight()
            r5.getClass()
            float[] r14 = r0.J0
            int r15 = defpackage.b33.b(r14)
            nl6 r3 = r5.b
            r15 = r15 & 2
            if (r15 != 0) goto L78
        L75:
            r16 = r6
            goto L7a
        L78:
            r14 = 0
            goto L75
        L7a:
            long r6 = r3.c
            boolean r6 = defpackage.u33.a(r12, r6)
            if (r6 != 0) goto L86
            r3.c = r12
            r6 = r9
            goto L87
        L86:
            r6 = 0
        L87:
            long r12 = r3.d
            boolean r7 = defpackage.u33.a(r10, r12)
            if (r7 != 0) goto L92
            r3.d = r10
            r6 = r9
        L92:
            if (r14 == 0) goto L95
            r6 = r9
        L95:
            long r7 = (long) r8
            long r7 = r7 << r4
            long r10 = (long) r2
            long r10 = r10 & r16
            long r7 = r7 | r10
            long r10 = r3.e
            int r2 = (r7 > r10 ? 1 : (r7 == r10 ? 0 : -1))
            if (r2 == 0) goto La4
            r3.e = r7
            r6 = r9
        La4:
            if (r6 != 0) goto Lad
            boolean r2 = r5.e
            if (r2 == 0) goto Lab
            goto Lad
        Lab:
            r3 = 0
            goto Lae
        Lad:
            r3 = r9
        Lae:
            r5.e = r3
            ws3 r2 = r0.F0
            r2.a(r1)
            ja5 r0 = r0.getRectManager()
            r0.b()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.platform.AndroidComposeView.H():void");
    }

    public final void I(float f) {
        if (this.f) {
            if (f > 0.0f) {
                if (Float.isNaN(this.k1) || f > this.k1) {
                    this.k1 = f;
                    return;
                }
                return;
            }
            if (f < 0.0f) {
                if (Float.isNaN(this.l1) || f < this.l1) {
                    this.l1 = f;
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        view.getClass();
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = generateDefaultLayoutParams();
        }
        addViewInLayout(view, i, layoutParams, true);
    }

    @Override // android.view.View
    public final void autofill(SparseArray sparseArray) {
        rr5 rr5VarZ;
        Function1 function1;
        if (e()) {
            qf qfVar = this._autofillManager;
            if (qfVar != null) {
                int size = sparseArray.size();
                for (int i = 0; i < size; i++) {
                    int iKeyAt = sparseArray.keyAt(i);
                    AutofillValue autofillValueI = r2.i(sparseArray.get(iKeyAt));
                    if (autofillValueI.isText()) {
                        LayoutNode layoutNode = (LayoutNode) qfVar.b.c.b(iKeyAt);
                        if (layoutNode != null && (rr5VarZ = layoutNode.z()) != null) {
                            Object objG = rr5VarZ.f5289a.g(qr5.g);
                            if (objG == null) {
                                objG = null;
                            }
                            z1 z1Var = (z1) objG;
                            if (z1Var != null && (function1 = (Function1) z1Var.b) != null) {
                            }
                        }
                    } else if (autofillValueI.isDate()) {
                        o0.q("ComposeAutofillManager", "Auto filling Date fields is not yet supported.");
                    } else if (autofillValueI.isList()) {
                        o0.q("ComposeAutofillManager", "Auto filling dropdown lists is not yet supported.");
                    } else if (autofillValueI.isToggle()) {
                        o0.q("ComposeAutofillManager", "Auto filling toggle fields are not yet supported.");
                    }
                }
            }
            nv5 nv5Var = this.v0;
            if (nv5Var != null) {
                m10 m10Var = (m10) nv5Var.b;
                if (m10Var.f4046a.isEmpty()) {
                    return;
                }
                int size2 = sparseArray.size();
                for (int i2 = 0; i2 < size2; i2++) {
                    int iKeyAt2 = sparseArray.keyAt(i2);
                    AutofillValue autofillValueI2 = r2.i(sparseArray.get(iKeyAt2));
                    if (autofillValueI2.isText()) {
                        autofillValueI2.getTextValue().toString();
                        if (m10Var.f4046a.get(Integer.valueOf(iKeyAt2)) != null) {
                            ax6.w();
                            return;
                        }
                    } else {
                        if (autofillValueI2.isDate()) {
                            throw new th4("An operation is not implemented: b/138604541: Add onFill() callback for date");
                        }
                        if (autofillValueI2.isList()) {
                            throw new th4("An operation is not implemented: b/138604541: Add onFill() callback for list");
                        }
                        if (autofillValueI2.isToggle()) {
                            throw new th4("An operation is not implemented: b/138604541:  Add onFill() callback for toggle");
                        }
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final boolean canScrollHorizontally(int i) {
        return this.k0.m(this.f297a, i, false);
    }

    @Override // android.view.View
    public final boolean canScrollVertically(int i) {
        return this.k0.m(this.f297a, i, true);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        if (!isAttachedToWindow()) {
            l(getRoot());
        }
        s(true);
        n36.k().m();
        this.r0 = true;
        fj0 fj0Var = this.c0;
        sf sfVar = fj0Var.f2173a;
        Canvas canvas2 = sfVar.f5433a;
        sfVar.f5433a = canvas;
        getRoot().j(sfVar, null);
        fj0Var.f2173a.f5433a = canvas2;
        ArrayList arrayList = this.p0;
        if (!arrayList.isEmpty()) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((lp2) ((co4) arrayList.get(i))).g();
            }
        }
        int i2 = jd7.f3475a;
        arrayList.clear();
        this.r0 = false;
        ArrayList arrayList2 = this.q0;
        if (arrayList2 != null) {
            arrayList.addAll(arrayList2);
            arrayList2.clear();
        }
        if (this.f) {
            uo.a(this, this.k1);
            View view = this.e;
            if (view == null) {
                Intrinsics.e("frameRateCategoryView");
                throw null;
            }
            uo.a(view, this.l1);
            if (!Float.isNaN(this.l1)) {
                view.invalidate();
                drawChild(canvas, view, getDrawingTime());
            }
            this.k1 = Float.NaN;
            this.l1 = Float.NaN;
        }
        getRectManager().b();
    }

    @Override // android.view.View
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        tp tpVar;
        dh5 dh5Var;
        int size;
        tp tpVar2;
        g94 g94VarF;
        tp tpVar3;
        if (this.o1) {
            o6 o6Var = this.n1;
            removeCallbacks(o6Var);
            if (motionEvent.getActionMasked() == 8) {
                this.o1 = false;
            } else {
                o6Var.run();
            }
        }
        if (n(motionEvent) || !isAttachedToWindow()) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int i = 1;
        if (motionEvent.getActionMasked() != 8) {
            if (!motionEvent.isFromSource(2)) {
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                Float.floatToRawIntBits(x);
                Float.floatToRawIntBits(y);
                motionEvent.getEventTime();
                motionEvent.getActionMasked();
                rf2 rf2Var = (rf2) getFocusOwner();
                if (rf2Var.d.e) {
                    System.out.println((Object) "FocusRelatedWarning: Dispatching indirect touch event while the focus system is invalidated.");
                } else {
                    zf2 zf2VarH = ch.H(rf2Var.c);
                    if (zf2VarH != null) {
                        if (!zf2VarH.f2347a.c0) {
                            p13.b("visitAncestors called on an unattached node");
                        }
                        g94 g94Var = zf2VarH.f2347a;
                        LayoutNode layoutNodeO = ma3.O(zf2VarH);
                        while (layoutNodeO != null) {
                            if ((((g94) layoutNodeO.s0.i).d & 2097152) != 0) {
                                while (g94Var != null) {
                                    if ((g94Var.c & 2097152) != 0) {
                                        g94 g94VarF2 = g94Var;
                                        dd4 dd4Var = null;
                                        while (g94VarF2 != null) {
                                            if ((g94VarF2.c & 2097152) != 0 && (g94VarF2 instanceof ln1)) {
                                                int i2 = 0;
                                                for (g94 g94Var2 = ((ln1) g94VarF2).e0; g94Var2 != null; g94Var2 = g94Var2.f) {
                                                    if ((g94Var2.c & 2097152) != 0) {
                                                        i2++;
                                                        if (i2 == 1) {
                                                            g94VarF2 = g94Var2;
                                                        } else {
                                                            if (dd4Var == null) {
                                                                dd4Var = new dd4(new g94[16]);
                                                            }
                                                            if (g94VarF2 != null) {
                                                                dd4Var.b(g94VarF2);
                                                                g94VarF2 = null;
                                                            }
                                                            dd4Var.b(g94Var2);
                                                        }
                                                    }
                                                }
                                                if (i2 == 1) {
                                                }
                                            }
                                            g94VarF2 = ma3.f(dd4Var);
                                        }
                                    }
                                    g94Var = g94Var.e;
                                }
                            }
                            layoutNodeO = layoutNodeO.x();
                            g94Var = (layoutNodeO == null || (tpVar = layoutNodeO.s0) == null) ? null : (lf6) tpVar.f;
                        }
                    }
                }
            }
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        if (!motionEvent.isFromSource(4194304)) {
            return (k(motionEvent) & 1) != 0;
        }
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        motionEvent.getAxisValue(26);
        Context context = getContext();
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            Method method = vc7.f6068a;
            mo.j(viewConfiguration);
        } else {
            vc7.a(viewConfiguration, context);
        }
        Context context2 = getContext();
        if (i3 >= 26) {
            mo.i(viewConfiguration);
        } else {
            vc7.a(viewConfiguration, context2);
        }
        motionEvent.getEventTime();
        motionEvent.getDeviceId();
        qf2 focusOwner = getFocusOwner();
        eg egVar = new eg(i, this, motionEvent);
        rf2 rf2Var2 = (rf2) focusOwner;
        if (rf2Var2.d.e) {
            System.out.println((Object) "FocusRelatedWarning: Dispatching rotary event while the focus system is invalidated.");
            return false;
        }
        zf2 zf2VarH2 = ch.H(rf2Var2.c);
        if (zf2VarH2 != null) {
            if (!zf2VarH2.f2347a.c0) {
                p13.b("visitAncestors called on an unattached node");
            }
            g94 g94Var3 = zf2VarH2.f2347a;
            LayoutNode layoutNodeO2 = ma3.O(zf2VarH2);
            loop0: while (true) {
                if (layoutNodeO2 == null) {
                    g94VarF = null;
                    break;
                }
                if ((((g94) layoutNodeO2.s0.i).d & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                    while (g94Var3 != null) {
                        if ((g94Var3.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                            g94VarF = g94Var3;
                            dd4 dd4Var2 = null;
                            while (g94VarF != null) {
                                if (g94VarF instanceof dh5) {
                                    break loop0;
                                }
                                if ((g94VarF.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0 && (g94VarF instanceof ln1)) {
                                    int i4 = 0;
                                    for (g94 g94Var4 = ((ln1) g94VarF).e0; g94Var4 != null; g94Var4 = g94Var4.f) {
                                        if ((g94Var4.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                                            i4++;
                                            if (i4 == 1) {
                                                g94VarF = g94Var4;
                                            } else {
                                                if (dd4Var2 == null) {
                                                    dd4Var2 = new dd4(new g94[16]);
                                                }
                                                if (g94VarF != null) {
                                                    dd4Var2.b(g94VarF);
                                                    g94VarF = null;
                                                }
                                                dd4Var2.b(g94Var4);
                                            }
                                        }
                                    }
                                    if (i4 == 1) {
                                    }
                                }
                                g94VarF = ma3.f(dd4Var2);
                            }
                        }
                        g94Var3 = g94Var3.e;
                    }
                }
                layoutNodeO2 = layoutNodeO2.x();
                g94Var3 = (layoutNodeO2 == null || (tpVar3 = layoutNodeO2.s0) == null) ? null : (lf6) tpVar3.f;
            }
            dh5Var = (dh5) g94VarF;
        } else {
            dh5Var = null;
        }
        if (dh5Var != null) {
            if (!dh5Var.f2347a.c0) {
                p13.b("visitAncestors called on an unattached node");
            }
            g94 g94Var5 = dh5Var.f2347a.e;
            LayoutNode layoutNodeO3 = ma3.O(dh5Var);
            ArrayList arrayList = null;
            while (layoutNodeO3 != null) {
                if ((((g94) layoutNodeO3.s0.i).d & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                    while (g94Var5 != null) {
                        if ((g94Var5.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                            g94 g94VarF3 = g94Var5;
                            dd4 dd4Var3 = null;
                            while (g94VarF3 != null) {
                                if (g94VarF3 instanceof dh5) {
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(g94VarF3);
                                } else if ((g94VarF3.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0 && (g94VarF3 instanceof ln1)) {
                                    int i5 = 0;
                                    for (g94 g94Var6 = ((ln1) g94VarF3).e0; g94Var6 != null; g94Var6 = g94Var6.f) {
                                        if ((g94Var6.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                                            i5++;
                                            if (i5 == 1) {
                                                g94VarF3 = g94Var6;
                                            } else {
                                                if (dd4Var3 == null) {
                                                    dd4Var3 = new dd4(new g94[16]);
                                                }
                                                if (g94VarF3 != null) {
                                                    dd4Var3.b(g94VarF3);
                                                    g94VarF3 = null;
                                                }
                                                dd4Var3.b(g94Var6);
                                            }
                                        }
                                    }
                                    if (i5 == 1) {
                                    }
                                }
                                g94VarF3 = ma3.f(dd4Var3);
                            }
                        }
                        g94Var5 = g94Var5.e;
                    }
                }
                layoutNodeO3 = layoutNodeO3.x();
                g94Var5 = (layoutNodeO3 == null || (tpVar2 = layoutNodeO3.s0) == null) ? null : (lf6) tpVar2.f;
            }
            if (arrayList != null && arrayList.size() - 1 >= 0) {
                while (true) {
                    int i6 = size - 1;
                    ((dh5) arrayList.get(size)).getClass();
                    if (i6 < 0) {
                        break;
                    }
                    size = i6;
                }
            }
            g94 g94VarF4 = dh5Var.f2347a;
            dd4 dd4Var4 = null;
            while (g94VarF4 != null) {
                if (!(g94VarF4 instanceof dh5) && (g94VarF4.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0 && (g94VarF4 instanceof ln1)) {
                    int i7 = 0;
                    for (g94 g94Var7 = ((ln1) g94VarF4).e0; g94Var7 != null; g94Var7 = g94Var7.f) {
                        if ((g94Var7.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                            i7++;
                            if (i7 == 1) {
                                g94VarF4 = g94Var7;
                            } else {
                                if (dd4Var4 == null) {
                                    dd4Var4 = new dd4(new g94[16]);
                                }
                                if (g94VarF4 != null) {
                                    dd4Var4.b(g94VarF4);
                                    g94VarF4 = null;
                                }
                                dd4Var4.b(g94Var7);
                            }
                        }
                    }
                    if (i7 == 1) {
                    }
                }
                g94VarF4 = ma3.f(dd4Var4);
            }
            if (!((Boolean) egVar.invoke()).booleanValue()) {
                g94 g94VarF5 = dh5Var.f2347a;
                dd4 dd4Var5 = null;
                while (g94VarF5 != null) {
                    if (!(g94VarF5 instanceof dh5) && (g94VarF5.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0 && (g94VarF5 instanceof ln1)) {
                        int i8 = 0;
                        for (g94 g94Var8 = ((ln1) g94VarF5).e0; g94Var8 != null; g94Var8 = g94Var8.f) {
                            if ((g94Var8.c & Http2.INITIAL_MAX_FRAME_SIZE) != 0) {
                                i8++;
                                if (i8 == 1) {
                                    g94VarF5 = g94Var8;
                                } else {
                                    if (dd4Var5 == null) {
                                        dd4Var5 = new dd4(new g94[16]);
                                    }
                                    if (g94VarF5 != null) {
                                        dd4Var5.b(g94VarF5);
                                        g94VarF5 = null;
                                    }
                                    dd4Var5.b(g94Var8);
                                }
                            }
                        }
                        if (i8 == 1) {
                        }
                    }
                    g94VarF5 = ma3.f(dd4Var5);
                }
                if (arrayList != null) {
                    int size2 = arrayList.size();
                    for (int i9 = 0; i9 < size2; i9++) {
                        rb rbVar = ((dh5) arrayList.get(i9)).d0;
                    }
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x0101, code lost:
    
        r5.getAndroidViewsHandler$ui_release().dispatchGenericMotionEvent(r24);
        r5 = r2.e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x010a, code lost:
    
        if (r5 != r14) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x010d, code lost:
    
        r2.e = r14;
        defpackage.ug.E(r2, r14, 128, null, 12);
        defpackage.ug.E(r2, r5, androidx.core.app.NotificationCompat.FLAG_LOCAL_ONLY, null, 12);
     */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0151  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean dispatchHoverEvent(android.view.MotionEvent r24) {
        /*
            Method dump skipped, instruction units count: 346
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.platform.AndroidComposeView.dispatchHoverEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int i = 0;
        if (!isFocused()) {
            return ((rf2) getFocusOwner()).d(keyEvent, new eg(i, this, keyEvent));
        }
        int metaState = keyEvent.getMetaState();
        this.b0.getClass();
        ((x36) mj7.f4172a).setValue(new fx4(metaState));
        return ((rf2) getFocusOwner()).d(keyEvent, xw0.Y) || super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEventPreIme(KeyEvent keyEvent) {
        tp tpVar;
        if (isFocused()) {
            rf2 rf2Var = (rf2) getFocusOwner();
            if (rf2Var.d.e) {
                System.out.println((Object) "FocusRelatedWarning: Dispatching intercepted soft keyboard event while the focus system is invalidated.");
            } else {
                zf2 zf2VarH = ch.H(rf2Var.c);
                if (zf2VarH != null) {
                    if (!zf2VarH.f2347a.c0) {
                        p13.b("visitAncestors called on an unattached node");
                    }
                    g94 g94Var = zf2VarH.f2347a;
                    LayoutNode layoutNodeO = ma3.O(zf2VarH);
                    while (layoutNodeO != null) {
                        if ((((g94) layoutNodeO.s0.i).d & 131072) != 0) {
                            while (g94Var != null) {
                                if ((g94Var.c & 131072) != 0) {
                                    g94 g94VarF = g94Var;
                                    dd4 dd4Var = null;
                                    while (g94VarF != null) {
                                        if ((g94VarF.c & 131072) != 0 && (g94VarF instanceof ln1)) {
                                            int i = 0;
                                            for (g94 g94Var2 = ((ln1) g94VarF).e0; g94Var2 != null; g94Var2 = g94Var2.f) {
                                                if ((g94Var2.c & 131072) != 0) {
                                                    i++;
                                                    if (i == 1) {
                                                        g94VarF = g94Var2;
                                                    } else {
                                                        if (dd4Var == null) {
                                                            dd4Var = new dd4(new g94[16]);
                                                        }
                                                        if (g94VarF != null) {
                                                            dd4Var.b(g94VarF);
                                                            g94VarF = null;
                                                        }
                                                        dd4Var.b(g94Var2);
                                                    }
                                                }
                                            }
                                            if (i == 1) {
                                            }
                                        }
                                        g94VarF = ma3.f(dd4Var);
                                    }
                                }
                                g94Var = g94Var.e;
                            }
                        }
                        layoutNodeO = layoutNodeO.x();
                        g94Var = (layoutNodeO == null || (tpVar = layoutNodeO.s0) == null) ? null : (lf6) tpVar.f;
                    }
                }
            }
        }
        return super.dispatchKeyEventPreIme(keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchProvideStructure(ViewStructure viewStructure) {
        if (Build.VERSION.SDK_INT < 28) {
            vg.f6087a.a(viewStructure, getView());
        } else {
            super.dispatchProvideStructure(viewStructure);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (this.o1) {
            o6 o6Var = this.n1;
            removeCallbacks(o6Var);
            MotionEvent motionEvent2 = this.g1;
            motionEvent2.getClass();
            if (motionEvent.getActionMasked() == 0 && motionEvent2.getSource() == motionEvent.getSource() && motionEvent2.getToolType(0) == motionEvent.getToolType(0)) {
                this.o1 = false;
            } else {
                o6Var.run();
            }
        }
        if (!n(motionEvent) && isAttachedToWindow() && (motionEvent.getActionMasked() != 2 || p(motionEvent))) {
            int iK = k(motionEvent);
            if ((iK & 2) != 0) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            if ((iK & 1) != 0) {
                return true;
            }
        }
        return false;
    }

    public final View findViewByAccessibilityIdTraversal(int accessibilityId) throws IllegalAccessException, InvocationTargetException {
        try {
            if (Build.VERSION.SDK_INT < 29) {
                return i(accessibilityId, this);
            }
            Method declaredMethod = View.class.getDeclaredMethod("findViewByAccessibilityIdTraversal", Integer.TYPE);
            declaredMethod.setAccessible(true);
            Object objInvoke = declaredMethod.invoke(this, Integer.valueOf(accessibilityId));
            if (objInvoke instanceof View) {
                return (View) objInvoke;
            }
            return null;
        } catch (NoSuchMethodException unused) {
            return null;
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i) {
        ha5 ha5VarF;
        if (view == null || this.F0.c) {
            return super.focusSearch(view, i);
        }
        Object obj = kf2.f.get();
        obj.getClass();
        View viewB = ((kf2) obj).b(i, view, this);
        if (view == this) {
            zf2 zf2VarH = ch.H(((rf2) getFocusOwner()).c);
            ha5VarF = zf2VarH != null ? ch.I(zf2VarH) : null;
            if (ha5VarF == null) {
                ha5VarF = kw7.F(view, this);
            }
        } else {
            ha5VarF = kw7.F(view, this);
        }
        hf2 hf2VarF0 = kw7.f0(i);
        int i2 = hf2VarF0 != null ? hf2VarF0.f2602a : 6;
        pb5 pb5Var = new pb5();
        if (((rf2) getFocusOwner()).e(i2, ha5VarF, new gg(0, pb5Var)) != null) {
            Object obj2 = pb5Var.f4783a;
            if (obj2 != null) {
                if (viewB != null) {
                    if (i2 == 1 || i2 == 2) {
                        return super.focusSearch(view, i);
                    }
                    if (yr5.p(ch.I((zf2) obj2), kw7.F(viewB, this), ha5VarF, i2)) {
                    }
                }
                return this;
            }
            if (viewB == null) {
            }
            return viewB;
        }
        return view;
    }

    public final wl getAndroidViewsHandler$ui_release() {
        if (this.C0 == null) {
            wl wlVar = new wl(getContext());
            this.C0 = wlVar;
            addView(wlVar, -1);
            requestLayout();
        }
        wl wlVar2 = this.C0;
        wlVar2.getClass();
        return wlVar2;
    }

    @Override // defpackage.do4
    public g10 getAutofill() {
        return this.v0;
    }

    @Override // defpackage.do4
    public l10 getAutofillManager() {
        return this._autofillManager;
    }

    @Override // defpackage.do4
    public m10 getAutofillTree() {
        return this.autofillTree;
    }

    public final Function1<Configuration, Unit> getConfigurationChangeObserver() {
        return this.configurationChangeObserver;
    }

    /* JADX INFO: renamed from: getContentCaptureManager$ui_release, reason: from getter */
    public final oh getContentCaptureManager() {
        return this.contentCaptureManager;
    }

    @Override // defpackage.do4
    public CoroutineContext getCoroutineContext() {
        return this.coroutineContext;
    }

    @Override // defpackage.do4
    public co1 getDensity() {
        return (co1) ((x36) this.density).getValue();
    }

    public ha5 getEmbeddedViewFocusRect() {
        if (isFocused()) {
            zf2 zf2VarH = ch.H(((rf2) getFocusOwner()).c);
            if (zf2VarH != null) {
                return ch.I(zf2VarH);
            }
            return null;
        }
        View viewFindFocus = findFocus();
        if (viewFindFocus != null) {
            return kw7.F(viewFindFocus, this);
        }
        return null;
    }

    @Override // defpackage.do4
    public qf2 getFocusOwner() {
        return this.i;
    }

    @Override // android.view.View
    public final void getFocusedRect(Rect rect) {
        ha5 embeddedViewFocusRect = getEmbeddedViewFocusRect();
        if (embeddedViewFocusRect != null) {
            rect.left = Math.round(embeddedViewFocusRect.f2578a);
            rect.top = Math.round(embeddedViewFocusRect.b);
            rect.right = Math.round(embeddedViewFocusRect.c);
            rect.bottom = Math.round(embeddedViewFocusRect.d);
            return;
        }
        if (Intrinsics.a(((rf2) getFocusOwner()).e(6, null, rb.d), Boolean.TRUE)) {
            super.getFocusedRect(rect);
        } else {
            rect.set(Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
        }
    }

    @Override // defpackage.do4
    public hg2 getFontFamilyResolver() {
        return (hg2) ((x36) this.fontFamilyResolver).getValue();
    }

    @Override // defpackage.do4
    public fg2 getFontLoader() {
        return this.Y0;
    }

    @Override // defpackage.do4
    public ip2 getGraphicsContext() {
        return this.n0;
    }

    @Override // defpackage.do4
    public vs2 getHapticFeedBack() {
        return this.c1;
    }

    public boolean getHasPendingMeasureOrLayout() {
        return this.F0.b.r();
    }

    @Override // android.view.View
    public int getImportantForAutofill() {
        return 1;
    }

    @Override // defpackage.do4
    public h23 getInputModeManager() {
        return this.d1;
    }

    public final q23 getInsetsListener() {
        return this.insetsListener;
    }

    /* JADX INFO: renamed from: getLastMatrixRecalculationAnimationTime$ui_release, reason: from getter */
    public final long getLastMatrixRecalculationAnimationTime() {
        return this.lastMatrixRecalculationAnimationTime;
    }

    @Override // android.view.View, android.view.ViewParent, defpackage.do4
    public od3 getLayoutDirection() {
        return (od3) ((x36) this.layoutDirection).getValue();
    }

    public long getMeasureIteration() {
        ws3 ws3Var = this.F0;
        if (!ws3Var.c) {
            p13.a("measureIteration should be only used during the measure/layout pass");
        }
        return ws3Var.g;
    }

    @Override // defpackage.do4
    public l94 getModifierLocalManager() {
        return this.modifierLocalManager;
    }

    @Override // defpackage.do4
    public AndroidComposeView getOutOfFrameExecutor() {
        if (isAttachedToWindow()) {
            return this;
        }
        return null;
    }

    @Override // defpackage.do4
    public su4 getPlacementScope() {
        int i = uu4.b;
        return new dp3(this, 1);
    }

    @Override // defpackage.do4
    public zw4 getPointerIconService() {
        return this.u1;
    }

    @Override // defpackage.do4
    public ja5 getRectManager() {
        return this.rectManager;
    }

    @Override // defpackage.do4
    public LayoutNode getRoot() {
        return this.root;
    }

    public ah5 getRootForTest() {
        return this.i0;
    }

    public final boolean getScrollCaptureInProgress$ui_release() {
        xq1 xq1Var;
        if (Build.VERSION.SDK_INT < 31 || (xq1Var = this.s1) == null) {
            return false;
        }
        return ((Boolean) ((x36) ((ad4) xq1Var.b)).getValue()).booleanValue();
    }

    @Override // defpackage.do4
    public as5 getSemanticsOwner() {
        return this.semanticsOwner;
    }

    @Override // defpackage.do4
    public be3 getSharedDrawScope() {
        return this.sharedDrawScope;
    }

    @Override // defpackage.do4
    public boolean getShowLayoutBounds() {
        return Build.VERSION.SDK_INT >= 30 ? po.f4847a.a(this) : this.showLayoutBounds;
    }

    @Override // defpackage.do4
    public fo4 getSnapshotObserver() {
        return this.snapshotObserver;
    }

    @Override // defpackage.do4
    public g46 getSoftwareKeyboardController() {
        return this.X0;
    }

    @Override // defpackage.do4
    public ij6 getTextInputService() {
        return this.textInputService;
    }

    @Override // defpackage.do4
    public pk6 getTextToolbar() {
        return this.f1;
    }

    public final zg5 getUncaughtExceptionHandler$ui_release() {
        return null;
    }

    public View getView() {
        return this;
    }

    @Override // defpackage.do4
    public uc7 getViewConfiguration() {
        return this.d0;
    }

    public final bg getViewTreeOwners() {
        return (bg) this.P0.getValue();
    }

    @Override // defpackage.do4
    public lj7 getWindowInfo() {
        return this.b0;
    }

    /* JADX INFO: renamed from: get_autofillManager$ui_release, reason: from getter */
    public final qf get_autofillManager() {
        return this._autofillManager;
    }

    public final void j(LayoutNode layoutNode, boolean z) {
        this.F0.f(layoutNode, z);
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x007b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int k(android.view.MotionEvent r17) {
        /*
            Method dump skipped, instruction units count: 373
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.platform.AndroidComposeView.k(android.view.MotionEvent):int");
    }

    public final void m(LayoutNode layoutNode) {
        this.F0.p(layoutNode, false);
        dd4 dd4VarC = layoutNode.C();
        Object[] objArr = dd4VarC.f1699a;
        int i = dd4VarC.c;
        for (int i2 = 0; i2 < i; i2++) {
            m((LayoutNode) objArr[i2]);
        }
    }

    public final boolean o(MotionEvent motionEvent) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        return 0.0f <= x && x <= ((float) getWidth()) && 0.0f <= y && y <= ((float) getHeight());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        si3 lifecycle;
        ej3 ej3Var;
        nv5 nv5Var;
        super.onAttachedToWindow();
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
            setShowLayoutBounds(qp7.u());
        }
        this.insetsListener.onViewAttachedToWindow(this);
        if (i > 28) {
            if (z1 == null) {
                xb xbVar = new xb(i);
                z1 = xbVar;
                StrictMode.VmPolicy vmPolicy = StrictMode.getVmPolicy();
                try {
                    if (v1 == null) {
                        v1 = Class.forName("android.os.SystemProperties");
                    }
                    if (x1 == null) {
                        StrictMode.setVmPolicy(StrictMode.VmPolicy.LAX);
                        Class cls = v1;
                        x1 = cls != null ? cls.getDeclaredMethod("addChangeCallback", Runnable.class) : null;
                    }
                    Method method = x1;
                    if (method != null) {
                        method.invoke(null, xbVar);
                    }
                } catch (Throwable unused) {
                }
                StrictMode.setVmPolicy(vmPolicy);
            }
            fc4 fc4Var = y1;
            synchronized (fc4Var) {
                fc4Var.a(this);
            }
        }
        ((x36) this.b0.f812a).setValue(Boolean.valueOf(hasWindowFocus()));
        this.b0.getClass();
        this.b0.getClass();
        m(getRoot());
        l(getRoot());
        getSnapshotObserver().f2204a.d();
        if (e() && (nv5Var = this.v0) != null) {
            i10 i10Var = i10.f2741a;
            i10Var.getClass();
            ((AutofillManager) nv5Var.c).registerCallback(h10.f(i10Var));
        }
        ej3 ej3VarI = os5.i(this);
        tm5 tm5VarF = kf.f(this);
        bg viewTreeOwners = getViewTreeOwners();
        if (viewTreeOwners == null || (ej3VarI != null && tm5VarF != null && (ej3VarI != (ej3Var = viewTreeOwners.f578a) || tm5VarF != ej3Var))) {
            if (ej3VarI == null) {
                vk5.k("Composed into the View which doesn't propagate ViewTreeLifecycleOwner!");
                return;
            }
            if (tm5VarF == null) {
                vk5.k("Composed into the View which doesn't propagateViewTreeSavedStateRegistryOwner!");
                return;
            }
            if (viewTreeOwners != null && (lifecycle = viewTreeOwners.f578a.getLifecycle()) != null) {
                lifecycle.c(this);
            }
            ej3VarI.getLifecycle().a(this);
            bg bgVar = new bg(ej3VarI, tm5VarF);
            set_viewTreeOwners(bgVar);
            Function1 function1 = this.Q0;
            if (function1 != null) {
                function1.invoke(bgVar);
            }
            this.Q0 = null;
        }
        ((x36) this.d1.f2752a).setValue(new g23(isInTouchMode() ? 1 : 2));
        bg viewTreeOwners2 = getViewTreeOwners();
        si3 lifecycle2 = viewTreeOwners2 != null ? viewTreeOwners2.f578a.getLifecycle() : null;
        if (lifecycle2 == null) {
            throw qe0.f("No lifecycle owner exists");
        }
        lifecycle2.a(this);
        lifecycle2.a(this.contentCaptureManager);
        getViewTreeObserver().addOnGlobalLayoutListener(this.R0);
        getViewTreeObserver().addOnScrollChangedListener(this.S0);
        getViewTreeObserver().addOnTouchModeChangeListener(this.T0);
        if (Build.VERSION.SDK_INT >= 31) {
            zg.f6998a.b(this);
        }
        qf qfVar = this._autofillManager;
        if (qfVar != null) {
            ((rf2) getFocusOwner()).g.a(qfVar);
            getSemanticsOwner().d.a(qfVar);
        }
    }

    @Override // android.view.View
    public final boolean onCheckIsTextEditor() {
        hw5 hw5Var = (hw5) this.W0.get();
        xj xjVar = (xj) (hw5Var != null ? hw5Var.b : null);
        if (xjVar == null) {
            return this.U0.d;
        }
        hw5 hw5Var2 = (hw5) xjVar.d.get();
        f23 f23Var = (f23) (hw5Var2 != null ? hw5Var2.b : null);
        return f23Var != null && (f23Var.e ^ true);
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setDensity(kw7.o(getContext()));
        this.b0.getClass();
        int i = Build.VERSION.SDK_INT;
        if ((i >= 31 ? configuration.fontWeightAdjustment : 0) != this.a1) {
            this.a1 = i >= 31 ? configuration.fontWeightAdjustment : 0;
            setFontFamilyResolver(ew.n(getContext()));
        }
        this.configurationChangeObserver.invoke(configuration);
    }

    @Override // android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        int i;
        hw5 hw5Var = (hw5) this.W0.get();
        xj xjVar = (xj) (hw5Var != null ? hw5Var.b : null);
        if (xjVar == null) {
            kj6 kj6Var = this.U0;
            if (kj6Var.d) {
                sz2 sz2Var = kj6Var.h;
                bj6 bj6Var = kj6Var.g;
                int i2 = sz2Var.d;
                if (i2 == 1) {
                    i = 0;
                } else if (i2 == 0) {
                    i = 1;
                } else if (i2 == 2) {
                    i = 2;
                } else if (i2 == 6) {
                    i = 5;
                } else if (i2 == 5) {
                    i = 7;
                } else if (i2 == 3) {
                    i = 3;
                } else if (i2 == 4) {
                    i = 4;
                } else {
                    if (i2 != 7) {
                        vk5.k("invalid ImeAction");
                        return null;
                    }
                    i = 6;
                }
                editorInfo.imeOptions = i;
                int i3 = sz2Var.c;
                if (i3 == 1) {
                    editorInfo.inputType = 1;
                } else if (i3 == 2) {
                    editorInfo.inputType = 1;
                    editorInfo.imeOptions = Integer.MIN_VALUE | i;
                } else if (i3 == 3) {
                    editorInfo.inputType = 2;
                } else if (i3 == 4) {
                    editorInfo.inputType = 3;
                } else if (i3 == 5) {
                    editorInfo.inputType = 17;
                } else if (i3 == 6) {
                    editorInfo.inputType = 33;
                } else if (i3 == 7) {
                    editorInfo.inputType = 129;
                } else if (i3 == 8) {
                    editorInfo.inputType = 18;
                } else {
                    if (i3 != 9) {
                        vk5.k("Invalid Keyboard Type");
                        return null;
                    }
                    editorInfo.inputType = 8194;
                }
                int i4 = editorInfo.inputType;
                if ((i4 & 1) == 1) {
                    editorInfo.inputType = i4 | 131072;
                    if (i2 == 1) {
                        editorInfo.imeOptions |= 1073741824;
                    }
                }
                int i5 = editorInfo.inputType;
                if ((i5 & 1) == 1) {
                    int i6 = sz2Var.f5559a;
                    if (i6 == 1) {
                        editorInfo.inputType = i5 | 4096;
                    } else if (i6 == 2) {
                        editorInfo.inputType = i5 | Segment.SIZE;
                    } else if (i6 == 3) {
                        editorInfo.inputType = i5 | Http2.INITIAL_MAX_FRAME_SIZE;
                    }
                    if (sz2Var.b) {
                        editorInfo.inputType |= 32768;
                    }
                }
                long j = bj6Var.b;
                int i7 = gk6.c;
                editorInfo.initialSelStart = (int) (j >> 32);
                editorInfo.initialSelEnd = (int) (j & KeyboardMap.kValueMask);
                fq3.F(editorInfo, bj6Var.f602a.b);
                editorInfo.imeOptions |= 33554432;
                if (ry1.d()) {
                    ry1.a().i(editorInfo);
                }
                ea5 ea5Var = new ea5(kj6Var.g, new z95(kj6Var, 10), kj6Var.h.b);
                kj6Var.i.add(new WeakReference(ea5Var));
                return ea5Var;
            }
        } else {
            hw5 hw5Var2 = (hw5) xjVar.d.get();
            f23 f23Var = (f23) (hw5Var2 != null ? hw5Var2.b : null);
            if (f23Var != null) {
                synchronized (f23Var.c) {
                    if (f23Var.e) {
                        return null;
                    }
                    fa5 fa5VarA = f23Var.f2079a.a(editorInfo);
                    mc mcVar = new mc(f23Var, 21);
                    int i8 = Build.VERSION.SDK_INT;
                    InputConnection jj4Var = i8 >= 34 ? new jj4(fa5VarA, mcVar) : i8 >= 25 ? new ij4(fa5VarA, mcVar) : new hj4(fa5VarA, mcVar);
                    f23Var.d.b(new vh7(jj4Var));
                    return jj4Var;
                }
            }
        }
        return null;
    }

    @Override // android.view.View
    public final void onCreateVirtualViewTranslationRequests(long[] jArr, int[] iArr, Consumer consumer) {
        wr5 wr5Var;
        oh ohVar = this.contentCaptureManager;
        ohVar.getClass();
        for (long j : jArr) {
            zr5 zr5Var = (zr5) ohVar.e().b((int) j);
            if (zr5Var != null && (wr5Var = zr5Var.f7075a) != null) {
                xf.r();
                ViewTranslationRequest.Builder builderM = xf.m(ohVar.f4597a.getAutofillId(), wr5Var.g);
                Object objG = wr5Var.d.f5289a.g(bs5.z);
                if (objG == null) {
                    objG = null;
                }
                List list = (List) objG;
                if (list != null) {
                    builderM.setValue("android:text", TranslationRequestValue.forText(new vn(tl3.a(list, "\n", null, 62))));
                    consumer.accept(builderM.build());
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        nv5 nv5Var;
        super.onDetachedFromWindow();
        this.insetsListener.onViewDetachedFromWindow(this);
        if (this.f) {
            View view = this.e;
            if (view == null) {
                Intrinsics.e("frameRateCategoryView");
                throw null;
            }
            removeView(view);
        }
        int i = Build.VERSION.SDK_INT;
        if (i > 28) {
            fc4 fc4Var = y1;
            synchronized (fc4Var) {
                fc4Var.i(this);
            }
        }
        c46 c46Var = getSnapshotObserver().f2204a;
        mb mbVar = c46Var.h;
        if (mbVar != null) {
            mbVar.e();
        }
        c46Var.a();
        this.b0.getClass();
        bg viewTreeOwners = getViewTreeOwners();
        si3 lifecycle = viewTreeOwners != null ? viewTreeOwners.f578a.getLifecycle() : null;
        if (lifecycle == null) {
            throw qe0.f("No lifecycle owner exists");
        }
        lifecycle.c(this.contentCaptureManager);
        lifecycle.c(this);
        if (e() && (nv5Var = this.v0) != null) {
            i10 i10Var = i10.f2741a;
            i10Var.getClass();
            ((AutofillManager) nv5Var.c).unregisterCallback(h10.f(i10Var));
        }
        getViewTreeObserver().removeOnGlobalLayoutListener(this.R0);
        getViewTreeObserver().removeOnScrollChangedListener(this.S0);
        getViewTreeObserver().removeOnTouchModeChangeListener(this.T0);
        if (i >= 31) {
            zg.f6998a.a(this);
        }
        qf qfVar = this._autofillManager;
        if (qfVar != null) {
            getSemanticsOwner().d.i(qfVar);
            ((rf2) getFocusOwner()).g.i(qfVar);
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    public final void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        if (z || hasFocus()) {
            return;
        }
        h08.w(((rf2) getFocusOwner()).c, true);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.lastMatrixRecalculationAnimationTime = 0L;
        this.F0.j(this.p1);
        this.D0 = null;
        H();
        if (this.C0 != null) {
            getAndroidViewsHandler$ui_release().layout(0, 0, i3 - i, i4 - i2);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        ws3 ws3Var = this.F0;
        Trace.beginSection("AndroidOwner:onMeasure");
        try {
            if (!isAttachedToWindow()) {
                m(getRoot());
            }
            long jH = h(i);
            fx6 fx6Var = gx6.b;
            int i3 = (int) (jH >>> 32);
            int i4 = (int) (jH & KeyboardMap.kValueMask);
            long jH2 = h(i2);
            long jP = b33.p(i3, i4, (int) (jH2 >>> 32), (int) (KeyboardMap.kValueMask & jH2));
            nz0 nz0Var = this.D0;
            if (nz0Var == null) {
                this.D0 = new nz0(jP);
                this.E0 = false;
            } else if (!nz0.b(nz0Var.f4493a, jP)) {
                this.E0 = true;
            }
            ws3Var.q(jP);
            ws3Var.l();
            setMeasuredDimension(getRoot().A(), getRoot().p());
            if (this.C0 != null) {
                getAndroidViewsHandler$ui_release().measure(View.MeasureSpec.makeMeasureSpec(getRoot().A(), 1073741824), View.MeasureSpec.makeMeasureSpec(getRoot().p(), 1073741824));
            }
        } finally {
            Trace.endSection();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x009c  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onProvideAutofillVirtualStructure(android.view.ViewStructure r12, int r13) {
        /*
            Method dump skipped, instruction units count: 265
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.platform.AndroidComposeView.onProvideAutofillVirtualStructure(android.view.ViewStructure, int):void");
    }

    @Override // android.view.ViewGroup, android.view.View
    public final PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i) {
        yw4 yw4Var;
        int toolType = motionEvent.getToolType(i);
        if (motionEvent.isFromSource(8194) || !motionEvent.isFromSource(16386) || (!(toolType == 2 || toolType == 4) || (yw4Var = ((ig) getPointerIconService()).f2837a) == null)) {
            return super.onResolvePointerIcon(motionEvent, i);
        }
        Context context = getContext();
        return yw4Var instanceof yj ? PointerIcon.getSystemIcon(context, ((yj) yw4Var).b) : PointerIcon.getSystemIcon(context, 1000);
    }

    @Override // androidx.lifecycle.DefaultLifecycleObserver
    public final void onResume(ej3 ej3Var) {
        if (Build.VERSION.SDK_INT < 30) {
            setShowLayoutBounds(qp7.u());
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        if (this.b) {
            od3 od3Var = i != 0 ? i != 1 ? null : od3.b : od3.f4581a;
            if (od3Var == null) {
                od3Var = od3.f4581a;
            }
            setLayoutDirection(od3Var);
        }
    }

    @Override // android.view.View
    public final void onScrollCaptureSearch(Rect rect, Point point, Consumer consumer) {
        xq1 xq1Var;
        if (Build.VERSION.SDK_INT < 31 || (xq1Var = this.s1) == null) {
            return;
        }
        as5 semanticsOwner = getSemanticsOwner();
        CoroutineContext coroutineContext = getCoroutineContext();
        dd4 dd4Var = new dd4(new ko5[16]);
        gq3.T(semanticsOwner.a(), 0, new jo5(1, 8, dd4.class, dd4Var, "add", "add(Ljava/lang/Object;)Z"));
        Arrays.sort(dd4Var.f1699a, 0, dd4Var.c, new nt0(new Function1[]{ah4.i0, ah4.j0}, 0));
        int i = dd4Var.c;
        ko5 ko5Var = (ko5) (i == 0 ? null : dd4Var.f1699a[i - 1]);
        if (ko5Var == null) {
            return;
        }
        y33 y33Var = ko5Var.c;
        tv0 tv0Var = new tv0(ko5Var.f3757a, y33Var, fu7.f(coroutineContext), xq1Var, this);
        NodeCoordinator nodeCoordinator = ko5Var.d;
        ha5 ha5VarI = ma3.q(nodeCoordinator).I(nodeCoordinator, true);
        long jA = y33Var.a();
        ScrollCaptureTarget scrollCaptureTargetG = df2.g(this, zi1.X(ma3.Q(ha5VarI)), new Point((int) (jA >> 32), (int) (jA & KeyboardMap.kValueMask)), tv0Var);
        scrollCaptureTargetG.setScrollBounds(zi1.X(y33Var));
        consumer.accept(scrollCaptureTargetG);
    }

    @Override // android.view.View
    public final void onVirtualViewTranslationResponses(LongSparseArray longSparseArray) {
        oh ohVar = this.contentCaptureManager;
        ohVar.getClass();
        if (Build.VERSION.SDK_INT < 31) {
            return;
        }
        if (Intrinsics.a(Looper.getMainLooper().getThread(), Thread.currentThread())) {
            dv7.E(ohVar, longSparseArray);
        } else {
            ohVar.f4597a.post(new mh(0, ohVar, longSparseArray));
        }
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z) {
        boolean zU;
        ((x36) this.b0.f812a).setValue(Boolean.valueOf(z));
        this.r1 = true;
        super.onWindowFocusChanged(z);
        if (!z || Build.VERSION.SDK_INT >= 30 || getShowLayoutBounds() == (zU = qp7.u())) {
            return;
        }
        setShowLayoutBounds(zU);
        l(getRoot());
    }

    public final boolean p(MotionEvent motionEvent) {
        MotionEvent motionEvent2;
        return (motionEvent.getPointerCount() == 1 && (motionEvent2 = this.g1) != null && motionEvent2.getPointerCount() == motionEvent.getPointerCount() && motionEvent.getRawX() == motionEvent2.getRawX() && motionEvent.getRawY() == motionEvent2.getRawY()) ? false : true;
    }

    public final void q(float[] fArr) {
        z();
        qs3.e(fArr, this.J0);
        float fIntBitsToFloat = Float.intBitsToFloat((int) (this.N0 >> 32));
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (this.N0 & KeyboardMap.kValueMask));
        float[] fArr2 = this.I0;
        qs3.d(fArr2);
        qs3.f(fArr2, fIntBitsToFloat, fIntBitsToFloat2);
        ch.R(fArr, fArr2);
    }

    public final long r(long j) {
        z();
        long jB = qs3.b(j, this.J0);
        float fIntBitsToFloat = Float.intBitsToFloat((int) (this.N0 >> 32)) + Float.intBitsToFloat((int) (jB >> 32));
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (this.N0 & KeyboardMap.kValueMask)) + Float.intBitsToFloat((int) (jB & KeyboardMap.kValueMask));
        return (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & KeyboardMap.kValueMask);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i, Rect rect) {
        if (isFocused()) {
            return true;
        }
        int iOrdinal = ((rf2) getFocusOwner()).c.H0().ordinal();
        if (iOrdinal == 0 || iOrdinal == 1 || iOrdinal == 2) {
            return super.requestFocus(i, rect);
        }
        int i2 = 0;
        if (iOrdinal != 3) {
            g.a();
            return false;
        }
        hf2 hf2VarF0 = kw7.f0(i);
        int i3 = hf2VarF0 != null ? hf2VarF0.f2602a : 7;
        return Intrinsics.a(((rf2) getFocusOwner()).e(i3, rect != null ? zi1.a0(rect) : null, new jg(i3, i2)), Boolean.TRUE);
    }

    public final void s(boolean z) {
        kg kgVar;
        ws3 ws3Var = this.F0;
        if (ws3Var.b.r() || ((dd4) ws3Var.e.b).c != 0) {
            Trace.beginSection("AndroidOwner:measureAndLayout");
            if (z) {
                try {
                    kgVar = this.p1;
                } finally {
                    Trace.endSection();
                }
            } else {
                kgVar = null;
            }
            if (ws3Var.j(kgVar)) {
                requestLayout();
            }
            ws3Var.a(false);
        }
    }

    public void setAccessibilityEventBatchIntervalMillis(long intervalMillis) {
        this.k0.h = intervalMillis;
    }

    public final void setConfigurationChangeObserver(Function1<? super Configuration, Unit> function1) {
        this.configurationChangeObserver = function1;
    }

    public final void setContentCaptureManager$ui_release(oh ohVar) {
        this.contentCaptureManager = ohVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [g94] */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v12 */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5, types: [g94] */
    /* JADX WARN: Type inference failed for: r3v6, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r3v9 */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v10 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v3, types: [dd4] */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6, types: [dd4] */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r5v5 */
    public void setCoroutineContext(CoroutineContext coroutineContext) {
        this.coroutineContext = coroutineContext;
        g94 g94Var = (g94) getRoot().s0.i;
        if (g94Var instanceof jc6) {
            ((jc6) g94Var).H0();
        }
        if (!g94Var.f2347a.c0) {
            p13.b("visitSubtreeIf called on an unattached node");
        }
        dd4 dd4Var = new dd4(new g94[16]);
        g94 g94Var2 = g94Var.f2347a;
        g94 g94Var3 = g94Var2.f;
        if (g94Var3 == null) {
            ma3.d(dd4Var, g94Var2);
        } else {
            dd4Var.b(g94Var3);
        }
        while (true) {
            int i = dd4Var.c;
            if (i == 0) {
                return;
            }
            g94 g94Var4 = (g94) dd4Var.k(i - 1);
            if ((g94Var4.d & 16) != 0) {
                for (g94 g94Var5 = g94Var4; g94Var5 != null; g94Var5 = g94Var5.f) {
                    if ((g94Var5.c & 16) != 0) {
                        ?? F = g94Var5;
                        ?? dd4Var2 = 0;
                        while (F != 0) {
                            if (F instanceof dx4) {
                                dx4 dx4Var = (dx4) F;
                                if (dx4Var instanceof jc6) {
                                    ((jc6) dx4Var).H0();
                                }
                            } else if ((F.c & 16) != 0 && (F instanceof ln1)) {
                                g94 g94Var6 = ((ln1) F).e0;
                                int i2 = 0;
                                F = F;
                                dd4Var2 = dd4Var2;
                                while (g94Var6 != null) {
                                    if ((g94Var6.c & 16) != 0) {
                                        i2++;
                                        dd4Var2 = dd4Var2;
                                        if (i2 == 1) {
                                            F = g94Var6;
                                        } else {
                                            if (dd4Var2 == 0) {
                                                dd4Var2 = new dd4(new g94[16]);
                                            }
                                            if (F != 0) {
                                                dd4Var2.b(F);
                                                F = 0;
                                            }
                                            dd4Var2.b(g94Var6);
                                        }
                                    }
                                    g94Var6 = g94Var6.f;
                                    F = F;
                                    dd4Var2 = dd4Var2;
                                }
                                if (i2 == 1) {
                                }
                            }
                            F = ma3.f(dd4Var2);
                        }
                    }
                }
            }
            ma3.d(dd4Var, g94Var4);
        }
    }

    public final void setLastMatrixRecalculationAnimationTime$ui_release(long j) {
        this.lastMatrixRecalculationAnimationTime = j;
    }

    public final void setOnViewTreeOwnersAvailable(Function1<? super bg, Unit> callback) {
        bg viewTreeOwners = getViewTreeOwners();
        if (viewTreeOwners != null) {
            callback.invoke(viewTreeOwners);
        }
        if (isAttachedToWindow()) {
            return;
        }
        this.Q0 = callback;
    }

    @Override // defpackage.do4
    public void setShowLayoutBounds(boolean z) {
        this.showLayoutBounds = z;
    }

    public void setUncaughtExceptionHandler(zg5 handler) {
        this.F0.getClass();
    }

    public final void setUncaughtExceptionHandler$ui_release(zg5 zg5Var) {
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public final void t(LayoutNode layoutNode, long j) {
        ws3 ws3Var = this.F0;
        Trace.beginSection("AndroidOwner:measureAndLayout");
        try {
            ws3Var.k(layoutNode, j);
            if (!ws3Var.b.r()) {
                ws3Var.a(false);
            }
            getRectManager().b();
        } finally {
            Trace.endSection();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:55:0x00ae, code lost:
    
        r4.k(0, r0);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void u() {
        /*
            r10 = this;
            boolean r0 = r10.x0
            r1 = 0
            r2 = 0
            if (r0 == 0) goto L48
            fo4 r0 = r10.getSnapshotObserver()
            c46 r0 = r0.f2204a
            java.lang.Object r3 = r0.g
            monitor-enter(r3)
            dd4 r0 = r0.f     // Catch: java.lang.Throwable -> L36
            int r4 = r0.c     // Catch: java.lang.Throwable -> L36
            r5 = r2
            r6 = r5
        L15:
            java.lang.Object[] r7 = r0.f1699a
            if (r5 >= r4) goto L3b
            r7 = r7[r5]     // Catch: java.lang.Throwable -> L36
            b46 r7 = (defpackage.b46) r7     // Catch: java.lang.Throwable -> L36
            r7.d()     // Catch: java.lang.Throwable -> L36
            sc4 r7 = r7.f     // Catch: java.lang.Throwable -> L36
            boolean r7 = r7.j()     // Catch: java.lang.Throwable -> L36
            if (r7 != 0) goto L2b
            int r6 = r6 + 1
            goto L38
        L2b:
            if (r6 <= 0) goto L38
            java.lang.Object[] r7 = r0.f1699a     // Catch: java.lang.Throwable -> L36
            int r8 = r5 - r6
            r9 = r7[r5]     // Catch: java.lang.Throwable -> L36
            r7[r8] = r9     // Catch: java.lang.Throwable -> L36
            goto L38
        L36:
            r10 = move-exception
            goto L46
        L38:
            int r5 = r5 + 1
            goto L15
        L3b:
            int r5 = r4 - r6
            java.util.Arrays.fill(r7, r5, r4, r1)     // Catch: java.lang.Throwable -> L36
            r0.c = r5     // Catch: java.lang.Throwable -> L36
            monitor-exit(r3)
            r10.x0 = r2
            goto L48
        L46:
            monitor-exit(r3)
            throw r10
        L48:
            wl r0 = r10.C0
            if (r0 == 0) goto L4f
            f(r0)
        L4f:
            boolean r0 = e()
            if (r0 == 0) goto L75
            qf r0 = r10._autofillManager
            if (r0 == 0) goto L75
            qb4 r3 = r0.h
            int r4 = r3.d
            if (r4 != 0) goto L6e
            boolean r4 = r0.i
            if (r4 == 0) goto L6e
            bk1 r4 = r0.f5012a
            java.lang.Object r4 = r4.b
            android.view.autofill.AutofillManager r4 = (android.view.autofill.AutofillManager) r4
            defpackage.bv4.v(r4)
            r0.i = r2
        L6e:
            int r3 = r3.d
            if (r3 == 0) goto L75
            r3 = 1
            r0.i = r3
        L75:
            fc4 r0 = r10.j1
            boolean r0 = r0.h()
            if (r0 == 0) goto Lb2
            fc4 r0 = r10.j1
            java.lang.Object r0 = r0.e(r2)
            if (r0 == 0) goto Lb2
            fc4 r0 = r10.j1
            int r0 = r0.b
            r3 = r2
        L8a:
            fc4 r4 = r10.j1
            if (r3 >= r0) goto Lae
            java.lang.Object r4 = r4.e(r3)
            kotlin.jvm.functions.Function0 r4 = (kotlin.jvm.functions.Function0) r4
            fc4 r5 = r10.j1
            if (r3 < 0) goto Laa
            int r6 = r5.b
            if (r3 >= r6) goto Laa
            java.lang.Object[] r5 = r5.f2137a
            r6 = r5[r3]
            r5[r3] = r1
            if (r4 == 0) goto La7
            r4.invoke()
        La7:
            int r3 = r3 + 1
            goto L8a
        Laa:
            r5.m(r3)
            throw r1
        Lae:
            r4.k(r2, r0)
            goto L75
        Lb2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.compose.ui.platform.AndroidComposeView.u():void");
    }

    public final void v(LayoutNode layoutNode) {
        ug ugVar = this.k0;
        ugVar.A = true;
        if (ugVar.v()) {
            ugVar.w(layoutNode);
        }
        oh ohVar = this.contentCaptureManager;
        ohVar.i = true;
        if (ohVar.f()) {
            ohVar.v.e(Unit.f3760a);
        }
    }

    public final void w(LayoutNode layoutNode, boolean z, boolean z2, boolean z3) {
        LayoutNode layoutNodeX;
        LayoutNode layoutNodeX2;
        ws3 ws3Var = this.F0;
        if (!z) {
            if (ws3Var.p(layoutNode, z2) && z3) {
                C(layoutNode);
                return;
            }
            return;
        }
        fs fsVar = ws3Var.b;
        LayoutNode layoutNode2 = layoutNode.i;
        de3 de3Var = layoutNode.t0;
        if (layoutNode2 == null) {
            p13.b("Error: requestLookaheadRemeasure cannot be called on a node outside LookaheadScope");
        }
        int iOrdinal = de3Var.d.ordinal();
        if (iOrdinal != 0) {
            if (iOrdinal == 1) {
                return;
            }
            if (iOrdinal != 2 && iOrdinal != 3) {
                if (iOrdinal != 4) {
                    g.a();
                    return;
                }
                if (!de3Var.e || z2) {
                    de3Var.e = true;
                    de3Var.p.j0 = true;
                    if (layoutNode.B0) {
                        return;
                    }
                    if ((Intrinsics.a(layoutNode.N(), Boolean.TRUE) || ws3.h(layoutNode)) && ((layoutNodeX = layoutNode.x()) == null || !layoutNodeX.t0.e)) {
                        fsVar.a(layoutNode, s53.f5378a);
                    } else if ((layoutNode.M() || ws3.i(layoutNode)) && ((layoutNodeX2 = layoutNode.x()) == null || !layoutNodeX2.s())) {
                        fsVar.a(layoutNode, s53.c);
                    }
                    if (ws3Var.d || !z3) {
                        return;
                    }
                    C(layoutNode);
                    return;
                }
                return;
            }
        }
        ws3Var.h.b(new vs3(layoutNode, true, z2));
    }

    public final void x(LayoutNode layoutNode, boolean z, boolean z2) {
        de3 de3Var = layoutNode.t0;
        ws3 ws3Var = this.F0;
        if (!z) {
            ws3Var.getClass();
            int iOrdinal = de3Var.d.ordinal();
            if (iOrdinal == 0 || iOrdinal == 1 || iOrdinal == 2 || iOrdinal == 3) {
                return;
            }
            if (iOrdinal != 4) {
                g.a();
                return;
            }
            LayoutNode layoutNodeX = layoutNode.x();
            boolean z3 = layoutNodeX == null || layoutNodeX.M();
            if (!z2) {
                if (layoutNode.s()) {
                    return;
                }
                if (layoutNode.q() && layoutNode.M() == z3 && layoutNode.M() == de3Var.p.i0) {
                    return;
                }
            }
            ys3 ys3Var = de3Var.p;
            ys3Var.k0 = true;
            ys3Var.l0 = true;
            if (!layoutNode.B0 && ys3Var.i0 && z3) {
                if ((layoutNodeX == null || !layoutNodeX.q()) && (layoutNodeX == null || !layoutNodeX.s())) {
                    ws3Var.b.a(layoutNode, s53.d);
                }
                if (ws3Var.d) {
                    return;
                }
                C(null);
                return;
            }
            return;
        }
        fs fsVar = ws3Var.b;
        int iOrdinal2 = de3Var.d.ordinal();
        if (iOrdinal2 != 0) {
            if (iOrdinal2 == 1) {
                return;
            }
            if (iOrdinal2 != 2) {
                if (iOrdinal2 == 3) {
                    return;
                }
                if (iOrdinal2 != 4) {
                    g.a();
                    return;
                }
            }
        }
        if ((de3Var.e || de3Var.f) && !z2) {
            return;
        }
        de3Var.f = true;
        de3Var.g = true;
        ys3 ys3Var2 = de3Var.p;
        ys3Var2.k0 = true;
        ys3Var2.l0 = true;
        if (layoutNode.B0) {
            return;
        }
        LayoutNode layoutNodeX2 = layoutNode.x();
        if (Intrinsics.a(layoutNode.N(), Boolean.TRUE) && ((layoutNodeX2 == null || !layoutNodeX2.t0.e) && (layoutNodeX2 == null || !layoutNodeX2.t0.f))) {
            fsVar.a(layoutNode, s53.b);
        } else if (layoutNode.M() && ((layoutNodeX2 == null || !layoutNodeX2.q()) && (layoutNodeX2 == null || !layoutNodeX2.s()))) {
            fsVar.a(layoutNode, s53.d);
        }
        if (ws3Var.d) {
            return;
        }
        C(null);
    }

    public final void y() {
        ug ugVar = this.k0;
        ugVar.A = true;
        if (ugVar.v() && !ugVar.L) {
            ugVar.L = true;
            ugVar.l.post(ugVar.N);
        }
        oh ohVar = this.contentCaptureManager;
        ohVar.i = true;
        if (!ohVar.f() || ohVar.c0) {
            return;
        }
        ohVar.c0 = true;
        ohVar.w.post(ohVar.d0);
    }

    public final void z() {
        if (this.M0) {
            return;
        }
        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        if (jCurrentAnimationTimeMillis != this.lastMatrixRecalculationAnimationTime) {
            this.lastMatrixRecalculationAnimationTime = jCurrentAnimationTimeMillis;
            td0 td0Var = this.q1;
            float[] fArr = this.J0;
            td0Var.a(this, fArr);
            qp7.C(fArr, this.K0);
            ViewParent parent = getParent();
            View view = this;
            while (parent instanceof ViewGroup) {
                view = (View) parent;
                parent = ((ViewGroup) view).getParent();
            }
            int[] iArr = this.H0;
            view.getLocationOnScreen(iArr);
            float f = iArr[0];
            float f2 = iArr[1];
            view.getLocationInWindow(iArr);
            this.N0 = (((long) Float.floatToRawIntBits(f - iArr[0])) << 32) | (((long) Float.floatToRawIntBits(f2 - iArr[1])) & KeyboardMap.kValueMask);
        }
    }

    @Override // defpackage.do4
    public nf getAccessibilityManager() {
        return this.accessibilityManager;
    }

    @Override // defpackage.do4
    public vf getClipboard() {
        return this.clipboard;
    }

    @Override // defpackage.do4
    public wf getClipboardManager() {
        return this.clipboardManager;
    }

    @Override // defpackage.do4
    public gi getDragAndDropManager() {
        return this.dragAndDropManager;
    }

    /* JADX INFO: renamed from: getLayoutNodes, reason: from getter and merged with bridge method [inline-methods] */
    public pb4 m0getLayoutNodes() {
        return this.layoutNodes;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        addView(view, -1);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParamsGenerateDefaultLayoutParams = generateDefaultLayoutParams();
        layoutParamsGenerateDefaultLayoutParams.width = i;
        layoutParamsGenerateDefaultLayoutParams.height = i2;
        addViewInLayout(view, -1, layoutParamsGenerateDefaultLayoutParams, true);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        addViewInLayout(view, i, layoutParams, true);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        addViewInLayout(view, -1, layoutParams, true);
    }
}

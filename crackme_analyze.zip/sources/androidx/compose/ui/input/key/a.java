package androidx.compose.ui.input.key;

import defpackage.h94;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(h94 h94Var, Function1 function1) {
        return h94Var.d(new KeyInputElement(function1, null));
    }

    public static final h94 b(h94 h94Var, Function1 function1) {
        return h94Var.d(new KeyInputElement(null, function1));
    }
}

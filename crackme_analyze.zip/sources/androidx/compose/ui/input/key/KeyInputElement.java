package androidx.compose.ui.input.key;

import defpackage.g94;
import defpackage.p94;
import defpackage.qa3;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/input/key/KeyInputElement;", "Lp94;", "Lqa3;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class KeyInputElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function1 f285a;
    public final Function1 b;

    public KeyInputElement(Function1 function1, Function1 function12) {
        this.f285a = function1;
        this.b = function12;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof KeyInputElement)) {
            return false;
        }
        KeyInputElement keyInputElement = (KeyInputElement) obj;
        return this.f285a == keyInputElement.f285a && this.b == keyInputElement.b;
    }

    @Override // defpackage.p94
    public final g94 f() {
        qa3 qa3Var = new qa3();
        qa3Var.d0 = this.f285a;
        qa3Var.e0 = this.b;
        return qa3Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        qa3 qa3Var = (qa3) g94Var;
        qa3Var.d0 = this.f285a;
        qa3Var.e0 = this.b;
    }

    public final int hashCode() {
        Function1 function1 = this.f285a;
        int iHashCode = (function1 != null ? function1.hashCode() : 0) * 31;
        Function1 function12 = this.b;
        return iHashCode + (function12 != null ? function12.hashCode() : 0);
    }
}

package androidx.compose.ui.input.pointer;

import defpackage.f53;
import defpackage.fm6;
import defpackage.g94;
import defpackage.l96;
import defpackage.ms1;
import defpackage.p94;
import defpackage.yj;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/input/pointer/StylusHoverIconModifierElement;", "Lp94;", "Ll96;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class StylusHoverIconModifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ms1 f288a;

    public StylusHoverIconModifierElement(ms1 ms1Var) {
        this.f288a = ms1Var;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof StylusHoverIconModifierElement)) {
            return false;
        }
        StylusHoverIconModifierElement stylusHoverIconModifierElement = (StylusHoverIconModifierElement) obj;
        yj yjVar = f53.f;
        return yjVar.equals(yjVar) && Intrinsics.a(this.f288a, stylusHoverIconModifierElement.f288a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new l96(f53.f, this.f288a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        l96 l96Var = (l96) g94Var;
        yj yjVar = f53.f;
        if (!Intrinsics.a(l96Var.e0, yjVar)) {
            l96Var.e0 = yjVar;
            if (l96Var.f0) {
                l96Var.H0();
            }
        }
        l96Var.d0 = this.f288a;
    }

    public final int hashCode() {
        int iF = fm6.f(1022 * 31, 31, false);
        ms1 ms1Var = this.f288a;
        return iF + (ms1Var != null ? ms1Var.hashCode() : 0);
    }

    public final String toString() {
        return "StylusHoverIconModifierElement(icon=" + f53.f + ", overrideDescendants=false, touchBoundsExpansion=" + this.f288a + ')';
    }
}

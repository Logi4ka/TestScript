package androidx.compose.ui.input.pointer;

import defpackage.g94;
import defpackage.p94;
import defpackage.xw4;
import defpackage.yj;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/input/pointer/PointerHoverIconModifierElement;", "Lp94;", "Lxw4;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class PointerHoverIconModifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final yj f287a;

    public PointerHoverIconModifierElement(yj yjVar) {
        this.f287a = yjVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof PointerHoverIconModifierElement) && this.f287a.equals(((PointerHoverIconModifierElement) obj).f287a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new xw4(this.f287a, null);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        xw4 xw4Var = (xw4) g94Var;
        yj yjVar = xw4Var.e0;
        yj yjVar2 = this.f287a;
        if (Intrinsics.a(yjVar, yjVar2)) {
            return;
        }
        xw4Var.e0 = yjVar2;
        if (xw4Var.f0) {
            xw4Var.H0();
        }
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + (this.f287a.b * 31);
    }

    public final String toString() {
        return "PointerHoverIconModifierElement(icon=" + this.f287a + ", overrideDescendants=false)";
    }
}

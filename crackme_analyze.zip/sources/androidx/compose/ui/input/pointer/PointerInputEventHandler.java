package androidx.compose.ui.input.pointer;

import defpackage.ex4;
import defpackage.f11;
import kotlin.Metadata;
import kotlin.Unit;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\bæ\u0080\u0001\u0018\u00002\u00020\u0001J\u0014\u0010\u0004\u001a\u00020\u0003*\u00020\u0002H¦B¢\u0006\u0004\b\u0004\u0010\u0005ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0006À\u0006\u0001"}, d2 = {"Landroidx/compose/ui/input/pointer/PointerInputEventHandler;", HttpUrl.FRAGMENT_ENCODE_SET, "Lex4;", HttpUrl.FRAGMENT_ENCODE_SET, "invoke", "(Lex4;Lf11;)Ljava/lang/Object;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public interface PointerInputEventHandler {
    Object invoke(ex4 ex4Var, f11<? super Unit> f11Var);
}

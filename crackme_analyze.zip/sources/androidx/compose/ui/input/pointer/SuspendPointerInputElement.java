package androidx.compose.ui.input.pointer;

import defpackage.g94;
import defpackage.jc6;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/input/pointer/SuspendPointerInputElement;", "Lp94;", "Ljc6;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class SuspendPointerInputElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f289a;
    public final Object b;
    public final PointerInputEventHandler c;

    public SuspendPointerInputElement(Object obj, Object obj2, PointerInputEventHandler pointerInputEventHandler, int i) {
        obj2 = (i & 2) != 0 ? null : obj2;
        this.f289a = obj;
        this.b = obj2;
        this.c = pointerInputEventHandler;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SuspendPointerInputElement)) {
            return false;
        }
        SuspendPointerInputElement suspendPointerInputElement = (SuspendPointerInputElement) obj;
        return Intrinsics.a(this.f289a, suspendPointerInputElement.f289a) && Intrinsics.a(this.b, suspendPointerInputElement.b) && this.c == suspendPointerInputElement.c;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new jc6(this.f289a, this.b, this.c);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        jc6 jc6Var = (jc6) g94Var;
        Object obj = jc6Var.d0;
        Object obj2 = this.f289a;
        boolean z = !Intrinsics.a(obj, obj2);
        jc6Var.d0 = obj2;
        Object obj3 = jc6Var.e0;
        Object obj4 = this.b;
        if (!Intrinsics.a(obj3, obj4)) {
            z = true;
        }
        jc6Var.e0 = obj4;
        Class<?> cls = jc6Var.f0.getClass();
        PointerInputEventHandler pointerInputEventHandler = this.c;
        if (cls == pointerInputEventHandler.getClass() ? z : true) {
            jc6Var.H0();
        }
        jc6Var.f0 = pointerInputEventHandler;
    }

    public final int hashCode() {
        Object obj = this.f289a;
        int iHashCode = (obj != null ? obj.hashCode() : 0) * 31;
        Object obj2 = this.b;
        return this.c.hashCode() + ((iHashCode + (obj2 != null ? obj2.hashCode() : 0)) * 961);
    }
}

package androidx.compose.ui.input.rotary;

import defpackage.dh5;
import defpackage.g94;
import defpackage.p94;
import defpackage.rb;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/input/rotary/RotaryInputElement;", "Lp94;", "Ldh5;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class RotaryInputElement extends p94 {
    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof RotaryInputElement);
    }

    @Override // defpackage.p94
    public final g94 f() {
        rb rbVar = rb.e;
        dh5 dh5Var = new dh5();
        dh5Var.d0 = rbVar;
        return dh5Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((dh5) g94Var).d0 = rb.e;
    }

    public final int hashCode() {
        return rb.e.hashCode() * 31;
    }
}

package androidx.compose.ui.input.nestedscroll;

import defpackage.ff4;
import defpackage.g94;
import defpackage.kf4;
import defpackage.nv5;
import defpackage.p94;
import defpackage.ui;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;", "Lp94;", "Lkf4;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class NestedScrollElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ff4 f286a;

    public NestedScrollElement(ff4 ff4Var) {
        this.f286a = ff4Var;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof NestedScrollElement) && Intrinsics.a(((NestedScrollElement) obj).f286a, this.f286a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new kf4(this.f286a, null);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        kf4 kf4Var = (kf4) g94Var;
        kf4Var.d0 = this.f286a;
        nv5 nv5Var = kf4Var.e0;
        if (((kf4) nv5Var.f4480a) == kf4Var) {
            nv5Var.f4480a = null;
        }
        nv5 nv5Var2 = new nv5(17);
        kf4Var.e0 = nv5Var2;
        if (kf4Var.c0) {
            nv5Var2.f4480a = kf4Var;
            nv5Var2.b = null;
            kf4Var.f0 = null;
            nv5Var2.c = new ui(kf4Var, 14);
            nv5Var2.d = kf4Var.t0();
        }
    }

    public final int hashCode() {
        return this.f286a.hashCode() * 31;
    }
}

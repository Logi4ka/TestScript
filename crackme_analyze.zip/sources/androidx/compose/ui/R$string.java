package androidx.compose.ui;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int autofill = 2131820585;
    public static int close_drawer = 2131820605;
    public static int close_sheet = 2131820606;
    public static int default_error_message = 2131820628;
    public static int default_popup_window_title = 2131820631;
    public static int dropdown_menu = 2131820633;
    public static int in_progress = 2131820797;
    public static int indeterminate = 2131820798;
    public static int navigation_menu = 2131820972;
    public static int not_selected = 2131820973;
    public static int range_end = 2131820984;
    public static int range_start = 2131820985;
    public static int selected = 2131820991;
    public static int snackbar_pane_title = 2131820994;
    public static int state_empty = 2131820995;
    public static int state_off = 2131820996;
    public static int state_on = 2131820997;
    public static int switch_role = 2131821000;
    public static int tab = 2131821001;
    public static int template_percent = 2131821002;

    private R$string() {
    }
}

package androidx.compose.ui.draw;

import androidx.compose.ui.node.NodeCoordinator;
import defpackage.bc4;
import defpackage.ds5;
import defpackage.fm6;
import defpackage.fx6;
import defpackage.g94;
import defpackage.gx6;
import defpackage.is1;
import defpackage.ky5;
import defpackage.l60;
import defpackage.ma3;
import defpackage.p94;
import defpackage.qe0;
import defpackage.zr0;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/draw/ShadowGraphicsLayerElement;", "Lp94;", "Ll60;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class ShadowGraphicsLayerElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ky5 f279a;

    /* JADX INFO: renamed from: b, reason: from toString */
    public final boolean clip;
    public final long c;

    /* JADX INFO: renamed from: d, reason: from toString */
    public final long ambientColor;

    public ShadowGraphicsLayerElement(ky5 ky5Var, boolean z, long j, long j2) {
        this.f279a = ky5Var;
        this.clip = z;
        this.c = j;
        this.ambientColor = j2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ShadowGraphicsLayerElement)) {
            return false;
        }
        ShadowGraphicsLayerElement shadowGraphicsLayerElement = (ShadowGraphicsLayerElement) obj;
        return is1.a(3.0f, 3.0f) && Intrinsics.a(this.f279a, shadowGraphicsLayerElement.f279a) && this.clip == shadowGraphicsLayerElement.clip && zr0.c(this.c, shadowGraphicsLayerElement.c) && zr0.c(this.ambientColor, shadowGraphicsLayerElement.ambientColor);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new l60(new ds5(this, 2));
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        l60 l60Var = (l60) g94Var;
        l60Var.d0 = new ds5(this, 2);
        NodeCoordinator nodeCoordinator = ma3.M(l60Var, 2).e0;
        if (nodeCoordinator != null) {
            nodeCoordinator.n1(l60Var.d0, true);
        }
    }

    public final int hashCode() {
        int iF = fm6.f((this.f279a.hashCode() + (Float.hashCode(3.0f) * 31)) * 31, 31, this.clip);
        int i = zr0.h;
        fx6 fx6Var = gx6.b;
        return Long.hashCode(this.ambientColor) + qe0.e(this.c, iF, 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("ShadowGraphicsLayerElement(elevation=");
        sb.append((Object) is1.b(3.0f));
        sb.append(", shape=");
        sb.append(this.f279a);
        sb.append(", clip=");
        sb.append(this.clip);
        sb.append(", ambientColor=");
        bc4.s(this.c, ", spotColor=", sb);
        sb.append((Object) zr0.i(this.ambientColor));
        sb.append(')');
        return sb.toString();
    }
}

package androidx.compose.ui.draw;

import defpackage.g50;
import defpackage.h01;
import defpackage.h94;
import defpackage.i60;
import defpackage.pa0;
import defpackage.yp4;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final h94 a(h94 h94Var, Function1 function1) {
        return h94Var.d(new DrawBehindElement(function1));
    }

    public static final h94 b(h94 h94Var, Function1 function1) {
        return h94Var.d(new DrawWithCacheElement(function1));
    }

    public static final h94 c(h94 h94Var, Function1 function1) {
        return h94Var.d(new DrawWithContentElement(function1));
    }

    public static h94 d(h94 h94Var, yp4 yp4Var, h01 h01Var, float f, i60 i60Var, int i) {
        g50 g50Var = pa0.i;
        if ((i & 16) != 0) {
            f = 1.0f;
        }
        return h94Var.d(new PainterElement(yp4Var, g50Var, h01Var, f, i60Var));
    }
}

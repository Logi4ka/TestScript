package androidx.compose.ui.draw;

import defpackage.at3;
import defpackage.be3;
import defpackage.bt3;
import defpackage.cp3;
import defpackage.do2;
import defpackage.ej0;
import defpackage.f53;
import defpackage.fk;
import defpackage.g94;
import defpackage.gc;
import defpackage.h01;
import defpackage.i16;
import defpackage.i60;
import defpackage.jo;
import defpackage.nz0;
import defpackage.pz0;
import defpackage.st1;
import defpackage.td3;
import defpackage.tu4;
import defpackage.us3;
import defpackage.yp4;
import io.flutter.embedding.android.KeyboardMap;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0002\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003R\"\u0010\u0005\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Landroidx/compose/ui/draw/PainterNode;", "Ltd3;", "Lg94;", "Lst1;", "Lyp4;", "painter", "Lyp4;", "F0", "()Lyp4;", "K0", "(Lyp4;)V", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class PainterNode extends g94 implements td3, st1 {
    public gc d0;
    public h01 e0;
    public float f0;
    public i60 g0;
    private yp4 painter;

    public PainterNode(yp4 yp4Var, gc gcVar, h01 h01Var, float f, i60 i60Var) {
        this.painter = yp4Var;
        this.d0 = gcVar;
        this.e0 = h01Var;
        this.f0 = f;
        this.g0 = i60Var;
    }

    public static boolean H0(long j) {
        return !i16.a(j, 9205357640488583168L) && (Float.floatToRawIntBits(Float.intBitsToFloat((int) (j & KeyboardMap.kValueMask))) & jo.API_PRIORITY_OTHER) < 2139095040;
    }

    public static boolean I0(long j) {
        return !i16.a(j, 9205357640488583168L) && (Float.floatToRawIntBits(Float.intBitsToFloat((int) (j >> 32))) & jo.API_PRIORITY_OTHER) < 2139095040;
    }

    /* JADX INFO: renamed from: F0, reason: from getter */
    public final yp4 getPainter() {
        return this.painter;
    }

    public final boolean G0() {
        return this.painter.getW() != 9205357640488583168L;
    }

    public final long J0(long j) {
        boolean z = false;
        boolean z2 = nz0.d(j) && nz0.c(j);
        if (nz0.f(j) && nz0.e(j)) {
            z = true;
        }
        if ((!G0() && z2) || z) {
            return nz0.a(j, nz0.h(j), 0, nz0.g(j), 0, 10);
        }
        long jH = this.painter.getW();
        int iRound = I0(jH) ? Math.round(Float.intBitsToFloat((int) (jH >> 32))) : nz0.j(j);
        int iRound2 = H0(jH) ? Math.round(Float.intBitsToFloat((int) (jH & KeyboardMap.kValueMask))) : nz0.i(j);
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(pz0.f(iRound2, j))) & KeyboardMap.kValueMask) | (((long) Float.floatToRawIntBits(pz0.g(iRound, j))) << 32);
        if (G0()) {
            long jFloatToRawIntBits2 = (((long) Float.floatToRawIntBits(!I0(this.painter.getW()) ? Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32)) : Float.intBitsToFloat((int) (this.painter.getW() >> 32)))) << 32) | (((long) Float.floatToRawIntBits(!H0(this.painter.getW()) ? Float.intBitsToFloat((int) (jFloatToRawIntBits & KeyboardMap.kValueMask)) : Float.intBitsToFloat((int) (this.painter.getW() & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask);
            jFloatToRawIntBits = (Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32)) == 0.0f || Float.intBitsToFloat((int) (jFloatToRawIntBits & KeyboardMap.kValueMask)) == 0.0f) ? 0L : f53.V(jFloatToRawIntBits2, this.e0.d(jFloatToRawIntBits2, jFloatToRawIntBits));
        }
        return nz0.a(j, pz0.g(Math.round(Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32))), j), 0, pz0.f(Math.round(Float.intBitsToFloat((int) (jFloatToRawIntBits & KeyboardMap.kValueMask))), j), 0, 10);
    }

    public final void K0(yp4 yp4Var) {
        this.painter = yp4Var;
    }

    @Override // defpackage.td3
    public final int R(cp3 cp3Var, us3 us3Var, int i) {
        if (!G0()) {
            return us3Var.b(i);
        }
        long jJ0 = J0(pz0.b(i, 0, 13));
        return Math.max(nz0.i(jJ0), us3Var.b(i));
    }

    @Override // defpackage.td3
    public final int X(cp3 cp3Var, us3 us3Var, int i) {
        if (!G0()) {
            return us3Var.P(i);
        }
        long jJ0 = J0(pz0.b(i, 0, 13));
        return Math.max(nz0.i(jJ0), us3Var.P(i));
    }

    @Override // defpackage.td3
    public final at3 b(bt3 bt3Var, us3 us3Var, long j) {
        tu4 tu4VarT = us3Var.t(J0(j));
        return bt3.V(bt3Var, tu4VarT.f5755a, tu4VarT.b, new fk(tu4VarT, 4));
    }

    @Override // defpackage.st1
    public final void c0(be3 be3Var) {
        ej0 ej0Var = be3Var.f572a;
        long jH = this.painter.getW();
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(I0(jH) ? Float.intBitsToFloat((int) (jH >> 32)) : Float.intBitsToFloat((int) (ej0Var.d() >> 32)))) << 32) | (((long) Float.floatToRawIntBits(H0(jH) ? Float.intBitsToFloat((int) (jH & KeyboardMap.kValueMask)) : Float.intBitsToFloat((int) (ej0Var.d() & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask);
        long jV = (Float.intBitsToFloat((int) (ej0Var.d() >> 32)) == 0.0f || Float.intBitsToFloat((int) (ej0Var.d() & KeyboardMap.kValueMask)) == 0.0f) ? 0L : f53.V(jFloatToRawIntBits, this.e0.d(jFloatToRawIntBits, ej0Var.d()));
        long jA = this.d0.a((((long) Math.round(Float.intBitsToFloat((int) (jV >> 32)))) << 32) | (((long) Math.round(Float.intBitsToFloat((int) (jV & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask), (((long) Math.round(Float.intBitsToFloat((int) (ej0Var.d() >> 32)))) << 32) | (((long) Math.round(Float.intBitsToFloat((int) (ej0Var.d() & KeyboardMap.kValueMask)))) & KeyboardMap.kValueMask), be3Var.getLayoutDirection());
        float f = (int) (jA >> 32);
        float f2 = (int) (jA & KeyboardMap.kValueMask);
        ((do2) ej0Var.b.f2228a).q(f, f2);
        try {
            this.painter.g(be3Var, jV, this.f0, this.g0);
            ((do2) ej0Var.b.f2228a).q(-f, -f2);
            be3Var.a();
        } catch (Throwable th) {
            ((do2) ej0Var.b.f2228a).q(-f, -f2);
            throw th;
        }
    }

    @Override // defpackage.td3
    public final int e(cp3 cp3Var, us3 us3Var, int i) {
        if (!G0()) {
            return us3Var.n(i);
        }
        long jJ0 = J0(pz0.b(0, i, 7));
        return Math.max(nz0.j(jJ0), us3Var.n(i));
    }

    @Override // defpackage.td3
    public final int f0(cp3 cp3Var, us3 us3Var, int i) {
        if (!G0()) {
            return us3Var.l(i);
        }
        long jJ0 = J0(pz0.b(0, i, 7));
        return Math.max(nz0.j(jJ0), us3Var.l(i));
    }

    public final String toString() {
        return "PainterModifier(painter=" + this.painter + ", sizeToIntrinsics=true, alignment=" + this.d0 + ", alpha=" + this.f0 + ", colorFilter=" + this.g0 + ')';
    }

    @Override // defpackage.g94
    public final boolean u0() {
        return false;
    }
}

package androidx.compose.ui.draw;

import defpackage.fm6;
import defpackage.g94;
import defpackage.gc;
import defpackage.gq3;
import defpackage.h01;
import defpackage.i16;
import defpackage.i60;
import defpackage.lh1;
import defpackage.oh1;
import defpackage.p94;
import defpackage.yp4;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001R\u0017\u0010\u0004\u001a\u00020\u00038\u0006¢\u0006\f\n\u0004\b\u0004\u0010\u0005\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Landroidx/compose/ui/draw/PainterElement;", "Lp94;", "Landroidx/compose/ui/draw/PainterNode;", "Lyp4;", "painter", "Lyp4;", "getPainter", "()Lyp4;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class PainterElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final gc f278a;
    public final h01 b;
    public final float c;
    public final i60 d;
    private final yp4 painter;

    public PainterElement(yp4 yp4Var, gc gcVar, h01 h01Var, float f, i60 i60Var) {
        this.painter = yp4Var;
        this.f278a = gcVar;
        this.b = h01Var;
        this.c = f;
        this.d = i60Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PainterElement)) {
            return false;
        }
        PainterElement painterElement = (PainterElement) obj;
        return Intrinsics.a(this.painter, painterElement.painter) && Intrinsics.a(this.f278a, painterElement.f278a) && Intrinsics.a(this.b, painterElement.b) && Float.compare(this.c, painterElement.c) == 0 && Intrinsics.a(this.d, painterElement.d);
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new PainterNode(this.painter, this.f278a, this.b, this.c, this.d);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        PainterNode painterNode = (PainterNode) g94Var;
        painterNode.getClass();
        boolean zA = i16.a(painterNode.getPainter().h(), this.painter.h());
        painterNode.K0(this.painter);
        painterNode.d0 = this.f278a;
        painterNode.e0 = this.b;
        painterNode.f0 = this.c;
        painterNode.g0 = this.d;
        if (!zA) {
            gq3.F(painterNode);
        }
        lh1.E(painterNode);
    }

    public final int hashCode() {
        int iC = oh1.c((this.b.hashCode() + ((this.f278a.hashCode() + fm6.f(this.painter.hashCode() * 31, 31, true)) * 31)) * 31, this.c, 31);
        i60 i60Var = this.d;
        return iC + (i60Var == null ? 0 : i60Var.hashCode());
    }

    public final String toString() {
        return "PainterElement(painter=" + this.painter + ", sizeToIntrinsics=true, alignment=" + this.f278a + ", contentScale=" + this.b + ", alpha=" + this.c + ", colorFilter=" + this.d + ')';
    }
}

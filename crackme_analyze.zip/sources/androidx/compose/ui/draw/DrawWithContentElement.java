package androidx.compose.ui.draw;

import defpackage.g94;
import defpackage.p94;
import defpackage.vt1;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/draw/DrawWithContentElement;", "Lp94;", "Lvt1;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class DrawWithContentElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function1 f277a;

    public DrawWithContentElement(Function1 function1) {
        this.f277a = function1;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DrawWithContentElement) {
            return this.f277a == ((DrawWithContentElement) obj).f277a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        vt1 vt1Var = new vt1();
        vt1Var.d0 = this.f277a;
        return vt1Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((vt1) g94Var).d0 = this.f277a;
    }

    public final int hashCode() {
        return this.f277a.hashCode();
    }
}

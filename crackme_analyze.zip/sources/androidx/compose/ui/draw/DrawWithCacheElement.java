package androidx.compose.ui.draw;

import defpackage.g94;
import defpackage.hd0;
import defpackage.id0;
import defpackage.p94;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/draw/DrawWithCacheElement;", "Lp94;", "Lhd0;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class DrawWithCacheElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Function1 f276a;

    public DrawWithCacheElement(Function1 function1) {
        this.f276a = function1;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DrawWithCacheElement) {
            return this.f276a == ((DrawWithCacheElement) obj).f276a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new hd0(new id0(), this.f276a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        hd0 hd0Var = (hd0) g94Var;
        hd0Var.f0 = this.f276a;
        hd0Var.F0();
    }

    public final int hashCode() {
        return this.f276a.hashCode();
    }
}

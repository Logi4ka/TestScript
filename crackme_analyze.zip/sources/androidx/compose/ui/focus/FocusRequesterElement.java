package androidx.compose.ui.focus;

import defpackage.g94;
import defpackage.p94;
import defpackage.tf2;
import defpackage.vf2;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/focus/FocusRequesterElement;", "Lp94;", "Lvf2;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class FocusRequesterElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final tf2 f282a;

    public FocusRequesterElement(tf2 tf2Var) {
        this.f282a = tf2Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof FocusRequesterElement) && Intrinsics.a(this.f282a, ((FocusRequesterElement) obj).f282a);
    }

    @Override // defpackage.p94
    public final g94 f() {
        vf2 vf2Var = new vf2();
        vf2Var.d0 = this.f282a;
        return vf2Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        vf2 vf2Var = (vf2) g94Var;
        vf2Var.d0.f5663a.j(vf2Var);
        tf2 tf2Var = this.f282a;
        vf2Var.d0 = tf2Var;
        tf2Var.f5663a.b(vf2Var);
    }

    public final int hashCode() {
        return this.f282a.hashCode();
    }

    public final String toString() {
        return "FocusRequesterElement(focusRequester=" + this.f282a + ')';
    }
}

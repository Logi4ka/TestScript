package androidx.compose.ui.layout;

import defpackage.g94;
import defpackage.p94;
import defpackage.sd3;
import defpackage.zk2;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/layout/LayoutElement;", "Lp94;", "Lsd3;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class LayoutElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zk2 f290a;

    public LayoutElement(zk2 zk2Var) {
        this.f290a = zk2Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof LayoutElement) {
            return this.f290a == ((LayoutElement) obj).f290a;
        }
        return false;
    }

    @Override // defpackage.p94
    public final g94 f() {
        sd3 sd3Var = new sd3();
        sd3Var.d0 = this.f290a;
        return sd3Var;
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        ((sd3) g94Var).d0 = this.f290a;
    }

    public final int hashCode() {
        return this.f290a.hashCode();
    }
}

package androidx.compose.ui.layout;

import androidx.compose.ui.node.LayoutNode;
import defpackage.g94;
import defpackage.ma3;
import defpackage.p94;
import defpackage.q23;
import defpackage.wh5;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Landroidx/compose/ui/layout/RulerProviderModifierElement;", "Lp94;", "Lwh5;", "ui_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class RulerProviderModifierElement extends p94 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q23 f293a;

    public RulerProviderModifierElement(q23 q23Var) {
        this.f293a = q23Var;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        RulerProviderModifierElement rulerProviderModifierElement = obj instanceof RulerProviderModifierElement ? (RulerProviderModifierElement) obj : null;
        return (rulerProviderModifierElement != null ? rulerProviderModifierElement.f293a : null) == this.f293a;
    }

    @Override // defpackage.p94
    public final g94 f() {
        return new wh5(this.f293a);
    }

    @Override // defpackage.p94
    public final void g(g94 g94Var) {
        wh5 wh5Var = (wh5) g94Var;
        q23 q23Var = wh5Var.d0;
        q23 q23Var2 = this.f293a;
        if (q23Var != q23Var2) {
            wh5Var.d0 = q23Var2;
            LayoutNode.b0(ma3.O(wh5Var), false, 7);
        }
    }

    public final int hashCode() {
        return this.f293a.hashCode();
    }
}

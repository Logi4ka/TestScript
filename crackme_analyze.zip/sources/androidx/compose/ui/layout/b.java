package androidx.compose.ui.layout;

import defpackage.gv5;
import defpackage.h94;
import defpackage.pb4;
import defpackage.q23;
import defpackage.uk7;
import defpackage.vk7;
import defpackage.w13;
import defpackage.wk7;
import defpackage.zo3;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final pb4 f294a;
    public static final vk7[] b;
    public static final pb4 c;

    static {
        pb4 pb4Var = new pb4(8);
        vk7.f6115a.getClass();
        wk7 wk7Var = uk7.g;
        pb4Var.h(1, wk7Var);
        wk7 wk7Var2 = uk7.f;
        pb4Var.h(2, wk7Var2);
        wk7 wk7Var3 = uk7.b;
        pb4Var.h(4, wk7Var3);
        wk7 wk7Var4 = uk7.d;
        pb4Var.h(8, wk7Var4);
        wk7 wk7Var5 = uk7.h;
        pb4Var.h(16, wk7Var5);
        wk7 wk7Var6 = uk7.e;
        pb4Var.h(32, wk7Var6);
        wk7 wk7Var7 = uk7.i;
        pb4Var.h(64, wk7Var7);
        f294a = pb4Var;
        b = new vk7[]{wk7Var, wk7Var2, wk7Var3, wk7Var7, wk7Var5, wk7Var6, wk7Var4, uk7.j, uk7.c};
        pb4 pb4Var2 = new pb4(7);
        pb4Var2.h(1, wk7Var);
        pb4Var2.h(2, wk7Var2);
        pb4Var2.h(4, wk7Var3);
        pb4Var2.h(16, wk7Var5);
        pb4Var2.h(64, wk7Var7);
        pb4Var2.h(32, wk7Var6);
        pb4Var2.h(8, wk7Var4);
        c = pb4Var2;
    }

    public static final void a(zo3 zo3Var, w13 w13Var, long j, int i, int i2) {
        if (gv5.c(j, -1L)) {
            return;
        }
        float f = (int) ((j >>> 48) & WebSocketProtocol.PAYLOAD_SHORT_MAX);
        float f2 = (int) ((j >>> 32) & WebSocketProtocol.PAYLOAD_SHORT_MAX);
        float f3 = i - ((int) ((j >>> 16) & WebSocketProtocol.PAYLOAD_SHORT_MAX));
        float f4 = i2 - ((int) (j & WebSocketProtocol.PAYLOAD_SHORT_MAX));
        zo3Var.a(w13Var.b(), f);
        zo3Var.a(w13Var.d(), f2);
        zo3Var.a(w13Var.c(), f3);
        zo3Var.a(w13Var.a(), f4);
    }

    public static final h94 b(q23 q23Var) {
        return new RulerProviderModifierElement(q23Var);
    }
}

package androidx.autofill;

/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static int notification_action_color_filter = 2131100432;
    public static int notification_icon_bg_color = 2131100433;
    public static int ripple_material_light = 2131100445;
    public static int secondary_text_default_material_light = 2131100447;

    private R$color() {
    }
}

package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.PopupWindow;
import androidx.appcompat.R$styleable;
import defpackage.gx5;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
class AppCompatPopupWindow extends PopupWindow {
    public AppCompatPopupWindow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a(context, attributeSet, i);
    }

    public final void a(Context context, AttributeSet attributeSet, int i) {
        gx5 gx5VarX = gx5.x(context, attributeSet, R$styleable.PopupWindow, i);
        int i2 = R$styleable.PopupWindow_overlapAnchor;
        TypedArray typedArray = (TypedArray) gx5VarX.c;
        if (typedArray.hasValue(i2)) {
            setOverlapAnchor(typedArray.getBoolean(R$styleable.PopupWindow_overlapAnchor, false));
        }
        setBackgroundDrawable(gx5VarX.i(R$styleable.PopupWindow_android_popupBackground));
        gx5VarX.z();
    }
}

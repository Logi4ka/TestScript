package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$styleable;
import defpackage.c06;
import defpackage.dv1;
import defpackage.jo;
import defpackage.kl3;
import defpackage.ll3;
import defpackage.ml3;
import defpackage.nl3;
import defpackage.ol3;
import defpackage.pl3;
import defpackage.tf1;
import io.sentry.android.core.o0;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ListPopupWindow implements c06 {
    public static final Method p0;
    public static final Method q0;
    public boolean X;
    public boolean Y;
    public int Z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f181a;
    public ListAdapter b;
    public final int b0;
    public dv1 c;
    public tf1 c0;
    public final int d;
    public View d0;
    public int e;
    public AdapterView.OnItemClickListener e0;
    public int f;
    public AdapterView.OnItemSelectedListener f0;
    public final nl3 g0;
    public final pl3 h0;
    public int i;
    public final ol3 i0;
    public final nl3 j0;
    public final Handler k0;
    public final Rect l0;
    public Rect m0;
    public boolean n0;
    public final PopupWindow o0;
    public final int v;
    public boolean w;

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                p0 = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
            }
            try {
                q0 = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
            }
        }
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i, int i2) {
        this.d = -2;
        this.e = -2;
        this.v = 1002;
        this.Z = 0;
        this.b0 = jo.API_PRIORITY_OTHER;
        this.g0 = new nl3(this, 1);
        this.h0 = new pl3(this, 0);
        this.i0 = new ol3(this);
        this.j0 = new nl3(this, 0);
        this.l0 = new Rect();
        this.f181a = context;
        this.k0 = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ListPopupWindow, i, 0);
        this.f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(R$styleable.ListPopupWindow_android_dropDownHorizontalOffset, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(R$styleable.ListPopupWindow_android_dropDownVerticalOffset, 0);
        this.i = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.w = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        AppCompatPopupWindow appCompatPopupWindow = new AppCompatPopupWindow(context, attributeSet, i, 0);
        appCompatPopupWindow.a(context, attributeSet, i);
        this.o0 = appCompatPopupWindow;
        appCompatPopupWindow.setInputMethodMode(1);
    }

    @Override // defpackage.c06
    public final boolean a() {
        return this.o0.isShowing();
    }

    public final int b() {
        return this.f;
    }

    public final void d(int i) {
        this.f = i;
    }

    @Override // defpackage.c06
    public final void dismiss() {
        PopupWindow popupWindow = this.o0;
        popupWindow.dismiss();
        popupWindow.setContentView(null);
        this.c = null;
        this.k0.removeCallbacks(this.g0);
    }

    public final Drawable f() {
        return this.o0.getBackground();
    }

    public final void h(Drawable drawable) {
        this.o0.setBackgroundDrawable(drawable);
    }

    @Override // defpackage.c06
    public final dv1 j() {
        return this.c;
    }

    public final void k(int i) {
        this.i = i;
        this.w = true;
    }

    public final int n() {
        if (this.w) {
            return this.i;
        }
        return 0;
    }

    public void o(ListAdapter listAdapter) {
        tf1 tf1Var = this.c0;
        if (tf1Var == null) {
            this.c0 = new tf1(this, 1);
        } else {
            ListAdapter listAdapter2 = this.b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(tf1Var);
            }
        }
        this.b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.c0);
        }
        dv1 dv1Var = this.c;
        if (dv1Var != null) {
            dv1Var.setAdapter(this.b);
        }
    }

    public dv1 p(Context context, boolean z) {
        return new dv1(context, z);
    }

    public final void q(int i) {
        Drawable background = this.o0.getBackground();
        if (background == null) {
            this.e = i;
            return;
        }
        Rect rect = this.l0;
        background.getPadding(rect);
        this.e = rect.left + rect.right + i;
    }

    @Override // defpackage.c06
    public final void show() {
        int i;
        int paddingBottom;
        dv1 dv1Var;
        dv1 dv1Var2 = this.c;
        Context context = this.f181a;
        PopupWindow popupWindow = this.o0;
        if (dv1Var2 == null) {
            dv1 dv1VarP = p(context, !this.n0);
            this.c = dv1VarP;
            dv1VarP.setAdapter(this.b);
            this.c.setOnItemClickListener(this.e0);
            this.c.setFocusable(true);
            this.c.setFocusableInTouchMode(true);
            this.c.setOnItemSelectedListener(new kl3(this, 0));
            this.c.setOnScrollListener(this.i0);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f0;
            if (onItemSelectedListener != null) {
                this.c.setOnItemSelectedListener(onItemSelectedListener);
            }
            popupWindow.setContentView(this.c);
        }
        Drawable background = popupWindow.getBackground();
        Rect rect = this.l0;
        if (background != null) {
            background.getPadding(rect);
            int i2 = rect.top;
            i = rect.bottom + i2;
            if (!this.w) {
                this.i = -i2;
            }
        } else {
            rect.setEmpty();
            i = 0;
        }
        int iA = ll3.a(popupWindow, this.d0, this.i, popupWindow.getInputMethodMode() == 2);
        int i3 = this.d;
        if (i3 == -1) {
            paddingBottom = iA + i;
        } else {
            int i4 = this.e;
            int iA2 = this.c.a(i4 != -2 ? i4 != -1 ? View.MeasureSpec.makeMeasureSpec(i4, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE), iA);
            paddingBottom = iA2 + (iA2 > 0 ? this.c.getPaddingBottom() + this.c.getPaddingTop() + i : 0);
        }
        boolean z = popupWindow.getInputMethodMode() == 2;
        popupWindow.setWindowLayoutType(this.v);
        if (popupWindow.isShowing()) {
            if (this.d0.isAttachedToWindow()) {
                int width = this.e;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = this.d0.getWidth();
                }
                if (i3 == -1) {
                    i3 = z ? paddingBottom : -1;
                    int i5 = this.e;
                    if (z) {
                        popupWindow.setWidth(i5 == -1 ? -1 : 0);
                        popupWindow.setHeight(0);
                    } else {
                        popupWindow.setWidth(i5 == -1 ? -1 : 0);
                        popupWindow.setHeight(-1);
                    }
                } else if (i3 == -2) {
                    i3 = paddingBottom;
                }
                popupWindow.setOutsideTouchable(true);
                View view = this.d0;
                int i6 = width;
                int i7 = this.f;
                int i8 = this.i;
                int i9 = i6 < 0 ? -1 : i6;
                if (i3 < 0) {
                    i3 = -1;
                }
                popupWindow.update(view, i7, i8, i9, i3);
                return;
            }
            return;
        }
        int width2 = this.e;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = this.d0.getWidth();
        }
        if (i3 == -1) {
            i3 = -1;
        } else if (i3 == -2) {
            i3 = paddingBottom;
        }
        popupWindow.setWidth(width2);
        popupWindow.setHeight(i3);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = p0;
            if (method != null) {
                try {
                    method.invoke(popupWindow, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        } else {
            ml3.b(popupWindow, true);
        }
        popupWindow.setOutsideTouchable(true);
        popupWindow.setTouchInterceptor(this.h0);
        if (this.Y) {
            popupWindow.setOverlapAnchor(this.X);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = q0;
            if (method2 != null) {
                try {
                    method2.invoke(popupWindow, this.m0);
                } catch (Exception e) {
                    o0.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e);
                }
            }
        } else {
            ml3.a(popupWindow, this.m0);
        }
        popupWindow.showAsDropDown(this.d0, this.f, this.i, this.Z);
        this.c.setSelection(-1);
        if ((!this.n0 || this.c.isInTouchMode()) && (dv1Var = this.c) != null) {
            dv1Var.setListSelectionHidden(true);
            dv1Var.requestLayout();
        }
        if (this.n0) {
            return;
        }
        this.k0.post(this.j0);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.listPopupWindowStyle);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public ListPopupWindow(Context context) {
        this(context, null, R$attr.listPopupWindowStyle);
    }
}

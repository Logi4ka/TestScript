package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$dimen;
import androidx.appcompat.R$id;
import androidx.appcompat.R$layout;
import androidx.appcompat.R$string;
import androidx.appcompat.R$styleable;
import androidx.core.app.NotificationCompat;
import androidx.customview.view.AbsSavedState;
import defpackage.aq5;
import defpackage.bm2;
import defpackage.gx5;
import defpackage.ha6;
import defpackage.hr;
import defpackage.jr0;
import defpackage.kl3;
import defpackage.lh3;
import defpackage.q94;
import defpackage.qc7;
import defpackage.qe0;
import defpackage.tp5;
import defpackage.uf1;
import defpackage.up5;
import defpackage.vp5;
import defpackage.wp5;
import defpackage.xp5;
import defpackage.y82;
import defpackage.yp5;
import io.sentry.android.core.o0;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class SearchView extends LinearLayoutCompat implements jr0 {
    public static final q94 V0;
    public final Intent A0;
    public final CharSequence B0;
    public View.OnFocusChangeListener C0;
    public View.OnClickListener D0;
    public boolean E0;
    public boolean F0;
    public uf1 G0;
    public boolean H0;
    public CharSequence I0;
    public boolean J0;
    public boolean K0;
    public int L0;
    public boolean M0;
    public CharSequence N0;
    public boolean O0;
    public int P0;
    public SearchableInfo Q0;
    public Bundle R0;
    public final tp5 S0;
    public final tp5 T0;
    public final WeakHashMap U0;
    public final SearchAutoComplete h0;
    public final View i0;
    public final View j0;
    public final View k0;
    public final ImageView l0;
    public final ImageView m0;
    public final ImageView n0;
    public final ImageView o0;
    public final View p0;
    public aq5 q0;
    public final Rect r0;
    public final Rect s0;
    public final int[] t0;
    public final int[] u0;
    public final ImageView v0;
    public final Drawable w0;
    public final int x0;
    public final int y0;
    public final Intent z0;

    /* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new i();
        public boolean c;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.c = ((Boolean) parcel.readValue(null)).booleanValue();
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder("SearchView.SavedState{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" isIconified=");
            return qe0.o(sb, this.c, "}");
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeValue(Boolean.valueOf(this.c));
        }
    }

    static {
        q94 q94Var = null;
        if (Build.VERSION.SDK_INT < 29) {
            q94 q94Var2 = new q94();
            q94Var2.f4982a = null;
            q94Var2.b = null;
            q94Var2.c = null;
            q94.a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                q94Var2.f4982a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                q94Var2.b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                q94Var2.c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
            q94Var = q94Var2;
        }
        V0 = q94Var;
    }

    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.r0 = new Rect();
        this.s0 = new Rect();
        this.t0 = new int[2];
        this.u0 = new int[2];
        this.S0 = new tp5(this, 0);
        this.T0 = new tp5(this, 1);
        this.U0 = new WeakHashMap();
        f fVar = new f(this);
        g gVar = new g(this);
        vp5 vp5Var = new vp5(this);
        hr hrVar = new hr(this, 2);
        kl3 kl3Var = new kl3(this, 1);
        y82 y82Var = new y82(this, 1);
        gx5 gx5VarX = gx5.x(context, attributeSet, R$styleable.SearchView, i);
        qc7.n(this, context, R$styleable.SearchView, attributeSet, (TypedArray) gx5VarX.c, i);
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        int i2 = R$styleable.SearchView_layout;
        int i3 = R$layout.abc_search_view;
        TypedArray typedArray = (TypedArray) gx5VarX.c;
        layoutInflaterFrom.inflate(typedArray.getResourceId(i2, i3), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R$id.search_src_text);
        this.h0 = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.i0 = findViewById(R$id.search_edit_frame);
        View viewFindViewById = findViewById(R$id.search_plate);
        this.j0 = viewFindViewById;
        View viewFindViewById2 = findViewById(R$id.submit_area);
        this.k0 = viewFindViewById2;
        ImageView imageView = (ImageView) findViewById(R$id.search_button);
        this.l0 = imageView;
        ImageView imageView2 = (ImageView) findViewById(R$id.search_go_btn);
        this.m0 = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R$id.search_close_btn);
        this.n0 = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R$id.search_voice_btn);
        this.o0 = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R$id.search_mag_icon);
        this.v0 = imageView5;
        viewFindViewById.setBackground(gx5VarX.i(R$styleable.SearchView_queryBackground));
        viewFindViewById2.setBackground(gx5VarX.i(R$styleable.SearchView_submitBackground));
        imageView.setImageDrawable(gx5VarX.i(R$styleable.SearchView_searchIcon));
        imageView2.setImageDrawable(gx5VarX.i(R$styleable.SearchView_goIcon));
        imageView3.setImageDrawable(gx5VarX.i(R$styleable.SearchView_closeIcon));
        imageView4.setImageDrawable(gx5VarX.i(R$styleable.SearchView_voiceIcon));
        imageView5.setImageDrawable(gx5VarX.i(R$styleable.SearchView_searchIcon));
        this.w0 = gx5VarX.i(R$styleable.SearchView_searchHintIcon);
        lh3.k(imageView, getResources().getString(R$string.abc_searchview_description_search));
        this.x0 = typedArray.getResourceId(R$styleable.SearchView_suggestionRowLayout, R$layout.abc_search_dropdown_item_icons_2line);
        this.y0 = typedArray.getResourceId(R$styleable.SearchView_commitIcon, 0);
        imageView.setOnClickListener(fVar);
        imageView3.setOnClickListener(fVar);
        imageView2.setOnClickListener(fVar);
        imageView4.setOnClickListener(fVar);
        searchAutoComplete.setOnClickListener(fVar);
        searchAutoComplete.addTextChangedListener(y82Var);
        searchAutoComplete.setOnEditorActionListener(vp5Var);
        searchAutoComplete.setOnItemClickListener(hrVar);
        searchAutoComplete.setOnItemSelectedListener(kl3Var);
        searchAutoComplete.setOnKeyListener(gVar);
        searchAutoComplete.setOnFocusChangeListener(new up5(this));
        setIconifiedByDefault(typedArray.getBoolean(R$styleable.SearchView_iconifiedByDefault, true));
        int dimensionPixelSize = typedArray.getDimensionPixelSize(R$styleable.SearchView_android_maxWidth, -1);
        if (dimensionPixelSize != -1) {
            setMaxWidth(dimensionPixelSize);
        }
        this.B0 = typedArray.getText(R$styleable.SearchView_defaultQueryHint);
        this.I0 = typedArray.getText(R$styleable.SearchView_queryHint);
        int i4 = typedArray.getInt(R$styleable.SearchView_android_imeOptions, -1);
        if (i4 != -1) {
            setImeOptions(i4);
        }
        int i5 = typedArray.getInt(R$styleable.SearchView_android_inputType, -1);
        if (i5 != -1) {
            setInputType(i5);
        }
        setFocusable(typedArray.getBoolean(R$styleable.SearchView_android_focusable, true));
        gx5VarX.z();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.z0 = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.A0 = intent2;
        intent2.addFlags(268435456);
        View viewFindViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.p0 = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.addOnLayoutChangeListener(new bm2(this, 2));
        }
        w(this.E0);
        t();
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R$dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R$dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.h0;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void clearFocus() {
        this.K0 = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.h0;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.K0 = false;
    }

    public int getImeOptions() {
        return this.h0.getImeOptions();
    }

    public int getInputType() {
        return this.h0.getInputType();
    }

    public int getMaxWidth() {
        return this.L0;
    }

    public CharSequence getQuery() {
        return this.h0.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.I0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.Q0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.B0 : getContext().getText(this.Q0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.y0;
    }

    public int getSuggestionRowLayout() {
        return this.x0;
    }

    public uf1 getSuggestionsAdapter() {
        return this.G0;
    }

    public final Intent j(Uri uri, String str, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.N0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.R0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.Q0.getSearchActivity());
        return intent;
    }

    public final Intent k(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.R0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void l() {
        int i = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.h0;
        if (i >= 29) {
            h.a(searchAutoComplete);
            return;
        }
        q94 q94Var = V0;
        q94Var.getClass();
        q94.a();
        Method method = q94Var.f4982a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, null);
            } catch (Exception unused) {
            }
        }
        q94Var.getClass();
        q94.a();
        Method method2 = q94Var.b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, null);
            } catch (Exception unused2) {
            }
        }
    }

    public final void m() {
        SearchAutoComplete searchAutoComplete = this.h0;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText(HttpUrl.FRAGMENT_ENCODE_SET);
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.E0) {
            clearFocus();
            w(true);
        }
    }

    public final void n(int i) {
        int position;
        String strH;
        Cursor cursor = this.G0.c;
        if (cursor != null && cursor.moveToPosition(i)) {
            Intent intentJ = null;
            try {
                int i2 = ha6.m0;
                String strH2 = ha6.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (strH2 == null) {
                    strH2 = this.Q0.getSuggestIntentAction();
                }
                if (strH2 == null) {
                    strH2 = "android.intent.action.SEARCH";
                }
                String strH3 = ha6.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (strH3 == null) {
                    strH3 = this.Q0.getSuggestIntentData();
                }
                if (strH3 != null && (strH = ha6.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) != null) {
                    strH3 = strH3 + "/" + Uri.encode(strH);
                }
                intentJ = j(strH3 == null ? null : Uri.parse(strH3), strH2, ha6.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), ha6.h(cursor, cursor.getColumnIndex("suggest_intent_query")));
            } catch (RuntimeException e) {
                try {
                    position = cursor.getPosition();
                } catch (RuntimeException unused) {
                    position = -1;
                }
                o0.s("SearchView", "Search suggestions cursor at row " + position + " returned exception.", e);
            }
            if (intentJ != null) {
                try {
                    getContext().startActivity(intentJ);
                } catch (RuntimeException e2) {
                    o0.e("SearchView", "Failed launch activity: " + intentJ, e2);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.h0;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void o(int i) {
        Editable text = this.h0.getText();
        Cursor cursor = this.G0.c;
        if (cursor == null) {
            return;
        }
        if (!cursor.moveToPosition(i)) {
            setQuery(text);
            return;
        }
        String strC = this.G0.c(cursor);
        if (strC != null) {
            setQuery(strC);
        } else {
            setQuery(text);
        }
    }

    @Override // defpackage.jr0
    public final void onActionViewCollapsed() {
        SearchAutoComplete searchAutoComplete = this.h0;
        searchAutoComplete.setText(HttpUrl.FRAGMENT_ENCODE_SET);
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.N0 = HttpUrl.FRAGMENT_ENCODE_SET;
        clearFocus();
        w(true);
        searchAutoComplete.setImeOptions(this.P0);
        this.O0 = false;
    }

    @Override // defpackage.jr0
    public final void onActionViewExpanded() {
        if (this.O0) {
            return;
        }
        this.O0 = true;
        SearchAutoComplete searchAutoComplete = this.h0;
        int imeOptions = searchAutoComplete.getImeOptions();
        this.P0 = imeOptions;
        searchAutoComplete.setImeOptions(imeOptions | 33554432);
        searchAutoComplete.setText(HttpUrl.FRAGMENT_ENCODE_SET);
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        removeCallbacks(this.S0);
        post(this.T0);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            SearchAutoComplete searchAutoComplete = this.h0;
            int[] iArr = this.t0;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.u0;
            getLocationInWindow(iArr2);
            int i5 = iArr[1] - iArr2[1];
            int i6 = iArr[0] - iArr2[0];
            int width = searchAutoComplete.getWidth() + i6;
            int height = searchAutoComplete.getHeight() + i5;
            Rect rect = this.r0;
            rect.set(i6, i5, width, height);
            int i7 = rect.left;
            int i8 = rect.right;
            int i9 = i4 - i2;
            Rect rect2 = this.s0;
            rect2.set(i7, 0, i8, i9);
            aq5 aq5Var = this.q0;
            if (aq5Var == null) {
                aq5 aq5Var2 = new aq5(searchAutoComplete, rect2, rect);
                this.q0 = aq5Var2;
                setTouchDelegate(aq5Var2);
            } else {
                aq5Var.b.set(rect2);
                Rect rect3 = aq5Var.d;
                rect3.set(rect2);
                int i10 = -aq5Var.e;
                rect3.inset(i10, i10);
                aq5Var.c.set(rect);
            }
        }
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.View
    public final void onMeasure(int i, int i2) {
        int i3;
        if (this.F0) {
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        if (mode == Integer.MIN_VALUE) {
            int i4 = this.L0;
            size = i4 > 0 ? Math.min(i4, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.L0;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i3 = this.L0) > 0) {
            size = Math.min(i3, size);
        }
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f329a);
        w(savedState.c);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.c = this.F0;
        return savedState;
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        post(this.S0);
    }

    public final void p(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public final void q() {
        SearchAutoComplete searchAutoComplete = this.h0;
        Editable text = searchAutoComplete.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.Q0 != null) {
            getContext().startActivity(j(null, "android.intent.action.SEARCH", null, text.toString()));
        }
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void r() {
        boolean zIsEmpty = TextUtils.isEmpty(this.h0.getText());
        int i = (!zIsEmpty || (this.E0 && !this.O0)) ? 0 : 8;
        ImageView imageView = this.n0;
        imageView.setVisibility(i);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(!zIsEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i, Rect rect) {
        if (this.K0 || !isFocusable()) {
            return false;
        }
        if (this.F0) {
            return super.requestFocus(i, rect);
        }
        boolean zRequestFocus = this.h0.requestFocus(i, rect);
        if (zRequestFocus) {
            w(false);
        }
        return zRequestFocus;
    }

    public final void s() {
        int[] iArr = this.h0.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.j0.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.k0.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public void setAppSearchData(Bundle bundle) {
        this.R0 = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            m();
            return;
        }
        w(false);
        SearchAutoComplete searchAutoComplete = this.h0;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.D0;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.E0 == z) {
            return;
        }
        this.E0 = z;
        w(z);
        t();
    }

    public void setImeOptions(int i) {
        this.h0.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.h0.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.L0 = i;
        requestLayout();
    }

    public void setOnCloseListener(wp5 wp5Var) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.C0 = onFocusChangeListener;
    }

    public void setOnQueryTextListener(xp5 xp5Var) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.D0 = onClickListener;
    }

    public void setOnSuggestionListener(yp5 yp5Var) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.I0 = charSequence;
        t();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.J0 = z;
        uf1 uf1Var = this.G0;
        if (uf1Var instanceof ha6) {
            ((ha6) uf1Var).e0 = z ? 2 : 1;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0098  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void setSearchableInfo(android.app.SearchableInfo r7) {
        /*
            r6 = this;
            r6.Q0 = r7
            r0 = 0
            r1 = 1
            androidx.appcompat.widget.SearchView$SearchAutoComplete r2 = r6.h0
            if (r7 == 0) goto L65
            int r7 = r7.getSuggestThreshold()
            r2.setThreshold(r7)
            android.app.SearchableInfo r7 = r6.Q0
            int r7 = r7.getImeOptions()
            r2.setImeOptions(r7)
            android.app.SearchableInfo r7 = r6.Q0
            int r7 = r7.getInputType()
            r3 = r7 & 15
            if (r3 != r1) goto L31
            r3 = -65537(0xfffffffffffeffff, float:NaN)
            r7 = r7 & r3
            android.app.SearchableInfo r3 = r6.Q0
            java.lang.String r3 = r3.getSuggestAuthority()
            if (r3 == 0) goto L31
            r3 = 589824(0x90000, float:8.2652E-40)
            r7 = r7 | r3
        L31:
            r2.setInputType(r7)
            uf1 r7 = r6.G0
            if (r7 == 0) goto L3b
            r7.b(r0)
        L3b:
            android.app.SearchableInfo r7 = r6.Q0
            java.lang.String r7 = r7.getSuggestAuthority()
            if (r7 == 0) goto L62
            ha6 r7 = new ha6
            android.content.Context r3 = r6.getContext()
            android.app.SearchableInfo r4 = r6.Q0
            java.util.WeakHashMap r5 = r6.U0
            r7.<init>(r3, r6, r4, r5)
            r6.G0 = r7
            r2.setAdapter(r7)
            uf1 r7 = r6.G0
            ha6 r7 = (defpackage.ha6) r7
            boolean r3 = r6.J0
            if (r3 == 0) goto L5f
            r3 = 2
            goto L60
        L5f:
            r3 = r1
        L60:
            r7.e0 = r3
        L62:
            r6.t()
        L65:
            android.app.SearchableInfo r7 = r6.Q0
            r3 = 0
            if (r7 == 0) goto L98
            boolean r7 = r7.getVoiceSearchEnabled()
            if (r7 == 0) goto L98
            android.app.SearchableInfo r7 = r6.Q0
            boolean r7 = r7.getVoiceSearchLaunchWebSearch()
            if (r7 == 0) goto L7b
            android.content.Intent r0 = r6.z0
            goto L85
        L7b:
            android.app.SearchableInfo r7 = r6.Q0
            boolean r7 = r7.getVoiceSearchLaunchRecognizer()
            if (r7 == 0) goto L85
            android.content.Intent r0 = r6.A0
        L85:
            if (r0 == 0) goto L98
            android.content.Context r7 = r6.getContext()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            r4 = 65536(0x10000, float:9.18355E-41)
            android.content.pm.ResolveInfo r7 = r7.resolveActivity(r0, r4)
            if (r7 == 0) goto L98
            goto L99
        L98:
            r1 = r3
        L99:
            r6.M0 = r1
            if (r1 == 0) goto La2
            java.lang.String r7 = "nm"
            r2.setPrivateImeOptions(r7)
        La2:
            boolean r7 = r6.F0
            r6.w(r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.H0 = z;
        w(this.F0);
    }

    public void setSuggestionsAdapter(uf1 uf1Var) {
        this.G0 = uf1Var;
        this.h0.setAdapter(uf1Var);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void t() {
        CharSequence queryHint = getQueryHint();
        CharSequence charSequence = queryHint;
        if (queryHint == null) {
            charSequence = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        boolean z = this.E0;
        SearchAutoComplete searchAutoComplete = this.h0;
        CharSequence charSequence2 = charSequence;
        if (z) {
            Drawable drawable = this.w0;
            charSequence2 = charSequence;
            if (drawable != null) {
                int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
                drawable.setBounds(0, 0, textSize, textSize);
                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
                spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
                spannableStringBuilder.append(charSequence);
                charSequence2 = spannableStringBuilder;
            }
        }
        searchAutoComplete.setHint(charSequence2);
    }

    public final void u() {
        this.k0.setVisibility(((this.H0 || this.M0) && !this.F0 && (this.m0.getVisibility() == 0 || this.o0.getVisibility() == 0)) ? 0 : 8);
    }

    public final void v(boolean z) {
        boolean z2 = this.H0;
        this.m0.setVisibility((!z2 || !(z2 || this.M0) || this.F0 || !hasFocus() || (!z && this.M0)) ? 8 : 0);
    }

    public final void w(boolean z) {
        this.F0 = z;
        int i = 8;
        int i2 = z ? 0 : 8;
        boolean zIsEmpty = TextUtils.isEmpty(this.h0.getText());
        this.l0.setVisibility(i2);
        v(!zIsEmpty);
        this.i0.setVisibility(z ? 8 : 0);
        ImageView imageView = this.v0;
        imageView.setVisibility((imageView.getDrawable() == null || this.E0) ? 8 : 0);
        r();
        if (this.M0 && !this.F0 && zIsEmpty) {
            this.m0.setVisibility(8);
            i = 0;
        }
        this.o0.setVisibility(i);
        u();
    }

    /* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
    public static class SearchAutoComplete extends AppCompatAutoCompleteTextView {
        public int e;
        public SearchView f;
        public boolean i;
        public final j v;

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.v = new j(this);
            this.e = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return NotificationCompat.FLAG_LOCAL_ONLY;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        public final void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                h.b(this, 1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            q94 q94Var = SearchView.V0;
            q94Var.getClass();
            q94.a();
            Method method = q94Var.c;
            if (method != null) {
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final boolean enoughToFilter() {
            return this.e <= 0 || super.enoughToFilter();
        }

        @Override // androidx.appcompat.widget.AppCompatAutoCompleteTextView, android.widget.TextView, android.view.View
        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.i) {
                j jVar = this.v;
                removeCallbacks(jVar);
                post(jVar);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            SearchView searchView = this.f;
            searchView.w(searchView.F0);
            searchView.post(searchView.S0);
            if (searchView.h0.hasFocus()) {
                searchView.l();
            }
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.f.hasFocus() && getVisibility() == 0) {
                this.i = true;
                Context context = getContext();
                q94 q94Var = SearchView.V0;
                if (context.getResources().getConfiguration().orientation == 2) {
                    a();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            j jVar = this.v;
            if (!z) {
                this.i = false;
                removeCallbacks(jVar);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.i = true;
                    return;
                }
                this.i = false;
                removeCallbacks(jVar);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i) {
            super.setThreshold(i);
            this.e = i;
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, R$attr.autoCompleteTextViewStyle);
        }
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.searchViewStyle);
    }
}

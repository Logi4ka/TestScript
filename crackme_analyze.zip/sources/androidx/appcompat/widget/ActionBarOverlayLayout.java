package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import androidx.core.app.NotificationCompat;
import defpackage.ak7;
import defpackage.bx7;
import defpackage.c5;
import defpackage.ck7;
import defpackage.d5;
import defpackage.dk7;
import defpackage.e5;
import defpackage.ek7;
import defpackage.ew3;
import defpackage.f5;
import defpackage.fc7;
import defpackage.gj1;
import defpackage.hc7;
import defpackage.hj1;
import defpackage.jo;
import defpackage.kj7;
import defpackage.kk7;
import defpackage.ne7;
import defpackage.nk7;
import defpackage.o23;
import defpackage.of4;
import defpackage.pf4;
import defpackage.qc7;
import defpackage.qf4;
import defpackage.vk5;
import defpackage.ww3;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements gj1, of4, pf4 {
    public static final int[] u0 = {R$attr.actionBarSize, R.attr.windowContentOverlay};
    public static final nk7 v0;
    public static final Rect w0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f159a;
    public int b;
    public boolean b0;
    public ContentFrameLayout c;
    public int c0;
    public ActionBarContainer d;
    public int d0;
    public hj1 e;
    public final Rect e0;
    public Drawable f;
    public final Rect f0;
    public final Rect g0;
    public final Rect h0;
    public boolean i;
    public nk7 i0;
    public nk7 j0;
    public nk7 k0;
    public nk7 l0;
    public e5 m0;
    public OverScroller n0;
    public ViewPropertyAnimator o0;
    public final c5 p0;
    public final d5 q0;
    public final d5 r0;
    public final qf4 s0;
    public final f5 t0;
    public boolean v;
    public boolean w;

    /* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    static {
        int i = Build.VERSION.SDK_INT;
        ek7 dk7Var = i >= 30 ? new dk7() : i >= 29 ? new ck7() : new ak7();
        dk7Var.g(o23.b(0, 1, 0, 1));
        v0 = dk7Var.b();
        w0 = new Rect();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = 0;
        this.e0 = new Rect();
        this.f0 = new Rect();
        this.g0 = new Rect();
        this.h0 = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        nk7 nk7Var = nk7.b;
        this.i0 = nk7Var;
        this.j0 = nk7Var;
        this.k0 = nk7Var;
        this.l0 = nk7Var;
        this.p0 = new c5(this, 0);
        this.q0 = new d5(this, 0);
        this.r0 = new d5(this, 1);
        c(context);
        this.s0 = new qf4();
        f5 f5Var = new f5(context);
        f5Var.setWillNotDraw(true);
        this.t0 = f5Var;
        addView(f5Var);
    }

    public static boolean a(View view, Rect rect, boolean z) {
        boolean z2;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
        int i2 = rect.left;
        if (i != i2) {
            ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = i2;
            z2 = true;
        } else {
            z2 = false;
        }
        int i3 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
        int i4 = rect.top;
        if (i3 != i4) {
            ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = i4;
            z2 = true;
        }
        int i5 = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
        int i6 = rect.right;
        if (i5 != i6) {
            ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = i6;
            z2 = true;
        }
        if (z) {
            int i7 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
            int i8 = rect.bottom;
            if (i7 != i8) {
                ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = i8;
                return true;
            }
        }
        return z2;
    }

    public final void b() {
        removeCallbacks(this.q0);
        removeCallbacks(this.r0);
        ViewPropertyAnimator viewPropertyAnimator = this.o0;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void c(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(u0);
        this.f159a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.n0 = new OverScroller(context);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void d(int i) {
        e();
        if (i == 2) {
            this.e.getClass();
        } else if (i == 5) {
            this.e.getClass();
        } else {
            if (i != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f != null) {
            if (this.d.getVisibility() == 0) {
                translationY = (int) (this.d.getTranslationY() + this.d.getBottom() + 0.5f);
            } else {
                translationY = 0;
            }
            this.f.setBounds(0, translationY, getWidth(), this.f.getIntrinsicHeight() + translationY);
            this.f.draw(canvas);
        }
    }

    public final void e() {
        hj1 wrapper;
        if (this.c == null) {
            this.c = (ContentFrameLayout) findViewById(R$id.action_bar_activity_content);
            this.d = (ActionBarContainer) findViewById(R$id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R$id.action_bar);
            if (callbackFindViewById instanceof hj1) {
                wrapper = (hj1) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    vk5.k("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                    return;
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.e = wrapper;
        }
    }

    public final void f(Menu menu, ww3 ww3Var) {
        e();
        m mVar = (m) this.e;
        Toolbar toolbar = mVar.f189a;
        if (mVar.m == null) {
            b bVar = new b(toolbar.getContext());
            mVar.m = bVar;
            bVar.w = R$id.action_menu_presenter;
        }
        b bVar2 = mVar.m;
        bVar2.e = ww3Var;
        ew3 ew3Var = (ew3) menu;
        if (ew3Var == null && toolbar.f183a == null) {
            return;
        }
        toolbar.f();
        ew3 ew3Var2 = toolbar.f183a.h0;
        if (ew3Var2 == ew3Var) {
            return;
        }
        if (ew3Var2 != null) {
            ew3Var2.r(toolbar.D0);
            ew3Var2.r(toolbar.E0);
        }
        if (toolbar.E0 == null) {
            toolbar.E0 = new k(toolbar);
        }
        bVar2.g0 = true;
        Context context = toolbar.b0;
        if (ew3Var != null) {
            ew3Var.b(bVar2, context);
            ew3Var.b(toolbar.E0, toolbar.b0);
        } else {
            bVar2.k(context, null);
            toolbar.E0.k(toolbar.b0, null);
            bVar2.b(true);
            toolbar.E0.b(true);
        }
        toolbar.f183a.setPopupTheme(toolbar.c0);
        toolbar.f183a.setPresenter(bVar2);
        toolbar.D0 = bVar2;
        toolbar.w();
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        qf4 qf4Var = this.s0;
        return qf4Var.b | qf4Var.f5015a;
    }

    public CharSequence getTitle() {
        e();
        return ((m) this.e).f189a.getTitle();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        e();
        nk7 nk7VarH = nk7.h(this, windowInsets);
        boolean zA = a(this.d, new Rect(nk7VarH.b(), nk7VarH.d(), nk7VarH.c(), nk7VarH.a()), false);
        WeakHashMap weakHashMap = qc7.f4998a;
        Rect rect = this.e0;
        hc7.b(this, nk7VarH, rect);
        int i = rect.left;
        int i2 = rect.top;
        int i3 = rect.right;
        int i4 = rect.bottom;
        kk7 kk7Var = nk7VarH.f4398a;
        nk7 nk7VarM = kk7Var.m(i, i2, i3, i4);
        this.i0 = nk7VarM;
        boolean z = true;
        if (!this.j0.equals(nk7VarM)) {
            this.j0 = this.i0;
            zA = true;
        }
        Rect rect2 = this.f0;
        if (rect2.equals(rect)) {
            z = zA;
        } else {
            rect2.set(rect);
        }
        if (z) {
            requestLayout();
        }
        return kk7Var.a().f4398a.c().f4398a.b().g();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        c(getContext());
        WeakHashMap weakHashMap = qc7.f4998a;
        fc7.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        b();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + paddingLeft;
                int i7 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x00aa  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onMeasure(int r13, int r14) {
        /*
            Method dump skipped, instruction units count: 371
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (!this.w || !z) {
            return false;
        }
        this.n0.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, jo.API_PRIORITY_OTHER);
        if (this.n0.getFinalY() > this.d.getHeight()) {
            b();
            this.r0.run();
        } else {
            b();
            this.q0.run();
        }
        this.b0 = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.c0 + i2;
        this.c0 = i5;
        setActionBarHideOffset(i5);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        kj7 kj7Var;
        ne7 ne7Var;
        this.s0.f5015a = i;
        this.c0 = getActionBarHideOffset();
        b();
        e5 e5Var = this.m0;
        if (e5Var == null || (ne7Var = (kj7Var = (kj7) e5Var).t) == null) {
            return;
        }
        ne7Var.a();
        kj7Var.t = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.d.getVisibility() != 0) {
            return false;
        }
        return this.w;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.w || this.b0) {
            return;
        }
        if (this.c0 <= this.d.getHeight()) {
            b();
            postDelayed(this.q0, 600L);
        } else {
            b();
            postDelayed(this.r0, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        e();
        int i2 = this.d0 ^ i;
        this.d0 = i;
        boolean z = (i & 4) == 0;
        boolean z2 = (i & NotificationCompat.FLAG_LOCAL_ONLY) != 0;
        e5 e5Var = this.m0;
        if (e5Var != null) {
            kj7 kj7Var = (kj7) e5Var;
            kj7Var.o = !z2;
            if (z || !z2) {
                if (kj7Var.q) {
                    kj7Var.q = false;
                    kj7Var.y(true);
                }
            } else if (!kj7Var.q) {
                kj7Var.q = true;
                kj7Var.y(true);
            }
        }
        if ((i2 & NotificationCompat.FLAG_LOCAL_ONLY) == 0 || this.m0 == null) {
            return;
        }
        WeakHashMap weakHashMap = qc7.f4998a;
        fc7.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.b = i;
        e5 e5Var = this.m0;
        if (e5Var != null) {
            ((kj7) e5Var).n = i;
        }
    }

    public void setActionBarHideOffset(int i) {
        b();
        this.d.setTranslationY(-Math.max(0, Math.min(i, this.d.getHeight())));
    }

    public void setActionBarVisibilityCallback(e5 e5Var) {
        this.m0 = e5Var;
        if (getWindowToken() != null) {
            ((kj7) this.m0).n = this.b;
            int i = this.d0;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                WeakHashMap weakHashMap = qc7.f4998a;
                fc7.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.v = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.w) {
            this.w = z;
            if (z) {
                return;
            }
            b();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i) {
        e();
        m mVar = (m) this.e;
        mVar.d = i != 0 ? bx7.t(mVar.f189a.getContext(), i) : null;
        mVar.c();
    }

    public void setLogo(int i) {
        e();
        m mVar = (m) this.e;
        mVar.e = i != 0 ? bx7.t(mVar.f189a.getContext(), i) : null;
        mVar.c();
    }

    public void setOverlayMode(boolean z) {
        this.i = z;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    @Override // defpackage.gj1
    public void setWindowCallback(Window.Callback callback) {
        e();
        ((m) this.e).k = callback;
    }

    @Override // defpackage.gj1
    public void setWindowTitle(CharSequence charSequence) {
        e();
        m mVar = (m) this.e;
        if (mVar.g) {
            return;
        }
        Toolbar toolbar = mVar.f189a;
        mVar.h = charSequence;
        if ((mVar.b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (mVar.g) {
                qc7.p(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // defpackage.of4
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr, int i3) {
    }

    @Override // defpackage.of4
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    @Override // defpackage.pf4
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        onNestedScroll(view, i, i2, i3, i4, i5);
    }

    @Override // defpackage.of4
    public final boolean onStartNestedScroll(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    public void setIcon(Drawable drawable) {
        e();
        m mVar = (m) this.e;
        mVar.d = drawable;
        mVar.c();
    }

    @Override // defpackage.of4
    public final void onNestedScrollAccepted(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // defpackage.of4
    public final void onStopNestedScroll(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }
}

package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.R$attr;
import defpackage.a01;
import defpackage.b01;
import defpackage.br;
import defpackage.d01;
import defpackage.do2;
import defpackage.e23;
import defpackage.fl4;
import defpackage.fv5;
import defpackage.hm6;
import defpackage.lr;
import defpackage.qc7;
import defpackage.rr;
import defpackage.vk6;
import defpackage.yk6;
import defpackage.yq;
import defpackage.zp;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatEditText extends EditText implements fl4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zp f168a;
    public final rr b;
    public final e23 c;
    public final vk6 d;
    public final e23 e;
    public yq f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatEditText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        hm6.a(context);
        yk6.a(this, getContext());
        zp zpVar = new zp(this);
        this.f168a = zpVar;
        zpVar.d(attributeSet, i);
        rr rrVar = new rr(this);
        this.b = rrVar;
        rrVar.f(attributeSet, i);
        rrVar.b();
        e23 e23Var = new e23(9, false);
        e23Var.b = this;
        this.c = e23Var;
        this.d = new vk6();
        e23 e23Var2 = new e23((EditText) this);
        this.e = e23Var2;
        e23Var2.D(attributeSet, i);
        KeyListener keyListener = getKeyListener();
        if (keyListener instanceof NumberKeyListener) {
            return;
        }
        boolean zIsFocusable = super.isFocusable();
        boolean zIsClickable = super.isClickable();
        boolean zIsLongClickable = super.isLongClickable();
        int inputType = super.getInputType();
        KeyListener keyListenerZ = e23Var2.z(keyListener);
        if (keyListenerZ == keyListener) {
            return;
        }
        super.setKeyListener(keyListenerZ);
        super.setRawInputType(inputType);
        super.setFocusable(zIsFocusable);
        super.setClickable(zIsClickable);
        super.setLongClickable(zIsLongClickable);
    }

    private yq getSuperCaller() {
        if (this.f == null) {
            this.f = new yq(this);
        }
        return this.f;
    }

    @Override // defpackage.fl4
    public final d01 a(d01 d01Var) {
        this.d.getClass();
        return vk6.a(this, d01Var);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        zp zpVar = this.f168a;
        if (zpVar != null) {
            zpVar.a();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return fv5.v(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.f168a;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.f168a;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.widget.EditText, android.widget.TextView
    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        e23 e23Var;
        if (Build.VERSION.SDK_INT >= 28 || (e23Var = this.c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) e23Var.c;
        return textClassifier == null ? lr.a((TextView) e23Var.b) : textClassifier;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0044 A[PHI: r1
  0x0044: PHI (r1v9 java.lang.String[]) = (r1v4 java.lang.String[]), (r1v10 java.lang.String[]) binds: [B:26:0x005b, B:18:0x0042] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0062  */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo r6) {
        /*
            r5 = this;
            android.view.inputmethod.InputConnection r0 = super.onCreateInputConnection(r6)
            rr r1 = r5.b
            r1.getClass()
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 30
            if (r1 >= r2) goto L18
            if (r0 == 0) goto L18
            java.lang.CharSequence r3 = r5.getText()
            defpackage.fq3.F(r6, r3)
        L18:
            defpackage.kw7.X(r6, r0, r5)
            if (r0 == 0) goto L68
            if (r1 > r2) goto L68
            java.lang.String[] r2 = defpackage.qc7.g(r5)
            if (r2 == 0) goto L68
            defpackage.fq3.E(r6, r2)
            mb r2 = new mb
            r3 = 12
            r2.<init>(r5, r3)
            r3 = 25
            if (r1 < r3) goto L3a
            a23 r1 = new a23
            r1.<init>(r0, r2)
        L38:
            r0 = r1
            goto L68
        L3a:
            java.lang.String[] r4 = defpackage.fq3.d
            if (r1 < r3) goto L46
            java.lang.String[] r1 = defpackage.uw1.e(r6)
            if (r1 == 0) goto L5e
        L44:
            r4 = r1
            goto L5e
        L46:
            android.os.Bundle r1 = r6.extras
            if (r1 != 0) goto L4b
            goto L5e
        L4b:
            java.lang.String r3 = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
            java.lang.String[] r1 = r1.getStringArray(r3)
            if (r1 != 0) goto L5b
            android.os.Bundle r1 = r6.extras
            java.lang.String r3 = "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
            java.lang.String[] r1 = r1.getStringArray(r3)
        L5b:
            if (r1 == 0) goto L5e
            goto L44
        L5e:
            int r1 = r4.length
            if (r1 != 0) goto L62
            goto L68
        L62:
            b23 r1 = new b23
            r1.<init>(r0, r2)
            goto L38
        L68:
            e23 r5 = r5.e
            zy1 r5 = r5.E(r0, r6)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatEditText.onCreateInputConnection(android.view.inputmethod.EditorInfo):android.view.inputmethod.InputConnection");
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i = Build.VERSION.SDK_INT;
        if (i < 30 || i >= 33) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onDragEvent(DragEvent dragEvent) {
        Activity activity;
        boolean zA = false;
        if (Build.VERSION.SDK_INT < 31 && dragEvent.getLocalState() == null && qc7.g(this) != null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    activity = null;
                    break;
                }
                if (context instanceof Activity) {
                    activity = (Activity) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (activity == null) {
                toString();
            } else if (dragEvent.getAction() != 1 && dragEvent.getAction() == 3) {
                zA = br.a(dragEvent, this, activity);
            }
        }
        if (zA) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public final boolean onTextContextMenuItem(int i) {
        a01 do2Var;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31 || qc7.g(this) == null || !(i == 16908322 || i == 16908337)) {
            return super.onTextContextMenuItem(i);
        }
        ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService("clipboard");
        ClipData primaryClip = clipboardManager == null ? null : clipboardManager.getPrimaryClip();
        if (primaryClip != null && primaryClip.getItemCount() > 0) {
            if (i2 >= 31) {
                do2Var = new do2(primaryClip, 1);
            } else {
                b01 b01Var = new b01();
                b01Var.b = primaryClip;
                b01Var.c = 1;
                do2Var = b01Var;
            }
            do2Var.setFlags(i == 16908322 ? 0 : 1);
            qc7.k(this, do2Var.build());
        }
        return true;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.f168a;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.f168a;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(fv5.w(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z) {
        this.e.M(z);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.e.z(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.f168a;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.f168a;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        rr rrVar = this.b;
        rrVar.k(colorStateList);
        rrVar.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        rr rrVar = this.b;
        rrVar.l(mode);
        rrVar.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.g(context, i);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        e23 e23Var;
        if (Build.VERSION.SDK_INT >= 28 || (e23Var = this.c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            e23Var.c = textClassifier;
        }
    }

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.editTextStyle);
    }
}

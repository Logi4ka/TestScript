package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.appcompat.R$attr;
import defpackage.ar;
import defpackage.hm6;
import defpackage.im6;
import defpackage.yk6;
import defpackage.zp;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatImageButton extends ImageButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zp f169a;
    public final ar b;
    public boolean c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        hm6.a(context);
        this.c = false;
        yk6.a(this, getContext());
        zp zpVar = new zp(this);
        this.f169a = zpVar;
        zpVar.d(attributeSet, i);
        ar arVar = new ar(this);
        this.b = arVar;
        arVar.b(attributeSet, i);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        zp zpVar = this.f169a;
        if (zpVar != null) {
            zpVar.a();
        }
        ar arVar = this.b;
        if (arVar != null) {
            arVar.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.f169a;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.f169a;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        im6 im6Var;
        ar arVar = this.b;
        if (arVar == null || (im6Var = arVar.b) == null) {
            return null;
        }
        return im6Var.f2882a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        im6 im6Var;
        ar arVar = this.b;
        if (arVar == null || (im6Var = arVar.b) == null) {
            return null;
        }
        return im6Var.b;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(this.b.f429a.getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.f169a;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.f169a;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        ar arVar = this.b;
        if (arVar != null) {
            arVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        ar arVar = this.b;
        if (arVar != null && drawable != null && !this.c) {
            arVar.c = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (arVar != null) {
            arVar.a();
            if (this.c) {
                return;
            }
            ImageView imageView = arVar.f429a;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(arVar.c);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.c = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        this.b.c(i);
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        ar arVar = this.b;
        if (arVar != null) {
            arVar.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.f169a;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.f169a;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        ar arVar = this.b;
        if (arVar != null) {
            if (arVar.b == null) {
                arVar.b = new im6();
            }
            im6 im6Var = arVar.b;
            im6Var.f2882a = colorStateList;
            im6Var.d = true;
            arVar.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        ar arVar = this.b;
        if (arVar != null) {
            if (arVar.b == null) {
                arVar.b = new im6();
            }
            im6 im6Var = arVar.b;
            im6Var.b = mode;
            im6Var.c = true;
            arVar.a();
        }
    }

    public AppCompatImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.imageButtonStyle);
    }
}

package androidx.appcompat.widget;

import android.content.Context;
import android.os.Parcelable;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.Toolbar;
import defpackage.ew3;
import defpackage.jr0;
import defpackage.lw3;
import defpackage.n96;
import defpackage.xw3;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class k implements xw3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ew3 f188a;
    public lw3 b;
    public final /* synthetic */ Toolbar c;

    public k(Toolbar toolbar) {
        this.c = toolbar;
    }

    @Override // defpackage.xw3
    public final void b(boolean z) {
        if (this.b != null) {
            ew3 ew3Var = this.f188a;
            if (ew3Var != null) {
                int size = ew3Var.f.size();
                for (int i = 0; i < size; i++) {
                    if (this.f188a.getItem(i) == this.b) {
                        return;
                    }
                }
            }
            f(this.b);
        }
    }

    @Override // defpackage.xw3
    public final boolean c(n96 n96Var) {
        return false;
    }

    @Override // defpackage.xw3
    public final boolean d() {
        return false;
    }

    @Override // defpackage.xw3
    public final void e(ew3 ew3Var, boolean z) {
    }

    @Override // defpackage.xw3
    public final boolean f(lw3 lw3Var) {
        Toolbar toolbar = this.c;
        KeyEvent.Callback callback = toolbar.w;
        if (callback instanceof jr0) {
            ((jr0) callback).onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.w);
        toolbar.removeView(toolbar.v);
        toolbar.w = null;
        ArrayList arrayList = toolbar.w0;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.b = null;
        toolbar.requestLayout();
        lw3Var.C = false;
        lw3Var.n.p(false);
        toolbar.w();
        return true;
    }

    @Override // defpackage.xw3
    public final void g(Parcelable parcelable) {
    }

    @Override // defpackage.xw3
    public final int getId() {
        return 0;
    }

    @Override // defpackage.xw3
    public final boolean i(lw3 lw3Var) {
        Toolbar toolbar = this.c;
        toolbar.c();
        ViewParent parent = toolbar.v.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.v);
            }
            toolbar.addView(toolbar.v);
        }
        View actionView = lw3Var.getActionView();
        toolbar.w = actionView;
        this.b = lw3Var;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.w);
            }
            Toolbar.LayoutParams layoutParamsH = Toolbar.h();
            layoutParamsH.f151a = (toolbar.f0 & 112) | 8388611;
            layoutParamsH.b = 2;
            toolbar.w.setLayoutParams(layoutParamsH);
            toolbar.addView(toolbar.w);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (((Toolbar.LayoutParams) childAt.getLayoutParams()).b != 2 && childAt != toolbar.f183a) {
                toolbar.removeViewAt(childCount);
                toolbar.w0.add(childAt);
            }
        }
        toolbar.requestLayout();
        lw3Var.C = true;
        lw3Var.n.p(false);
        KeyEvent.Callback callback = toolbar.w;
        if (callback instanceof jr0) {
            ((jr0) callback).onActionViewExpanded();
        }
        toolbar.w();
        return true;
    }

    @Override // defpackage.xw3
    public final void k(Context context, ew3 ew3Var) {
        lw3 lw3Var;
        ew3 ew3Var2 = this.f188a;
        if (ew3Var2 != null && (lw3Var = this.b) != null) {
            ew3Var2.d(lw3Var);
        }
        this.f188a = ew3Var;
    }

    @Override // defpackage.xw3
    public final Parcelable l() {
        return null;
    }
}

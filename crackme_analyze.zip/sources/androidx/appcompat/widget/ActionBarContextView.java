package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import androidx.appcompat.R$layout;
import androidx.appcompat.R$styleable;
import defpackage.a5;
import defpackage.ax3;
import defpackage.bx7;
import defpackage.e6;
import defpackage.ew3;
import defpackage.me7;
import defpackage.mf7;
import defpackage.qc7;
import defpackage.vk5;
import defpackage.y5;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final defpackage.k f158a;
    public final Context b;
    public CharSequence b0;
    public ActionMenuView c;
    public View c0;
    public b d;
    public View d0;
    public int e;
    public View e0;
    public me7 f;
    public LinearLayout f0;
    public TextView g0;
    public TextView h0;
    public boolean i;
    public final int i0;
    public final int j0;
    public boolean k0;
    public final int l0;
    public boolean v;
    public CharSequence w;

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        int resourceId;
        super(context, attributeSet, i);
        this.f158a = new defpackage.k(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R$attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.b = context;
        } else {
            this.b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ActionMode, i, 0);
        int i2 = R$styleable.ActionMode_background;
        setBackground((!typedArrayObtainStyledAttributes.hasValue(i2) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(i2, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(i2) : bx7.t(context, resourceId));
        this.i0 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.ActionMode_titleTextStyle, 0);
        this.j0 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.ActionMode_subtitleTextStyle, 0);
        this.e = typedArrayObtainStyledAttributes.getLayoutDimension(R$styleable.ActionMode_height, 0);
        this.l0 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.ActionMode_closeItemLayout, R$layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i, int i2) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i2);
        return Math.max(0, i - view.getMeasuredWidth());
    }

    public static int g(int i, int i2, int i3, View view, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = ((i3 - measuredHeight) / 2) + i2;
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    public final void c(e6 e6Var) {
        View view = this.c0;
        int i = 0;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.l0, (ViewGroup) this, false);
            this.c0 = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.c0);
        }
        View viewFindViewById = this.c0.findViewById(R$id.action_mode_close_button);
        this.d0 = viewFindViewById;
        viewFindViewById.setOnClickListener(new a5(e6Var, i));
        ew3 ew3VarC = e6Var.c();
        b bVar = this.d;
        if (bVar != null) {
            bVar.j();
            y5 y5Var = bVar.j0;
            if (y5Var != null && y5Var.b()) {
                y5Var.i.dismiss();
            }
        }
        b bVar2 = new b(getContext());
        this.d = bVar2;
        bVar2.b0 = true;
        bVar2.c0 = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        ew3VarC.b(this.d, this.b);
        b bVar3 = this.d;
        ax3 ax3Var = bVar3.v;
        if (ax3Var == null) {
            ax3 ax3Var2 = (ax3) bVar3.d.inflate(bVar3.f, (ViewGroup) this, false);
            bVar3.v = ax3Var2;
            ax3Var2.b(bVar3.c);
            bVar3.b(true);
        }
        ax3 ax3Var3 = bVar3.v;
        if (ax3Var != ax3Var3) {
            ((ActionMenuView) ax3Var3).setPresenter(bVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) ax3Var3;
        this.c = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.c, layoutParams);
    }

    public final void d() {
        if (this.f0 == null) {
            LayoutInflater.from(getContext()).inflate(R$layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f0 = linearLayout;
            this.g0 = (TextView) linearLayout.findViewById(R$id.action_bar_title);
            this.h0 = (TextView) this.f0.findViewById(R$id.action_bar_subtitle);
            int i = this.i0;
            if (i != 0) {
                this.g0.setTextAppearance(getContext(), i);
            }
            int i2 = this.j0;
            if (i2 != 0) {
                this.h0.setTextAppearance(getContext(), i2);
            }
        }
        this.g0.setText(this.w);
        this.h0.setText(this.b0);
        boolean zIsEmpty = TextUtils.isEmpty(this.w);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.b0);
        this.h0.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f0.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f0.getParent() == null) {
            addView(this.f0);
        }
    }

    public final void e() {
        removeAllViews();
        this.e0 = null;
        this.c = null;
        this.d = null;
        View view = this.d0;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f != null ? this.f158a.f3608a : getVisibility();
    }

    public int getContentHeight() {
        return this.e;
    }

    public CharSequence getSubtitle() {
        return this.b0;
    }

    public CharSequence getTitle() {
        return this.w;
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i) {
        if (i != getVisibility()) {
            me7 me7Var = this.f;
            if (me7Var != null) {
                me7Var.b();
            }
            super.setVisibility(i);
        }
    }

    public final me7 i(int i, long j) {
        me7 me7Var = this.f;
        if (me7Var != null) {
            me7Var.b();
        }
        defpackage.k kVar = this.f158a;
        if (i != 0) {
            me7 me7VarA = qc7.a(this);
            me7VarA.a(0.0f);
            me7VarA.c(j);
            ((ActionBarContextView) kVar.c).f = me7VarA;
            kVar.f3608a = i;
            me7VarA.d(kVar);
            return me7VarA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        me7 me7VarA2 = qc7.a(this);
        me7VarA2.a(1.0f);
        me7VarA2.c(j);
        ((ActionBarContextView) kVar.c).f = me7VarA2;
        kVar.f3608a = i;
        me7VarA2.d(kVar);
        return me7VarA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, R$styleable.ActionBar, R$attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(R$styleable.ActionBar_height, 0));
        typedArrayObtainStyledAttributes.recycle();
        b bVar = this.d;
        if (bVar != null) {
            Configuration configuration2 = bVar.b.getResources().getConfiguration();
            int i = configuration2.screenWidthDp;
            int i2 = configuration2.screenHeightDp;
            bVar.f0 = (configuration2.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && i2 > 720) || (i > 720 && i2 > 960)) ? 5 : (i >= 500 || (i > 640 && i2 > 480) || (i > 480 && i2 > 640)) ? 4 : i >= 360 ? 3 : 2;
            ew3 ew3Var = bVar.c;
            if (ew3Var != null) {
                ew3Var.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        b bVar = this.d;
        if (bVar != null) {
            bVar.j();
            y5 y5Var = this.d.j0;
            if (y5Var == null || !y5Var.b()) {
                return;
            }
            y5Var.i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.v = false;
        }
        if (!this.v) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.v = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.v = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2 = mf7.f4149a;
        boolean z3 = getLayoutDirection() == 1;
        int paddingRight = z3 ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.c0;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.c0.getLayoutParams();
            int i5 = z3 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = z3 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i7 = z3 ? paddingRight - i5 : paddingRight + i5;
            int iG = g(i7, paddingTop, paddingTop2, this.c0, z3) + i7;
            paddingRight = z3 ? iG - i6 : iG + i6;
        }
        LinearLayout linearLayout = this.f0;
        if (linearLayout != null && this.e0 == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(paddingRight, paddingTop, paddingTop2, this.f0, z3);
        }
        View view2 = this.e0;
        if (view2 != null) {
            g(paddingRight, paddingTop, paddingTop2, view2, z3);
        }
        int paddingLeft = z3 ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.c;
        if (actionMenuView != null) {
            g(paddingLeft, paddingTop, paddingTop2, actionMenuView, !z3);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            vk5.k(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
            return;
        }
        if (View.MeasureSpec.getMode(i2) == 0) {
            vk5.k(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
            return;
        }
        int size = View.MeasureSpec.getSize(i);
        int size2 = this.e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i2);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.c0;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.c0.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f0;
        if (linearLayout != null && this.e0 == null) {
            if (this.k0) {
                this.f0.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f0.getMeasuredWidth();
                boolean z = measuredWidth <= paddingLeft;
                if (z) {
                    paddingLeft -= measuredWidth;
                }
                this.f0.setVisibility(z ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.e0;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i3 = layoutParams.width;
            int i4 = i3 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i3 >= 0) {
                paddingLeft = Math.min(i3, paddingLeft);
            }
            int i5 = layoutParams.height;
            int i6 = i5 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i5 >= 0) {
                iMin = Math.min(i5, iMin);
            }
            this.e0.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i4), View.MeasureSpec.makeMeasureSpec(iMin, i6));
        }
        if (this.e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            int measuredHeight = getChildAt(i8).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i7) {
                i7 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i7);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.i = false;
        }
        if (!this.i) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.i = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.i = false;
        return true;
    }

    public void setContentHeight(int i) {
        this.e = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.e0;
        if (view2 != null) {
            removeView(view2);
        }
        this.e0 = view;
        if (view != null && (linearLayout = this.f0) != null) {
            removeView(linearLayout);
            this.f0 = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.b0 = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.w = charSequence;
        d();
        qc7.p(this, charSequence);
    }

    public void setTitleOptional(boolean z) {
        if (z != this.k0) {
            requestLayout();
        }
        this.k0 = z;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.actionModeStyle);
    }
}

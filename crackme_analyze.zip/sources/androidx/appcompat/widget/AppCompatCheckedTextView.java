package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$styleable;
import defpackage.bq;
import defpackage.bx7;
import defpackage.du1;
import defpackage.fv5;
import defpackage.gx5;
import defpackage.hm6;
import defpackage.kw7;
import defpackage.qc7;
import defpackage.rr;
import defpackage.yk6;
import defpackage.zp;
import defpackage.zq;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatCheckedTextView extends CheckedTextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final bq f167a;
    public final zp b;
    public final rr c;
    public zq d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet, int i) {
        int resourceId;
        int resourceId2;
        super(context, attributeSet, i);
        hm6.a(context);
        yk6.a(this, getContext());
        rr rrVar = new rr(this);
        this.c = rrVar;
        rrVar.f(attributeSet, i);
        rrVar.b();
        zp zpVar = new zp(this);
        this.b = zpVar;
        zpVar.d(attributeSet, i);
        this.f167a = new bq(this);
        gx5 gx5VarX = gx5.x(getContext(), attributeSet, R$styleable.CheckedTextView, i);
        TypedArray typedArray = (TypedArray) gx5VarX.c;
        qc7.n(this, getContext(), R$styleable.CheckedTextView, attributeSet, (TypedArray) gx5VarX.c, i);
        try {
            if (typedArray.hasValue(R$styleable.CheckedTextView_checkMarkCompat) && (resourceId2 = typedArray.getResourceId(R$styleable.CheckedTextView_checkMarkCompat, 0)) != 0) {
                try {
                    setCheckMarkDrawable(bx7.t(getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                    if (typedArray.hasValue(R$styleable.CheckedTextView_android_checkMark)) {
                        setCheckMarkDrawable(bx7.t(getContext(), resourceId));
                    }
                }
            } else if (typedArray.hasValue(R$styleable.CheckedTextView_android_checkMark) && (resourceId = typedArray.getResourceId(R$styleable.CheckedTextView_android_checkMark, 0)) != 0) {
                setCheckMarkDrawable(bx7.t(getContext(), resourceId));
            }
            if (typedArray.hasValue(R$styleable.CheckedTextView_checkMarkTint)) {
                setCheckMarkTintList(gx5VarX.h(R$styleable.CheckedTextView_checkMarkTint));
            }
            if (typedArray.hasValue(R$styleable.CheckedTextView_checkMarkTintMode)) {
                setCheckMarkTintMode(du1.c(typedArray.getInt(R$styleable.CheckedTextView_checkMarkTintMode, -1), null));
            }
            gx5VarX.z();
            getEmojiTextViewHelper().b(attributeSet, i);
        } catch (Throwable th) {
            gx5VarX.z();
            throw th;
        }
    }

    private zq getEmojiTextViewHelper() {
        if (this.d == null) {
            this.d = new zq(this);
        }
        return this.d;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.b();
        }
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.a();
        }
        bq bqVar = this.f167a;
        if (bqVar != null) {
            bqVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return fv5.v(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.b;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.b;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        bq bqVar = this.f167a;
        if (bqVar != null) {
            return (ColorStateList) bqVar.f639a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        bq bqVar = this.f167a;
        if (bqVar != null) {
            return (PorterDuff.Mode) bqVar.b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.c.e();
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        kw7.X(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().c(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        bq bqVar = this.f167a;
        if (bqVar != null) {
            if (bqVar.e) {
                bqVar.e = false;
            } else {
                bqVar.e = true;
                bqVar.b();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(fv5.w(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().d(z);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        bq bqVar = this.f167a;
        if (bqVar != null) {
            bqVar.f639a = colorStateList;
            bqVar.c = true;
            bqVar.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        bq bqVar = this.f167a;
        if (bqVar != null) {
            bqVar.b = mode;
            bqVar.d = true;
            bqVar.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        rr rrVar = this.c;
        rrVar.k(colorStateList);
        rrVar.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        rr rrVar = this.c;
        rrVar.l(mode);
        rrVar.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.g(context, i);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(bx7.t(getContext(), i));
    }

    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.checkedTextViewStyle);
    }
}

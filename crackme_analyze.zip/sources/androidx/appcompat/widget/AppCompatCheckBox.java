package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.CheckBox;
import androidx.appcompat.R$attr;
import defpackage.bq;
import defpackage.bx7;
import defpackage.hm6;
import defpackage.km6;
import defpackage.rr;
import defpackage.yk6;
import defpackage.zp;
import defpackage.zq;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatCheckBox extends CheckBox implements km6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final bq f166a;
    public final zp b;
    public final rr c;
    public zq d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatCheckBox(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        hm6.a(context);
        yk6.a(this, getContext());
        bq bqVar = new bq(this);
        this.f166a = bqVar;
        bqVar.d(attributeSet, i);
        zp zpVar = new zp(this);
        this.b = zpVar;
        zpVar.d(attributeSet, i);
        rr rrVar = new rr(this);
        this.c = rrVar;
        rrVar.f(attributeSet, i);
        getEmojiTextViewHelper().b(attributeSet, i);
    }

    private zq getEmojiTextViewHelper() {
        if (this.d == null) {
            this.d = new zq(this);
        }
        return this.d;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.a();
        }
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.b;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.b;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    @Override // defpackage.km6
    public ColorStateList getSupportButtonTintList() {
        bq bqVar = this.f166a;
        if (bqVar != null) {
            return (ColorStateList) bqVar.f639a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        bq bqVar = this.f166a;
        if (bqVar != null) {
            return (PorterDuff.Mode) bqVar.b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.c.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().c(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        bq bqVar = this.f166a;
        if (bqVar != null) {
            if (bqVar.e) {
                bqVar.e = false;
            } else {
                bqVar.e = true;
                bqVar.a();
            }
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.c;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.b;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    @Override // defpackage.km6
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        bq bqVar = this.f166a;
        if (bqVar != null) {
            bqVar.f639a = colorStateList;
            bqVar.c = true;
            bqVar.a();
        }
    }

    @Override // defpackage.km6
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        bq bqVar = this.f166a;
        if (bqVar != null) {
            bqVar.b = mode;
            bqVar.d = true;
            bqVar.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        rr rrVar = this.c;
        rrVar.k(colorStateList);
        rrVar.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        rr rrVar = this.c;
        rrVar.l(mode);
        rrVar.b();
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i) {
        setButtonDrawable(bx7.t(getContext(), i));
    }

    public AppCompatCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.checkboxStyle);
    }
}

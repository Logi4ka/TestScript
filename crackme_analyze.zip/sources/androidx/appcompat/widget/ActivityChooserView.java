package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import androidx.appcompat.R$dimen;
import androidx.appcompat.R$id;
import androidx.appcompat.R$layout;
import androidx.appcompat.R$styleable;
import defpackage.g6;
import defpackage.gx5;
import defpackage.i6;
import defpackage.j6;
import defpackage.k6;
import defpackage.l6;
import defpackage.m6;
import defpackage.n6;
import defpackage.qc7;
import defpackage.vk5;
import defpackage.w5;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ActivityChooserView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m6 f162a;
    public final n6 b;
    public PopupWindow.OnDismissListener b0;
    public final View c;
    public boolean c0;
    public final FrameLayout d;
    public final ImageView e;
    public final FrameLayout f;
    public g6 i;
    public final k6 v;
    public ListPopupWindow w;

    /* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
    public static class InnerLayout extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final int[] f163a = {R.attr.background};

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            gx5 gx5VarW = gx5.w(context, attributeSet, f163a);
            setBackgroundDrawable(gx5VarW.i(0));
            gx5VarW.z();
        }
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        int i2 = 0;
        new j6(this, i2);
        this.v = new k6(this, i2);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ActivityChooserView, i, 0);
        qc7.n(this, context, R$styleable.ActivityChooserView, attributeSet, typedArrayObtainStyledAttributes, i);
        typedArrayObtainStyledAttributes.getInt(R$styleable.ActivityChooserView_initialActivityCount, 4);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ActivityChooserView_expandActivityOverflowButtonDrawable);
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater.from(getContext()).inflate(R$layout.abc_activity_chooser_view, (ViewGroup) this, true);
        n6 n6Var = new n6(this);
        this.b = n6Var;
        View viewFindViewById = findViewById(R$id.activity_chooser_view_content);
        this.c = viewFindViewById;
        viewFindViewById.getBackground();
        FrameLayout frameLayout = (FrameLayout) findViewById(R$id.default_activity_button);
        this.f = frameLayout;
        frameLayout.setOnClickListener(n6Var);
        frameLayout.setOnLongClickListener(n6Var);
        FrameLayout frameLayout2 = (FrameLayout) findViewById(R$id.expand_activities_button);
        frameLayout2.setOnClickListener(n6Var);
        frameLayout2.setAccessibilityDelegate(new l6(0));
        frameLayout2.setOnTouchListener(new w5(this, frameLayout2, 2));
        this.d = frameLayout2;
        ImageView imageView = (ImageView) frameLayout2.findViewById(R$id.image);
        this.e = imageView;
        imageView.setImageDrawable(drawable);
        m6 m6Var = new m6(this);
        this.f162a = m6Var;
        m6Var.registerDataSetObserver(new j6(this, 1));
        Resources resources = context.getResources();
        Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R$dimen.abc_config_prefDialogWidth));
    }

    public final void a() {
        if (b()) {
            getListPopupWindow().dismiss();
            ViewTreeObserver viewTreeObserver = getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeGlobalOnLayoutListener(this.v);
            }
        }
    }

    public final boolean b() {
        return getListPopupWindow().o0.isShowing();
    }

    public i6 getDataModel() {
        this.f162a.getClass();
        return null;
    }

    public ListPopupWindow getListPopupWindow() {
        if (this.w == null) {
            ListPopupWindow listPopupWindow = new ListPopupWindow(getContext());
            this.w = listPopupWindow;
            listPopupWindow.o(this.f162a);
            ListPopupWindow listPopupWindow2 = this.w;
            listPopupWindow2.d0 = this;
            listPopupWindow2.n0 = true;
            listPopupWindow2.o0.setFocusable(true);
            ListPopupWindow listPopupWindow3 = this.w;
            n6 n6Var = this.b;
            listPopupWindow3.e0 = n6Var;
            listPopupWindow3.o0.setOnDismissListener(n6Var);
        }
        return this.w;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f162a.getClass();
        this.c0 = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f162a.getClass();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.v);
        }
        if (b()) {
            a();
        }
        this.c0 = false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.c.layout(0, 0, i3 - i, i4 - i2);
        if (b()) {
            return;
        }
        a();
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        if (this.f.getVisibility() != 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i2), 1073741824);
        }
        View view = this.c;
        measureChild(view, i, i2);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    public void setActivityChooserModel(i6 i6Var) {
        m6 m6Var = this.f162a;
        m6Var.f4085a.f162a.getClass();
        m6Var.notifyDataSetChanged();
        if (b()) {
            a();
            if (b() || !this.c0) {
                return;
            }
            m6Var.getClass();
            vk5.k("No data model. Did you call #setDataModel?");
        }
    }

    public void setDefaultActionButtonContentDescription(int i) {
    }

    public void setExpandActivityOverflowButtonContentDescription(int i) {
        this.e.setContentDescription(getContext().getString(i));
    }

    public void setExpandActivityOverflowButtonDrawable(Drawable drawable) {
        this.e.setImageDrawable(drawable);
    }

    public void setInitialActivityCount(int i) {
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener onDismissListener) {
        this.b0 = onDismissListener;
    }

    public void setProvider(g6 g6Var) {
        this.i = g6Var;
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}

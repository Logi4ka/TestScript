package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import defpackage.bx7;
import defpackage.cy4;
import defpackage.dy4;
import defpackage.e2;
import defpackage.e23;
import defpackage.es6;
import defpackage.fq3;
import defpackage.fv5;
import defpackage.hm6;
import defpackage.kw7;
import defpackage.lr;
import defpackage.ls7;
import defpackage.mf7;
import defpackage.os5;
import defpackage.rr;
import defpackage.sr;
import defpackage.tr;
import defpackage.ur;
import defpackage.yk6;
import defpackage.zp;
import defpackage.zq;
import defpackage.zr;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatTextView extends TextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zp f176a;
    public final rr b;
    public final e23 c;
    public zq d;
    public boolean e;
    public ls7 f;
    public Future i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        hm6.a(context);
        this.e = false;
        this.f = null;
        yk6.a(this, getContext());
        zp zpVar = new zp(this);
        this.f176a = zpVar;
        zpVar.d(attributeSet, i);
        rr rrVar = new rr(this);
        this.b = rrVar;
        rrVar.f(attributeSet, i);
        rrVar.b();
        e23 e23Var = new e23(9, false);
        e23Var.b = this;
        this.c = e23Var;
        getEmojiTextViewHelper().b(attributeSet, i);
    }

    private zq getEmojiTextViewHelper() {
        if (this.d == null) {
            this.d = new zq(this);
        }
        return this.d;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        zp zpVar = this.f176a;
        if (zpVar != null) {
            zpVar.a();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (mf7.c) {
            return super.getAutoSizeMaxTextSize();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return Math.round(rrVar.i.e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (mf7.c) {
            return super.getAutoSizeMinTextSize();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return Math.round(rrVar.i.d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (mf7.c) {
            return super.getAutoSizeStepGranularity();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return Math.round(rrVar.i.c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (mf7.c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        rr rrVar = this.b;
        return rrVar != null ? rrVar.i.f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (mf7.c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return rrVar.i.f7071a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return fv5.v(super.getCustomSelectionActionModeCallback());
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public sr getSuperCaller() {
        if (this.f == null) {
            int i = Build.VERSION.SDK_INT;
            if (i >= 34) {
                this.f = new ur(this);
            } else if (i >= 28) {
                this.f = new tr(this);
            } else if (i >= 26) {
                this.f = new ls7(this, 8);
            }
        }
        return this.f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.f176a;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.f176a;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        Future future = this.i;
        if (future != null) {
            try {
                this.i = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                fv5.h(this);
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        e23 e23Var;
        if (Build.VERSION.SDK_INT >= 28 || (e23Var = this.c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) e23Var.c;
        return textClassifier == null ? lr.a((TextView) e23Var.b) : textClassifier;
    }

    public cy4 getTextMetricsParamsCompat() {
        return fv5.h(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.b.getClass();
        if (Build.VERSION.SDK_INT < 30 && inputConnectionOnCreateInputConnection != null) {
            fq3.F(editorInfo, getText());
        }
        kw7.X(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i = Build.VERSION.SDK_INT;
        if (i < 30 || i >= 33 || !onCheckIsTextEditor()) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        rr rrVar = this.b;
        if (rrVar == null || mf7.c) {
            return;
        }
        rrVar.i.a();
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i, int i2) {
        Future future = this.i;
        if (future != null) {
            try {
                this.i = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                fv5.h(this);
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i, i2);
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        rr rrVar = this.b;
        if (rrVar != null) {
            zr zrVar = rrVar.i;
            if (mf7.c || !zrVar.f()) {
                return;
            }
            zrVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().c(z);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (mf7.c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.h(i, i2, i3, i4);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (mf7.c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.i(iArr, i);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (mf7.c) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.j(i);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.f176a;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.f176a;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i != 0 ? bx7.t(context, i) : null, i2 != 0 ? bx7.t(context, i2) : null, i3 != 0 ? bx7.t(context, i3) : null, i4 != 0 ? bx7.t(context, i4) : null);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i != 0 ? bx7.t(context, i) : null, i2 != 0 ? bx7.t(context, i2) : null, i3 != 0 ? bx7.t(context, i3) : null, i4 != 0 ? bx7.t(context, i4) : null);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(fv5.w(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().l(i);
        } else {
            fv5.q(this, i);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().g(i);
        } else {
            fv5.s(this, i);
        }
    }

    @Override // android.widget.TextView
    public final void setLineHeight(int i, float f) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 34) {
            getSuperCaller().n(i, f);
        } else if (i2 >= 34) {
            e2.n(this, i, f);
        } else {
            fv5.t(this, Math.round(TypedValue.applyDimension(i, f, getResources().getDisplayMetrics())));
        }
    }

    public void setPrecomputedText(dy4 dy4Var) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        fv5.h(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.f176a;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.f176a;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        rr rrVar = this.b;
        rrVar.k(colorStateList);
        rrVar.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        rr rrVar = this.b;
        rrVar.l(mode);
        rrVar.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.g(context, i);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        e23 e23Var;
        if (Build.VERSION.SDK_INT >= 28 || (e23Var = this.c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            e23Var.c = textClassifier;
        }
    }

    public void setTextFuture(Future<dy4> future) {
        this.i = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(cy4 cy4Var) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = cy4Var.b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i = 1;
        if (textDirectionHeuristic2 != textDirectionHeuristic3 && textDirectionHeuristic2 != (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i = 7;
            }
        }
        setTextDirection(i);
        getPaint().set(cy4Var.f1574a);
        setBreakStrategy(cy4Var.c);
        setHyphenationFrequency(cy4Var.d);
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i, float f) {
        boolean z = mf7.c;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            zr zrVar = rrVar.i;
            if (z || zrVar.f()) {
                return;
            }
            zrVar.g(f, i);
        }
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface, int i) {
        Typeface typefaceCreate;
        if (this.e) {
            return;
        }
        if (typeface == null || i <= 0) {
            typefaceCreate = null;
        } else {
            Context context = getContext();
            os5 os5Var = es6.f2018a;
            if (context == null) {
                defpackage.g.l("Context cannot be null");
                return;
            }
            typefaceCreate = Typeface.create(typeface, i);
        }
        this.e = true;
        if (typefaceCreate != null) {
            typeface = typefaceCreate;
        }
        try {
            super.setTypeface(typeface, i);
        } finally {
            this.e = false;
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i) {
        fv5.t(this, i);
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }
}

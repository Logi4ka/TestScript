package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build;
import android.view.MenuItem;
import android.widget.PopupWindow;
import defpackage.dv1;
import defpackage.ew3;
import defpackage.kw3;
import defpackage.ls7;
import defpackage.lw3;
import defpackage.vw3;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class d extends ListPopupWindow implements kw3 {
    public static final Method s0;
    public ls7 r0;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                s0 = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
        }
    }

    @Override // defpackage.kw3
    public final void c(ew3 ew3Var, MenuItem menuItem) {
        ls7 ls7Var = this.r0;
        if (ls7Var != null) {
            ls7Var.c(ew3Var, menuItem);
        }
    }

    @Override // defpackage.kw3
    public final void i(ew3 ew3Var, lw3 lw3Var) {
        ls7 ls7Var = this.r0;
        if (ls7Var != null) {
            ls7Var.i(ew3Var, lw3Var);
        }
    }

    @Override // androidx.appcompat.widget.ListPopupWindow
    public final dv1 p(Context context, boolean z) {
        vw3 vw3Var = new vw3(context, z);
        vw3Var.setHoverListener(this);
        return vw3Var;
    }
}

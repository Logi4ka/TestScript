package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import defpackage.ew3;
import defpackage.gj1;
import defpackage.ls7;
import defpackage.me7;
import defpackage.tq;
import defpackage.xz0;
import defpackage.y5;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TypedValue f179a;
    public TypedValue b;
    public TypedValue c;
    public TypedValue d;
    public TypedValue e;
    public TypedValue f;
    public final Rect i;
    public xz0 v;

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.i = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.e == null) {
            this.e = new TypedValue();
        }
        return this.e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f == null) {
            this.f = new TypedValue();
        }
        return this.f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.c == null) {
            this.c = new TypedValue();
        }
        return this.c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.d == null) {
            this.d = new TypedValue();
        }
        return this.d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f179a == null) {
            this.f179a = new TypedValue();
        }
        return this.f179a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.b == null) {
            this.b = new TypedValue();
        }
        return this.b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        xz0 xz0Var = this.v;
        if (xz0Var != null) {
            xz0Var.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        b bVar;
        super.onDetachedFromWindow();
        xz0 xz0Var = this.v;
        if (xz0Var != null) {
            tq tqVar = (tq) ((ls7) xz0Var).b;
            gj1 gj1Var = tqVar.g0;
            if (gj1Var != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) gj1Var;
                actionBarOverlayLayout.e();
                ActionMenuView actionMenuView = ((m) actionBarOverlayLayout.e).f189a.f183a;
                if (actionMenuView != null && (bVar = actionMenuView.l0) != null) {
                    bVar.j();
                    y5 y5Var = bVar.j0;
                    if (y5Var != null && y5Var.b()) {
                        y5Var.i.dismiss();
                    }
                }
            }
            if (tqVar.l0 != null) {
                tqVar.Z.getDecorView().removeCallbacks(tqVar.m0);
                if (tqVar.l0.isShowing()) {
                    try {
                        tqVar.l0.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                tqVar.l0 = null;
            }
            me7 me7Var = tqVar.n0;
            if (me7Var != null) {
                me7Var.b();
            }
            ew3 ew3Var = tqVar.z(0).h;
            if (ew3Var != null) {
                ew3Var.c(true);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onMeasure(int r17, int r18) {
        /*
            Method dump skipped, instruction units count: 229
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(xz0 xz0Var) {
        this.v = xz0Var;
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}

package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.R$layout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import defpackage.a6;
import defpackage.ch5;
import defpackage.e30;
import defpackage.ew3;
import defpackage.g6;
import defpackage.lw3;
import defpackage.n96;
import defpackage.qw3;
import defpackage.rl2;
import defpackage.vk5;
import defpackage.ww3;
import defpackage.y5;
import defpackage.z5;
import defpackage.zw3;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class b extends e30 {
    public a6 X;
    public Drawable Y;
    public boolean Z;
    public boolean b0;
    public boolean c0;
    public int d0;
    public int e0;
    public int f0;
    public boolean g0;
    public final SparseBooleanArray h0;
    public y5 i0;
    public y5 j0;
    public rl2 k0;
    public z5 l0;
    public final ch5 m0;
    public int n0;

    public b(Context context) {
        int i = R$layout.abc_action_menu_layout;
        int i2 = R$layout.abc_action_menu_item_layout;
        this.f1851a = context;
        this.d = LayoutInflater.from(context);
        this.f = i;
        this.i = i2;
        this.h0 = new SparseBooleanArray();
        this.m0 = new ch5(this, 6);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View a(lw3 lw3Var, View view, ViewGroup viewGroup) {
        View actionView = lw3Var.getActionView();
        if (actionView == null || lw3Var.e()) {
            zw3 zw3Var = view instanceof zw3 ? (zw3) view : (zw3) this.d.inflate(this.i, viewGroup, false);
            zw3Var.c(lw3Var);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) zw3Var;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.v);
            if (this.l0 == null) {
                this.l0 = new z5(this);
            }
            actionMenuItemView.setPopupCallback(this.l0);
            actionView = (View) zw3Var;
        }
        actionView.setVisibility(lw3Var.C ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof ActionMenuView.LayoutParams)) {
            actionView.setLayoutParams(ActionMenuView.k(layoutParams));
        }
        return actionView;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.xw3
    public final void b(boolean z) {
        int i;
        ViewGroup viewGroup = (ViewGroup) this.v;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (viewGroup != null) {
            ew3 ew3Var = this.c;
            if (ew3Var != null) {
                ew3Var.i();
                ArrayList arrayListL = this.c.l();
                int size = arrayListL.size();
                i = 0;
                for (int i2 = 0; i2 < size; i2++) {
                    lw3 lw3Var = (lw3) arrayListL.get(i2);
                    if ((lw3Var.x & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i);
                        lw3 itemData = childAt instanceof zw3 ? ((zw3) childAt).getItemData() : null;
                        View viewA = a(lw3Var, childAt, viewGroup);
                        if (lw3Var != itemData) {
                            viewA.setPressed(false);
                            viewA.jumpDrawablesToCurrentState();
                        }
                        if (viewA != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) viewA.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(viewA);
                            }
                            ((ViewGroup) this.v).addView(viewA, i);
                        }
                        i++;
                    }
                }
            } else {
                i = 0;
            }
            while (i < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i) == this.X) {
                    i++;
                } else {
                    viewGroup.removeViewAt(i);
                }
            }
        }
        ((View) this.v).requestLayout();
        ew3 ew3Var2 = this.c;
        if (ew3Var2 != null) {
            ew3Var2.i();
            ArrayList arrayList2 = ew3Var2.i;
            int size2 = arrayList2.size();
            for (int i3 = 0; i3 < size2; i3++) {
                g6 g6Var = ((lw3) arrayList2.get(i3)).A;
                if (g6Var != null) {
                    g6Var.f2328a = this;
                }
            }
        }
        ew3 ew3Var3 = this.c;
        if (ew3Var3 != null) {
            ew3Var3.i();
            arrayList = ew3Var3.j;
        }
        if (this.b0 && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((lw3) arrayList.get(0)).C;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        a6 a6Var = this.X;
        if (z2) {
            if (a6Var == null) {
                this.X = new a6(this, this.f1851a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.X.getParent();
            if (viewGroup3 != this.v) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.X);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.v;
                a6 a6Var2 = this.X;
                actionMenuView.getClass();
                ActionMenuView.LayoutParams layoutParamsJ = ActionMenuView.j();
                layoutParamsJ.f161a = true;
                actionMenuView.addView(a6Var2, layoutParamsJ);
            }
        } else if (a6Var != null) {
            Object parent = a6Var.getParent();
            Object obj = this.v;
            if (parent == obj) {
                ((ViewGroup) obj).removeView(this.X);
            }
        }
        ((ActionMenuView) this.v).setOverflowReserved(this.b0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.xw3
    public final boolean c(n96 n96Var) {
        boolean z;
        if (n96Var.hasVisibleItems()) {
            n96 n96Var2 = n96Var;
            while (true) {
                ew3 ew3Var = n96Var2.A;
                if (ew3Var == this.c) {
                    break;
                }
                n96Var2 = (n96) ew3Var;
            }
            lw3 lw3Var = n96Var2.B;
            ViewGroup viewGroup = (ViewGroup) this.v;
            View view = null;
            view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                int i = 0;
                while (true) {
                    if (i >= childCount) {
                        break;
                    }
                    View childAt = viewGroup.getChildAt(i);
                    if ((childAt instanceof zw3) && ((zw3) childAt).getItemData() == lw3Var) {
                        view = childAt;
                        break;
                    }
                    i++;
                }
            }
            if (view != null) {
                this.n0 = n96Var.B.f4013a;
                int size = n96Var.f.size();
                int i2 = 0;
                while (true) {
                    if (i2 >= size) {
                        z = false;
                        break;
                    }
                    MenuItem item = n96Var.getItem(i2);
                    if (item.isVisible() && item.getIcon() != null) {
                        z = true;
                        break;
                    }
                    i2++;
                }
                y5 y5Var = new y5(this, this.b, n96Var, view);
                this.j0 = y5Var;
                y5Var.g = z;
                qw3 qw3Var = y5Var.i;
                if (qw3Var != null) {
                    qw3Var.p(z);
                }
                y5 y5Var2 = this.j0;
                if (!y5Var2.b()) {
                    if (y5Var2.e == null) {
                        vk5.k("MenuPopupHelper cannot be used without an anchor");
                        return false;
                    }
                    y5Var2.d(0, 0, false, false);
                }
                ww3 ww3Var = this.e;
                if (ww3Var != null) {
                    ww3Var.J(n96Var);
                }
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.xw3
    public final boolean d() {
        int size;
        ArrayList arrayListL;
        int i;
        boolean z;
        b bVar = this;
        ew3 ew3Var = bVar.c;
        if (ew3Var != null) {
            arrayListL = ew3Var.l();
            size = arrayListL.size();
        } else {
            size = 0;
            arrayListL = null;
        }
        int i2 = bVar.f0;
        int i3 = bVar.e0;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) bVar.v;
        int i4 = 0;
        boolean z2 = false;
        int i5 = 0;
        int i6 = 0;
        while (true) {
            i = 2;
            z = true;
            if (i4 >= size) {
                break;
            }
            lw3 lw3Var = (lw3) arrayListL.get(i4);
            int i7 = lw3Var.y;
            if ((i7 & 2) == 2) {
                i5++;
            } else if ((i7 & 1) == 1) {
                i6++;
            } else {
                z2 = true;
            }
            if (bVar.g0 && lw3Var.C) {
                i2 = 0;
            }
            i4++;
        }
        if (bVar.b0 && (z2 || i6 + i5 > i2)) {
            i2--;
        }
        int i8 = i2 - i5;
        SparseBooleanArray sparseBooleanArray = bVar.h0;
        sparseBooleanArray.clear();
        int i9 = 0;
        int i10 = 0;
        while (i9 < size) {
            lw3 lw3Var2 = (lw3) arrayListL.get(i9);
            int i11 = lw3Var2.y;
            boolean z3 = (i11 & 2) == i ? z : false;
            int i12 = lw3Var2.b;
            if (z3) {
                View viewA = bVar.a(lw3Var2, null, viewGroup);
                viewA.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredWidth = viewA.getMeasuredWidth();
                i3 -= measuredWidth;
                if (i10 == 0) {
                    i10 = measuredWidth;
                }
                if (i12 != 0) {
                    sparseBooleanArray.put(i12, z);
                }
                lw3Var2.g(z);
            } else if ((i11 & 1) == z) {
                boolean z4 = sparseBooleanArray.get(i12);
                boolean z5 = ((i8 > 0 || z4) && i3 > 0) ? z : false;
                if (z5) {
                    View viewA2 = bVar.a(lw3Var2, null, viewGroup);
                    viewA2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                    int measuredWidth2 = viewA2.getMeasuredWidth();
                    i3 -= measuredWidth2;
                    if (i10 == 0) {
                        i10 = measuredWidth2;
                    }
                    z5 &= i3 + i10 > 0;
                }
                if (z5 && i12 != 0) {
                    sparseBooleanArray.put(i12, true);
                } else if (z4) {
                    sparseBooleanArray.put(i12, false);
                    for (int i13 = 0; i13 < i9; i13++) {
                        lw3 lw3Var3 = (lw3) arrayListL.get(i13);
                        if (lw3Var3.b == i12) {
                            if ((lw3Var3.x & 32) == 32) {
                                i8++;
                            }
                            lw3Var3.g(false);
                        }
                    }
                }
                if (z5) {
                    i8--;
                }
                lw3Var2.g(z5);
            } else {
                lw3Var2.g(false);
                i9++;
                i = 2;
                bVar = this;
                z = true;
            }
            i9++;
            i = 2;
            bVar = this;
            z = true;
        }
        return z;
    }

    @Override // defpackage.xw3
    public final void e(ew3 ew3Var, boolean z) {
        j();
        y5 y5Var = this.j0;
        if (y5Var != null && y5Var.b()) {
            y5Var.i.dismiss();
        }
        ww3 ww3Var = this.e;
        if (ww3Var != null) {
            ww3Var.e(ew3Var, z);
        }
    }

    @Override // defpackage.xw3
    public final void g(Parcelable parcelable) {
        int i;
        MenuItem menuItemFindItem;
        if ((parcelable instanceof ActionMenuPresenter$SavedState) && (i = ((ActionMenuPresenter$SavedState) parcelable).f160a) > 0 && (menuItemFindItem = this.c.findItem(i)) != null) {
            c((n96) menuItemFindItem.getSubMenu());
        }
    }

    public final boolean j() {
        Object obj;
        rl2 rl2Var = this.k0;
        if (rl2Var != null && (obj = this.v) != null) {
            ((View) obj).removeCallbacks(rl2Var);
            this.k0 = null;
            return true;
        }
        y5 y5Var = this.i0;
        if (y5Var == null) {
            return false;
        }
        if (y5Var.b()) {
            y5Var.i.dismiss();
        }
        return true;
    }

    @Override // defpackage.xw3
    public final void k(Context context, ew3 ew3Var) {
        this.b = context;
        LayoutInflater.from(context);
        this.c = ew3Var;
        Resources resources = context.getResources();
        if (!this.c0) {
            this.b0 = true;
        }
        int i = 2;
        this.d0 = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        int i3 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i2 > 600 || ((i2 > 960 && i3 > 720) || (i2 > 720 && i3 > 960))) {
            i = 5;
        } else if (i2 >= 500 || ((i2 > 640 && i3 > 480) || (i2 > 480 && i3 > 640))) {
            i = 4;
        } else if (i2 >= 360) {
            i = 3;
        }
        this.f0 = i;
        int measuredWidth = this.d0;
        if (this.b0) {
            if (this.X == null) {
                a6 a6Var = new a6(this, this.f1851a);
                this.X = a6Var;
                if (this.Z) {
                    a6Var.setImageDrawable(this.Y);
                    this.Y = null;
                    this.Z = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.X.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.X.getMeasuredWidth();
        } else {
            this.X = null;
        }
        this.e0 = measuredWidth;
        float f = resources.getDisplayMetrics().density;
    }

    @Override // defpackage.xw3
    public final Parcelable l() {
        ActionMenuPresenter$SavedState actionMenuPresenter$SavedState = new ActionMenuPresenter$SavedState();
        actionMenuPresenter$SavedState.f160a = this.n0;
        return actionMenuPresenter$SavedState;
    }

    public final boolean m() {
        y5 y5Var = this.i0;
        return y5Var != null && y5Var.b();
    }

    public final boolean n() {
        ew3 ew3Var;
        boolean z = false;
        if (this.b0 && !m() && (ew3Var = this.c) != null && this.v != null && this.k0 == null) {
            ew3Var.i();
            if (!ew3Var.j.isEmpty()) {
                rl2 rl2Var = new rl2(1, this, new y5(this, this.b, this.c, this.X), z);
                this.k0 = rl2Var;
                ((View) this.v).post(rl2Var);
                return true;
            }
        }
        return false;
    }
}

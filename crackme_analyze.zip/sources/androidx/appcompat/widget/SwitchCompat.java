package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$string;
import androidx.appcompat.R$styleable;
import androidx.core.R$id;
import defpackage.bx7;
import defpackage.dc7;
import defpackage.du1;
import defpackage.fv5;
import defpackage.gx5;
import defpackage.ku7;
import defpackage.m01;
import defpackage.mf7;
import defpackage.qc;
import defpackage.qc7;
import defpackage.rc6;
import defpackage.rr;
import defpackage.ry1;
import defpackage.xl0;
import defpackage.yk6;
import defpackage.zq;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {
    public static final xl0 J0 = new xl0("thumbPos", Float.class, 17);
    public static final int[] K0 = {R.attr.state_checked};
    public final TextPaint A0;
    public final ColorStateList B0;
    public StaticLayout C0;
    public StaticLayout D0;
    public final qc E0;
    public ObjectAnimator F0;
    public zq G0;
    public rc6 H0;
    public final Rect I0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Drawable f182a;
    public ColorStateList b;
    public boolean b0;
    public PorterDuff.Mode c;
    public int c0;
    public boolean d;
    public int d0;
    public boolean e;
    public int e0;
    public Drawable f;
    public boolean f0;
    public CharSequence g0;
    public CharSequence h0;
    public ColorStateList i;
    public CharSequence i0;
    public CharSequence j0;
    public boolean k0;
    public int l0;
    public final int m0;
    public float n0;
    public float o0;
    public final VelocityTracker p0;
    public final int q0;
    public float r0;
    public int s0;
    public int t0;
    public int u0;
    public PorterDuff.Mode v;
    public int v0;
    public boolean w;
    public int w0;
    public int x0;
    public int y0;
    public boolean z0;

    public SwitchCompat(Context context, AttributeSet attributeSet, int i) {
        int resourceId;
        super(context, attributeSet, i);
        this.b = null;
        this.c = null;
        this.d = false;
        this.e = false;
        this.i = null;
        this.v = null;
        this.w = false;
        this.b0 = false;
        this.p0 = VelocityTracker.obtain();
        this.z0 = true;
        this.I0 = new Rect();
        yk6.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.A0 = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        gx5 gx5VarX = gx5.x(context, attributeSet, R$styleable.SwitchCompat, i);
        TypedArray typedArray = (TypedArray) gx5VarX.c;
        qc7.n(this, context, R$styleable.SwitchCompat, attributeSet, typedArray, i);
        Drawable drawableI = gx5VarX.i(R$styleable.SwitchCompat_android_thumb);
        this.f182a = drawableI;
        if (drawableI != null) {
            drawableI.setCallback(this);
        }
        Drawable drawableI2 = gx5VarX.i(R$styleable.SwitchCompat_track);
        this.f = drawableI2;
        if (drawableI2 != null) {
            drawableI2.setCallback(this);
        }
        setTextOnInternal(typedArray.getText(R$styleable.SwitchCompat_android_textOn));
        setTextOffInternal(typedArray.getText(R$styleable.SwitchCompat_android_textOff));
        this.k0 = typedArray.getBoolean(R$styleable.SwitchCompat_showText, true);
        this.c0 = typedArray.getDimensionPixelSize(R$styleable.SwitchCompat_thumbTextPadding, 0);
        this.d0 = typedArray.getDimensionPixelSize(R$styleable.SwitchCompat_switchMinWidth, 0);
        this.e0 = typedArray.getDimensionPixelSize(R$styleable.SwitchCompat_switchPadding, 0);
        this.f0 = typedArray.getBoolean(R$styleable.SwitchCompat_splitTrack, false);
        ColorStateList colorStateListH = gx5VarX.h(R$styleable.SwitchCompat_thumbTint);
        if (colorStateListH != null) {
            this.b = colorStateListH;
            this.d = true;
        }
        PorterDuff.Mode modeC = du1.c(typedArray.getInt(R$styleable.SwitchCompat_thumbTintMode, -1), null);
        if (this.c != modeC) {
            this.c = modeC;
            this.e = true;
        }
        if (this.d || this.e) {
            a();
        }
        ColorStateList colorStateListH2 = gx5VarX.h(R$styleable.SwitchCompat_trackTint);
        if (colorStateListH2 != null) {
            this.i = colorStateListH2;
            this.w = true;
        }
        PorterDuff.Mode modeC2 = du1.c(typedArray.getInt(R$styleable.SwitchCompat_trackTintMode, -1), null);
        if (this.v != modeC2) {
            this.v = modeC2;
            this.b0 = true;
        }
        if (this.w || this.b0) {
            b();
        }
        int resourceId2 = typedArray.getResourceId(R$styleable.SwitchCompat_switchTextAppearance, 0);
        if (resourceId2 != 0) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(resourceId2, R$styleable.TextAppearance);
            int i2 = R$styleable.TextAppearance_android_textColor;
            ColorStateList colorStateList = (!typedArrayObtainStyledAttributes.hasValue(i2) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(i2, 0)) == 0 || (colorStateList = m01.getColorStateList(context, resourceId)) == null) ? typedArrayObtainStyledAttributes.getColorStateList(i2) : colorStateList;
            if (colorStateList != null) {
                this.B0 = colorStateList;
            } else {
                this.B0 = getTextColors();
            }
            int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.TextAppearance_android_textSize, 0);
            if (dimensionPixelSize != 0) {
                float f = dimensionPixelSize;
                if (f != textPaint.getTextSize()) {
                    textPaint.setTextSize(f);
                    requestLayout();
                }
            }
            int i3 = typedArrayObtainStyledAttributes.getInt(R$styleable.TextAppearance_android_typeface, -1);
            int i4 = typedArrayObtainStyledAttributes.getInt(R$styleable.TextAppearance_android_textStyle, -1);
            Typeface typeface = i3 != 1 ? i3 != 2 ? i3 != 3 ? null : Typeface.MONOSPACE : Typeface.SERIF : Typeface.SANS_SERIF;
            if (i4 > 0) {
                Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i4) : Typeface.create(typeface, i4);
                setSwitchTypeface(typefaceDefaultFromStyle);
                int i5 = i4 & (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0));
                textPaint.setFakeBoldText((i5 & 1) != 0);
                textPaint.setTextSkewX((i5 & 2) != 0 ? -0.25f : 0.0f);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                setSwitchTypeface(typeface);
            }
            if (typedArrayObtainStyledAttributes.getBoolean(R$styleable.TextAppearance_textAllCaps, false)) {
                Context context2 = getContext();
                qc qcVar = new qc();
                qcVar.f4994a = context2.getResources().getConfiguration().locale;
                this.E0 = qcVar;
            } else {
                this.E0 = null;
            }
            setTextOnInternal(this.g0);
            setTextOffInternal(this.i0);
            typedArrayObtainStyledAttributes.recycle();
        }
        new rr(this).f(attributeSet, i);
        gx5VarX.z();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.m0 = viewConfiguration.getScaledTouchSlop();
        this.q0 = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().b(attributeSet, i);
        refreshDrawableState();
        setChecked(isChecked());
    }

    private zq getEmojiTextViewHelper() {
        if (this.G0 == null) {
            this.G0 = new zq(this);
        }
        return this.G0;
    }

    private boolean getTargetCheckedState() {
        return this.r0 > 0.5f;
    }

    private int getThumbOffset() {
        boolean z = mf7.f4149a;
        int layoutDirection = getLayoutDirection();
        float f = this.r0;
        if (layoutDirection == 1) {
            f = 1.0f - f;
        }
        return (int) ((f * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.I0;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f182a;
        Rect rectB = drawable2 != null ? du1.b(drawable2) : du1.c;
        return ((((this.s0 - this.u0) - rect.left) - rect.right) - rectB.left) - rectB.right;
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.i0 = charSequence;
        TransformationMethod transformationMethodR = ((ku7) getEmojiTextViewHelper().b.b).R(this.E0);
        if (transformationMethodR != null) {
            charSequence = transformationMethodR.getTransformation(charSequence, this);
        }
        this.j0 = charSequence;
        this.D0 = null;
        if (this.k0) {
            d();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.g0 = charSequence;
        TransformationMethod transformationMethodR = ((ku7) getEmojiTextViewHelper().b.b).R(this.E0);
        if (transformationMethodR != null) {
            charSequence = transformationMethodR.getTransformation(charSequence, this);
        }
        this.h0 = charSequence;
        this.C0 = null;
        if (this.k0) {
            d();
        }
    }

    public final void a() {
        Drawable drawable = this.f182a;
        if (drawable != null) {
            if (this.d || this.e) {
                Drawable drawableMutate = drawable.mutate();
                this.f182a = drawableMutate;
                if (this.d) {
                    drawableMutate.setTintList(this.b);
                }
                if (this.e) {
                    this.f182a.setTintMode(this.c);
                }
                if (this.f182a.isStateful()) {
                    this.f182a.setState(getDrawableState());
                }
            }
        }
    }

    public final void b() {
        Drawable drawable = this.f;
        if (drawable != null) {
            if (this.w || this.b0) {
                Drawable drawableMutate = drawable.mutate();
                this.f = drawableMutate;
                if (this.w) {
                    drawableMutate.setTintList(this.i);
                }
                if (this.b0) {
                    this.f.setTintMode(this.v);
                }
                if (this.f.isStateful()) {
                    this.f.setState(getDrawableState());
                }
            }
        }
    }

    public final void c() {
        setTextOnInternal(this.g0);
        setTextOffInternal(this.i0);
        requestLayout();
    }

    public final void d() {
        if (this.H0 == null && ((ku7) this.G0.b.b).B() && ry1.d()) {
            ry1 ry1VarA = ry1.a();
            int iC = ry1VarA.c();
            if (iC == 3 || iC == 0) {
                rc6 rc6Var = new rc6(this);
                this.H0 = rc6Var;
                ry1VarA.h(rc6Var);
            }
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i;
        int i2;
        int i3 = this.v0;
        int i4 = this.w0;
        int i5 = this.x0;
        int i6 = this.y0;
        int thumbOffset = getThumbOffset() + i3;
        Drawable drawable = this.f182a;
        Rect rectB = drawable != null ? du1.b(drawable) : du1.c;
        Drawable drawable2 = this.f;
        Rect rect = this.I0;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i7 = rect.left;
            thumbOffset += i7;
            if (rectB != null) {
                int i8 = rectB.left;
                if (i8 > i7) {
                    i3 += i8 - i7;
                }
                int i9 = rectB.top;
                int i10 = rect.top;
                i = i9 > i10 ? (i9 - i10) + i4 : i4;
                int i11 = rectB.right;
                int i12 = rect.right;
                if (i11 > i12) {
                    i5 -= i11 - i12;
                }
                int i13 = rectB.bottom;
                int i14 = rect.bottom;
                if (i13 > i14) {
                    i2 = i6 - (i13 - i14);
                }
                this.f.setBounds(i3, i, i5, i2);
            } else {
                i = i4;
            }
            i2 = i6;
            this.f.setBounds(i3, i, i5, i2);
        }
        Drawable drawable3 = this.f182a;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i15 = thumbOffset - rect.left;
            int i16 = thumbOffset + this.u0 + rect.right;
            this.f182a.setBounds(i15, i4, i16, i6);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i15, i4, i16, i6);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.f182a;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.setHotspot(f, f2);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f182a;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        boolean z = mf7.f4149a;
        if (getLayoutDirection() != 1) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.s0;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.e0 : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        boolean z = mf7.f4149a;
        if (getLayoutDirection() == 1) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.s0;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.e0 : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return fv5.v(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.k0;
    }

    public boolean getSplitTrack() {
        return this.f0;
    }

    public int getSwitchMinWidth() {
        return this.d0;
    }

    public int getSwitchPadding() {
        return this.e0;
    }

    public CharSequence getTextOff() {
        return this.i0;
    }

    public CharSequence getTextOn() {
        return this.g0;
    }

    public Drawable getThumbDrawable() {
        return this.f182a;
    }

    public final float getThumbPosition() {
        return this.r0;
    }

    public int getThumbTextPadding() {
        return this.c0;
    }

    public ColorStateList getThumbTintList() {
        return this.b;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.c;
    }

    public Drawable getTrackDrawable() {
        return this.f;
    }

    public ColorStateList getTrackTintList() {
        return this.i;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.v;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f182a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.F0;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.F0.end();
        this.F0 = null;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, K0);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Drawable drawable = this.f;
        Rect rect = this.I0;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i = this.w0;
        int i2 = this.y0;
        int i3 = i + rect.top;
        int i4 = i2 - rect.bottom;
        Drawable drawable2 = this.f182a;
        if (drawable != null) {
            if (!this.f0 || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectB = du1.b(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectB.left;
                rect.right -= rectB.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        StaticLayout staticLayout = getTargetCheckedState() ? this.C0 : this.D0;
        if (staticLayout != null) {
            int[] drawableState = getDrawableState();
            TextPaint textPaint = this.A0;
            ColorStateList colorStateList = this.B0;
            if (colorStateList != null) {
                textPaint.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            textPaint.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (staticLayout.getWidth() / 2), ((i3 + i4) / 2) - (staticLayout.getHeight() / 2));
            staticLayout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.g0 : this.i0;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int iMax;
        int width;
        int paddingLeft;
        int height;
        int paddingTop;
        super.onLayout(z, i, i2, i3, i4);
        int iMax2 = 0;
        if (this.f182a != null) {
            Drawable drawable = this.f;
            Rect rect = this.I0;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectB = du1.b(this.f182a);
            iMax = Math.max(0, rectB.left - rect.left);
            iMax2 = Math.max(0, rectB.right - rect.right);
        } else {
            iMax = 0;
        }
        boolean z2 = mf7.f4149a;
        if (getLayoutDirection() == 1) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.s0 + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.s0) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int height2 = ((getHeight() + getPaddingTop()) - getPaddingBottom()) / 2;
            int i5 = this.t0;
            int i6 = height2 - (i5 / 2);
            height = i5 + i6;
            paddingTop = i6;
        } else if (gravity != 80) {
            paddingTop = getPaddingTop();
            height = this.t0 + paddingTop;
        } else {
            height = getHeight() - getPaddingBottom();
            paddingTop = height - this.t0;
        }
        this.v0 = paddingLeft;
        this.w0 = paddingTop;
        this.y0 = height;
        this.x0 = width;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i2) {
        int intrinsicWidth;
        int intrinsicHeight;
        int intrinsicHeight2 = 0;
        if (this.k0) {
            StaticLayout staticLayout = this.C0;
            TextPaint textPaint = this.A0;
            if (staticLayout == null) {
                CharSequence charSequence = this.h0;
                this.C0 = new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
            if (this.D0 == null) {
                CharSequence charSequence2 = this.j0;
                this.D0 = new StaticLayout(charSequence2, textPaint, charSequence2 != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence2, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
        }
        Drawable drawable = this.f182a;
        Rect rect = this.I0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.f182a.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.f182a.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        this.u0 = Math.max(this.k0 ? (this.c0 * 2) + Math.max(this.C0.getWidth(), this.D0.getWidth()) : 0, intrinsicWidth);
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.f.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax = rect.left;
        int iMax2 = rect.right;
        Drawable drawable3 = this.f182a;
        if (drawable3 != null) {
            Rect rectB = du1.b(drawable3);
            iMax = Math.max(iMax, rectB.left);
            iMax2 = Math.max(iMax2, rectB.right);
        }
        boolean z = this.z0;
        int iMax3 = this.d0;
        if (z) {
            iMax3 = Math.max(iMax3, (this.u0 * 2) + iMax + iMax2);
        }
        int iMax4 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.s0 = iMax3;
        this.t0 = iMax4;
        super.onMeasure(i, i2);
        if (getMeasuredHeight() < iMax4) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax4);
        }
    }

    @Override // android.view.View
    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.g0 : this.i0;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x008e  */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouchEvent(android.view.MotionEvent r10) {
        /*
            Method dump skipped, instruction units count: 329
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SwitchCompat.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().c(z);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z) {
        super.setChecked(z);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            if (Build.VERSION.SDK_INT >= 30) {
                Object string = this.g0;
                if (string == null) {
                    string = getResources().getString(R$string.abc_capital_on);
                }
                Object obj = string;
                WeakHashMap weakHashMap = qc7.f4998a;
                new dc7(R$id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, obj);
            }
        } else if (Build.VERSION.SDK_INT >= 30) {
            Object string2 = this.i0;
            if (string2 == null) {
                string2 = getResources().getString(R$string.abc_capital_off);
            }
            Object obj2 = string2;
            WeakHashMap weakHashMap2 = qc7.f4998a;
            new dc7(R$id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, obj2);
        }
        if (getWindowToken() == null || !isLaidOut()) {
            ObjectAnimator objectAnimator = this.F0;
            if (objectAnimator != null) {
                objectAnimator.cancel();
            }
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
            return;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, J0, zIsChecked ? 1.0f : 0.0f);
        this.F0 = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.F0.setAutoCancel(true);
        this.F0.start();
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(fv5.w(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().d(z);
        setTextOnInternal(this.g0);
        setTextOffInternal(this.i0);
        requestLayout();
    }

    public final void setEnforceSwitchWidth(boolean z) {
        this.z0 = z;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z) {
        if (this.k0 != z) {
            this.k0 = z;
            requestLayout();
            if (z) {
                d();
            }
        }
    }

    public void setSplitTrack(boolean z) {
        this.f0 = z;
        invalidate();
    }

    public void setSwitchMinWidth(int i) {
        this.d0 = i;
        requestLayout();
    }

    public void setSwitchPadding(int i) {
        this.e0 = i;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        TextPaint textPaint = this.A0;
        if ((textPaint.getTypeface() == null || textPaint.getTypeface().equals(typeface)) && (textPaint.getTypeface() != null || typeface == null)) {
            return;
        }
        textPaint.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.i0;
        if (string == null) {
            string = getResources().getString(R$string.abc_capital_off);
        }
        WeakHashMap weakHashMap = qc7.f4998a;
        new dc7(R$id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, string);
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (!isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.g0;
        if (string == null) {
            string = getResources().getString(R$string.abc_capital_on);
        }
        WeakHashMap weakHashMap = qc7.f4998a;
        new dc7(R$id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, string);
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f182a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f182a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f) {
        this.r0 = f;
        invalidate();
    }

    public void setThumbResource(int i) {
        setThumbDrawable(bx7.t(getContext(), i));
    }

    public void setThumbTextPadding(int i) {
        this.c0 = i;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.b = colorStateList;
        this.d = true;
        a();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.c = mode;
        this.e = true;
        a();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i) {
        setTrackDrawable(bx7.t(getContext(), i));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.i = colorStateList;
        this.w = true;
        b();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.v = mode;
        this.b0 = true;
        b();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f182a || drawable == this.f;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.switchStyle);
    }
}

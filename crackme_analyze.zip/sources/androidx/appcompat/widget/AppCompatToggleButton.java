package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;
import defpackage.rr;
import defpackage.yk6;
import defpackage.zp;
import defpackage.zq;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatToggleButton extends ToggleButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zp f177a;
    public final rr b;
    public zq c;

    public AppCompatToggleButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        yk6.a(this, getContext());
        zp zpVar = new zp(this);
        this.f177a = zpVar;
        zpVar.d(attributeSet, i);
        rr rrVar = new rr(this);
        this.b = rrVar;
        rrVar.f(attributeSet, i);
        getEmojiTextViewHelper().b(attributeSet, i);
    }

    private zq getEmojiTextViewHelper() {
        if (this.c == null) {
            this.c = new zq(this);
        }
        return this.c;
    }

    @Override // android.widget.ToggleButton, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        zp zpVar = this.f177a;
        if (zpVar != null) {
            zpVar.a();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.f177a;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.f177a;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().c(z);
    }

    @Override // android.widget.ToggleButton, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.f177a;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.f177a;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.f177a;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.f177a;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        rr rrVar = this.b;
        rrVar.k(colorStateList);
        rrVar.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        rr rrVar = this.b;
        rrVar.l(mode);
        rrVar.b();
    }

    public AppCompatToggleButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.buttonStyleToggle);
    }
}

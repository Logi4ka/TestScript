package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import androidx.appcompat.R$attr;
import defpackage.fv5;
import defpackage.hm6;
import defpackage.mf7;
import defpackage.rr;
import defpackage.yk6;
import defpackage.zp;
import defpackage.zq;
import defpackage.zr;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatButton extends Button {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zp f165a;
    public final rr b;
    public zq c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        hm6.a(context);
        yk6.a(this, getContext());
        zp zpVar = new zp(this);
        this.f165a = zpVar;
        zpVar.d(attributeSet, i);
        rr rrVar = new rr(this);
        this.b = rrVar;
        rrVar.f(attributeSet, i);
        rrVar.b();
        getEmojiTextViewHelper().b(attributeSet, i);
    }

    private zq getEmojiTextViewHelper() {
        if (this.c == null) {
            this.c = new zq(this);
        }
        return this.c;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        zp zpVar = this.f165a;
        if (zpVar != null) {
            zpVar.a();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (mf7.c) {
            return super.getAutoSizeMaxTextSize();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return Math.round(rrVar.i.e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (mf7.c) {
            return super.getAutoSizeMinTextSize();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return Math.round(rrVar.i.d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (mf7.c) {
            return super.getAutoSizeStepGranularity();
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return Math.round(rrVar.i.c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (mf7.c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        rr rrVar = this.b;
        return rrVar != null ? rrVar.i.f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (mf7.c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            return rrVar.i.f7071a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return fv5.v(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        zp zpVar = this.f165a;
        if (zpVar != null) {
            return zpVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        zp zpVar = this.f165a;
        if (zpVar != null) {
            return zpVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        rr rrVar = this.b;
        if (rrVar == null || mf7.c) {
            return;
        }
        rrVar.i.a();
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        rr rrVar = this.b;
        if (rrVar != null) {
            zr zrVar = rrVar.i;
            if (mf7.c || !zrVar.f()) {
                return;
            }
            zrVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().c(z);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (mf7.c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.h(i, i2, i3, i4);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (mf7.c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.i(iArr, i);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (mf7.c) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.j(i);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        zp zpVar = this.f165a;
        if (zpVar != null) {
            zpVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        zp zpVar = this.f165a;
        if (zpVar != null) {
            zpVar.f(i);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(fv5.w(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z) {
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.f5286a.setAllCaps(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        zp zpVar = this.f165a;
        if (zpVar != null) {
            zpVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        zp zpVar = this.f165a;
        if (zpVar != null) {
            zpVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        rr rrVar = this.b;
        rrVar.k(colorStateList);
        rrVar.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        rr rrVar = this.b;
        rrVar.l(mode);
        rrVar.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        rr rrVar = this.b;
        if (rrVar != null) {
            rrVar.g(context, i);
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i, float f) {
        boolean z = mf7.c;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        rr rrVar = this.b;
        if (rrVar != null) {
            zr zrVar = rrVar.i;
            if (z || zrVar.f()) {
                return;
            }
            zrVar.g(f, i);
        }
    }

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.buttonStyle);
    }
}

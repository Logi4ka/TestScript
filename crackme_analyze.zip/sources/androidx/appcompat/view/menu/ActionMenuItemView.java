package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.R$styleable;
import androidx.appcompat.widget.AppCompatTextView;
import defpackage.b6;
import defpackage.dw3;
import defpackage.ew3;
import defpackage.lh3;
import defpackage.lw3;
import defpackage.w5;
import defpackage.x5;
import defpackage.zw3;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends AppCompatTextView implements zw3, View.OnClickListener, b6 {
    public Drawable b0;
    public dw3 c0;
    public w5 d0;
    public x5 e0;
    public boolean f0;
    public boolean g0;
    public final int h0;
    public int i0;
    public final int j0;
    public lw3 v;
    public CharSequence w;

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.f0 = g();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ActionMenuItemView, i, 0);
        this.h0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.ActionMenuItemView_android_minWidth, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.j0 = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.i0 = -1;
        setSaveEnabled(false);
    }

    @Override // defpackage.b6
    public final boolean a() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // defpackage.b6
    public final boolean b() {
        return !TextUtils.isEmpty(getText()) && this.v.getIcon() == null;
    }

    @Override // defpackage.zw3
    public final void c(lw3 lw3Var) {
        this.v = lw3Var;
        setIcon(lw3Var.getIcon());
        setTitle(lw3Var.getTitleCondensed());
        setId(lw3Var.f4013a);
        setVisibility(lw3Var.isVisible() ? 0 : 8);
        setEnabled(lw3Var.isEnabled());
        if (lw3Var.hasSubMenu() && this.d0 == null) {
            this.d0 = new w5(this);
        }
    }

    public final boolean g() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i2 = configuration.screenHeightDp;
        if (i < 480) {
            return (i >= 640 && i2 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // defpackage.zw3
    public lw3 getItemData() {
        return this.v;
    }

    public final void h() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.w);
        if (this.b0 != null && ((this.v.y & 4) != 4 || (!this.f0 && !this.g0))) {
            z = false;
        }
        boolean z3 = z2 & z;
        setText(z3 ? this.w : null);
        CharSequence charSequence = this.v.q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z3 ? null : this.v.e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.v.r;
        if (TextUtils.isEmpty(charSequence2)) {
            lh3.k(this, z3 ? null : this.v.e);
        } else {
            lh3.k(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        dw3 dw3Var = this.c0;
        if (dw3Var != null) {
            dw3Var.a(this.v);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f0 = g();
        h();
    }

    @Override // androidx.appcompat.widget.AppCompatTextView, android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i2) {
        int i3;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i3 = this.i0) >= 0) {
            super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int i4 = this.h0;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i4) : i4;
        if (mode != 1073741824 && i4 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i2);
        }
        if (!zIsEmpty || this.b0 == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.b0.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        w5 w5Var;
        if (this.v.hasSubMenu() && (w5Var = this.d0) != null && w5Var.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.g0 != z) {
            this.g0 = z;
            lw3 lw3Var = this.v;
            if (lw3Var != null) {
                ew3 ew3Var = lw3Var.n;
                ew3Var.k = true;
                ew3Var.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.b0 = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.j0;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (intrinsicHeight * (i / intrinsicWidth));
                intrinsicWidth = i;
            }
            if (intrinsicHeight > i) {
                intrinsicWidth = (int) (intrinsicWidth * (i / intrinsicHeight));
            } else {
                i = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i);
        }
        setCompoundDrawables(drawable, null, null, null);
        h();
    }

    public void setItemInvoker(dw3 dw3Var) {
        this.c0 = dw3Var;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i, int i2, int i3, int i4) {
        this.i0 = i;
        super.setPadding(i, i2, i3, i4);
    }

    public void setPopupCallback(x5 x5Var) {
        this.e0 = x5Var;
    }

    public void setTitle(CharSequence charSequence) {
        this.w = charSequence;
        h();
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}

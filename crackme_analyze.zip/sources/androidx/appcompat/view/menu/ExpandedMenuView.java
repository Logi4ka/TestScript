package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import defpackage.ax3;
import defpackage.dw3;
import defpackage.ew3;
import defpackage.gx5;
import defpackage.lw3;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements dw3, ax3, AdapterView.OnItemClickListener {
    public static final int[] b = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ew3 f155a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        gx5 gx5VarX = gx5.x(context, attributeSet, b, i);
        TypedArray typedArray = (TypedArray) gx5VarX.c;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(gx5VarX.i(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(gx5VarX.i(1));
        }
        gx5VarX.z();
    }

    @Override // defpackage.dw3
    public final boolean a(lw3 lw3Var) {
        return this.f155a.q(lw3Var, null, 0);
    }

    @Override // defpackage.ax3
    public final void b(ew3 ew3Var) {
        this.f155a = ew3Var;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        a((lw3) getAdapter().getItem(i));
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listViewStyle);
    }
}

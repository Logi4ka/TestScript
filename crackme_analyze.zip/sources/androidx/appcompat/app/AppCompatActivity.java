package androidx.appcompat.app;

import android.R;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;
import defpackage.ab6;
import defpackage.aq;
import defpackage.b5;
import defpackage.d6;
import defpackage.e6;
import defpackage.fg6;
import defpackage.fq;
import defpackage.g;
import defpackage.gq;
import defpackage.gq3;
import defpackage.je5;
import defpackage.jn6;
import defpackage.kj7;
import defpackage.m01;
import defpackage.rw1;
import defpackage.tq;
import defpackage.um3;
import defpackage.vk5;
import defpackage.w97;
import defpackage.xp;
import defpackage.xq;
import defpackage.y4;
import defpackage.yo3;
import defpackage.yp;
import io.sentry.android.core.o0;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class AppCompatActivity extends FragmentActivity implements aq {
    private static final String DELEGATE_TAG = "androidx:appcompat";
    private gq mDelegate;
    private Resources mResources;

    public AppCompatActivity() {
        getSavedStateRegistry().c(DELEGATE_TAG, new xp(this));
        addOnContextAvailableListener(new yp(this));
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        initializeViewTreeOwners();
        tq tqVar = (tq) getDelegate();
        tqVar.w();
        ((ViewGroup) tqVar.p0.findViewById(R.id.content)).addView(view, layoutParams);
        tqVar.b0.a(tqVar.Z.getCallback());
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00aa  */
    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void attachBaseContext(android.content.Context r10) {
        /*
            Method dump skipped, instruction units count: 567
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatActivity.attachBaseContext(android.content.Context):void");
    }

    @Override // android.app.Activity
    public void closeOptionsMenu() {
        y4 supportActionBar = getSupportActionBar();
        if (getWindow().hasFeature(0)) {
            if (supportActionBar == null || !supportActionBar.a()) {
                super.closeOptionsMenu();
            }
        }
    }

    @Override // androidx.core.app.ComponentActivity, android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        y4 supportActionBar = getSupportActionBar();
        if (keyCode == 82 && supportActionBar != null && supportActionBar.l(keyEvent)) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity
    public <T extends View> T findViewById(int i) {
        tq tqVar = (tq) getDelegate();
        tqVar.w();
        return (T) tqVar.Z.findViewById(i);
    }

    public gq getDelegate() {
        if (this.mDelegate == null) {
            fq fqVar = gq.f2445a;
            this.mDelegate = new tq(this, null, this, this);
        }
        return this.mDelegate;
    }

    public b5 getDrawerToggleDelegate() {
        ((tq) getDelegate()).getClass();
        return new rw1(22);
    }

    @Override // android.app.Activity
    public MenuInflater getMenuInflater() {
        tq tqVar = (tq) getDelegate();
        if (tqVar.e0 == null) {
            tqVar.A();
            y4 y4Var = tqVar.d0;
            tqVar.e0 = new ab6(y4Var != null ? y4Var.e() : tqVar.Y);
        }
        return tqVar.e0;
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        Resources resources = this.mResources;
        if (resources == null) {
            int i = w97.f6264a;
        }
        return resources == null ? super.getResources() : resources;
    }

    public y4 getSupportActionBar() {
        tq tqVar = (tq) getDelegate();
        tqVar.A();
        return tqVar.d0;
    }

    public Intent getSupportParentActivityIntent() {
        return gq3.A(this);
    }

    @Override // android.app.Activity
    public void invalidateOptionsMenu() {
        getDelegate().a();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) throws IllegalAccessException {
        super.onConfigurationChanged(configuration);
        tq tqVar = (tq) getDelegate();
        if (tqVar.u0 && tqVar.o0) {
            tqVar.A();
            y4 y4Var = tqVar.d0;
            if (y4Var != null) {
                y4Var.i();
            }
        }
        xq xqVarA = xq.a();
        Context context = tqVar.Y;
        synchronized (xqVarA) {
            je5 je5Var = xqVarA.f6577a;
            synchronized (je5Var) {
                yo3 yo3Var = (yo3) je5Var.b.get(context);
                if (yo3Var != null) {
                    yo3Var.a();
                }
            }
        }
        tqVar.G0 = new Configuration(tqVar.Y.getResources().getConfiguration());
        tqVar.m(false, false);
        if (this.mResources != null) {
            this.mResources.updateConfiguration(super.getResources().getConfiguration(), super.getResources().getDisplayMetrics());
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onContentChanged() {
        onSupportContentChanged();
    }

    public void onCreateSupportNavigateUpTaskStack(fg6 fg6Var) {
        ArrayList arrayList = fg6Var.f2156a;
        AppCompatActivity appCompatActivity = fg6Var.b;
        Intent supportParentActivityIntent = getSupportParentActivityIntent();
        if (supportParentActivityIntent == null) {
            supportParentActivityIntent = gq3.A(this);
        }
        if (supportParentActivityIntent != null) {
            ComponentName component = supportParentActivityIntent.getComponent();
            if (component == null) {
                component = supportParentActivityIntent.resolveActivity(appCompatActivity.getPackageManager());
            }
            int size = arrayList.size();
            try {
                for (Intent intentB = gq3.B(appCompatActivity, component); intentB != null; intentB = gq3.B(appCompatActivity, intentB.getComponent())) {
                    arrayList.add(size, intentB);
                }
                arrayList.add(supportParentActivityIntent);
            } catch (PackageManager.NameNotFoundException e) {
                o0.d("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                g.p(e);
            }
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        getDelegate().d();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        Window window;
        if (Build.VERSION.SDK_INT >= 26 || keyEvent.isCtrlPressed() || KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) || keyEvent.getRepeatCount() != 0 || KeyEvent.isModifierKey(keyEvent.getKeyCode()) || (window = getWindow()) == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent)) {
            return super.onKeyDown(i, keyEvent);
        }
        return true;
    }

    public void onLocalesChanged(um3 um3Var) {
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        y4 supportActionBar = getSupportActionBar();
        if (menuItem.getItemId() != 16908332 || supportActionBar == null || (supportActionBar.d() & 4) == 0) {
            return false;
        }
        return onSupportNavigateUp();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuOpened(int i, Menu menu) {
        return super.onMenuOpened(i, menu);
    }

    public void onNightModeChanged(int i) {
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i, Menu menu) {
        super.onPanelClosed(i, menu);
    }

    @Override // android.app.Activity
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((tq) getDelegate()).w();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        tq tqVar = (tq) getDelegate();
        tqVar.A();
        y4 y4Var = tqVar.d0;
        if (y4Var != null) {
            y4Var.q(true);
        }
    }

    public void onPrepareSupportNavigateUpTaskStack(fg6 fg6Var) {
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() throws IllegalAccessException {
        super.onStart();
        ((tq) getDelegate()).m(true, false);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
        tq tqVar = (tq) getDelegate();
        tqVar.A();
        y4 y4Var = tqVar.d0;
        if (y4Var != null) {
            y4Var.q(false);
        }
    }

    @Override // defpackage.aq
    public void onSupportActionModeFinished(e6 e6Var) {
    }

    @Override // defpackage.aq
    public void onSupportActionModeStarted(e6 e6Var) {
    }

    @Deprecated
    public void onSupportContentChanged() {
    }

    public boolean onSupportNavigateUp() {
        Intent supportParentActivityIntent = getSupportParentActivityIntent();
        if (supportParentActivityIntent == null) {
            return false;
        }
        if (!supportShouldUpRecreateTask(supportParentActivityIntent)) {
            supportNavigateUpTo(supportParentActivityIntent);
            return true;
        }
        fg6 fg6Var = new fg6(this);
        onCreateSupportNavigateUpTaskStack(fg6Var);
        onPrepareSupportNavigateUpTaskStack(fg6Var);
        ArrayList arrayList = fg6Var.f2156a;
        if (arrayList.isEmpty()) {
            vk5.k("No intents added to TaskStackBuilder; cannot startActivities");
            return false;
        }
        Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[0]);
        intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
        AppCompatActivity appCompatActivity = fg6Var.b;
        if (!m01.startActivities(appCompatActivity, intentArr, null)) {
            Intent intent = new Intent(intentArr[intentArr.length - 1]);
            intent.addFlags(268435456);
            appCompatActivity.startActivity(intent);
        }
        try {
            finishAffinity();
        } catch (IllegalStateException unused) {
            finish();
        }
        return true;
    }

    @Override // android.app.Activity
    public void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        getDelegate().k(charSequence);
    }

    @Override // defpackage.aq
    public e6 onWindowStartingSupportActionMode(d6 d6Var) {
        return null;
    }

    @Override // android.app.Activity
    public void openOptionsMenu() {
        y4 supportActionBar = getSupportActionBar();
        if (getWindow().hasFeature(0)) {
            if (supportActionBar == null || !supportActionBar.m()) {
                super.openOptionsMenu();
            }
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void setContentView(int i) {
        initializeViewTreeOwners();
        getDelegate().g(i);
    }

    public void setSupportActionBar(Toolbar toolbar) {
        tq tqVar = (tq) getDelegate();
        if (tqVar.X instanceof Activity) {
            tqVar.A();
            y4 y4Var = tqVar.d0;
            if (y4Var instanceof kj7) {
                vk5.k("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
                return;
            }
            tqVar.e0 = null;
            if (y4Var != null) {
                y4Var.j();
            }
            tqVar.d0 = null;
            if (toolbar != null) {
                Object obj = tqVar.X;
                jn6 jn6Var = new jn6(toolbar, obj instanceof Activity ? ((Activity) obj).getTitle() : tqVar.f0, tqVar.b0);
                tqVar.d0 = jn6Var;
                tqVar.b0.b = jn6Var.c;
                toolbar.setBackInvokedCallbackEnabled(true);
            } else {
                tqVar.b0.b = null;
            }
            tqVar.a();
        }
    }

    @Deprecated
    public void setSupportProgress(int i) {
    }

    @Deprecated
    public void setSupportProgressBarIndeterminate(boolean z) {
    }

    @Deprecated
    public void setSupportProgressBarIndeterminateVisibility(boolean z) {
    }

    @Deprecated
    public void setSupportProgressBarVisibility(boolean z) {
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public void setTheme(int i) {
        super.setTheme(i);
        ((tq) getDelegate()).I0 = i;
    }

    public e6 startSupportActionMode(d6 d6Var) {
        return getDelegate().l(d6Var);
    }

    @Override // androidx.fragment.app.FragmentActivity
    public void supportInvalidateOptionsMenu() {
        getDelegate().a();
    }

    public void supportNavigateUpTo(Intent intent) {
        navigateUpTo(intent);
    }

    public boolean supportRequestWindowFeature(int i) {
        return getDelegate().f(i);
    }

    public boolean supportShouldUpRecreateTask(Intent intent) {
        return shouldUpRecreateTask(intent);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void setContentView(View view) {
        initializeViewTreeOwners();
        getDelegate().i(view);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        initializeViewTreeOwners();
        getDelegate().j(view, layoutParams);
    }
}

package androidx.appcompat;

/* JADX INFO: loaded from: classes.dex */
public final class R$layout {
    public static int abc_action_bar_title_item = 2131492864;
    public static int abc_action_bar_up_container = 2131492865;
    public static int abc_action_menu_item_layout = 2131492866;
    public static int abc_action_menu_layout = 2131492867;
    public static int abc_action_mode_bar = 2131492868;
    public static int abc_action_mode_close_item_material = 2131492869;
    public static int abc_activity_chooser_view = 2131492870;
    public static int abc_activity_chooser_view_list_item = 2131492871;
    public static int abc_alert_dialog_button_bar_material = 2131492872;
    public static int abc_alert_dialog_material = 2131492873;
    public static int abc_alert_dialog_title_material = 2131492874;
    public static int abc_cascading_menu_item_layout = 2131492875;
    public static int abc_dialog_title_material = 2131492876;
    public static int abc_expanded_menu_layout = 2131492877;
    public static int abc_list_menu_item_checkbox = 2131492878;
    public static int abc_list_menu_item_icon = 2131492879;
    public static int abc_list_menu_item_layout = 2131492880;
    public static int abc_list_menu_item_radio = 2131492881;
    public static int abc_popup_menu_header_item_layout = 2131492882;
    public static int abc_popup_menu_item_layout = 2131492883;
    public static int abc_screen_content_include = 2131492884;
    public static int abc_screen_simple = 2131492885;
    public static int abc_screen_simple_overlay_action_mode = 2131492886;
    public static int abc_screen_toolbar = 2131492887;
    public static int abc_search_dropdown_item_icons_2line = 2131492888;
    public static int abc_search_view = 2131492889;
    public static int abc_select_dialog_material = 2131492890;
    public static int abc_tooltip = 2131492891;
    public static int select_dialog_item_material = 2131493008;
    public static int select_dialog_multichoice_material = 2131493009;
    public static int select_dialog_singlechoice_material = 2131493010;
    public static int support_simple_spinner_dropdown_item = 2131493012;

    private R$layout() {
    }
}

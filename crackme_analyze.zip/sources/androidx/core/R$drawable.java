package androidx.core;

/* JADX INFO: loaded from: classes.dex */
public final class R$drawable {
    public static int ic_call_answer = 2131230901;
    public static int ic_call_answer_low = 2131230902;
    public static int ic_call_answer_video = 2131230903;
    public static int ic_call_answer_video_low = 2131230904;
    public static int ic_call_decline = 2131230905;
    public static int ic_call_decline_low = 2131230906;
    public static int notification_action_background = 2131230988;
    public static int notification_bg = 2131230989;
    public static int notification_bg_low = 2131230990;
    public static int notification_bg_low_normal = 2131230991;
    public static int notification_bg_low_pressed = 2131230992;
    public static int notification_bg_normal = 2131230993;
    public static int notification_bg_normal_pressed = 2131230994;
    public static int notification_icon_background = 2131230995;
    public static int notification_oversize_large_icon_bg = 2131230996;
    public static int notification_template_icon_bg = 2131230997;
    public static int notification_template_icon_low_bg = 2131230998;
    public static int notification_tile_bg = 2131230999;
    public static int notify_panel_notification_icon_bg = 2131231000;

    private R$drawable() {
    }
}

package androidx.core;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static int TextAppearance_Compat_Notification = 2131886576;
    public static int TextAppearance_Compat_Notification_Info = 2131886577;
    public static int TextAppearance_Compat_Notification_Line2 = 2131886579;
    public static int TextAppearance_Compat_Notification_Time = 2131886582;
    public static int TextAppearance_Compat_Notification_Title = 2131886584;
    public static int Widget_Compat_NotificationActionContainer = 2131886973;
    public static int Widget_Compat_NotificationActionText = 2131886974;

    private R$style() {
    }
}

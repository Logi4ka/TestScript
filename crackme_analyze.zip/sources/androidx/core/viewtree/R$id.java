package androidx.core.viewtree;

/* JADX INFO: loaded from: classes2.dex */
public final class R$id {
    public static int view_tree_disjoint_parent = 2131296925;

    private R$id() {
    }
}

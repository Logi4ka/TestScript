package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import defpackage.tb7;
import defpackage.ub7;
import defpackage.vb7;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(tb7 tb7Var) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        vb7 vb7VarH = remoteActionCompat.f321a;
        boolean z = true;
        if (tb7Var.e(1)) {
            vb7VarH = tb7Var.h();
        }
        remoteActionCompat.f321a = (IconCompat) vb7VarH;
        CharSequence charSequence = remoteActionCompat.b;
        if (tb7Var.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((ub7) tb7Var).e);
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.c;
        if (tb7Var.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((ub7) tb7Var).e);
        }
        remoteActionCompat.c = charSequence2;
        remoteActionCompat.d = (PendingIntent) tb7Var.g(remoteActionCompat.d, 4);
        boolean z2 = remoteActionCompat.e;
        if (tb7Var.e(5)) {
            z2 = ((ub7) tb7Var).e.readInt() != 0;
        }
        remoteActionCompat.e = z2;
        boolean z3 = remoteActionCompat.f;
        if (!tb7Var.e(6)) {
            z = z3;
        } else if (((ub7) tb7Var).e.readInt() == 0) {
            z = false;
        }
        remoteActionCompat.f = z;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, tb7 tb7Var) {
        tb7Var.getClass();
        IconCompat iconCompat = remoteActionCompat.f321a;
        tb7Var.i(1);
        tb7Var.k(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        tb7Var.i(2);
        Parcel parcel = ((ub7) tb7Var).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.c;
        tb7Var.i(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.d;
        tb7Var.i(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.e;
        tb7Var.i(5);
        parcel.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f;
        tb7Var.i(6);
        parcel.writeInt(z2 ? 1 : 0);
    }
}

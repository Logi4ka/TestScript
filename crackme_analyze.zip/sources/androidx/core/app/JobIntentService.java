package androidx.core.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import defpackage.g;
import defpackage.u63;
import defpackage.v63;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Deprecated
public abstract class JobIntentService extends Service {
    public static final HashMap b = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public v63 f320a;

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        v63 v63Var = this.f320a;
        if (v63Var != null) {
            return v63Var.getBinder();
        }
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            this.f320a = new v63(this);
            return;
        }
        this.f320a = null;
        ComponentName componentName = new ComponentName(this, getClass());
        HashMap map = b;
        if (((u63) map.get(componentName)) == null) {
            if (i >= 26) {
                g.l("Can't be here without a job id");
                return;
            }
            u63 u63Var = new u63();
            getApplicationContext();
            PowerManager powerManager = (PowerManager) getSystemService("power");
            powerManager.newWakeLock(1, componentName.getClassName() + ":launch").setReferenceCounted(false);
            powerManager.newWakeLock(1, componentName.getClassName() + ":run").setReferenceCounted(false);
            map.put(componentName, u63Var);
        }
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        return 2;
    }
}

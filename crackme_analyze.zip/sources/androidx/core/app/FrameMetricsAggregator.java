package androidx.core.app;

import android.util.SparseIntArray;
import defpackage.p88;
import defpackage.yj2;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes2.dex */
public class FrameMetricsAggregator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p88 f319a;

    public FrameMetricsAggregator(int i) {
        p88 p88Var = new p88();
        p88Var.b = new SparseIntArray[9];
        p88Var.c = new ArrayList();
        p88Var.d = new yj2(p88Var);
        p88Var.f4769a = i;
        this.f319a = p88Var;
    }

    public FrameMetricsAggregator() {
        this(1);
    }
}

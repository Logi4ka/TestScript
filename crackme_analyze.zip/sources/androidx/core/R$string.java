package androidx.core;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int call_notification_answer_action = 2131820594;
    public static int call_notification_answer_video_action = 2131820595;
    public static int call_notification_decline_action = 2131820596;
    public static int call_notification_hang_up_action = 2131820597;
    public static int call_notification_incoming_text = 2131820598;
    public static int call_notification_ongoing_text = 2131820599;
    public static int call_notification_screening_text = 2131820600;
    public static int status_bar_notification_info_overflow = 2131820998;

    private R$string() {
    }
}

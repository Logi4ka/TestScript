package androidx.activity;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int report_drawn = 2131296693;
    public static int view_tree_on_back_pressed_dispatcher_owner = 2131296927;

    private R$id() {
    }
}

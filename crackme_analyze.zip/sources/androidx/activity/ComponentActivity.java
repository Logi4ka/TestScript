package androidx.activity;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.ComponentActivity;
import com.google.firebase.analytics.FirebaseAnalytics;
import defpackage.af1;
import defpackage.as6;
import defpackage.bj3;
import defpackage.bu0;
import defpackage.cu0;
import defpackage.dl4;
import defpackage.du0;
import defpackage.ej3;
import defpackage.el4;
import defpackage.fu0;
import defpackage.ga5;
import defpackage.gj3;
import defpackage.gw3;
import defpackage.gz2;
import defpackage.h7;
import defpackage.hl4;
import defpackage.hu0;
import defpackage.i7;
import defpackage.iw3;
import defpackage.jb4;
import defpackage.jk2;
import defpackage.ju0;
import defpackage.jw3;
import defpackage.k01;
import defpackage.k7;
import defpackage.ko1;
import defpackage.ku0;
import defpackage.lu0;
import defpackage.mb4;
import defpackage.mu0;
import defpackage.nd5;
import defpackage.nu0;
import defpackage.od7;
import defpackage.pd7;
import defpackage.pe3;
import defpackage.pu4;
import defpackage.q7;
import defpackage.qd5;
import defpackage.qi3;
import defpackage.qm5;
import defpackage.qz0;
import defpackage.r55;
import defpackage.r7;
import defpackage.ri3;
import defpackage.rm5;
import defpackage.sd7;
import defpackage.si3;
import defpackage.sm5;
import defpackage.td7;
import defpackage.tk4;
import defpackage.tm5;
import defpackage.ue3;
import defpackage.uk4;
import defpackage.vi2;
import defpackage.vk5;
import defpackage.wk4;
import defpackage.x06;
import defpackage.yk4;
import defpackage.ys2;
import defpackage.yw3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import okhttp3.HttpUrl;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000Æ\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\b\u0016\u0018\u0000 Ã\u00012\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u00052\u00020\u00062\u00020\u00072\u00020\b2\u00020\u00022\u00020\t2\u00020\n2\u00020\u00022\u00020\u000b2\u00020\f2\u00020\u00022\u00020\r2\u00020\u0002:\nÄ\u0001Å\u0001Æ\u0001\u008b\u0001Ç\u0001J\u0017\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u000eH\u0015¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u0011\u0010\u0015\u001a\u0004\u0018\u00010\u0002H\u0017¢\u0006\u0004\b\u0015\u0010\u0014J\u0019\u0010\u0018\u001a\u00020\u00102\b\b\u0001\u0010\u0017\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u0019\u0010\u0018\u001a\u00020\u00102\b\u0010\u001b\u001a\u0004\u0018\u00010\u001aH\u0016¢\u0006\u0004\b\u0018\u0010\u001cJ#\u0010\u0018\u001a\u00020\u00102\b\u0010\u001b\u001a\u0004\u0018\u00010\u001a2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u0016¢\u0006\u0004\b\u0018\u0010\u001fJ#\u0010 \u001a\u00020\u00102\b\u0010\u001b\u001a\u0004\u0018\u00010\u001a2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u0016¢\u0006\u0004\b \u0010\u001fJ\u000f\u0010!\u001a\u00020\u0010H\u0017¢\u0006\u0004\b!\u0010\"J\u0011\u0010$\u001a\u0004\u0018\u00010#H\u0016¢\u0006\u0004\b$\u0010%J\u0015\u0010(\u001a\u00020\u00102\u0006\u0010'\u001a\u00020&¢\u0006\u0004\b(\u0010)J\u0015\u0010*\u001a\u00020\u00102\u0006\u0010'\u001a\u00020&¢\u0006\u0004\b*\u0010)J)\u0010/\u001a\u00020.2\u0006\u0010+\u001a\u00020\u00162\b\u0010\u001b\u001a\u0004\u0018\u00010\u001a2\u0006\u0010-\u001a\u00020,H\u0016¢\u0006\u0004\b/\u00100J\u001f\u00101\u001a\u00020.2\u0006\u0010+\u001a\u00020\u00162\u0006\u0010-\u001a\u00020,H\u0016¢\u0006\u0004\b1\u00102J\u001f\u00103\u001a\u00020\u00102\u0006\u0010+\u001a\u00020\u00162\u0006\u0010-\u001a\u00020,H\u0016¢\u0006\u0004\b3\u00104J\u0017\u00107\u001a\u00020\u00102\u0006\u00106\u001a\u000205H\u0016¢\u0006\u0004\b7\u00108J\u001f\u00107\u001a\u00020\u00102\u0006\u00106\u001a\u0002052\u0006\u00109\u001a\u00020\u0003H\u0016¢\u0006\u0004\b7\u0010:J'\u00107\u001a\u00020\u00102\u0006\u00106\u001a\u0002052\u0006\u00109\u001a\u00020\u00032\u0006\u0010<\u001a\u00020;H\u0017¢\u0006\u0004\b7\u0010=J\u0017\u0010>\u001a\u00020\u00102\u0006\u00106\u001a\u000205H\u0016¢\u0006\u0004\b>\u00108J\u000f\u0010?\u001a\u00020\u0010H\u0016¢\u0006\u0004\b?\u0010\"J\u000f\u0010@\u001a\u00020\u0010H\u0017¢\u0006\u0004\b@\u0010\"J\u001f\u0010D\u001a\u00020\u00102\u0006\u0010B\u001a\u00020A2\u0006\u0010C\u001a\u00020\u0016H\u0017¢\u0006\u0004\bD\u0010EJ)\u0010D\u001a\u00020\u00102\u0006\u0010B\u001a\u00020A2\u0006\u0010C\u001a\u00020\u00162\b\u0010F\u001a\u0004\u0018\u00010\u000eH\u0017¢\u0006\u0004\bD\u0010GJA\u0010M\u001a\u00020\u00102\u0006\u0010B\u001a\u00020H2\u0006\u0010C\u001a\u00020\u00162\b\u0010I\u001a\u0004\u0018\u00010A2\u0006\u0010J\u001a\u00020\u00162\u0006\u0010K\u001a\u00020\u00162\u0006\u0010L\u001a\u00020\u0016H\u0017¢\u0006\u0004\bM\u0010NJK\u0010M\u001a\u00020\u00102\u0006\u0010B\u001a\u00020H2\u0006\u0010C\u001a\u00020\u00162\b\u0010I\u001a\u0004\u0018\u00010A2\u0006\u0010J\u001a\u00020\u00162\u0006\u0010K\u001a\u00020\u00162\u0006\u0010L\u001a\u00020\u00162\b\u0010F\u001a\u0004\u0018\u00010\u000eH\u0017¢\u0006\u0004\bM\u0010OJI\u0010Y\u001a\b\u0012\u0004\u0012\u00028\u00000X\"\u0004\b\u0000\u0010P\"\u0004\b\u0001\u0010Q2\u0012\u0010S\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010R2\u0006\u0010U\u001a\u00020T2\f\u0010W\u001a\b\u0012\u0004\u0012\u00028\u00010V¢\u0006\u0004\bY\u0010ZJA\u0010Y\u001a\b\u0012\u0004\u0012\u00028\u00000X\"\u0004\b\u0000\u0010P\"\u0004\b\u0001\u0010Q2\u0012\u0010S\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010R2\f\u0010W\u001a\b\u0012\u0004\u0012\u00028\u00010V¢\u0006\u0004\bY\u0010[J\u0017\u0010^\u001a\u00020\u00102\u0006\u0010]\u001a\u00020\\H\u0017¢\u0006\u0004\b^\u0010_J\u001b\u0010a\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020\\0`¢\u0006\u0004\ba\u0010bJ\u001b\u0010c\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020\\0`¢\u0006\u0004\bc\u0010bJ\u0017\u0010e\u001a\u00020\u00102\u0006\u0010d\u001a\u00020\u0016H\u0017¢\u0006\u0004\be\u0010\u0019J\u001b\u0010f\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00160`¢\u0006\u0004\bf\u0010bJ\u001b\u0010g\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00160`¢\u0006\u0004\bg\u0010bJ\u0017\u0010h\u001a\u00020\u00102\u0006\u0010B\u001a\u00020AH\u0015¢\u0006\u0004\bh\u0010iJ\u001b\u0010j\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020A0`¢\u0006\u0004\bj\u0010bJ\u001b\u0010k\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020A0`¢\u0006\u0004\bk\u0010bJ\u0017\u0010m\u001a\u00020\u00102\u0006\u0010l\u001a\u00020.H\u0017¢\u0006\u0004\bm\u0010nJ\u001f\u0010m\u001a\u00020\u00102\u0006\u0010l\u001a\u00020.2\u0006\u0010]\u001a\u00020\\H\u0017¢\u0006\u0004\bm\u0010oJ\u001b\u0010q\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020p0`¢\u0006\u0004\bq\u0010bJ\u001b\u0010r\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020p0`¢\u0006\u0004\br\u0010bJ\u0017\u0010t\u001a\u00020\u00102\u0006\u0010s\u001a\u00020.H\u0017¢\u0006\u0004\bt\u0010nJ\u001f\u0010t\u001a\u00020\u00102\u0006\u0010s\u001a\u00020.2\u0006\u0010]\u001a\u00020\\H\u0017¢\u0006\u0004\bt\u0010oJ\u001b\u0010v\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020u0`¢\u0006\u0004\bv\u0010bJ\u001b\u0010w\u001a\u00020\u00102\f\u0010'\u001a\b\u0012\u0004\u0012\u00020u0`¢\u0006\u0004\bw\u0010bJ\u000f\u0010x\u001a\u00020\u0010H\u0015¢\u0006\u0004\bx\u0010\"J\u0015\u0010z\u001a\u00020\u00102\u0006\u0010'\u001a\u00020y¢\u0006\u0004\bz\u0010{J\u0015\u0010|\u001a\u00020\u00102\u0006\u0010'\u001a\u00020y¢\u0006\u0004\b|\u0010{J\u000f\u0010}\u001a\u00020\u0010H\u0016¢\u0006\u0004\b}\u0010\"R\u0015\u0010\u007f\u001a\u00020~8\u0002X\u0082\u0004¢\u0006\u0007\n\u0005\b\u007f\u0010\u0080\u0001R\u0018\u0010\u0082\u0001\u001a\u00030\u0081\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0082\u0001\u0010\u0083\u0001R\u001f\u0010\u0085\u0001\u001a\u00030\u0084\u00018\u0002X\u0082\u0004¢\u0006\u000f\n\u0006\b\u0085\u0001\u0010\u0086\u0001\u0012\u0005\b\u0087\u0001\u0010\"R\u001c\u0010\u0089\u0001\u001a\u0005\u0018\u00010\u0088\u00018\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0089\u0001\u0010\u008a\u0001R\u0018\u0010\u008c\u0001\u001a\u00030\u008b\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u008c\u0001\u0010\u008d\u0001R!\u0010\u0093\u0001\u001a\u00030\u008e\u00018VX\u0096\u0084\u0002¢\u0006\u0010\n\u0006\b\u008f\u0001\u0010\u0090\u0001\u001a\u0006\b\u0091\u0001\u0010\u0092\u0001R\u0018\u0010\u0094\u0001\u001a\u00020\u00168\u0002@\u0002X\u0083\u000e¢\u0006\u0007\n\u0005\b\u0094\u0001\u0010PR\u0018\u0010\u0096\u0001\u001a\u00030\u0095\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0096\u0001\u0010\u0097\u0001R\u001c\u0010\u0098\u0001\u001a\u00020T8\u0006¢\u0006\u0010\n\u0006\b\u0098\u0001\u0010\u0099\u0001\u001a\u0006\b\u009a\u0001\u0010\u009b\u0001R$\u0010\u009d\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\\0`0\u009c\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u009d\u0001\u0010\u009e\u0001R$\u0010\u009f\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00160`0\u009c\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u009f\u0001\u0010\u009e\u0001R$\u0010 \u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020A0`0\u009c\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b \u0001\u0010\u009e\u0001R$\u0010¡\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020p0`0\u009c\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b¡\u0001\u0010\u009e\u0001R$\u0010¢\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020u0`0\u009c\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b¢\u0001\u0010\u009e\u0001R\u001e\u0010£\u0001\u001a\t\u0012\u0004\u0012\u00020y0\u009c\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b£\u0001\u0010\u009e\u0001R\u0019\u0010¤\u0001\u001a\u00020.8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b¤\u0001\u0010¥\u0001R\u0019\u0010¦\u0001\u001a\u00020.8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b¦\u0001\u0010¥\u0001R!\u0010«\u0001\u001a\u00030§\u00018VX\u0096\u0084\u0002¢\u0006\u0010\n\u0006\b¨\u0001\u0010\u0090\u0001\u001a\u0006\b©\u0001\u0010ª\u0001R(\u0010±\u0001\u001a\u00030¬\u00018FX\u0086\u0084\u0002¢\u0006\u0017\n\u0006\b\u00ad\u0001\u0010\u0090\u0001\u0012\u0005\b°\u0001\u0010\"\u001a\u0006\b®\u0001\u0010¯\u0001R\u0018\u0010³\u0001\u001a\u0004\u0018\u00010\u00028WX\u0096\u0004¢\u0006\u0007\u001a\u0005\b²\u0001\u0010\u0014R\u0018\u0010·\u0001\u001a\u00030´\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\bµ\u0001\u0010¶\u0001R\u0018\u0010º\u0001\u001a\u00030\u0088\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\b¸\u0001\u0010¹\u0001R\u0018\u0010¾\u0001\u001a\u00030»\u00018WX\u0096\u0004¢\u0006\b\u001a\u0006\b¼\u0001\u0010½\u0001R\u0015\u0010Â\u0001\u001a\u00030¿\u00018F¢\u0006\b\u001a\u0006\bÀ\u0001\u0010Á\u0001¨\u0006È\u0001"}, d2 = {"Landroidx/activity/ComponentActivity;", "Landroidx/core/app/ComponentActivity;", HttpUrl.FRAGMENT_ENCODE_SET, "Lej3;", "Ltd7;", "Lys2;", "Ltm5;", "Luk4;", "Lr7;", "Lwk4;", "Lhl4;", "Ldl4;", "Lel4;", "Lgw3;", "Landroid/os/Bundle;", "outState", HttpUrl.FRAGMENT_ENCODE_SET, "onSaveInstanceState", "(Landroid/os/Bundle;)V", "onRetainNonConfigurationInstance", "()Ljava/lang/Object;", "onRetainCustomNonConfigurationInstance", HttpUrl.FRAGMENT_ENCODE_SET, "layoutResID", "setContentView", "(I)V", "Landroid/view/View;", "view", "(Landroid/view/View;)V", "Landroid/view/ViewGroup$LayoutParams;", "params", "(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V", "addContentView", "initializeViewTreeOwners", "()V", "Landroid/content/Context;", "peekAvailableContext", "()Landroid/content/Context;", "Lyk4;", "listener", "addOnContextAvailableListener", "(Lyk4;)V", "removeOnContextAvailableListener", "featureId", "Landroid/view/Menu;", "menu", HttpUrl.FRAGMENT_ENCODE_SET, "onPreparePanel", "(ILandroid/view/View;Landroid/view/Menu;)Z", "onCreatePanelMenu", "(ILandroid/view/Menu;)Z", "onPanelClosed", "(ILandroid/view/Menu;)V", "Lyw3;", "provider", "addMenuProvider", "(Lyw3;)V", "owner", "(Lyw3;Lej3;)V", "Lri3;", "state", "(Lyw3;Lej3;Lri3;)V", "removeMenuProvider", "invalidateMenu", "onBackPressed", "Landroid/content/Intent;", "intent", "requestCode", "startActivityForResult", "(Landroid/content/Intent;I)V", "options", "(Landroid/content/Intent;ILandroid/os/Bundle;)V", "Landroid/content/IntentSender;", "fillInIntent", "flagsMask", "flagsValues", "extraFlags", "startIntentSenderForResult", "(Landroid/content/IntentSender;ILandroid/content/Intent;III)V", "(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V", "I", "O", "Li7;", "contract", "Lq7;", "registry", "Lh7;", "callback", "Lk7;", "registerForActivityResult", "(Li7;Lq7;Lh7;)Lk7;", "(Li7;Lh7;)Lk7;", "Landroid/content/res/Configuration;", "newConfig", "onConfigurationChanged", "(Landroid/content/res/Configuration;)V", "Lqz0;", "addOnConfigurationChangedListener", "(Lqz0;)V", "removeOnConfigurationChangedListener", FirebaseAnalytics.Param.LEVEL, "onTrimMemory", "addOnTrimMemoryListener", "removeOnTrimMemoryListener", "onNewIntent", "(Landroid/content/Intent;)V", "addOnNewIntentListener", "removeOnNewIntentListener", "isInMultiWindowMode", "onMultiWindowModeChanged", "(Z)V", "(ZLandroid/content/res/Configuration;)V", "Ljb4;", "addOnMultiWindowModeChangedListener", "removeOnMultiWindowModeChangedListener", "isInPictureInPictureMode", "onPictureInPictureModeChanged", "Lpu4;", "addOnPictureInPictureModeChangedListener", "removeOnPictureInPictureModeChangedListener", "onUserLeaveHint", "Ljava/lang/Runnable;", "addOnUserLeaveHintListener", "(Ljava/lang/Runnable;)V", "removeOnUserLeaveHintListener", "reportFullyDrawn", "Lk01;", "contextAwareHelper", "Lk01;", "Ljw3;", "menuHostHelper", "Ljw3;", "Lrm5;", "savedStateRegistryController", "Lrm5;", "getSavedStateRegistryController$annotations", "Lsd7;", "_viewModelStore", "Lsd7;", "Lku0;", "reportFullyDrawnExecutor", "Lku0;", "Ljk2;", "fullyDrawnReporter$delegate", "Lpe3;", "getFullyDrawnReporter", "()Ljk2;", "fullyDrawnReporter", "contentLayoutId", "Ljava/util/concurrent/atomic/AtomicInteger;", "nextLocalRequestCode", "Ljava/util/concurrent/atomic/AtomicInteger;", "activityResultRegistry", "Lq7;", "getActivityResultRegistry", "()Lq7;", "Ljava/util/concurrent/CopyOnWriteArrayList;", "onConfigurationChangedListeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "onTrimMemoryListeners", "onNewIntentListeners", "onMultiWindowModeChangedListeners", "onPictureInPictureModeChangedListeners", "onUserLeaveHintListeners", "dispatchingOnMultiWindowModeChanged", "Z", "dispatchingOnPictureInPictureModeChanged", "Lpd7;", "defaultViewModelProviderFactory$delegate", "getDefaultViewModelProviderFactory", "()Lpd7;", "defaultViewModelProviderFactory", "Ltk4;", "onBackPressedDispatcher$delegate", "getOnBackPressedDispatcher", "()Ltk4;", "getOnBackPressedDispatcher$annotations", "onBackPressedDispatcher", "getLastCustomNonConfigurationInstance", "lastCustomNonConfigurationInstance", "Lsi3;", "getLifecycle", "()Lsi3;", "lifecycle", "getViewModelStore", "()Lsd7;", "viewModelStore", "Laf1;", "getDefaultViewModelCreationExtras", "()Laf1;", "defaultViewModelCreationExtras", "Lqm5;", "getSavedStateRegistry", "()Lqm5;", "savedStateRegistry", "Companion", "gu0", "hu0", "ju0", "lu0", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class ComponentActivity extends androidx.core.app.ComponentActivity implements td7, ys2, tm5, uk4, r7, wk4, hl4, dl4, el4, gw3 {
    private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
    private static final hu0 Companion = new hu0();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f148a = 0;
    private sd7 _viewModelStore;
    private final q7 activityResultRegistry;
    private int contentLayoutId;
    private final k01 contextAwareHelper = new k01();

    /* JADX INFO: renamed from: defaultViewModelProviderFactory$delegate, reason: from kotlin metadata */
    private final pe3 defaultViewModelProviderFactory;
    private boolean dispatchingOnMultiWindowModeChanged;
    private boolean dispatchingOnPictureInPictureModeChanged;

    /* JADX INFO: renamed from: fullyDrawnReporter$delegate, reason: from kotlin metadata */
    private final pe3 fullyDrawnReporter;
    private final jw3 menuHostHelper;
    private final AtomicInteger nextLocalRequestCode;

    /* JADX INFO: renamed from: onBackPressedDispatcher$delegate, reason: from kotlin metadata */
    private final pe3 onBackPressedDispatcher;
    private final CopyOnWriteArrayList<qz0> onConfigurationChangedListeners;
    private final CopyOnWriteArrayList<qz0> onMultiWindowModeChangedListeners;
    private final CopyOnWriteArrayList<qz0> onNewIntentListeners;
    private final CopyOnWriteArrayList<qz0> onPictureInPictureModeChangedListeners;
    private final CopyOnWriteArrayList<qz0> onTrimMemoryListeners;
    private final CopyOnWriteArrayList<Runnable> onUserLeaveHintListeners;
    private final ku0 reportFullyDrawnExecutor;
    private final rm5 savedStateRegistryController;

    public ComponentActivity() {
        int i = 0;
        this.menuHostHelper = new jw3(new bu0(this, i));
        sm5 sm5Var = new sm5(this, new gz2(this, 24));
        this.savedStateRegistryController = new rm5(sm5Var);
        this.reportFullyDrawnExecutor = new lu0(this);
        this.fullyDrawnReporter = ue3.b(new nu0(this, 2));
        this.nextLocalRequestCode = new AtomicInteger();
        this.activityResultRegistry = new mu0(this);
        this.onConfigurationChangedListeners = new CopyOnWriteArrayList<>();
        this.onTrimMemoryListeners = new CopyOnWriteArrayList<>();
        this.onNewIntentListeners = new CopyOnWriteArrayList<>();
        this.onMultiWindowModeChangedListeners = new CopyOnWriteArrayList<>();
        this.onPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<>();
        this.onUserLeaveHintListeners = new CopyOnWriteArrayList<>();
        if (getLifecycle() == null) {
            vk5.k("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
            throw null;
        }
        getLifecycle().a(new cu0(this, i));
        int i2 = 1;
        getLifecycle().a(new cu0(this, i2));
        getLifecycle().a(new ga5(this, i2));
        sm5Var.a();
        r55.B(this);
        getSavedStateRegistry().c(ACTIVITY_RESULT_TAG, new du0(this, i));
        addOnContextAvailableListener(new yk4() { // from class: eu0
            @Override // defpackage.yk4
            public final void a(ComponentActivity componentActivity) {
                ComponentActivity.a(this.f2026a, componentActivity);
            }
        });
        this.defaultViewModelProviderFactory = ue3.b(new nu0(this, i));
        this.onBackPressedDispatcher = ue3.b(new nu0(this, 3));
    }

    public static void a(ComponentActivity componentActivity, Context context) {
        context.getClass();
        Bundle bundleA = componentActivity.getSavedStateRegistry().a(ACTIVITY_RESULT_TAG);
        if (bundleA != null) {
            q7 q7Var = componentActivity.activityResultRegistry;
            LinkedHashMap linkedHashMap = q7Var.b;
            LinkedHashMap linkedHashMap2 = q7Var.f4967a;
            Bundle bundle = q7Var.g;
            ArrayList<Integer> integerArrayList = bundleA.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = bundleA.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList == null || integerArrayList == null) {
                return;
            }
            ArrayList<String> stringArrayList2 = bundleA.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
            if (stringArrayList2 != null) {
                q7Var.d.addAll(stringArrayList2);
            }
            Bundle bundle2 = bundleA.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
            if (bundle2 != null) {
                bundle.putAll(bundle2);
            }
            int size = stringArrayList.size();
            for (int i = 0; i < size; i++) {
                String str = stringArrayList.get(i);
                if (linkedHashMap.containsKey(str)) {
                    Integer num = (Integer) linkedHashMap.remove(str);
                    if (!bundle.containsKey(str)) {
                        as6.c(linkedHashMap2).remove(num);
                    }
                }
                Integer num2 = integerArrayList.get(i);
                num2.getClass();
                int iIntValue = num2.intValue();
                String str2 = stringArrayList.get(i);
                str2.getClass();
                String str3 = str2;
                linkedHashMap2.put(Integer.valueOf(iIntValue), str3);
                q7Var.b.put(str3, Integer.valueOf(iIntValue));
            }
        }
    }

    public static final void access$ensureViewModelStore(ComponentActivity componentActivity) {
        if (componentActivity._viewModelStore == null) {
            ju0 ju0Var = (ju0) componentActivity.getLastNonConfigurationInstance();
            if (ju0Var != null) {
                componentActivity._viewModelStore = ju0Var.b;
            }
            if (componentActivity._viewModelStore == null) {
                componentActivity._viewModelStore = new sd7();
            }
        }
    }

    public static void b(ComponentActivity componentActivity, ej3 ej3Var, qi3 qi3Var) {
        if (qi3Var == qi3.ON_DESTROY) {
            componentActivity.contextAwareHelper.b = null;
            if (!componentActivity.isChangingConfigurations()) {
                componentActivity.getViewModelStore().a();
            }
            lu0 lu0Var = (lu0) componentActivity.reportFullyDrawnExecutor;
            ComponentActivity componentActivity2 = lu0Var.d;
            componentActivity2.getWindow().getDecorView().removeCallbacks(lu0Var);
            componentActivity2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(lu0Var);
        }
    }

    public static Bundle c(ComponentActivity componentActivity) {
        Bundle bundle = new Bundle();
        q7 q7Var = componentActivity.activityResultRegistry;
        q7Var.getClass();
        LinkedHashMap linkedHashMap = q7Var.b;
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(linkedHashMap.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(linkedHashMap.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(q7Var.d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(q7Var.g));
        return bundle;
    }

    public static /* synthetic */ void getOnBackPressedDispatcher$annotations() {
    }

    @Override // android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams params) {
        initializeViewTreeOwners();
        ku0 ku0Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((lu0) ku0Var).a(decorView);
        super.addContentView(view, params);
    }

    public void addMenuProvider(yw3 provider, ej3 owner) {
        provider.getClass();
        owner.getClass();
        jw3 jw3Var = this.menuHostHelper;
        jw3Var.b.add(provider);
        jw3Var.f3587a.run();
        si3 lifecycle = owner.getLifecycle();
        HashMap map = jw3Var.c;
        iw3 iw3Var = (iw3) map.remove(provider);
        if (iw3Var != null) {
            iw3Var.f3361a.c(iw3Var.b);
            iw3Var.b = null;
        }
        map.put(provider, new iw3(lifecycle, new fu0(1, jw3Var, provider)));
    }

    @Override // defpackage.wk4
    public final void addOnConfigurationChangedListener(qz0 listener) {
        listener.getClass();
        this.onConfigurationChangedListeners.add(listener);
    }

    public final void addOnContextAvailableListener(yk4 listener) {
        listener.getClass();
        k01 k01Var = this.contextAwareHelper;
        k01Var.getClass();
        ComponentActivity componentActivity = k01Var.b;
        if (componentActivity != null) {
            listener.a(componentActivity);
        }
        k01Var.f3611a.add(listener);
    }

    @Override // defpackage.dl4
    public final void addOnMultiWindowModeChangedListener(qz0 listener) {
        listener.getClass();
        this.onMultiWindowModeChangedListeners.add(listener);
    }

    public final void addOnNewIntentListener(qz0 listener) {
        listener.getClass();
        this.onNewIntentListeners.add(listener);
    }

    @Override // defpackage.el4
    public final void addOnPictureInPictureModeChangedListener(qz0 listener) {
        listener.getClass();
        this.onPictureInPictureModeChangedListeners.add(listener);
    }

    @Override // defpackage.hl4
    public final void addOnTrimMemoryListener(qz0 listener) {
        listener.getClass();
        this.onTrimMemoryListeners.add(listener);
    }

    public final void addOnUserLeaveHintListener(Runnable listener) {
        listener.getClass();
        this.onUserLeaveHintListeners.add(listener);
    }

    @Override // defpackage.r7
    public final q7 getActivityResultRegistry() {
        return this.activityResultRegistry;
    }

    @Override // defpackage.ys2
    public af1 getDefaultViewModelCreationExtras() {
        mb4 mb4Var = new mb4(0);
        Application application = getApplication();
        LinkedHashMap linkedHashMap = mb4Var.f93a;
        if (application != null) {
            Application application2 = getApplication();
            application2.getClass();
            linkedHashMap.put(od7.d, application2);
        }
        linkedHashMap.put(r55.v, this);
        linkedHashMap.put(r55.w, this);
        Intent intent = getIntent();
        Bundle extras = intent != null ? intent.getExtras() : null;
        if (extras != null) {
            linkedHashMap.put(r55.X, extras);
        }
        return mb4Var;
    }

    public pd7 getDefaultViewModelProviderFactory() {
        return (pd7) this.defaultViewModelProviderFactory.getValue();
    }

    public jk2 getFullyDrawnReporter() {
        return (jk2) this.fullyDrawnReporter.getValue();
    }

    @ko1
    public Object getLastCustomNonConfigurationInstance() {
        ju0 ju0Var = (ju0) getLastNonConfigurationInstance();
        if (ju0Var != null) {
            return ju0Var.f3574a;
        }
        return null;
    }

    @Override // androidx.core.app.ComponentActivity, defpackage.ej3
    public si3 getLifecycle() {
        return super.getLifecycle();
    }

    @Override // defpackage.uk4
    public final tk4 getOnBackPressedDispatcher() {
        return (tk4) this.onBackPressedDispatcher.getValue();
    }

    @Override // defpackage.tm5
    public final qm5 getSavedStateRegistry() {
        return this.savedStateRegistryController.b;
    }

    @Override // defpackage.td7
    public sd7 getViewModelStore() {
        if (getApplication() == null) {
            vk5.k("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
            return null;
        }
        if (this._viewModelStore == null) {
            ju0 ju0Var = (ju0) getLastNonConfigurationInstance();
            if (ju0Var != null) {
                this._viewModelStore = ju0Var.b;
            }
            if (this._viewModelStore == null) {
                this._viewModelStore = new sd7();
            }
        }
        sd7 sd7Var = this._viewModelStore;
        sd7Var.getClass();
        return sd7Var;
    }

    public void initializeViewTreeOwners() {
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(androidx.lifecycle.runtime.R$id.view_tree_lifecycle_owner, this);
        View decorView2 = getWindow().getDecorView();
        decorView2.getClass();
        decorView2.setTag(androidx.lifecycle.viewmodel.R$id.view_tree_view_model_store_owner, this);
        View decorView3 = getWindow().getDecorView();
        decorView3.getClass();
        decorView3.setTag(androidx.savedstate.R$id.view_tree_saved_state_registry_owner, this);
        View decorView4 = getWindow().getDecorView();
        decorView4.getClass();
        decorView4.setTag(R$id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView5 = getWindow().getDecorView();
        decorView5.getClass();
        decorView5.setTag(R$id.report_drawn, this);
    }

    public void invalidateMenu() {
        invalidateOptionsMenu();
    }

    @Override // android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        if (this.activityResultRegistry.a(i, i2, intent)) {
            return;
        }
        super.onActivityResult(i, i2, intent);
    }

    @Override // android.app.Activity
    @ko1
    public void onBackPressed() {
        getOnBackPressedDispatcher().d();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        newConfig.getClass();
        super.onConfigurationChanged(newConfig);
        Iterator<qz0> it = this.onConfigurationChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(newConfig);
        }
    }

    @Override // androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.savedStateRegistryController.a(bundle);
        k01 k01Var = this.contextAwareHelper;
        k01Var.getClass();
        k01Var.b = this;
        Iterator it = k01Var.f3611a.iterator();
        while (it.hasNext()) {
            ((yk4) it.next()).a(this);
        }
        super.onCreate(bundle);
        int i = qd5.b;
        nd5.b(this);
        int i2 = this.contentLayoutId;
        if (i2 != 0) {
            setContentView(i2);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        menu.getClass();
        if (featureId != 0) {
            return true;
        }
        super.onCreatePanelMenu(featureId, menu);
        jw3 jw3Var = this.menuHostHelper;
        MenuInflater menuInflater = getMenuInflater();
        Iterator it = jw3Var.b.iterator();
        while (it.hasNext()) {
            ((vi2) ((yw3) it.next())).f6104a.k(menu, menuInflater);
        }
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        menuItem.getClass();
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.menuHostHelper.a(menuItem);
        }
        return false;
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean isInMultiWindowMode, Configuration newConfig) {
        newConfig.getClass();
        this.dispatchingOnMultiWindowModeChanged = true;
        try {
            super.onMultiWindowModeChanged(isInMultiWindowMode, newConfig);
            this.dispatchingOnMultiWindowModeChanged = false;
            Iterator<qz0> it = this.onMultiWindowModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new jb4(isInMultiWindowMode));
            }
        } catch (Throwable th) {
            this.dispatchingOnMultiWindowModeChanged = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        intent.getClass();
        super.onNewIntent(intent);
        Iterator<qz0> it = this.onNewIntentListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int featureId, Menu menu) {
        menu.getClass();
        Iterator it = this.menuHostHelper.b.iterator();
        while (it.hasNext()) {
            ((vi2) ((yw3) it.next())).f6104a.q(menu);
        }
        super.onPanelClosed(featureId, menu);
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        newConfig.getClass();
        this.dispatchingOnPictureInPictureModeChanged = true;
        try {
            super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
            this.dispatchingOnPictureInPictureModeChanged = false;
            Iterator<qz0> it = this.onPictureInPictureModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new pu4(isInPictureInPictureMode));
            }
        } catch (Throwable th) {
            this.dispatchingOnPictureInPictureModeChanged = false;
            throw th;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int featureId, View view, Menu menu) {
        menu.getClass();
        if (featureId != 0) {
            return true;
        }
        super.onPreparePanel(featureId, view, menu);
        Iterator it = this.menuHostHelper.b.iterator();
        while (it.hasNext()) {
            ((vi2) ((yw3) it.next())).f6104a.t(menu);
        }
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        strArr.getClass();
        iArr.getClass();
        if (this.activityResultRegistry.a(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @ko1
    public Object onRetainCustomNonConfigurationInstance() {
        return null;
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        ju0 ju0Var;
        Object objOnRetainCustomNonConfigurationInstance = onRetainCustomNonConfigurationInstance();
        sd7 sd7Var = this._viewModelStore;
        if (sd7Var == null && (ju0Var = (ju0) getLastNonConfigurationInstance()) != null) {
            sd7Var = ju0Var.b;
        }
        if (sd7Var == null && objOnRetainCustomNonConfigurationInstance == null) {
            return null;
        }
        ju0 ju0Var2 = new ju0();
        ju0Var2.f3574a = objOnRetainCustomNonConfigurationInstance;
        ju0Var2.b = sd7Var;
        return ju0Var2;
    }

    @Override // androidx.core.app.ComponentActivity, android.app.Activity
    public void onSaveInstanceState(Bundle outState) {
        outState.getClass();
        if (getLifecycle() instanceof gj3) {
            si3 lifecycle = getLifecycle();
            lifecycle.getClass();
            ((gj3) lifecycle).h(ri3.c);
        }
        super.onSaveInstanceState(outState);
        this.savedStateRegistryController.b(outState);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Iterator<qz0> it = this.onTrimMemoryListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(Integer.valueOf(level));
        }
    }

    @Override // android.app.Activity
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        Iterator<Runnable> it = this.onUserLeaveHintListeners.iterator();
        while (it.hasNext()) {
            it.next().run();
        }
    }

    public Context peekAvailableContext() {
        return this.contextAwareHelper.b;
    }

    public final <I, O> k7 registerForActivityResult(i7 contract, q7 registry, h7 callback) {
        contract.getClass();
        registry.getClass();
        callback.getClass();
        return registry.d("activity_rq#" + this.nextLocalRequestCode.getAndIncrement(), this, contract, callback);
    }

    @Override // defpackage.gw3
    public void removeMenuProvider(yw3 provider) {
        provider.getClass();
        this.menuHostHelper.b(provider);
    }

    @Override // defpackage.wk4
    public final void removeOnConfigurationChangedListener(qz0 listener) {
        listener.getClass();
        this.onConfigurationChangedListeners.remove(listener);
    }

    public final void removeOnContextAvailableListener(yk4 listener) {
        listener.getClass();
        k01 k01Var = this.contextAwareHelper;
        k01Var.getClass();
        k01Var.f3611a.remove(listener);
    }

    @Override // defpackage.dl4
    public final void removeOnMultiWindowModeChangedListener(qz0 listener) {
        listener.getClass();
        this.onMultiWindowModeChangedListeners.remove(listener);
    }

    public final void removeOnNewIntentListener(qz0 listener) {
        listener.getClass();
        this.onNewIntentListeners.remove(listener);
    }

    @Override // defpackage.el4
    public final void removeOnPictureInPictureModeChangedListener(qz0 listener) {
        listener.getClass();
        this.onPictureInPictureModeChangedListeners.remove(listener);
    }

    @Override // defpackage.hl4
    public final void removeOnTrimMemoryListener(qz0 listener) {
        listener.getClass();
        this.onTrimMemoryListeners.remove(listener);
    }

    public final void removeOnUserLeaveHintListener(Runnable listener) {
        listener.getClass();
        this.onUserLeaveHintListeners.remove(listener);
    }

    @Override // android.app.Activity
    public void reportFullyDrawn() {
        try {
            if (x06.g()) {
                Trace.beginSection(x06.k("reportFullyDrawn() for ComponentActivity"));
            }
            super.reportFullyDrawn();
            jk2 fullyDrawnReporter = getFullyDrawnReporter();
            synchronized (fullyDrawnReporter.f3515a) {
                try {
                    fullyDrawnReporter.b = true;
                    Iterator it = fullyDrawnReporter.c.iterator();
                    while (it.hasNext()) {
                        ((Function0) it.next()).invoke();
                    }
                    fullyDrawnReporter.c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        } finally {
            Trace.endSection();
        }
    }

    @Override // android.app.Activity
    public void setContentView(int layoutResID) {
        initializeViewTreeOwners();
        ku0 ku0Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((lu0) ku0Var).a(decorView);
        super.setContentView(layoutResID);
    }

    @Override // android.app.Activity
    @ko1
    public void startActivityForResult(Intent intent, int requestCode) {
        intent.getClass();
        super.startActivityForResult(intent, requestCode);
    }

    @Override // android.app.Activity
    @ko1
    public void startIntentSenderForResult(IntentSender intent, int requestCode, Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags) throws IntentSender.SendIntentException {
        intent.getClass();
        super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags);
    }

    @Override // android.app.Activity
    @ko1
    public void startActivityForResult(Intent intent, int requestCode, Bundle options) {
        intent.getClass();
        super.startActivityForResult(intent, requestCode, options);
    }

    @Override // android.app.Activity
    @ko1
    public void startIntentSenderForResult(IntentSender intent, int requestCode, Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, Bundle options) throws IntentSender.SendIntentException {
        intent.getClass();
        super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags, options);
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        initializeViewTreeOwners();
        ku0 ku0Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((lu0) ku0Var).a(decorView);
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        initializeViewTreeOwners();
        ku0 ku0Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((lu0) ku0Var).a(decorView);
        super.setContentView(view, params);
    }

    public final <I, O> k7 registerForActivityResult(i7 contract, h7 callback) {
        contract.getClass();
        callback.getClass();
        return registerForActivityResult(contract, this.activityResultRegistry, callback);
    }

    @Override // android.app.Activity
    @ko1
    public void onMultiWindowModeChanged(boolean isInMultiWindowMode) {
        if (this.dispatchingOnMultiWindowModeChanged) {
            return;
        }
        Iterator<qz0> it = this.onMultiWindowModeChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(new jb4(isInMultiWindowMode));
        }
    }

    @Override // android.app.Activity
    @ko1
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
        if (this.dispatchingOnPictureInPictureModeChanged) {
            return;
        }
        Iterator<qz0> it = this.onPictureInPictureModeChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(new pu4(isInPictureInPictureMode));
        }
    }

    @Override // defpackage.gw3
    public void addMenuProvider(yw3 provider) {
        provider.getClass();
        jw3 jw3Var = this.menuHostHelper;
        jw3Var.b.add(provider);
        jw3Var.f3587a.run();
    }

    public void addMenuProvider(final yw3 provider, ej3 owner, final ri3 state) {
        provider.getClass();
        owner.getClass();
        state.getClass();
        final jw3 jw3Var = this.menuHostHelper;
        jw3Var.getClass();
        si3 lifecycle = owner.getLifecycle();
        HashMap map = jw3Var.c;
        iw3 iw3Var = (iw3) map.remove(provider);
        if (iw3Var != null) {
            iw3Var.f3361a.c(iw3Var.b);
            iw3Var.b = null;
        }
        map.put(provider, new iw3(lifecycle, new bj3() { // from class: hw3
            @Override // defpackage.bj3
            public final void onStateChanged(ej3 ej3Var, qi3 qi3Var) {
                jw3 jw3Var2 = jw3Var;
                jw3Var2.getClass();
                Runnable runnable = jw3Var2.f3587a;
                CopyOnWriteArrayList copyOnWriteArrayList = jw3Var2.b;
                qi3.Companion.getClass();
                ri3 ri3Var = state;
                ri3Var.getClass();
                int iOrdinal = ri3Var.ordinal();
                qi3 qi3Var2 = iOrdinal != 2 ? iOrdinal != 3 ? iOrdinal != 4 ? null : qi3.ON_RESUME : qi3.ON_START : qi3.ON_CREATE;
                yw3 yw3Var = provider;
                if (qi3Var == qi3Var2) {
                    copyOnWriteArrayList.add(yw3Var);
                    runnable.run();
                } else if (qi3Var == qi3.ON_DESTROY) {
                    jw3Var2.b(yw3Var);
                } else if (qi3Var == oi3.a(ri3Var)) {
                    copyOnWriteArrayList.remove(yw3Var);
                    runnable.run();
                }
            }
        }));
    }
}

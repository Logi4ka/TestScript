package androidx.camera.camera2;

import defpackage.fi0;
import defpackage.gc4;
import defpackage.gi0;
import defpackage.in4;
import defpackage.of0;
import defpackage.pf0;
import defpackage.qf0;
import defpackage.sz;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class Camera2Config$DefaultProvider {
    public gi0 getCameraXConfig() {
        of0 of0Var = new of0();
        pf0 pf0Var = new pf0();
        qf0 qf0Var = new qf0();
        fi0 fi0Var = new fi0(0);
        sz szVar = gi0.b;
        gc4 gc4Var = fi0Var.b;
        gc4Var.o(szVar, of0Var);
        gc4Var.o(gi0.c, pf0Var);
        gc4Var.o(gi0.d, qf0Var);
        return new gi0(in4.e(gc4Var));
    }
}

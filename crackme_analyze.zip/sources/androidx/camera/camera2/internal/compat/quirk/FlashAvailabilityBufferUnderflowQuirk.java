package androidx.camera.camera2.internal.compat.quirk;

import android.util.Pair;
import defpackage.b85;
import java.util.HashSet;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class FlashAvailabilityBufferUnderflowQuirk implements b85 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final HashSet f196a;

    static {
        HashSet hashSet = new HashSet();
        f196a = hashSet;
        Locale locale = Locale.US;
        hashSet.add(new Pair("sprd".toLowerCase(locale), "lemp".toLowerCase(locale)));
        hashSet.add(new Pair("sprd".toLowerCase(locale), "DM20C".toLowerCase(locale)));
    }
}

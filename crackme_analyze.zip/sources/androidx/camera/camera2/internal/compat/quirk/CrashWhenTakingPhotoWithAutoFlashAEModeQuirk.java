package androidx.camera.camera2.internal.compat.quirk;

import defpackage.b85;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class CrashWhenTakingPhotoWithAutoFlashAEModeQuirk implements b85 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final List f193a = Arrays.asList("SM-A3000", "SM-A3009", "SM-A300F", "SM-A300FU", "SM-A300G", "SM-A300H", "SM-A300M", "SM-A300X", "SM-A300XU", "SM-A300XZ", "SM-A300Y", "SM-A300YZ", "SM-J510FN", "5059X");
}

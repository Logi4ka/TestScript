package androidx.camera.camera2.internal.compat.quirk;

import android.os.Build;
import defpackage.b85;
import defpackage.bc4;
import defpackage.fb6;
import defpackage.gb6;
import defpackage.y00;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ExtraSupportedSurfaceCombinationsQuirk implements b85 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final fb6 f195a;
    public static final fb6 b;
    public static final HashSet c;
    public static final HashSet d;

    static {
        fb6 fb6Var = new fb6();
        gb6 gb6Var = gb6.VGA;
        bc4.q(2, gb6Var, 0L, fb6Var);
        gb6 gb6Var2 = gb6.PREVIEW;
        bc4.q(1, gb6Var2, 0L, fb6Var);
        gb6 gb6Var3 = gb6.MAXIMUM;
        bc4.q(2, gb6Var3, 0L, fb6Var);
        f195a = fb6Var;
        fb6 fb6Var2 = new fb6();
        fb6Var2.a(new y00(1, gb6Var2, 0L));
        fb6Var2.a(new y00(1, gb6Var, 0L));
        bc4.q(2, gb6Var3, 0L, fb6Var2);
        b = fb6Var2;
        c = new HashSet(Arrays.asList("PIXEL 6", "PIXEL 6 PRO", "PIXEL 7", "PIXEL 7 PRO", "PIXEL 8", "PIXEL 8 PRO"));
        d = new HashSet(Arrays.asList("SM-S921", "SC-51E", "SCG25", "SM-S926", "SM-S928", "SC-52E", "SCG26"));
    }

    public static boolean b() {
        if (!"samsung".equalsIgnoreCase(Build.BRAND)) {
            return false;
        }
        String upperCase = Build.MODEL.toUpperCase(Locale.US);
        Iterator it = d.iterator();
        while (it.hasNext()) {
            if (upperCase.startsWith((String) it.next())) {
                return true;
            }
        }
        return false;
    }
}

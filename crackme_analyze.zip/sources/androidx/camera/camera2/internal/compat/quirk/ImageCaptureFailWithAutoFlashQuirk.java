package androidx.camera.camera2.internal.compat.quirk;

import defpackage.b85;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class ImageCaptureFailWithAutoFlashQuirk implements b85 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final List f198a = Arrays.asList("sm-j700f", "sm-j710f");
}

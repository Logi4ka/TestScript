package androidx.camera.core;

import android.graphics.Bitmap;
import android.media.Image;
import android.media.ImageWriter;
import android.util.Log;
import android.view.Surface;
import defpackage.ax2;
import defpackage.dv7;
import defpackage.my2;
import defpackage.oy2;
import defpackage.qy2;
import java.nio.ByteBuffer;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public abstract class ImageProcessingUtil {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int f213a;

    static {
        System.loadLibrary("image_processing_util_jni");
    }

    public static void a(oy2 oy2Var) {
        if (!d(oy2Var)) {
            dv7.G("ImageProcessingUtil", "Unsupported format for YUV to RGB");
            return;
        }
        int width = oy2Var.getWidth();
        int height = oy2Var.getHeight();
        int iB = oy2Var.k()[0].b();
        int iB2 = oy2Var.k()[1].b();
        int iB3 = oy2Var.k()[2].b();
        int iH = oy2Var.k()[0].h();
        int iH2 = oy2Var.k()[1].h();
        if (nativeShiftPixel(oy2Var.k()[0].getBuffer(), iB, oy2Var.k()[1].getBuffer(), iB2, oy2Var.k()[2].getBuffer(), iB3, iH, iH2, width, height, iH, iH2, iH2) != 0) {
            dv7.G("ImageProcessingUtil", "One pixel shift for YUV failure");
        }
    }

    public static ax2 b(oy2 oy2Var, qy2 qy2Var, ByteBuffer byteBuffer, int i, boolean z) {
        if (!d(oy2Var)) {
            dv7.G("ImageProcessingUtil", "Unsupported format for YUV to RGB");
            return null;
        }
        System.currentTimeMillis();
        if (i != 0 && i != 90 && i != 180 && i != 270) {
            dv7.G("ImageProcessingUtil", "Unsupported rotation degrees for rotate RGB");
            return null;
        }
        Surface surface = qy2Var.getSurface();
        int width = oy2Var.getWidth();
        int height = oy2Var.getHeight();
        int iB = oy2Var.k()[0].b();
        int iB2 = oy2Var.k()[1].b();
        int iB3 = oy2Var.k()[2].b();
        int iH = oy2Var.k()[0].h();
        int iH2 = oy2Var.k()[1].h();
        if (nativeConvertAndroid420ToABGR(oy2Var.k()[0].getBuffer(), iB, oy2Var.k()[1].getBuffer(), iB2, oy2Var.k()[2].getBuffer(), iB3, iH, iH2, surface, byteBuffer, width, height, z ? iH : 0, z ? iH2 : 0, z ? iH2 : 0, i) != 0) {
            dv7.G("ImageProcessingUtil", "YUV to RGB conversion failure");
            return null;
        }
        if (Log.isLoggable("MH", 3)) {
            Locale locale = Locale.US;
            System.currentTimeMillis();
            dv7.f0("ImageProcessingUtil");
            f213a++;
        }
        oy2 oy2VarAcquireLatestImage = qy2Var.acquireLatestImage();
        if (oy2VarAcquireLatestImage == null) {
            dv7.G("ImageProcessingUtil", "YUV to RGB acquireLatestImage failure");
            return null;
        }
        ax2 ax2Var = new ax2(oy2VarAcquireLatestImage);
        ax2Var.c(new my2(oy2VarAcquireLatestImage, oy2Var, 0));
        return ax2Var;
    }

    public static void c(Bitmap bitmap, ByteBuffer byteBuffer, int i) {
        nativeCopyBetweenByteBufferAndBitmap(bitmap, byteBuffer, i, bitmap.getRowBytes(), bitmap.getWidth(), bitmap.getHeight(), true);
    }

    public static boolean d(oy2 oy2Var) {
        return oy2Var.getFormat() == 35 && oy2Var.k().length == 3;
    }

    public static ax2 e(oy2 oy2Var, qy2 qy2Var, ImageWriter imageWriter, ByteBuffer byteBuffer, ByteBuffer byteBuffer2, ByteBuffer byteBuffer3, int i) {
        String str;
        if (!d(oy2Var)) {
            dv7.G("ImageProcessingUtil", "Unsupported format for rotate YUV");
            return null;
        }
        if (i != 0 && i != 90 && i != 180 && i != 270) {
            dv7.G("ImageProcessingUtil", "Unsupported rotation degrees for rotate YUV");
            return null;
        }
        if (i > 0) {
            int width = oy2Var.getWidth();
            int height = oy2Var.getHeight();
            int iB = oy2Var.k()[0].b();
            int iB2 = oy2Var.k()[1].b();
            int iB3 = oy2Var.k()[2].b();
            int iH = oy2Var.k()[1].h();
            Image imageDequeueInputImage = imageWriter.dequeueInputImage();
            if (imageDequeueInputImage != null && nativeRotateYUV(oy2Var.k()[0].getBuffer(), iB, oy2Var.k()[1].getBuffer(), iB2, oy2Var.k()[2].getBuffer(), iB3, iH, imageDequeueInputImage.getPlanes()[0].getBuffer(), imageDequeueInputImage.getPlanes()[0].getRowStride(), imageDequeueInputImage.getPlanes()[0].getPixelStride(), imageDequeueInputImage.getPlanes()[1].getBuffer(), imageDequeueInputImage.getPlanes()[1].getRowStride(), imageDequeueInputImage.getPlanes()[1].getPixelStride(), imageDequeueInputImage.getPlanes()[2].getBuffer(), imageDequeueInputImage.getPlanes()[2].getRowStride(), imageDequeueInputImage.getPlanes()[2].getPixelStride(), byteBuffer, byteBuffer2, byteBuffer3, width, height, i) == 0) {
                imageWriter.queueInputImage(imageDequeueInputImage);
                oy2 oy2VarAcquireLatestImage = qy2Var.acquireLatestImage();
                if (oy2VarAcquireLatestImage == null) {
                    dv7.G("ImageProcessingUtil", "YUV rotation acquireLatestImage failure");
                    return null;
                }
                ax2 ax2Var = new ax2(oy2VarAcquireLatestImage);
                ax2Var.c(new my2(oy2VarAcquireLatestImage, oy2Var, 1));
                return ax2Var;
            }
            str = "ImageProcessingUtil";
        } else {
            str = "ImageProcessingUtil";
        }
        dv7.G(str, "rotate YUV failure");
        return null;
    }

    public static void f(byte[] bArr, Surface surface) {
        surface.getClass();
        if (nativeWriteJpegToSurface(bArr, surface) != 0) {
            dv7.G("ImageProcessingUtil", "Failed to enqueue JPEG image.");
        }
    }

    private static native int nativeConvertAndroid420ToABGR(ByteBuffer byteBuffer, int i, ByteBuffer byteBuffer2, int i2, ByteBuffer byteBuffer3, int i3, int i4, int i5, Surface surface, ByteBuffer byteBuffer4, int i6, int i7, int i8, int i9, int i10, int i11);

    private static native int nativeCopyBetweenByteBufferAndBitmap(Bitmap bitmap, ByteBuffer byteBuffer, int i, int i2, int i3, int i4, boolean z);

    private static native int nativeRotateYUV(ByteBuffer byteBuffer, int i, ByteBuffer byteBuffer2, int i2, ByteBuffer byteBuffer3, int i3, int i4, ByteBuffer byteBuffer4, int i5, int i6, ByteBuffer byteBuffer5, int i7, int i8, ByteBuffer byteBuffer6, int i9, int i10, ByteBuffer byteBuffer7, ByteBuffer byteBuffer8, ByteBuffer byteBuffer9, int i11, int i12, int i13);

    private static native int nativeShiftPixel(ByteBuffer byteBuffer, int i, ByteBuffer byteBuffer2, int i2, ByteBuffer byteBuffer3, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10);

    private static native int nativeWriteJpegToSurface(byte[] bArr, Surface surface);
}

package androidx.camera.core.internal.compat.quirk;

import defpackage.b85;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class SurfaceOrderQuirk implements b85 {
}

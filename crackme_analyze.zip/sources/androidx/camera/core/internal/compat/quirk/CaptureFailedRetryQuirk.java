package androidx.camera.core.internal.compat.quirk;

import android.util.Pair;
import defpackage.b85;
import java.util.Collections;
import java.util.HashSet;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public class CaptureFailedRetryQuirk implements b85 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final HashSet f214a = new HashSet(Collections.singletonList(Pair.create("SAMSUNG", "SM-G981U1")));
}

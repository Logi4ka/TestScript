package androidx.credentials.play.services.auth;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static int Theme_Hidden = 2131886686;

    private R$style() {
    }
}

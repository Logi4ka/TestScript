package androidx.credentials.playservices;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import androidx.credentials.playservices.HiddenActivity;
import com.google.android.gms.auth.api.identity.BeginSignInRequest;
import com.google.android.gms.auth.api.identity.GetSignInIntentRequest;
import com.google.android.gms.auth.api.identity.SavePasswordRequest;
import com.google.android.gms.fido.fido2.api.common.PublicKeyCredentialCreationOptions;
import com.google.android.gms.internal.p000authapi.zbaf;
import com.google.android.gms.internal.p000authapi.zbap;
import com.google.android.gms.tasks.OnFailureListener;
import defpackage.bf1;
import defpackage.cg6;
import defpackage.df1;
import defpackage.dg6;
import defpackage.hs7;
import defpackage.io;
import defpackage.j72;
import defpackage.k72;
import defpackage.mb;
import defpackage.ms7;
import defpackage.mu2;
import defpackage.pa0;
import defpackage.z95;
import io.sentry.android.core.o0;
import java.util.Set;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0017\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Landroidx/credentials/playservices/HiddenActivity;", "Landroid/app/Activity;", "<init>", "()V", "credentials-play-services-auth_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public class HiddenActivity extends Activity {
    public static final /* synthetic */ int c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ResultReceiver f327a;
    public boolean b;

    public final void a(ResultReceiver resultReceiver, String str, String str2) {
        Set set = df1.f1711a;
        bf1.c(resultReceiver, str, str2);
        finish();
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        ResultReceiver resultReceiver = this.f327a;
        if (resultReceiver != null) {
            Set set = df1.f1711a;
            Bundle bundle = new Bundle();
            bundle.putBoolean("FAILURE_RESPONSE", false);
            bundle.putInt("ACTIVITY_REQUEST_CODE", i);
            bundle.putParcelable("RESULT_DATA", intent);
            resultReceiver.send(i2, bundle);
        }
        this.b = false;
        finish();
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        overridePendingTransition(0, 0);
        String stringExtra = getIntent().getStringExtra("TYPE");
        ResultReceiver resultReceiver = (ResultReceiver) getIntent().getParcelableExtra("RESULT_RECEIVER");
        this.f327a = resultReceiver;
        if (resultReceiver == null) {
            finish();
        }
        if (bundle != null) {
            this.b = bundle.getBoolean("androidx.credentials.playservices.AWAITING_RESULT", false);
        }
        if (this.b) {
            return;
        }
        if (stringExtra != null) {
            final int i2 = 2;
            final int i3 = 3;
            final int i4 = 1;
            switch (stringExtra.hashCode()) {
                case -441061071:
                    if (stringExtra.equals("BEGIN_SIGN_IN")) {
                        BeginSignInRequest beginSignInRequest = (BeginSignInRequest) getIntent().getParcelableExtra("REQUEST_TYPE");
                        if ((beginSignInRequest != null ? new zbap((Activity) this, new ms7()).beginSignIn(beginSignInRequest).addOnSuccessListener(new mb(new mu2(getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), this, 0), 10)).addOnFailureListener(new OnFailureListener(this) { // from class: lu2
                            public final /* synthetic */ HiddenActivity b;

                            {
                                this.b = this;
                            }

                            @Override // com.google.android.gms.tasks.OnFailureListener
                            public final void onFailure(Exception exc) {
                                String str;
                                String str2;
                                int i5 = i3;
                                HiddenActivity hiddenActivity = this.b;
                                switch (i5) {
                                    case 0:
                                        int i6 = HiddenActivity.c;
                                        exc.getClass();
                                        str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                        ResultReceiver resultReceiver2 = hiddenActivity.f327a;
                                        resultReceiver2.getClass();
                                        hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                        break;
                                    case 1:
                                        int i7 = HiddenActivity.c;
                                        exc.getClass();
                                        str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                        ResultReceiver resultReceiver3 = hiddenActivity.f327a;
                                        resultReceiver3.getClass();
                                        hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                        break;
                                    case 2:
                                        int i8 = HiddenActivity.c;
                                        exc.getClass();
                                        str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                        ResultReceiver resultReceiver4 = hiddenActivity.f327a;
                                        resultReceiver4.getClass();
                                        hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                        break;
                                    default:
                                        int i9 = HiddenActivity.c;
                                        exc.getClass();
                                        str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                        ResultReceiver resultReceiver5 = hiddenActivity.f327a;
                                        resultReceiver5.getClass();
                                        hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                        break;
                                }
                            }
                        }) : null) == null) {
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
                case 15545322:
                    if (stringExtra.equals("CREATE_PUBLIC_KEY_CREDENTIAL")) {
                        PublicKeyCredentialCreationOptions publicKeyCredentialCreationOptions = (PublicKeyCredentialCreationOptions) getIntent().getParcelableExtra("REQUEST_TYPE");
                        int intExtra = getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1);
                        if (publicKeyCredentialCreationOptions != null) {
                            int i5 = k72.f3656a;
                            j72 j72Var = new j72(this, j72.f3434a, io.g, new pa0(22));
                            cg6 cg6VarBuilder = dg6.builder();
                            cg6VarBuilder.f808a = new z95(j72Var, publicKeyCredentialCreationOptions);
                            cg6VarBuilder.d = 5407;
                            taskAddOnFailureListener = j72Var.doRead(cg6VarBuilder.a()).addOnSuccessListener(new mb(new mu2(intExtra, this, 2), 7)).addOnFailureListener(new OnFailureListener(this) { // from class: lu2
                                public final /* synthetic */ HiddenActivity b;

                                {
                                    this.b = this;
                                }

                                @Override // com.google.android.gms.tasks.OnFailureListener
                                public final void onFailure(Exception exc) {
                                    String str;
                                    String str2;
                                    int i52 = i;
                                    HiddenActivity hiddenActivity = this.b;
                                    switch (i52) {
                                        case 0:
                                            int i6 = HiddenActivity.c;
                                            exc.getClass();
                                            str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                            ResultReceiver resultReceiver2 = hiddenActivity.f327a;
                                            resultReceiver2.getClass();
                                            hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                            break;
                                        case 1:
                                            int i7 = HiddenActivity.c;
                                            exc.getClass();
                                            str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                            ResultReceiver resultReceiver3 = hiddenActivity.f327a;
                                            resultReceiver3.getClass();
                                            hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                            break;
                                        case 2:
                                            int i8 = HiddenActivity.c;
                                            exc.getClass();
                                            str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                            ResultReceiver resultReceiver4 = hiddenActivity.f327a;
                                            resultReceiver4.getClass();
                                            hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                            break;
                                        default:
                                            int i9 = HiddenActivity.c;
                                            exc.getClass();
                                            str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                            ResultReceiver resultReceiver5 = hiddenActivity.f327a;
                                            resultReceiver5.getClass();
                                            hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                            break;
                                    }
                                }
                            });
                        }
                        if (taskAddOnFailureListener == null) {
                            o0.q("HiddenActivity", "During create public key credential, request is null, so nothing to launch for public key credentials");
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
                case 1246634622:
                    if (stringExtra.equals("CREATE_PASSWORD")) {
                        SavePasswordRequest savePasswordRequest = (SavePasswordRequest) getIntent().getParcelableExtra("REQUEST_TYPE");
                        if ((savePasswordRequest != null ? new zbaf((Activity) this, new hs7()).savePassword(savePasswordRequest).addOnSuccessListener(new mb(new mu2(getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), this, 1), 8)).addOnFailureListener(new OnFailureListener(this) { // from class: lu2
                            public final /* synthetic */ HiddenActivity b;

                            {
                                this.b = this;
                            }

                            @Override // com.google.android.gms.tasks.OnFailureListener
                            public final void onFailure(Exception exc) {
                                String str;
                                String str2;
                                int i52 = i4;
                                HiddenActivity hiddenActivity = this.b;
                                switch (i52) {
                                    case 0:
                                        int i6 = HiddenActivity.c;
                                        exc.getClass();
                                        str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                        ResultReceiver resultReceiver2 = hiddenActivity.f327a;
                                        resultReceiver2.getClass();
                                        hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                        break;
                                    case 1:
                                        int i7 = HiddenActivity.c;
                                        exc.getClass();
                                        str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                        ResultReceiver resultReceiver3 = hiddenActivity.f327a;
                                        resultReceiver3.getClass();
                                        hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                        break;
                                    case 2:
                                        int i8 = HiddenActivity.c;
                                        exc.getClass();
                                        str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                        ResultReceiver resultReceiver4 = hiddenActivity.f327a;
                                        resultReceiver4.getClass();
                                        hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                        break;
                                    default:
                                        int i9 = HiddenActivity.c;
                                        exc.getClass();
                                        str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                        ResultReceiver resultReceiver5 = hiddenActivity.f327a;
                                        resultReceiver5.getClass();
                                        hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                        break;
                                }
                            }
                        }) : null) == null) {
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
                case 1980564212:
                    if (stringExtra.equals("SIGN_IN_INTENT")) {
                        GetSignInIntentRequest getSignInIntentRequest = (GetSignInIntentRequest) getIntent().getParcelableExtra("REQUEST_TYPE");
                        if ((getSignInIntentRequest != null ? new zbap((Activity) this, new ms7()).getSignInIntent(getSignInIntentRequest).addOnSuccessListener(new mb(new mu2(getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), this, 3), 9)).addOnFailureListener(new OnFailureListener(this) { // from class: lu2
                            public final /* synthetic */ HiddenActivity b;

                            {
                                this.b = this;
                            }

                            @Override // com.google.android.gms.tasks.OnFailureListener
                            public final void onFailure(Exception exc) {
                                String str;
                                String str2;
                                int i52 = i2;
                                HiddenActivity hiddenActivity = this.b;
                                switch (i52) {
                                    case 0:
                                        int i6 = HiddenActivity.c;
                                        exc.getClass();
                                        str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                        ResultReceiver resultReceiver2 = hiddenActivity.f327a;
                                        resultReceiver2.getClass();
                                        hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                        break;
                                    case 1:
                                        int i7 = HiddenActivity.c;
                                        exc.getClass();
                                        str = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "CREATE_INTERRUPTED" : "CREATE_UNKNOWN";
                                        ResultReceiver resultReceiver3 = hiddenActivity.f327a;
                                        resultReceiver3.getClass();
                                        hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                        break;
                                    case 2:
                                        int i8 = HiddenActivity.c;
                                        exc.getClass();
                                        str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                        ResultReceiver resultReceiver4 = hiddenActivity.f327a;
                                        resultReceiver4.getClass();
                                        hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                        break;
                                    default:
                                        int i9 = HiddenActivity.c;
                                        exc.getClass();
                                        str2 = ((exc instanceof wo) && df1.f1711a.contains(Integer.valueOf(((wo) exc).getStatusCode()))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                                        ResultReceiver resultReceiver5 = hiddenActivity.f327a;
                                        resultReceiver5.getClass();
                                        hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                        break;
                                }
                            }
                        }) : null) == null) {
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
            }
        }
        o0.q("HiddenActivity", "Activity handed an unsupported type");
        finish();
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        bundle.putBoolean("androidx.credentials.playservices.AWAITING_RESULT", this.b);
        super.onSaveInstanceState(bundle);
    }
}

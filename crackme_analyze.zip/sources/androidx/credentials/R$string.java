package androidx.credentials;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static int android_credentials_TYPE_PASSWORD_CREDENTIAL = 2131820579;
    public static int androidx_credentials_TYPE_PUBLIC_KEY_CREDENTIAL = 2131820580;

    private R$string() {
    }
}

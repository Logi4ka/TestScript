package androidx.credentials;

/* JADX INFO: loaded from: classes.dex */
public final class R$drawable {
    public static int ic_other_sign_in = 2131230920;
    public static int ic_passkey = 2131230921;
    public static int ic_password = 2131230922;

    private R$drawable() {
    }
}

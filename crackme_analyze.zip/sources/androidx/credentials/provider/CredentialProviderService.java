package androidx.credentials.provider;

import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.OutcomeReceiver;
import android.service.credentials.BeginCreateCredentialRequest;
import android.service.credentials.BeginGetCredentialOption;
import android.service.credentials.BeginGetCredentialRequest;
import android.service.credentials.CallingAppInfo;
import android.service.credentials.ClearCredentialStateRequest;
import defpackage.a50;
import defpackage.bj;
import defpackage.g;
import defpackage.rz1;
import defpackage.tu;
import defpackage.u06;
import defpackage.wz1;
import defpackage.zj2;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Landroidx/credentials/provider/CredentialProviderService;", "Landroid/service/credentials/CredentialProviderService;", "credentials_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class CredentialProviderService extends android.service.credentials.CredentialProviderService {
    public abstract void a();

    public abstract void b();

    public abstract void c();

    public final void onBeginCreateCredential(BeginCreateCredentialRequest beginCreateCredentialRequest, CancellationSignal cancellationSignal, OutcomeReceiver outcomeReceiver) {
        Collection publicKeys;
        beginCreateCredentialRequest.getClass();
        cancellationSignal.getClass();
        outcomeReceiver.getClass();
        String type = beginCreateCredentialRequest.getType();
        type.getClass();
        Bundle data = beginCreateCredentialRequest.getData();
        data.getClass();
        CallingAppInfo callingAppInfo = beginCreateCredentialRequest.getCallingAppInfo();
        if (callingAppInfo != null) {
            String packageName = callingAppInfo.getPackageName();
            packageName.getClass();
            SigningInfo signingInfo = callingAppInfo.getSigningInfo();
            signingInfo.getClass();
            callingAppInfo.getOrigin();
            Signature[] apkContentsSigners = signingInfo.getApkContentsSigners();
            List listO = apkContentsSigners != null ? tu.o(apkContentsSigners) : rz1.f5334a;
            int i = Build.VERSION.SDK_INT;
            if (i < 35 || (publicKeys = signingInfo.getPublicKeys()) == null) {
                publicKeys = wz1.f6404a;
            }
            Collection collection = publicKeys;
            int schemeVersion = i >= 35 ? signingInfo.getSchemeVersion() : 0;
            Signature[] signingCertificateHistory = signingInfo.getSigningCertificateHistory();
            new u06(signingCertificateHistory != null ? tu.o(signingCertificateHistory) : rz1.f5334a, listO, collection, schemeVersion, signingInfo.hasPastSigningCertificates(), signingInfo.hasMultipleSigners());
            if (packageName.length() <= 0) {
                g.l("packageName must not be empty");
                return;
            }
        }
        try {
            if (!type.equals("android.credentials.TYPE_PASSWORD_CREDENTIAL")) {
                if (type.equals("androidx.credentials.TYPE_PUBLIC_KEY_CREDENTIAL")) {
                    try {
                        String string = data.getString("androidx.credentials.BUNDLE_KEY_REQUEST_JSON");
                        data.getByteArray("androidx.credentials.BUNDLE_KEY_CLIENT_DATA_HASH");
                        string.getClass();
                        if (string.length() != 0) {
                            try {
                                new JSONObject(string);
                                data.putString("androidx.credentials.BUNDLE_KEY_REQUEST_JSON", string);
                            } catch (Exception unused) {
                            }
                        }
                        throw new IllegalArgumentException("requestJson must not be empty, and must be a valid JSON");
                    } catch (Exception unused2) {
                        throw new zj2();
                    }
                }
                if (type.length() <= 0) {
                    throw new IllegalArgumentException("type should not be empty");
                }
            }
        } catch (zj2 unused3) {
            if (type.length() <= 0) {
                g.l("type should not be empty");
                return;
            }
        }
        a();
    }

    public final void onBeginGetCredential(BeginGetCredentialRequest beginGetCredentialRequest, CancellationSignal cancellationSignal, OutcomeReceiver outcomeReceiver) throws zj2 {
        Collection publicKeys;
        a50 a50Var;
        a50 a50Var2;
        Object objV;
        beginGetCredentialRequest.getClass();
        cancellationSignal.getClass();
        outcomeReceiver.getClass();
        ArrayList arrayList = new ArrayList();
        List beginGetCredentialOptions = beginGetCredentialRequest.getBeginGetCredentialOptions();
        beginGetCredentialOptions.getClass();
        Iterator it = beginGetCredentialOptions.iterator();
        while (it.hasNext()) {
            BeginGetCredentialOption beginGetCredentialOptionJ = bj.j(it.next());
            String id = beginGetCredentialOptionJ.getId();
            id.getClass();
            String type = beginGetCredentialOptionJ.getType();
            type.getClass();
            Bundle candidateQueryData = beginGetCredentialOptionJ.getCandidateQueryData();
            candidateQueryData.getClass();
            if (type.equals("android.credentials.TYPE_PASSWORD_CREDENTIAL")) {
                ArrayList<String> stringArrayList = candidateQueryData.getStringArrayList("androidx.credentials.BUNDLE_KEY_ALLOWED_USER_IDS");
                if (stringArrayList == null || (objV = CollectionsKt.V(stringArrayList)) == null) {
                    objV = wz1.f6404a;
                }
                objV.getClass();
                a50Var2 = new a50();
            } else {
                if (type.equals("androidx.credentials.TYPE_PUBLIC_KEY_CREDENTIAL")) {
                    try {
                        String string = candidateQueryData.getString("androidx.credentials.BUNDLE_KEY_REQUEST_JSON");
                        candidateQueryData.getByteArray("androidx.credentials.BUNDLE_KEY_CLIENT_DATA_HASH");
                        string.getClass();
                        a50Var = new a50();
                        if (string.length() != 0) {
                            try {
                                new JSONObject(string);
                            } catch (Exception unused) {
                            }
                        }
                        throw new IllegalArgumentException("requestJson must not be empty, and must be a valid JSON");
                    } catch (Exception unused2) {
                        throw new zj2();
                    }
                }
                a50Var = new a50();
                if (id.length() <= 0) {
                    g.l("id should not be empty");
                    return;
                } else if (type.length() <= 0) {
                    g.l("type should not be empty");
                    return;
                }
                a50Var2 = a50Var;
            }
            arrayList.add(a50Var2);
        }
        CallingAppInfo callingAppInfo = beginGetCredentialRequest.getCallingAppInfo();
        if (callingAppInfo != null) {
            String packageName = callingAppInfo.getPackageName();
            packageName.getClass();
            SigningInfo signingInfo = callingAppInfo.getSigningInfo();
            signingInfo.getClass();
            callingAppInfo.getOrigin();
            Signature[] apkContentsSigners = signingInfo.getApkContentsSigners();
            List listO = apkContentsSigners != null ? tu.o(apkContentsSigners) : rz1.f5334a;
            int i = Build.VERSION.SDK_INT;
            if (i < 35 || (publicKeys = signingInfo.getPublicKeys()) == null) {
                publicKeys = wz1.f6404a;
            }
            Collection collection = publicKeys;
            int schemeVersion = i >= 35 ? signingInfo.getSchemeVersion() : 0;
            Signature[] signingCertificateHistory = signingInfo.getSigningCertificateHistory();
            new u06(signingCertificateHistory != null ? tu.o(signingCertificateHistory) : rz1.f5334a, listO, collection, schemeVersion, signingInfo.hasPastSigningCertificates(), signingInfo.hasMultipleSigners());
            if (packageName.length() <= 0) {
                g.l("packageName must not be empty");
                return;
            }
        }
        b();
    }

    public final void onClearCredentialState(ClearCredentialStateRequest clearCredentialStateRequest, CancellationSignal cancellationSignal, OutcomeReceiver outcomeReceiver) {
        Object publicKeys;
        clearCredentialStateRequest.getClass();
        cancellationSignal.getClass();
        outcomeReceiver.getClass();
        String packageName = clearCredentialStateRequest.getCallingAppInfo().getPackageName();
        packageName.getClass();
        SigningInfo signingInfo = clearCredentialStateRequest.getCallingAppInfo().getSigningInfo();
        signingInfo.getClass();
        clearCredentialStateRequest.getCallingAppInfo().getOrigin();
        Signature[] apkContentsSigners = signingInfo.getApkContentsSigners();
        Object objO = apkContentsSigners != null ? tu.o(apkContentsSigners) : rz1.f5334a;
        int i = Build.VERSION.SDK_INT;
        if (i < 35 || (publicKeys = signingInfo.getPublicKeys()) == null) {
            publicKeys = wz1.f6404a;
        }
        if (i >= 35) {
            signingInfo.getSchemeVersion();
        }
        Signature[] signingCertificateHistory = signingInfo.getSigningCertificateHistory();
        Object objO2 = signingCertificateHistory != null ? tu.o(signingCertificateHistory) : rz1.f5334a;
        signingInfo.hasPastSigningCertificates();
        signingInfo.hasMultipleSigners();
        objO2.getClass();
        objO.getClass();
        publicKeys.getClass();
        if (packageName.length() > 0) {
            c();
        } else {
            g.l("packageName must not be empty");
        }
    }
}

package androidx.credentials;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static int androidx_credential_pendingCredentialRequest = 2131296346;

    private R$id() {
    }
}

package androidx.coordinatorlayout;

/* JADX INFO: loaded from: classes.dex */
public final class R$integer {
    public static int status_bar_notification_info_maxnum = 2131361863;

    private R$integer() {
    }
}

package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static int cardBackgroundColor = 2130968749;
    public static int cardCornerRadius = 2130968750;
    public static int cardElevation = 2130968751;
    public static int cardMaxElevation = 2130968753;
    public static int cardPreventCornerOverlap = 2130968754;
    public static int cardUseCompatPadding = 2130968755;
    public static int cardViewStyle = 2130968756;
    public static int contentPadding = 2130968922;
    public static int contentPaddingBottom = 2130968923;
    public static int contentPaddingLeft = 2130968925;
    public static int contentPaddingRight = 2130968926;
    public static int contentPaddingTop = 2130968928;

    private R$attr() {
    }
}

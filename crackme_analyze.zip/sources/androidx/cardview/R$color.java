package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static int cardview_dark_background = 2131099697;
    public static int cardview_light_background = 2131099698;
    public static int cardview_shadow_end_color = 2131099699;
    public static int cardview_shadow_start_color = 2131099700;

    private R$color() {
    }
}

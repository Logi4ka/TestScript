package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static int Base_CardView = 2131886097;
    public static int CardView = 2131886371;
    public static int CardView_Dark = 2131886372;
    public static int CardView_Light = 2131886373;

    private R$style() {
    }
}

package androidx.cardview;

import android.R;

/* JADX INFO: loaded from: classes.dex */
public final class R$styleable {
    public static int[] CardView = {R.attr.minWidth, R.attr.minHeight, com.supercell.brawlstars.R.attr.cardBackgroundColor, com.supercell.brawlstars.R.attr.cardCornerRadius, com.supercell.brawlstars.R.attr.cardElevation, com.supercell.brawlstars.R.attr.cardMaxElevation, com.supercell.brawlstars.R.attr.cardPreventCornerOverlap, com.supercell.brawlstars.R.attr.cardUseCompatPadding, com.supercell.brawlstars.R.attr.contentPadding, com.supercell.brawlstars.R.attr.contentPaddingBottom, com.supercell.brawlstars.R.attr.contentPaddingLeft, com.supercell.brawlstars.R.attr.contentPaddingRight, com.supercell.brawlstars.R.attr.contentPaddingTop};
    public static int CardView_android_minHeight = 1;
    public static int CardView_android_minWidth = 0;
    public static int CardView_cardBackgroundColor = 2;
    public static int CardView_cardCornerRadius = 3;
    public static int CardView_cardElevation = 4;
    public static int CardView_cardMaxElevation = 5;
    public static int CardView_cardPreventCornerOverlap = 6;
    public static int CardView_cardUseCompatPadding = 7;
    public static int CardView_contentPadding = 8;
    public static int CardView_contentPaddingBottom = 9;
    public static int CardView_contentPaddingLeft = 10;
    public static int CardView_contentPaddingRight = 11;
    public static int CardView_contentPaddingTop = 12;

    private R$styleable() {
    }
}

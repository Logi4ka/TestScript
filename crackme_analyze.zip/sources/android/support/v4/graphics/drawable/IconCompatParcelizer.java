package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import defpackage.tb7;

/* JADX INFO: compiled from: r8-map-id-e7ef173fcdbe9b5a93c401edf9ae8dfb63d3eeb2b04fca9ca9bf2b563883e163 */
/* JADX INFO: loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(tb7 tb7Var) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(tb7Var);
    }

    public static void write(IconCompat iconCompat, tb7 tb7Var) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, tb7Var);
    }
}

package android.app;

import nv.A;

/* JADX INFO: loaded from: classes.dex */
public /* synthetic */ class AppComponentFactory {
    static {
        A.b();
        throw new NoClassDefFoundError();
    }
}

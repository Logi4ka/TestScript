#!/usr/bin/env node
'use strict';
const { parseConfig, help } = require('./src/config');
const { Logger } = require('./src/logging');
const { Client } = require('./src/client');

async function main(args = process.argv.slice(2)) {
    if (args.includes('--help') || args.includes('-h')) {
        process.stdout.write(help() + '\n');
        return 0;
    }
    let logger = new Logger();
    let interrupt;
    try {
        const config = parseConfig(args);
        logger = new Logger(config);
        logger.start();
        const client = new Client(config, logger);
        interrupt = () => client.interrupt();
        process.once('SIGINT', interrupt);
        process.once('SIGTERM', interrupt);
        return (await client.run()).exitCode;
    } catch (error) {
        logger.info('crackme::onError', error.message, 'error');
        return 1;
    } finally {
        if (interrupt) {
            process.removeListener('SIGINT', interrupt);
            process.removeListener('SIGTERM', interrupt);
        }
    }
}

module.exports = { main };

if (require.main === module) {
    main().then(code => { process.exitCode = code; }, error => {
        process.stderr.write(`crackme::onError: ${error.message}\n`);
        process.exitCode = 1;
    });
}

'use strict';
const net = require('node:net');
const { PepperSession } = require('./crypto');
const { FrameDecoder, encodeFrame } = require('./protocol/protocol');
const { TYPES, messageName, encodeMessage, decodeMessage } = require('./protocol/messages');
const { socks5Connect } = require('./socks');

class Client {
    constructor(config, logger) {
        this.config = config;
        this.logger = logger;
        this.pepper = config.noCrypto ? null : new PepperSession(config.spk);
        this.decoder = new FrameDecoder();
        this.state = 'created';
        this.result = { exitCode: 2, outcome: 'incomplete', sent: 0, received: 0 };
        this.stopping = false;
        this.socket = null;
        this.receiveQueue = Promise.resolve();
    }

    status(scope, message, level = 'info', verboseOnly = false) {
        if (!verboseOnly || this.config.verbose) this.logger.info(scope, message, level);
    }

    run() {
        if (this.state !== 'created') throw new Error('A client session can only be run once');
        const { host, port, timeoutMs, noCrypto, proxyHost, proxyPort } = this.config;
        this.state = 'connecting';
        const dialHost = proxyHost ?? host, dialPort = proxyHost ? proxyPort : port;
        this.status('Messaging::connect', proxyHost
            ? `connecting to SOCKS5 proxy ${dialHost}:${dialPort} (target ${host}:${port})`
            : `connecting to ${host}:${port}`, 'info', true);
        if (noCrypto) this.status('Messaging::crypto', '--no-crypto: encryption and attestation disabled');
        return new Promise(resolve => {
            this.socket = net.createConnection({ host: dialHost, port: dialPort });
            this.connectTimer = setTimeout(() => {
                this.result.outcome = 'connect-timeout';
                this.status('Messaging::onTimeout', `connection timed out after ${timeoutMs} ms`, 'warn');
                this.stop();
            }, timeoutMs);
            this.socket.on('connect', async () => {
                clearTimeout(this.connectTimer);
                this.socket.setTimeout(timeoutMs);
                this.socket.setNoDelay(true);
                try {
                    let leftover = Buffer.alloc(0);
                    if (proxyHost) {
                        this.status('Messaging::proxy', `proxy connected; requesting tunnel to ${host}:${port}`, 'info', true);
                        leftover = await socks5Connect(this.socket, host, port, timeoutMs);
                        this.status('Messaging::proxy', `tunnel to ${host}:${port} established`, 'info', true);
                    }
                    this.state = 'awaiting-server-hello';
                    this.status('Messaging::onConnect', `connected to ${host}:${port}`);
                    this.socket.on('data', chunk => this.onData(chunk));
                    if (leftover.length) this.onData(leftover);
                    this.send(TYPES.CLIENT_HELLO);
                } catch (error) { this.fail(error); }
            });
            this.socket.on('timeout', () => {
                const reason = this.state === 'preparing-login' ? 'session response was not prepared'
                    : this.state === 'awaiting-login' ? 'no reply to Login'
                    : this.state === 'awaiting-server-hello' ? 'no ServerHello' : 'no further packets';
                this.result.outcome = 'login-timeout';
                this.status('Messaging::onTimeout', `idle for ${timeoutMs} ms (${reason}); closing`, 'warn');
                this.stop();
            });
            this.socket.on('error', error => this.fail(error));
            this.socket.on('close', () => {
                clearTimeout(this.connectTimer);
                this.stopping = true;
                this.state = 'closed';
                if (this.result.outcome === 'incomplete') this.result.outcome = 'server-closed-before-login';
                this.status('Messaging::onClose',
                    `connection closed; ${this.result.outcome}; TX ${this.result.sent}, RX ${this.result.received}`);
                resolve({ ...this.result });
            });
        });
    }

    onData(chunk) {
        try {
            const frames = this.decoder.push(chunk);
            this.receiveQueue = this.receiveQueue.then(async () => {
                for (const frame of frames) {
                    if (this.stopping) break;
                    await this.receive(frame);
                }
            }).catch(error => this.fail(error));
        } catch (error) { this.fail(error); }
    }

    send(id, config = this.config) {
        const { payload, fields, version } = encodeMessage(id, config);
        this.sendMessage(id, payload, fields, version);
    }

    sendMessage(id, payload, fields = null, version = 0) {
        if (!this.socket || this.stopping || this.socket.destroyed) throw new Error('Connection is closed');
        const wire = this.pepper ? this.pepper.seal(id, payload) : Buffer.from(payload);
        this.socket.write(encodeFrame(id, wire, version));
        this.result.sent++;
        this.logger.packet('TX', messageName(id), id, fields);
    }

    async receive({ id, version, payload: wire }) {
        let plain, fields;
        try {
            plain = this.pepper?.loginSent ? this.pepper.open(wire) : wire;
            fields = decodeMessage(id, plain);
        } catch (error) { return this.fail(error); }
        this.result.received++;
        this.logger.packet('RX', messageName(id), id, fields);
        if (fields.parseError) {
            this.status('MessageManager::decode', `${messageName(id)}: ${fields.parseError}`, 'warn');
            if (id === TYPES.SERVER_HELLO || id === TYPES.LOGIN_OK)
                return this.fail(new Error(`Cannot process ${messageName(id)}: invalid payload`));
        }
        switch (id) {
            case TYPES.SERVER_HELLO:
                if (this.state !== 'awaiting-server-hello') throw new Error('Unexpected ServerHello');
                await this.prepareLogin(Buffer.from(fields.tokenHex, 'hex'));
                break;
            case TYPES.LOGIN_FAILED:
                this.state = 'rejected';
                this.result.exitCode = 3;
                this.result.outcome = 'login-failed';
                this.status('MessageManager::onLoginFailedReceived',
                    `login rejected with error ${fields.errorCode ?? '?'}`, 'error');
                for (const name of ['redirect', 'updateUrl', 'message'])
                    if (fields[name]) this.status('LoginFailedMessage::details', `${name}: ${JSON.stringify(fields[name])}`);
                this.stop();
                break;
            case TYPES.LOGIN_OK:
                if (this.state !== 'awaiting-login' || (this.pepper && !this.pepper.serverNonce))
                    throw new Error('Unexpected LoginOk before a Login exchange');
                this.state = 'authenticated';
                this.result.exitCode = 0;
                this.result.outcome = 'login-ok';
                this.status('MessageManager::onLoginOkReceived',
                    `logged in as (${fields.accountId.join('-')}) ${fields.loginToken ?? 'null'}`);
                if (fields.serverEnvironment != null)
                    this.status('MessageManager::onLoginOkReceived', `server environment: ${fields.serverEnvironment}`);
                this.stop();
                break;
        }
    }

    // With encryption enabled the session response comes from src/attestation.js,
    // which must export prepareLogin(client, challenge) and finish by calling
    // client.sendLogin(challenge, response, source).
    async prepareLogin(challenge) {
        this.state = 'preparing-login';
        if (!this.pepper) {
            const loginConfig = { ...this.config, loginRuntime: { ...this.config.loginRuntime, string178: '' } };
            return this.sendLogin(challenge, Buffer.alloc(0), 'disabled-no-crypto', loginConfig);
        }
        let file;
        try { file = require.resolve('./attestation'); }
        catch (error) {
            if (error.code !== 'MODULE_NOT_FOUND') throw error;
            throw new Error('Attestation module is missing: src/attestation.js (or use --no-crypto)');
        }
        return require(file).prepareLogin(this, challenge);
    }

    sendLogin(challenge, response, source, loginConfig = this.config) {
        if (this.stopping) return;
        if (this.pepper) this.pepper.acceptHello(challenge, response);
        this.status('Messaging::prepareLogin', `session response: ${response.length} bytes (${source})`, 'info', true);
        this.state = 'awaiting-login';
        this.send(TYPES.LOGIN, loginConfig);
    }

    fail(error) {
        if (this.stopping) return;
        this.state = 'failed';
        this.result.exitCode = 1;
        this.result.outcome = 'error';
        this.status('Messaging::onError', `${error.code ? `${error.code}: ` : ''}${error.message}`, 'error');
        this.stop();
    }

    stop() {
        this.stopping = true;
        if (this.socket) this.socket.destroy();
    }

    interrupt() {
        if (this.stopping) return;
        this.result.exitCode = 130;
        this.result.outcome = 'interrupted';
        this.status('Messaging::onInterrupt', 'interrupted by user');
        this.stop();
    }
}

module.exports = { Client };

'use strict';

class BinaryWriter {
    constructor() { this.parts = []; }

    raw(value) { this.parts.push(Buffer.from(value)); return this; }
    byte(value) { return this.raw([value & 0xff]); }
    bool(value) { return this.byte(value ? 1 : 0); }
    int(value) {
        const bytes = Buffer.allocUnsafe(4);
        bytes.writeInt32BE(value);
        return this.raw(bytes);
    }
    uint(value) {
        const bytes = Buffer.allocUnsafe(4);
        bytes.writeUInt32BE(value);
        return this.raw(bytes);
    }
    long(hi, lo) { return this.uint(hi).uint(lo); }
    bytes(value) {
        if (value == null) return this.int(-1);
        const bytes = Buffer.from(value);
        return this.int(bytes.length).raw(bytes);
    }
    string(value) { return this.bytes(value == null ? null : Buffer.from(String(value), 'utf8')); }
    vint(value) {
        if (!Number.isInteger(value) || value < -0x80000000 || value > 0x7fffffff)
            throw new RangeError('VInt must fit a signed 32-bit integer');
        const sign = value < 0 ? 0x40 : 0;
        let next = value >> 6;
        const stop = value < 0 ? -1 : 0;
        this.byte((value & 0x3f) | sign | (next === stop ? 0 : 0x80));
        while (next !== stop) {
            const part = next & 0x7f;
            next >>= 7;
            this.byte(part | (next === stop ? 0 : 0x80));
        }
        return this;
    }
    reference(table, item = 0) {
        this.vint(table);
        if (table !== 0) this.vint(item);
        return this;
    }
    finish() { return Buffer.concat(this.parts); }
}

class BinaryReader {
    constructor(bytes) { this.buffer = Buffer.from(bytes); this.offset = 0; }
    get remaining() { return this.buffer.length - this.offset; }
    raw(size) {
        if (!Number.isInteger(size) || size < 0 || size > this.remaining)
            throw new RangeError(`Truncated payload at ${this.offset}: need ${size}, have ${this.remaining}`);
        const value = this.buffer.subarray(this.offset, this.offset + size);
        this.offset += size;
        return value;
    }
    int() { return this.raw(4).readInt32BE(0); }
    uint() { return this.raw(4).readUInt32BE(0); }
    long() { return [this.uint(), this.uint()]; }
    bytes(limit = 4 * 1024 * 1024) {
        const size = this.int();
        if (size === -1) return null;
        if (size < 0 || size > limit) throw new RangeError(`Invalid byte array length ${size}`);
        return this.raw(size);
    }
    string(limit = 1024 * 1024) {
        const value = this.bytes(limit);
        return value === null ? null : value.toString('utf8');
    }
}

const HEADER_SIZE = 7;
const MAX_PAYLOAD = 4 * 1024 * 1024;

function encodeFrame(id, payload, version = 0) {
    if (payload.length > MAX_PAYLOAD) throw new RangeError('Payload exceeds 4 MiB');
    const frame = Buffer.allocUnsafe(HEADER_SIZE + payload.length);
    frame.writeUInt16BE(id, 0);
    frame.writeUIntBE(payload.length, 2, 3);
    frame.writeUInt16BE(version, 5);
    Buffer.from(payload).copy(frame, HEADER_SIZE);
    return frame;
}

class FrameDecoder {
    constructor() { this.pending = Buffer.alloc(0); }
    push(chunk) {
        this.pending = Buffer.concat([this.pending, chunk]);
        const frames = [];
        let offset = 0;
        while (this.pending.length - offset >= HEADER_SIZE) {
            const size = this.pending.readUIntBE(offset + 2, 3);
            if (size > MAX_PAYLOAD) throw new RangeError(`Invalid frame length ${size}`);
            if (this.pending.length - offset < HEADER_SIZE + size) break;
            const frame = this.pending.subarray(offset, offset + HEADER_SIZE + size);
            frames.push({ id: frame.readUInt16BE(0), version: frame.readUInt16BE(5),
                payload: frame.subarray(HEADER_SIZE) });
            offset += frame.length;
        }
        this.pending = this.pending.subarray(offset);
        return frames;
    }
}

module.exports = { BinaryWriter, BinaryReader, encodeFrame, FrameDecoder };

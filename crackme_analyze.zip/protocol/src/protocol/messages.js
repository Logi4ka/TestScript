'use strict';
const { BinaryWriter, BinaryReader } = require('./protocol');

const TYPES = Object.freeze({ CLIENT_HELLO: 10100, LOGIN: 10101,
    SERVER_HELLO: 20100, LOGIN_FAILED: 20103, LOGIN_OK: 20104 });

const ClientHello = {
    name: 'ClientHelloMessage', messageType: TYPES.CLIENT_HELLO, messageVersion: 0,
    encode(config) {
        const payload = new BinaryWriter().int(config.protocolVersion).int(config.cryptoVersion)
            .int(config.major).int(config.build).int(config.minor).string(config.hash)
            .int(2).int(2).finish();
        return { payload, fields: { protocolVersion: config.protocolVersion,
            cryptoVersion: config.cryptoVersion, major: config.major, minor: config.minor,
            build: config.build, hash: config.hash } };
    },
};

const Login = {
    name: 'LoginMessage', messageType: TYPES.LOGIN, messageVersion: 10,
    encode(config) {
        const version = config.loginMessageVersion;
        if (config.loginPayload) return { payload: Buffer.from(config.loginPayload), version,
            fields: { format: 'supplied plaintext Login payload' } };
        const runtime = config.loginRuntime || {};
        const appVersion = config.appVersion ?? `${config.major}.${config.minor}`;
        const payload = new BinaryWriter()
            .long(config.hi, config.lo).string(config.token)
            .int(config.major).int(1).int(config.minor).string(config.hash)
            .string(config.deviceModel).reference(...(runtime.dataReference || [1, 0]))
            .string(config.locale).string(config.androidVersion).bool(true)
            .string('').string(config.androidId).bool(runtime.flag ?? false)
            .string('').int(runtime.integer ?? 0).vint(2)
            .string(appVersion).string(runtime.string148 ?? '').string(runtime.string158 ?? '')
            .vint(runtime.value168 ?? 0).string(runtime.string178 ?? '').string(runtime.string188 ?? '')
            .string(runtime.string198 ?? '').bytes(config.loginBlob).bool(runtime.flag1a8 ?? false);
        for (let i = 0; i < 6; i++) payload.string(runtime.tailStrings?.[i] ?? '');
        payload.string('').string('');
        return { payload: payload.finish(), version, fields: { accountId: [config.hi, config.lo],
            token: config.token, major: config.major, minor: config.minor, hash: config.hash,
            deviceModel: config.deviceModel, locale: config.locale, androidVersion: config.androidVersion,
            androidId: config.androidId, appVersion } };
    },
};

const ServerHello = {
    name: 'ServerHelloMessage', messageType: TYPES.SERVER_HELLO, messageVersion: 0,
    decode(reader, fields) {
        const token = reader.bytes(4096);
        if (!token?.length) throw new Error('ServerHello has no session token');
        fields.tokenHex = token.toString('hex');
    },
};

const LoginOk = {
    name: 'LoginOkMessage', messageType: TYPES.LOGIN_OK, messageVersion: 1,
    decode(reader, fields) {
        fields.accountId = reader.long();
        fields.homeId = reader.long();
        fields.loginToken = reader.string();
        if (!reader.remaining) return;
        fields.platformIdA = reader.string();
        fields.platformIdB = reader.string();
        fields.serverMajor = reader.int();
        fields.serverMinor = reader.int();
        fields.serverBuild = reader.int();
        fields.serverEnvironment = reader.string();
    },
};

const LoginFailed = {
    name: 'LoginFailedMessage', messageType: TYPES.LOGIN_FAILED, messageVersion: 11,
    decode(reader, fields) {
        fields.errorCode = reader.int();
        for (const name of ['fingerprint', 'redirect', 'assetUrl', 'updateUrl', 'message']) {
            if (reader.remaining === 0) return;
            fields[name] = reader.string();
        }
    },
};

const MESSAGES = Object.freeze(Object.fromEntries(
    [ClientHello, Login, ServerHello, LoginOk, LoginFailed].map(message => [message.messageType, message])));

function getMessage(id) {
    return MESSAGES[id] || { name: `UnknownMessage(${id})`, messageType: id, messageVersion: 0 };
}

function messageName(id) { return getMessage(id).name; }

function encodeMessage(id, config) {
    const message = getMessage(id);
    if (typeof message.encode !== 'function') throw new Error(`${message.name} has no encoder`);
    const encoded = message.encode(config);
    return { ...encoded, id, version: encoded.version ?? message.messageVersion };
}

function decodeMessage(id, payload) {
    const message = getMessage(id);
    const reader = new BinaryReader(payload);
    const fields = {};
    if (typeof message.decode !== 'function') return { decoded: false };
    try { message.decode(reader, fields); }
    catch (error) { fields.parseError = error.message; }
    return fields;
}

module.exports = { TYPES, messageName, encodeMessage, decodeMessage };

'use strict';

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const DEFAULTS = Object.freeze({
    host: 'game.brawlstarsgame.com', port: 9339, timeoutMs: 15000,
    major: 69, minor: 230, build: 0, protocolVersion: 2, cryptoVersion: 59,
    loginMessageVersion: 10, hash: '',
    spk: '5f4bfa1dc7b58fac0611f34dbaf3847b376f968530f76a9a202849017aa9510a',
    hi: 0, lo: 0, token: null,
    deviceModel: 'Android', androidVersion: '14', androidId: '', locale: 'en-US', appVersion: null,
    loginBlob: null, loginPayload: null, loginRuntime: null,
    sessionResponse: null, sessionResponseProvider: null,
    noCrypto: false, color: 'auto', verbose: false,
    proxy: null, proxyHost: null, proxyPort: null,
});

// [field, file setting, hex setting]
const BINARY_SETTINGS = [
    ['loginBlob', 'loginBlobFile', null],
    ['loginPayload', 'loginFile', 'loginHex'],
    ['sessionResponse', 'sessionResponseFile', 'sessionResponseHex'],
];

function parseConfig(args) {
    let configFile = path.join(ROOT, 'settings.json');
    for (let i = 0; i < args.length; i++) {
        if (args[i] === '--config') {
            if (args[i + 1] === undefined) throw new Error('Missing value for --config');
            configFile = path.resolve(args[++i]);
        }
    }
    const settings = JSON.parse(fs.readFileSync(configFile, 'utf8'));
    if (!settings || typeof settings !== 'object' || Array.isArray(settings))
        throw new Error('Settings must be a JSON object');
    const config = { ...DEFAULTS, ...settings, configFile };
    let positional = 0;
    for (let i = 0; i < args.length; i++) {
        const arg = args[i];
        const value = () => {
            if (++i >= args.length || args[i].startsWith('--')) throw new Error(`Missing value for ${arg}`);
            return args[i];
        };
        switch (arg) {
            case '--config': value(); break;
            case '--host': config.host = value(); break;
            case '--port': config.port = Number(value()); break;
            case '--no-crypto': config.noCrypto = true; break;
            case '--verbose': config.verbose = true; break;
            case '--no-color': config.color = 'never'; break;
            case '--proxy': config.proxy = value(); break;
            default:
                if (arg.startsWith('-')) throw new Error(`Unknown option: ${arg}. Use --help; other options belong in settings.json`);
                if (positional === 0) config.host = arg;
                else if (positional === 1) config.port = Number(arg);
                else throw new Error(`Unexpected argument: ${arg}`);
                positional++;
        }
    }
    if (config.noCrypto) {
        for (const field of ['sessionResponse', 'sessionResponseFile', 'sessionResponseHex', 'sessionResponseProvider'])
            config[field] = null;
    }
    loadBinarySettings(config);
    validate(config);
    return config;
}

function loadBinarySettings(config) {
    const resolve = value => path.resolve(path.dirname(config.configFile), value);
    for (const [field, fileField, hexField] of BINARY_SETTINGS) {
        const file = config[fileField], hex = hexField ? config[hexField] : null;
        if (file != null && hex != null) throw new Error(`Choose ${fileField} or ${hexField}`);
        if (file != null) {
            if (typeof file !== 'string' || !file) throw new Error(`${fileField} must be a path`);
            config[field] = fs.readFileSync(resolve(file));
        } else if (hex != null) {
            if (typeof hex !== 'string' || !/^(?:[\da-f]{2})*$/i.test(hex))
                throw new Error(`${hexField} must contain complete hex bytes`);
            config[field] = Buffer.from(hex, 'hex');
        }
    }
}

function parseProxy(config) {
    if (config.proxy === null) return;
    if (typeof config.proxy !== 'string' || !config.proxy.trim())
        throw new Error('proxy must be a nonempty "host:port" string or null');
    const at = config.proxy.lastIndexOf(':');
    if (at <= 0) throw new Error('proxy must be in the form host:port');
    const proxyHost = config.proxy.slice(0, at), proxyPort = Number(config.proxy.slice(at + 1));
    if (!proxyHost.trim()) throw new Error('proxy host must not be empty');
    if (!Number.isInteger(proxyPort) || proxyPort < 1 || proxyPort > 65535)
        throw new Error('proxy port must be an integer in 1..65535');
    config.proxyHost = proxyHost;
    config.proxyPort = proxyPort;
}

function validate(config) {
    const integer = (name, min, max) => {
        if (!Number.isInteger(config[name]) || config[name] < min || config[name] > max)
            throw new Error(`${name} must be an integer in ${min}..${max}`);
    };
    parseProxy(config);
    integer('port', 1, 65535);
    integer('timeoutMs', 1, 2147483647);
    integer('loginMessageVersion', 0, 0xffff);
    for (const name of ['major', 'minor', 'build', 'protocolVersion', 'cryptoVersion'])
        integer(name, 0, 0x7fffffff);
    for (const name of ['hi', 'lo']) integer(name, 0, 0xffffffff);
    if (typeof config.host !== 'string' || !config.host.trim()) throw new Error('host must be a nonempty string');
    if (typeof config.noCrypto !== 'boolean') throw new Error('noCrypto must be a boolean');
    if (!config.noCrypto && !/^[\da-f]{64}$/i.test(config.spk)) throw new Error('spk must be 32 hex bytes');
    if (typeof config.hash !== 'string') throw new Error('hash must be a string');
    if (!['auto', 'always', 'never'].includes(config.color)) throw new Error('color must be auto, always, or never');
    for (const name of ['deviceModel', 'androidVersion', 'androidId', 'locale'])
        if (typeof config[name] !== 'string') throw new Error(`${name} must be a string`);
    if (config.token !== null && typeof config.token !== 'string') throw new Error('token must be a string or null');
    if (config.appVersion !== null && typeof config.appVersion !== 'string')
        throw new Error('appVersion must be a string or null');
    for (const name of ['loginPayload', 'loginBlob']) {
        if (config[name] !== null && !Buffer.isBuffer(config[name]))
            throw new Error(`${name} must be supplied through its file/hex setting`);
        if (config[name] && (config[name].length === 0 && name === 'loginPayload'
            || config[name].length > 3 * 1024 * 1024)) throw new Error(`${name} has an invalid size`);
    }
    if (config.loginRuntime !== null && (typeof config.loginRuntime !== 'object' || Array.isArray(config.loginRuntime)))
        throw new Error('loginRuntime must be an object');
    if (config.sessionResponse !== null && (!Buffer.isBuffer(config.sessionResponse) || config.sessionResponse.length > 255))
        throw new Error('sessionResponse must be supplied as at most 255 bytes through its file/hex setting');
    if (config.sessionResponseProvider !== null) {
        if (typeof config.sessionResponseProvider !== 'string' || !config.sessionResponseProvider)
            throw new Error('sessionResponseProvider must be a module path or null');
        config.sessionResponseProvider = path.resolve(path.dirname(config.configFile), config.sessionResponseProvider);
        if (config.sessionResponse !== null) throw new Error('Choose a session response file/hex or a provider');
    }
}

function help() {
    return `crackme: minimal server login client

Usage: node index.js [host [port]] [options]

  --host HOST / --port N  Server
  --config FILE           JSON settings (default: settings.json)
  --proxy HOST:PORT       Connect through a SOCKS5 proxy (no-auth only)
  --no-crypto             Disable encryption and attestation
  --verbose               Print packet fields
  --no-color              Disable colors
  --help                  This help

Versions, hash, server key and account (hi, lo, token) live in settings.json.`;
}

module.exports = { parseConfig, help };

'use strict';

class Logger {
    constructor({ color = 'auto', verbose = false, output = process.stdout } = {}) {
        this.output = output;
        this.verbose = verbose;
        this.color = color === 'always' || (color === 'auto' && !('NO_COLOR' in process.env)
            && (Boolean(output.isTTY) || (process.env.FORCE_COLOR && process.env.FORCE_COLOR !== '0')));
    }

    paint(code, text) {
        const value = String(text);
        return this.color ? `\x1b[${code}m${value}\x1b[0m` : value;
    }

    line(text) { this.output.write(`${text}\n`); }

    start() { this.line(this.paint('1;92', 'crackme')); }

    info(scope, message, level = 'info') {
        const code = level === 'error' ? '1;91' : level === 'warn' ? '1;95' : '1;96';
        this.line(`${this.paint(code, `${scope}:`)} ${this.paint('1;37', message)}`);
    }

    packet(direction, name, id, fields) {
        const action = direction === 'TX' ? 'sent' : 'received';
        this.info(direction === 'TX' ? 'Messaging::send' : 'Messaging::nextMessage',
            `${action} ${name} with type ${id}`);
        if (this.verbose && fields) this.info('Messaging::fields', JSON.stringify(fields));
    }
}

module.exports = { Logger };

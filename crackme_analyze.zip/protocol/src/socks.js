'use strict';
const net = require('node:net');

// Minimal SOCKS5 client: no-auth CONNECT only (enough for local proxies
// such as v2ray/xray/clash listening on 127.0.0.1). Runs the handshake
// over an already-connected socket and resolves with any application
// bytes the server included right after the handshake reply (there
// normally are none, but we don't want to drop them if there are).
function socks5Connect(socket, host, port, timeoutMs) {
    return new Promise((resolve, reject) => {
        let buffer = Buffer.alloc(0);
        let step = 0; // 0 = awaiting method selection, 1 = awaiting CONNECT reply

        const timer = setTimeout(() => finish(new Error('SOCKS5 proxy handshake timed out')), timeoutMs);
        const finish = (error, leftover) => {
            clearTimeout(timer);
            socket.removeListener('data', onData);
            socket.removeListener('error', onError);
            if (error) reject(error); else resolve(leftover);
        };
        const onError = error => finish(error);

        const onData = chunk => {
            buffer = Buffer.concat([buffer, chunk]);
            try {
                if (step === 0) {
                    if (buffer.length < 2) return;
                    if (buffer[0] !== 0x05) throw new Error('Not a SOCKS5 proxy (unexpected version byte)');
                    if (buffer[1] !== 0x00) throw new Error('SOCKS5 proxy requires authentication, which is not supported');
                    buffer = buffer.subarray(2);
                    step = 1;
                    socket.write(buildConnectRequest(host, port));
                    if (buffer.length === 0) return;
                }
                if (step === 1) {
                    if (buffer.length < 4) return;
                    const reply = buffer[1];
                    if (reply !== 0x00) throw new Error(`SOCKS5 proxy refused the connection (reply code ${reply})`);
                    const addressType = buffer[3];
                    let addressLength;
                    if (addressType === 0x01) addressLength = 4;
                    else if (addressType === 0x04) addressLength = 16;
                    else if (addressType === 0x03) {
                        if (buffer.length < 5) return;
                        addressLength = 1 + buffer[4];
                    } else throw new Error('Unsupported SOCKS5 address type in reply');
                    const total = 4 + addressLength + 2;
                    if (buffer.length < total) return;
                    finish(null, buffer.subarray(total));
                }
            } catch (error) { finish(error); }
        };

        socket.on('data', onData);
        socket.on('error', onError);
        socket.write(Buffer.from([0x05, 0x01, 0x00])); // version 5, 1 method, no-auth
    });
}

function buildConnectRequest(host, port) {
    let address;
    if (net.isIPv4(host)) {
        address = Buffer.concat([Buffer.from([0x01]), Buffer.from(host.split('.').map(Number))]);
    } else if (net.isIPv6(host)) {
        throw new Error('IPv6 targets are not supported through the proxy');
    } else {
        const name = Buffer.from(host, 'utf8');
        if (name.length > 255) throw new Error('Hostname is too long for SOCKS5');
        address = Buffer.concat([Buffer.from([0x03, name.length]), name]);
    }
    const portBuffer = Buffer.alloc(2);
    portBuffer.writeUInt16BE(port);
    return Buffer.concat([Buffer.from([0x05, 0x01, 0x00]), address, portBuffer]);
}

module.exports = { socks5Connect };
